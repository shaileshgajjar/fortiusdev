-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Aug 09, 2016 at 05:22 AM
-- Server version: 5.6.26-cll-lve
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `complianceview`
--

-- --------------------------------------------------------

--
-- Table structure for table `assessment_reporting_sample_sets`
--

CREATE TABLE IF NOT EXISTS `assessment_reporting_sample_sets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `sample_type` varchar(50) NOT NULL,
  `set_or_subset` varchar(50) NOT NULL,
  `sample_type_desc` text CHARACTER SET utf8,
  `components` text CHARACTER SET utf8,
  `model_component` text CHARACTER SET utf8,
  `total_sampled` text CHARACTER SET utf8,
  `total_population` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=116 ;

-- --------------------------------------------------------

--
-- Table structure for table `assessor`
--

CREATE TABLE IF NOT EXISTS `assessor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL DEFAULT '0',
  `assessor_type` varchar(5) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `assessor_name` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `pci_credential` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `assessor_email` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `assessor_telephone` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Table structure for table `ass_other_service_providers`
--

CREATE TABLE IF NOT EXISTS `ass_other_service_providers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `company_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `shared_data` text CHARACTER SET utf8,
  `purpose_of_sharing` text CHARACTER SET utf8,
  `date_of_aoc` date DEFAULT NULL,
  `pci_dss_version` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Table structure for table `cde_type`
--

CREATE TABLE IF NOT EXISTS `cde_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cde_type` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE IF NOT EXISTS `chats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `sent_from_id` int(11) NOT NULL,
  `sent_from_role` varchar(1) NOT NULL,
  `sent_to_id` int(11) NOT NULL,
  `sent_to_role` varchar(1) NOT NULL,
  `chat_type` enum('0','1','2') NOT NULL COMMENT '0= procedure chat, 1 = personal chat, 2 = group chat(between QA QSA and users)',
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Holds chat rooms created by app users' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `chat_threads`
--

CREATE TABLE IF NOT EXISTS `chat_threads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `chat_text` text NOT NULL,
  `chat_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `procedure_id` int(11) NOT NULL,
  `from_id` int(11) NOT NULL,
  `is_read` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `compensating_control`
--

CREATE TABLE IF NOT EXISTS `compensating_control` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(10) NOT NULL DEFAULT '',
  `constraints` varchar(100) NOT NULL DEFAULT '',
  `objective` varchar(100) NOT NULL DEFAULT '',
  `identified_risk` varchar(100) NOT NULL DEFAULT '',
  `definition` varchar(100) NOT NULL DEFAULT '',
  `validation` varchar(100) NOT NULL DEFAULT '',
  `maintenance` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qa_id` int(11) NOT NULL DEFAULT '0',
  `qsa_id` int(11) NOT NULL DEFAULT '0',
  `merchant_type_id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `company_address` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zipcode` varchar(6) DEFAULT NULL,
  `company_url` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `contact_name` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `telephone` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `email` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `compliance_due_date` date NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `assr_company_name` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `assr_company_address` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `assr_company_url` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `secure_key` varchar(50) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `company_logo` varchar(250) NOT NULL,
  `assessment_stage` varchar(100) NOT NULL DEFAULT 'open',
  `assessment_name` varchar(100) NOT NULL,
  `roc_site` varchar(100) NOT NULL,
  `assr_city` varchar(50) NOT NULL,
  `assr_state` varchar(50) NOT NULL,
  `assr_country` varchar(100) NOT NULL,
  `assr_zip` varchar(6) NOT NULL,
  `assessment_version` enum('v30_','v31_','v32_') NOT NULL DEFAULT 'v32_',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `customer_assessor`
--

CREATE TABLE IF NOT EXISTS `customer_assessor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `assessor_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=186 ;

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE IF NOT EXISTS `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `procedure_id` int(11) NOT NULL DEFAULT '0',
  `roc_saq` varchar(3) NOT NULL DEFAULT '',
  `response` text CHARACTER SET latin1 NOT NULL,
  `inplace` varchar(2) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `constraints` text CHARACTER SET latin1 NOT NULL,
  `objective` text CHARACTER SET latin1 NOT NULL,
  `risk` text CHARACTER SET latin1 NOT NULL,
  `dcontrols` text CHARACTER SET latin1 NOT NULL,
  `vcontrols` text CHARACTER SET latin1 NOT NULL,
  `maintenance` text CHARACTER SET latin1 NOT NULL,
  `locked` varchar(1) NOT NULL DEFAULT '0',
  `completion_date` date NOT NULL,
  `updated_on` date NOT NULL,
  `reason_of_failure` text,
  `updated_by` varchar(1) DEFAULT NULL,
  `ready_for` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5434 ;

-- --------------------------------------------------------

--
-- Table structure for table `document_assessor`
--

CREATE TABLE IF NOT EXISTS `document_assessor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `assessor_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1051 ;

-- --------------------------------------------------------

--
-- Table structure for table `document_docsfiles`
--

CREATE TABLE IF NOT EXISTS `document_docsfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  `docfile_id` int(11) NOT NULL,
  `locked` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Media table to show docs in report added dosc at audit time' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `document_filter`
--

CREATE TABLE IF NOT EXISTS `document_filter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL DEFAULT '0',
  `document_id` int(11) NOT NULL DEFAULT '0',
  `filter_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=574 ;

-- --------------------------------------------------------

--
-- Table structure for table `document_interviewer`
--

CREATE TABLE IF NOT EXISTS `document_interviewer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  `interviewer_id` int(11) NOT NULL,
  `locked` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='interviewer data for specific Requirements procedure assiigned to ' AUTO_INCREMENT=24 ;

-- --------------------------------------------------------

--
-- Table structure for table `document_reporting`
--

CREATE TABLE IF NOT EXISTS `document_reporting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `reporting_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `company_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=839 ;

-- --------------------------------------------------------

--
-- Table structure for table `document_samplesets`
--

CREATE TABLE IF NOT EXISTS `document_samplesets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  `set_id` int(11) NOT NULL,
  `locked` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Media table to show docs in report added dosc at audit time' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `document_user_group`
--

CREATE TABLE IF NOT EXISTS `document_user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `user_group_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4048 ;

-- --------------------------------------------------------

--
-- Table structure for table `filter`
--

CREATE TABLE IF NOT EXISTS `filter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `filter_name` varchar(100) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

-- --------------------------------------------------------

--
-- Table structure for table `glossary`
--

CREATE TABLE IF NOT EXISTS `glossary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(10) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `login_history`
--

CREATE TABLE IF NOT EXISTS `login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `userrole` varchar(1) NOT NULL DEFAULT '',
  `last_login` datetime NOT NULL,
  `comments` varchar(255) NOT NULL DEFAULT '',
  `login_from` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6754 ;

-- --------------------------------------------------------

--
-- Table structure for table `merchant`
--

CREATE TABLE IF NOT EXISTS `merchant` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(50) NOT NULL,
  `dba` varchar(50) NOT NULL,
  `contact_name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `isa_name` varchar(50) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `email` varchar(25) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  `business_address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip_code` varchar(10) NOT NULL,
  `company_url` varchar(255) NOT NULL,
  `userrole` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `merchant_type`
--

CREATE TABLE IF NOT EXISTS `merchant_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant_type` varchar(100) NOT NULL,
  `roc_saq` varchar(5) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- Table structure for table `network_diagram`
--

CREATE TABLE IF NOT EXISTS `network_diagram` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `section_id` int(2) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `diagram_path` text NOT NULL,
  `upload_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

-- --------------------------------------------------------

--
-- Table structure for table `network_scope_purpose`
--

CREATE TABLE IF NOT EXISTS `network_scope_purpose` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `network_type` text CHARACTER SET utf8 NOT NULL,
  `network_name` text CHARACTER SET utf8,
  `network_purpose` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

-- --------------------------------------------------------

--
-- Table structure for table `network_segmetation`
--

CREATE TABLE IF NOT EXISTS `network_segmetation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `implemented` text,
  `technologies` text,
  `security_control` text NOT NULL,
  `methods_used` text,
  `verified_functioning` text,
  `mechanism` text,
  `not_used` text,
  `tech_included_pci_dss` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `notification_settings`
--

CREATE TABLE IF NOT EXISTS `notification_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `comp_id` int(11) DEFAULT NULL,
  `userrole` varchar(11) DEFAULT NULL,
  `freq` int(1) DEFAULT NULL,
  `day` varchar(11) DEFAULT NULL,
  `content` varchar(55) DEFAULT NULL,
  `alternate_email_id` varchar(100) DEFAULT NULL,
  `time_to_send` time NOT NULL DEFAULT '23:59:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Table structure for table `not_applicable`
--

CREATE TABLE IF NOT EXISTS `not_applicable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(10) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `other_business_entities`
--

CREATE TABLE IF NOT EXISTS `other_business_entities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `entity_name` varchar(250) CHARACTER SET utf8 NOT NULL,
  `part_or_separate` varchar(20) CHARACTER SET utf8 NOT NULL,
  `list_countries` text CHARACTER SET utf8,
  `entity_type` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT 'indoor',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

-- --------------------------------------------------------

--
-- Table structure for table `pci_team`
--

CREATE TABLE IF NOT EXISTS `pci_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_name` varchar(50) NOT NULL DEFAULT '',
  `member_email` varchar(100) NOT NULL DEFAULT '',
  `member_phone` varchar(50) NOT NULL DEFAULT '',
  `member_function` varchar(250) NOT NULL DEFAULT '',
  `areas_of_expertise` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `procedure`
--

CREATE TABLE IF NOT EXISTS `procedure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `number` varchar(10) NOT NULL DEFAULT '',
  `title` text NOT NULL,
  `qsa_isa` text NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `guidance` text NOT NULL,
  `usercan` varchar(1) NOT NULL DEFAULT '1',
  `allowdoc` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=399 ;

-- --------------------------------------------------------

--
-- Table structure for table `procedure_comment`
--

CREATE TABLE IF NOT EXISTS `procedure_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `company_id` int(11) NOT NULL DEFAULT '0',
  `procedure_id` int(11) NOT NULL DEFAULT '0',
  `comments` text NOT NULL,
  `comment_date` datetime NOT NULL,
  `commented_by` varchar(11) DEFAULT NULL,
  `commented_to` varchar(11) DEFAULT NULL,
  `comment_type` int(1) NOT NULL DEFAULT '0',
  `to_user_id` int(11) NOT NULL,
  `failed_control` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `procedure_document`
--

CREATE TABLE IF NOT EXISTS `procedure_document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL DEFAULT '0',
  `procedure_id` int(11) NOT NULL DEFAULT '0',
  `document` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `upload_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `procedure_merchant`
--

CREATE TABLE IF NOT EXISTS `procedure_merchant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL DEFAULT '0',
  `procedure_id` int(11) NOT NULL DEFAULT '0',
  `roc_saq` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4126 ;

-- --------------------------------------------------------

--
-- Table structure for table `reporting`
--

CREATE TABLE IF NOT EXISTS `reporting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `procedure_id` int(11) NOT NULL DEFAULT '0',
  `number` varchar(10) NOT NULL DEFAULT '',
  `title` text NOT NULL,
  `bulet` varchar(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1001 ;

-- --------------------------------------------------------

--
-- Table structure for table `requirements`
--

CREATE TABLE IF NOT EXISTS `requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(10) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `title` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `description` text CHARACTER SET latin1 NOT NULL,
  `major_observation` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_disclosure_summary`
--

CREATE TABLE IF NOT EXISTS `reviewed_disclosure_summary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `section` varchar(50) CHARACTER SET utf8 NOT NULL,
  `tested_procedure` text CHARACTER SET utf8,
  `summary` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_env_chd_flow`
--

CREATE TABLE IF NOT EXISTS `reviewed_env_chd_flow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `event_type` varchar(10) NOT NULL DEFAULT '',
  `event_name` varchar(200) NOT NULL,
  `types_chd` text CHARACTER SET utf8,
  `how_chd_transmitted` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_env_chd_storage`
--

CREATE TABLE IF NOT EXISTS `reviewed_env_chd_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `data_store` text CHARACTER SET utf8,
  `data_file` text NOT NULL,
  `data_elements_stored` text CHARACTER SET utf8,
  `data_security` text CHARACTER SET utf8,
  `access_to_data` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_env_docs`
--

CREATE TABLE IF NOT EXISTS `reviewed_env_docs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `doc_name` text CHARACTER SET utf8,
  `doc_purpose` text CHARACTER SET utf8,
  `doc_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_env_hardware_detail`
--

CREATE TABLE IF NOT EXISTS `reviewed_env_hardware_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type_of_device` text CHARACTER SET utf8,
  `vendor` text CHARACTER SET utf8,
  `vendor_role` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_env_individ_interviewed`
--

CREATE TABLE IF NOT EXISTS `reviewed_env_individ_interviewed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `emp_name` varchar(200) CHARACTER SET ucs2 DEFAULT NULL,
  `emp_role` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `organization` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `emp_isa` enum('yes','no') CHARACTER SET utf8 NOT NULL,
  `expertise_summary` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_env_sampling`
--

CREATE TABLE IF NOT EXISTS `reviewed_env_sampling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `sampling_1` text CHARACTER SET utf8,
  `sampling_2` text CHARACTER SET utf8,
  `sampling_3` text CHARACTER SET utf8,
  `sampling_4` text CHARACTER SET utf8,
  `sampling_5` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_env_software_details`
--

CREATE TABLE IF NOT EXISTS `reviewed_env_software_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` text CHARACTER SET utf8,
  `version` text CHARACTER SET utf8,
  `role` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_managed_services`
--

CREATE TABLE IF NOT EXISTS `reviewed_managed_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `assess_yes_no` enum('yes','no') CHARACTER SET utf8 NOT NULL,
  `detail_1` text CHARACTER SET utf8,
  `detail_2` text CHARACTER SET utf8,
  `detail_3` text CHARACTER SET utf8,
  `detail_4` text CHARACTER SET utf8,
  `detail_5` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_qrtly_init_freq`
--

CREATE TABLE IF NOT EXISTS `reviewed_qrtly_init_freq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `entity_type` enum('init','other') NOT NULL,
  `scan_dt` date NOT NULL,
  `yes_no` enum('yes','no','pass','fail') CHARACTER SET utf8 NOT NULL,
  `re_scan_dt` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_qrtly_results_all_other`
--

CREATE TABLE IF NOT EXISTS `reviewed_qrtly_results_all_other` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `yes_no` enum('yes','no') CHARACTER SET utf8 NOT NULL,
  `assessor_comment` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `reviewed_qrtly_results_init`
--

CREATE TABLE IF NOT EXISTS `reviewed_qrtly_results_init` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `yes_no` enum('yes','no') CHARACTER SET utf8 NOT NULL,
  `no_of_scan` int(3) NOT NULL,
  `assessor` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `document` text CHARACTER SET utf8,
  `how_verified` text CHARACTER SET utf8,
  `assessor_comments` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Table structure for table `saq_procedure`
--

CREATE TABLE IF NOT EXISTS `saq_procedure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `number` varchar(10) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `title` text CHARACTER SET latin1 NOT NULL,
  `qsa_isa` text CHARACTER SET latin1 NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `guidance` text NOT NULL,
  `usercan` varchar(1) NOT NULL DEFAULT '1',
  `allowdoc` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=396 ;

-- --------------------------------------------------------

--
-- Table structure for table `saq_requirements`
--

CREATE TABLE IF NOT EXISTS `saq_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(10) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `title` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `description` text CHARACTER SET latin1 NOT NULL,
  `major_observation` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `saq_sub_requirements`
--

CREATE TABLE IF NOT EXISTS `saq_sub_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `ref` varchar(10) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `title` text CHARACTER SET latin1 NOT NULL,
  `guidance` text CHARACTER SET latin1 NOT NULL,
  `critical_security` varchar(30) CHARACTER SET latin1 NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=244 ;

-- --------------------------------------------------------

--
-- Table structure for table `saq_wizards_pages`
--

CREATE TABLE IF NOT EXISTS `saq_wizards_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_no` varchar(10) NOT NULL,
  `section_title` text NOT NULL,
  `page` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `scope_cde`
--

CREATE TABLE IF NOT EXISTS `scope_cde` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cde_main` varchar(10) NOT NULL DEFAULT '',
  `ip_address` varchar(50) NOT NULL DEFAULT '',
  `cde_name` varchar(50) NOT NULL DEFAULT '',
  `member_function` varchar(250) NOT NULL DEFAULT '',
  `areas_of_expertise` varchar(250) NOT NULL DEFAULT '',
  `cde_type_id` int(11) NOT NULL DEFAULT '0',
  `purpose` varchar(250) NOT NULL DEFAULT '',
  `owner_id` int(11) NOT NULL DEFAULT '0',
  `system_admin_id` int(11) NOT NULL DEFAULT '0',
  `criticality` varchar(10) NOT NULL DEFAULT '',
  `patch_level` varchar(50) NOT NULL DEFAULT '',
  `last_scan_date` date NOT NULL,
  `scan_report` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assr_company_name` varchar(100) NOT NULL DEFAULT '',
  `assr_company_address` varchar(100) NOT NULL DEFAULT '',
  `assr_company_url` varchar(100) NOT NULL DEFAULT '',
  `failed_task_due_date` int(2) NOT NULL,
  `over_due_reminder` int(2) NOT NULL,
  `upcoming_reminder` int(2) NOT NULL,
  `email_from` varchar(250) NOT NULL,
  `sparkpost_key` text NOT NULL,
  `sparkpost_end_url` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `sow_connected_entiities`
--

CREATE TABLE IF NOT EXISTS `sow_connected_entiities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `connected_entity` text CHARACTER SET utf8 NOT NULL,
  `discussion_qsa_entity` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

-- --------------------------------------------------------

--
-- Table structure for table `sub_requirements`
--

CREATE TABLE IF NOT EXISTS `sub_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `ref` varchar(10) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `title` text CHARACTER SET latin1 NOT NULL,
  `guidance` text CHARACTER SET latin1 NOT NULL,
  `critical_security` varchar(30) CHARACTER SET latin1 NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=244 ;

-- --------------------------------------------------------

--
-- Table structure for table `technical_document`
--

CREATE TABLE IF NOT EXISTS `technical_document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_type` varchar(15) NOT NULL DEFAULT '',
  `ref` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(50) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `pci_dss_req` varchar(50) NOT NULL DEFAULT '',
  `version` varchar(50) NOT NULL DEFAULT '',
  `owner` varchar(50) NOT NULL DEFAULT '',
  `approved_by` varchar(50) NOT NULL DEFAULT '',
  `published_draft` varchar(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `third_party_payment_apps`
--

CREATE TABLE IF NOT EXISTS `third_party_payment_apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `app_name` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `version_of_product` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `pa_dss_validated` enum('yes','no') CHARACTER SET utf8 NOT NULL,
  `p2pe_validated` enum('yes','no') CHARACTER SET utf8 NOT NULL,
  `pci_ssc_ref_no` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `exp_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

-- --------------------------------------------------------

--
-- Table structure for table `third_party_payment_details`
--

CREATE TABLE IF NOT EXISTS `third_party_payment_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `implementation_guide` text CHARACTER SET utf8,
  `manual` text CHARACTER SET utf8,
  `scope_exclusion` text CHARACTER SET utf8,
  `additional_comments` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_group_id` int(11) NOT NULL DEFAULT '0',
  `company_id` int(11) NOT NULL DEFAULT '0',
  `assessor_id` int(11) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `pwd` varchar(64) NOT NULL DEFAULT '',
  `userrole` varchar(1) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) DEFAULT NULL,
  `title` varchar(10) DEFAULT NULL,
  `company_name` varchar(100) NOT NULL DEFAULT '',
  `mobile` varchar(50) NOT NULL DEFAULT '',
  `office_location` varchar(100) DEFAULT NULL,
  `pci_credential` varchar(20) NOT NULL DEFAULT '',
  `api` varchar(255) DEFAULT NULL,
  `users_avtar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=67 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_group`
--

CREATE TABLE IF NOT EXISTS `user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL DEFAULT '0',
  `user_group_name` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Table structure for table `v30_procedure`
--

CREATE TABLE IF NOT EXISTS `v30_procedure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `number` varchar(10) NOT NULL DEFAULT '',
  `title` text NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `guidance` text NOT NULL,
  `usercan` varchar(1) NOT NULL DEFAULT '1',
  `allowdoc` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=397 ;

-- --------------------------------------------------------

--
-- Table structure for table `v30_reporting`
--

CREATE TABLE IF NOT EXISTS `v30_reporting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `procedure_id` int(11) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `bulet` varchar(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1019 ;

-- --------------------------------------------------------

--
-- Table structure for table `v30_requirements`
--

CREATE TABLE IF NOT EXISTS `v30_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `major_observation` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `v30_sub_requirements`
--

CREATE TABLE IF NOT EXISTS `v30_sub_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `info` text NOT NULL,
  `srnote` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=236 ;

-- --------------------------------------------------------

--
-- Table structure for table `v31_audit_wizard`
--

CREATE TABLE IF NOT EXISTS `v31_audit_wizard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `date_of_report` date NOT NULL COMMENT 'Contact Information and Report Date',
  `timeframe` text NOT NULL COMMENT 'Contact Information and Report Date',
  `date_spent_onsite` text NOT NULL COMMENT 'Contact Information and Report Date',
  `pci_dss_version` varchar(10) DEFAULT NULL,
  `services_by_qsa` text,
  `nature_of_business` text,
  `eforts_by_qsa` text,
  `desc_of_time_spent` text NOT NULL COMMENT 'Contact Information and Report Date',
  `executive_summary1` text NOT NULL COMMENT 'Describe how and why the entity stores, processes, and/or transmits cardholder data:',
  `executive_summary2` text NOT NULL COMMENT 'What types of payment channels the entity serves, such as card-present and card-not-present:',
  `executive_summary3` text NOT NULL COMMENT 'Any entities that the assessed entitiy connects to for payment transmission or processing, including processor relationship:',
  `executive_other_summary` text NOT NULL,
  `desc_of_sow1` text NOT NULL,
  `desc_of_sow2` text NOT NULL,
  `desc_of_sow3` text NOT NULL,
  `desc_of_sow4` text NOT NULL,
  `desc_of_sow5` text NOT NULL,
  `desc_of_sow6` text NOT NULL,
  `sow_people` text NOT NULL,
  `sow_technologies` text NOT NULL,
  `sow_other_details` text NOT NULL,
  `sow_process` text NOT NULL,
  `sow_location_sites` text NOT NULL,
  `segment_used` enum('yes','no') NOT NULL,
  `sow_wireless_network_yes` text,
  `sow_wireless_network_no` text,
  `connected_ent_other_data` text CHARACTER SET utf8 NOT NULL,
  `inplace_yes_no` enum('yes','no') NOT NULL COMMENT 'Used for Environment Disclosure Summary section',
  `nottested_yes_no` enum('yes','no') NOT NULL COMMENT 'Used for Environment Disclosure Summary section',
  `attested_assessor` text NOT NULL,
  `list_countries` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `v31_procedure`
--

CREATE TABLE IF NOT EXISTS `v31_procedure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `number` varchar(10) NOT NULL DEFAULT '',
  `title` text NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `guidance` text NOT NULL,
  `usercan` varchar(1) NOT NULL DEFAULT '1',
  `allowdoc` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=399 ;

-- --------------------------------------------------------

--
-- Table structure for table `v31_reporting`
--

CREATE TABLE IF NOT EXISTS `v31_reporting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `procedure_id` int(11) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `bulet` varchar(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1026 ;

-- --------------------------------------------------------

--
-- Table structure for table `v31_requirements`
--

CREATE TABLE IF NOT EXISTS `v31_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `major_observation` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `v31_saq_audit_wizard`
--

CREATE TABLE IF NOT EXISTS `v31_saq_audit_wizard` (
  `id` int(10) NOT NULL,
  `company_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `qsa_contact_name` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(25) NOT NULL,
  `business_address` text NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(25) NOT NULL,
  `country` varchar(25) NOT NULL,
  `zip_code` varchar(100) NOT NULL,
  `url` text NOT NULL,
  `retailer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `v31_saq_procedure`
--

CREATE TABLE IF NOT EXISTS `v31_saq_procedure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `number` varchar(10) NOT NULL DEFAULT '',
  `title` text NOT NULL,
  `qsa_isa` text NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `guidance` text NOT NULL,
  `usercan` varchar(1) NOT NULL DEFAULT '1',
  `allowdoc` varchar(1) NOT NULL DEFAULT '1',
  `with_input` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1004 ;

-- --------------------------------------------------------

--
-- Table structure for table `v31_saq_reporting`
--

CREATE TABLE IF NOT EXISTS `v31_saq_reporting` (
  `id` int(11) NOT NULL,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `procedure_id` int(11) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `bulet` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `v31_saq_requirements`
--

CREATE TABLE IF NOT EXISTS `v31_saq_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(100) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `major_observation` text NOT NULL,
  `saq_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=78 ;

-- --------------------------------------------------------

--
-- Table structure for table `v31_saq_sub_requirements`
--

CREATE TABLE IF NOT EXISTS `v31_saq_sub_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `ref` varchar(10) NOT NULL DEFAULT '',
  `title` text NOT NULL,
  `srnote` text,
  `guidance` text NOT NULL,
  `critical_security` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1141 ;

-- --------------------------------------------------------

--
-- Table structure for table `v31_sub_requirements`
--

CREATE TABLE IF NOT EXISTS `v31_sub_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `info` text NOT NULL,
  `srnote` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=236 ;

-- --------------------------------------------------------

--
-- Table structure for table `v32_audit_wizard`
--

CREATE TABLE IF NOT EXISTS `v32_audit_wizard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `date_of_report` date NOT NULL COMMENT 'Contact Information and Report Date',
  `timeframe` text NOT NULL COMMENT 'Contact Information and Report Date',
  `date_spent_onsite` text NOT NULL COMMENT 'Contact Information and Report Date',
  `pci_dss_version` varchar(10) DEFAULT NULL,
  `services_by_qsa` text,
  `nature_of_business` text,
  `eforts_by_qsa` text,
  `desc_of_time_spent` text NOT NULL COMMENT 'Contact Information and Report Date',
  `executive_summary1` text NOT NULL COMMENT 'Describe how and why the entity stores, processes, and/or transmits cardholder data:',
  `executive_summary2` text NOT NULL COMMENT 'What types of payment channels the entity serves, such as card-present and card-not-present:',
  `executive_summary3` text NOT NULL COMMENT 'Any entities that the assessed entitiy connects to for payment transmission or processing, including processor relationship:',
  `desc_of_sow1` text NOT NULL,
  `desc_of_sow2` text NOT NULL,
  `desc_of_sow3` text NOT NULL,
  `desc_of_sow4` text NOT NULL,
  `desc_of_sow5` text NOT NULL,
  `desc_of_sow6` text NOT NULL,
  `sow_people` text NOT NULL,
  `sow_technologies` text NOT NULL,
  `sow_other_details` text NOT NULL,
  `sow_process` text NOT NULL,
  `sow_location_sites` text NOT NULL,
  `segment_used` enum('yes','no') NOT NULL,
  `sow_wireless_network_yes` text,
  `sow_wireless_network_no` text,
  `connected_ent_other_data` text CHARACTER SET utf8 NOT NULL,
  `inplace_yes_no` enum('yes','no') NOT NULL COMMENT 'Used for Environment Disclosure Summary section',
  `nottested_yes_no` enum('yes','no') NOT NULL COMMENT 'Used for Environment Disclosure Summary section',
  `attested_assessor` text NOT NULL,
  `list_countries` text NOT NULL,
  `section1_field1_4_1` text,
  `section1_field1_4_2` text,
  `executive_summary4` text,
  `executive_summary5` text,
  `card_holder_chd` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `v32_audit_wizard_roc_sec_3_5`
--

CREATE TABLE IF NOT EXISTS `v32_audit_wizard_roc_sec_3_5` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL COMMENT 'Company ID',
  `sec_3_5_entities` varchar(250) NOT NULL COMMENT 'Identify All Processing and Transmitting Entities  (i.e. Acquirer/ Bank/ Brands)',
  `sec_3_5_connected` enum('yes','no') NOT NULL DEFAULT 'no' COMMENT 'Directly Connected?',
  `sec_3_5_processing` enum('yes','no') NOT NULL DEFAULT 'no' COMMENT 'Reason(s) for Connection:',
  `sec_3_5_trans` enum('yes','no') NOT NULL DEFAULT 'no',
  `sec_3_5_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `v32_procedure`
--

CREATE TABLE IF NOT EXISTS `v32_procedure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `number` varchar(10) NOT NULL DEFAULT '',
  `title` text NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `guidance` text NOT NULL,
  `usercan` varchar(1) NOT NULL DEFAULT '1',
  `allowdoc` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=442 ;

-- --------------------------------------------------------

--
-- Table structure for table `v32_reporting`
--

CREATE TABLE IF NOT EXISTS `v32_reporting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `procedure_id` int(11) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `bulet` varchar(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1079 ;

-- --------------------------------------------------------

--
-- Table structure for table `v32_requirements`
--

CREATE TABLE IF NOT EXISTS `v32_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `major_observation` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `v32_saq_audit_wizard`
--

CREATE TABLE IF NOT EXISTS `v32_saq_audit_wizard` (
  `id` int(10) NOT NULL,
  `company_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `qsa_contact_name` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(25) NOT NULL,
  `business_address` text NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(25) NOT NULL,
  `country` varchar(25) NOT NULL,
  `zip_code` varchar(100) NOT NULL,
  `url` text NOT NULL,
  `retailer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `v32_saq_procedure`
--

CREATE TABLE IF NOT EXISTS `v32_saq_procedure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `number` varchar(10) NOT NULL DEFAULT '',
  `title` text NOT NULL,
  `qsa_isa` text NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `guidance` text NOT NULL,
  `usercan` varchar(1) NOT NULL DEFAULT '1',
  `allowdoc` varchar(1) NOT NULL DEFAULT '1',
  `with_input` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1004 ;

-- --------------------------------------------------------

--
-- Table structure for table `v32_saq_reporting`
--

CREATE TABLE IF NOT EXISTS `v32_saq_reporting` (
  `id` int(11) NOT NULL,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `sub_requirements_id` int(11) NOT NULL DEFAULT '0',
  `procedure_id` int(11) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `bulet` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `v32_saq_requirements`
--

CREATE TABLE IF NOT EXISTS `v32_saq_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(100) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `major_observation` text NOT NULL,
  `saq_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=78 ;

-- --------------------------------------------------------

--
-- Table structure for table `v32_saq_sub_requirements`
--

CREATE TABLE IF NOT EXISTS `v32_saq_sub_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `ref` varchar(10) NOT NULL DEFAULT '',
  `title` text NOT NULL,
  `srnote` text,
  `guidance` text NOT NULL,
  `critical_security` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1141 ;

-- --------------------------------------------------------

--
-- Table structure for table `v32_sub_requirements`
--

CREATE TABLE IF NOT EXISTS `v32_sub_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirements_id` int(11) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `info` text NOT NULL,
  `srnote` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=249 ;

-- --------------------------------------------------------

--
-- Table structure for table `v32_summary_of_findings`
--

CREATE TABLE IF NOT EXISTS `v32_summary_of_findings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `comp_ncomp_ntcomp_0` varchar(20) NOT NULL,
  `comp_ncomp_ntcomp_1` varchar(20) NOT NULL,
  `comp_ncomp_ntcomp_2` varchar(20) NOT NULL,
  `comp_ncomp_ntcomp_3` varchar(20) NOT NULL,
  `comp_ncomp_ntcomp_4` varchar(20) NOT NULL,
  `comp_ncomp_ntcomp_5` varchar(20) NOT NULL,
  `comp_ncomp_ntcomp_6` varchar(20) NOT NULL,
  `comp_ncomp_ntcomp_7` varchar(20) NOT NULL,
  `comp_ncomp_ntcomp_8` varchar(20) NOT NULL,
  `comp_ncomp_ntcomp_9` varchar(20) NOT NULL,
  `comp_ncomp_ntcomp_10` varchar(20) NOT NULL,
  `comp_ncomp_ntcomp_11` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wireless_tech_in_scope`
--

CREATE TABLE IF NOT EXISTS `wireless_tech_in_scope` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `wireless_tech` text CHARACTER SET utf8 NOT NULL,
  `used_to_store_chd` enum('yes','no') CHARACTER SET utf8 NOT NULL,
  `connected_to_cde` enum('yes','no') CHARACTER SET utf8 NOT NULL,
  `inpact_the_cde` enum('yes','no') CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

-- --------------------------------------------------------

--
-- Table structure for table `wireless_tech_not_in_scope`
--

CREATE TABLE IF NOT EXISTS `wireless_tech_not_in_scope` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `tech_not_in_scope` text CHARACTER SET utf8,
  `how_validated` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

-- --------------------------------------------------------

--
-- Table structure for table `wizards_pages`
--

CREATE TABLE IF NOT EXISTS `wizards_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_no` varchar(10) DEFAULT NULL,
  `section_title` text,
  `page` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
