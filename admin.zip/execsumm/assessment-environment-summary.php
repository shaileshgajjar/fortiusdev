<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '3.2';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['prescript']	= 'assessment-sow-summary.php';
$web['nextscript']	= 'network-segmentation.php';
$web['current_section']	= 'section3';
$web['id']				= $request->get('id', $session->get('cid'));

$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';

$web['audit_wizard_id'] = $session->get('audit_wizard_id');
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->setValue('sow_people', $request->get('sow_people', ''));
	$tbl->setValue('sow_technologies', $request->get('sow_technologies', ''));
	$tbl->setValue('sow_other_details', $request->get('sow_other_details', ''));
	$tbl->setValue('sow_process', $request->get('sow_process', ''));
	$tbl->setValue('sow_location_sites', $request->get('sow_location_sites', ''));
	$tbl->save();		
}

$web['fields'] = array();
$web['fields']['sow_people']['value'] 	= $tbl->getValue('sow_people');
$web['fields']['sow_technologies']['value']	 	= $tbl->getValue('sow_technologies');
$web['fields']['sow_other_details']['value'] 	= $tbl->getValue('sow_other_details');
$web['fields']['sow_process']['value'] 	= $tbl->getValue('sow_process');
$web['fields']['sow_location_sites']['value'] 	= $tbl->getValue('sow_location_sites');

echo $twig->render('assessment-environment-summary.html', array('web' => $web));
