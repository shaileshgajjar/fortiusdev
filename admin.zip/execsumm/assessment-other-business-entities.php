<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '3.6';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-connected-entities.php';
$web['nextscript']	= 'assessment-wireless-summary.php';
$web['current_section']	= 'section3';
$web['id']				= $request->get('id', $session->get('cid'));
$web['audit_wizard_id'] = $session->get('audit_wizard_id');
$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);

if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	//first save data of indoor entities connected 
	$list_countries = $request->get('list_countries', '');
	$tbl->setValue('list_countries', $list_countries);
	$tbl->save();
	
	$tbls = new table('other_business_entities'); 
	$tbls->delete('company_id', $web['id']);

	$vars = array('indoor', 'international');
	foreach($vars as $var)
	{
		$field1 = $request->get($var.'_entity_name', array());
		$field2	= $request->get($var.'_part_or_separate', array());
		$i = 0;
		foreach($field1 as $val )
		{
			$entity_name = $field1[$i];
			$part_or_separate = $field2[$i];
			$tbls->setValue('id', 0);
			$tbls->setValue('company_id', $web['id']);
			$tbls->setValue('entity_type', $var);
			$tbls->setValue('entity_name', $entity_name);
			$tbls->setValue('part_or_separate', $part_or_separate[0]);
			$tbls->save();
			$i++;	
		}			
	}
	unset($tbls);
}
$web['fields'] = array();
$web['fields']['list_countries']['value'] = $tbl->getValue('list_countries');
unset($tbl);

$tbl = new table('other_business_entities');
$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl->getList();
foreach($rows as $rw )
	$web['fields'][$rw['entity_type']][] = array('entity_name' => $rw['entity_name'], 'part_or_separate' => $rw['part_or_separate'], 'list_countries' => $rw['list_countries']);
if ( !isset($web['fields']['indoor']) )
	$web['fields']['indoor'][] = array('entity_name' => '', 'part_or_separate' => '', 'list_countries' => '');
if ( !isset($web['fields']['international']) )
	$web['fields']['international'][] = array('entity_name' => '', 'part_or_separate' => '', 'list_countries' => '');

echo $twig->render('assessment-other-business-entities.html', array('web' => $web));
