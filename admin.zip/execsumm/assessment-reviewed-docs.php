<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '4.10';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-third-party-payment-apps.php';
$web['nextscript']	= 'assessment-reviewed-managed-service-providers.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section4';
$web['id']			= $request->get('id', $session->get('cid'));
$web['section_id']		= $request->get('section_id',1);
$web['audit_wizard_id']	= $session->get('audit_wizard_id');
$web['task']			= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl1 = new table('reviewed_env_docs');
$tbl2 = new table('reviewed_env_individ_interviewed');
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$doc_name 		= $request->get('doc_name', array());
	$doc_purpose 	= $request->get('doc_purpose', array());
	$doc_date 		= $request->get('doc_date', array());
	$tbl1->delete('company_id', $web['id']);
	for($i=0; $i<count($doc_name); $i++ )
	{
		$tbl1->setValue('id', 0);
		$tbl1->setValue('company_id', $web['id']);
		$tbl1->setValue('doc_name', $doc_name[$i]);
		$tbl1->setValue('doc_purpose', $doc_purpose[$i]);
		$ary = explode('-', $doc_date[$i]);
		$tbl1->setValue('doc_date', $ary[2].'-'.$ary[0].'-'.$ary[1]);
		$tbl1->save();
	}

	$emp_name 			= $request->get('emp_name', array());
	$emp_role 			= $request->get('emp_role', array());
	$organization 		= $request->get('organization', array());
	$emp_isa 			= $request->get('emp_isa', array());
	$expertise_summary 	= $request->get('expertise_summary', array());
	$tbl2->delete('company_id', $web['id']);
	for($i=0; $i<count($emp_name); $i++ )
	{
		$tbl2->setValue('id', 0);
		$tbl2->setValue('company_id', $web['id']);
		$tbl2->setValue('emp_name', $emp_name[$i]);
		$tbl2->setValue('emp_role', $emp_role[$i]);
		$tbl2->setValue('organization', $organization[$i]);
		$tbl2->setValue('emp_isa', $emp_isa[$i]);
		$tbl2->setValue('expertise_summary', $expertise_summary[$i]);
		$tbl2->save();
	}
}

$web['current_date'] = date('m-d-Y');
$tbl1->cols('t1.*');
$tbl1->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl1->getList();
$web['docs'] = array();
$no = 0;
foreach($rows as $rw)
{
	$web['docs'][] = $rw;
	$web['docs'][$no]['doc_date'] = $lib->format_date($rw['doc_date'], 'm-d-Y');
	$no++;
}

$tbl2->cols('t1.*');
$tbl2->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl2->getList();
$web['individ'] = array();
foreach($rows as $rw)
	$web['individ'][] = $rw;	

if ( count($web['docs']) == 0 )
	$web['docs'][] = array('doc_name' => '', 'doc_purpose' => '', 'doc_date' => $web['current_date']);
if ( count($web['individ']) == 0 )
	$web['individ'][] = array('emp_name' => '', 'emp_role' => '', 'organization' => '', 'emp_isa' => 'no', 'expertise_summary' => '');

echo $twig->render('assessment-reviewed-docs.html', array('web' => $web));
