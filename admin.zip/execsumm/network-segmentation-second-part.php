<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '3.4';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'network-segmentation.php';
$web['nextscript']	= 'assessment-connected-entities.php';
$web['current_section']	= 'section3';
$web['id']				= $request->get('id', $session->get('cid'));

$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['audit_wizard_id'] = $session->get('audit_wizard_id');
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl = new table('network_scope_purpose'); 
	$tbl->delete('company_id', $web['id']);
	
	$vars = array('store_chd', 'not_store_chd', 'out_of_scope');
	foreach($vars as $var)
	{
		$store_chd 			= $request->get($var, array());
		$store_chd_purpose 	= $request->get($var.'_purpose', array());
		$i = 0;
		foreach($store_chd as $val )
		{
			$name = $store_chd[$i];
			$purpose = $store_chd_purpose[$i];
			$tbl->setValue('id', 0);
			$tbl->setValue('company_id', $web['id']);
			$tbl->setValue('network_type', $var);
			$tbl->setValue('network_name', $name);
			$tbl->setValue('network_purpose', $purpose);
			$tbl->save();
			$i++;	
		}			
	}
}

$web['fields'] = array();
$tbl = new table('network_scope_purpose');
$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl->getList();
foreach($rows as $rw )
	$web['fields'][$rw['network_type']][] = array('network_name' => $rw['network_name'], 'purpose' => $rw['network_purpose']);
	//$web['fields'][$rw['network_type']][$rw['network_name']] = $rw['network_purpose'];
if ( !isset($web['fields']['store_chd']) )
	$web['fields']['store_chd'][] = array('network_name' => '', 'purpose' => '');
if ( !isset($web['fields']['not_store_chd']) )
	$web['fields']['not_store_chd'][] = array('network_name' => '', 'purpose' => '');
if ( !isset($web['fields']['out_of_scope']) )
	$web['fields']['out_of_scope'][] = array('network_name' => '', 'purpose' => '');

echo $twig->render('network-segmentation-second-part.html', array('web' => $web));
?>