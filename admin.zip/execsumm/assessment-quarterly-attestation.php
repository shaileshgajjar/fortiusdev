<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '5.3';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['prescript']	= 'assessment-quarterly-res-other-entity.php';
$web['listscript']	= '/admin/customers.php';
$web['nextscript']	= '/admin/customers.php';
if ( $session->get('userrole') == 's' )
{
	$web['listscript']	= '/dashboard.php';
	$web['nextscript']	= '/dashboard.php';
}
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section5';
$web['id']				= $request->get('id', $session->get('cid'));

$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'title');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'rowid');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->setValue('attested_assessor', $request->get('attested_assessor', ''));
	$tbl->save();		
}

$web['fields'] = array();
$web['fields']['attested_assessor']['value'] 	= $tbl->getValue('attested_assessor');

echo $twig->render('assessment-quarterly-attestation.html', array('web' => $web));
