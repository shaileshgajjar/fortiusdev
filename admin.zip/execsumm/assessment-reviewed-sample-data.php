<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '4.7';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-reviewed-env-sampling-data.php';
$web['nextscript']	= 'assessment-service-providers-data.php';
$web['current_section']	= 'section4';
$web['id']			= $request->get('id', $session->get('cid'));

$web['task']			= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
$web['audit_wizard_id'] 	= $session->get('audit_wizard_id');
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$tbl = new table('assessment_reporting_sample_sets');

if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$sample_type 		= $request->get('sample_type', array());
	$set_or_subset 		= $request->get('set_or_subset', array());
	$sample_type_desc	= $request->get('sample_type_desc', array());
	$components			= $request->get('components', array());
	$total_sampled		= $request->get('total_sampled', array());
	$total_population	= $request->get('total_population', array());

	$tbl->delete('company_id', $web['id']);
	foreach($sample_type as $key => $val )
	{
		for($i=0; $i<count($components[$val]); $i++)
		{
			$tbl->setValue('id', 0);
			$tbl->setValue('company_id', $web['id']);
			$tbl->setValue('sample_type', $val);
			$tbl->setValue('set_or_subset', $set_or_subset[$val][$i]);
			$tbl->setValue('sample_type_desc', $sample_type_desc[$val][$i]);
			$tbl->setValue('components', $components[$val][$i]);
			$tbl->setValue('total_sampled', $total_sampled[$val][$i]);
			$tbl->setValue('total_population', $total_population[$val][$i]);
			$tbl->save();
		}
	}
}

$web['fields'] = array();
$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$tbl->condition('AND', 't1.set_or_subset', 'parent');
$rows = $tbl->getList();
unset($tbl);
$no = 0;
foreach($rows as $rw )
{
	$web['fields'][$no] = $rw;
	$tbl = new table('assessment_reporting_sample_sets');
	$tbl->condition('WHERE', 't1.company_id', $web['id']);
	$tbl->condition('AND', 't1.set_or_subset', $rw['sample_type']);
	$rows2 = $tbl->getList();
	foreach($rows2 as $rw2 )
		$web['fields'][$no][$rw['sample_type']][] = $rw2;
	$no++;
}

if ( count($web['fields']) == 0 )
{
	$web['fields'][0] = array('sample_type' => 'smpl0', 'set_or_subset' => 'parent', 'sample_type_desc' => '', 'components' => '', 'total_sampled' => '', 'total_population' => '');
	$web['fields'][0]['smpl0'][] = array('sample_type' => 'smpl0', 'set_or_subset' => 'smpl0', 'sample_type_desc' => '', 'components' => '', 'total_sampled' => '', 'total_population' => '');
}

echo $twig->render('assessment-reviewed-sample-data.html', array('web' => $web));
