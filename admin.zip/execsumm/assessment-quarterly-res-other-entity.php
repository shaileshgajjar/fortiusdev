<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '5.2';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= 'reviewed_qrtly_results_all_other';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-quarterly-result-initial.php';
$web['nextscript']	= 'assessment-quarterly-attestation.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section5';
$web['id']			= $request->get('id', $session->get('cid'));
$web['section_id']		= $request->get('section_id',1);
$web['audit_wizard_id']	= $session->get('audit_wizard_id');
$web['task']			= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl1 = new table('reviewed_qrtly_results_all_other');
$tbl1->find('company_id', $web['id']);
$tbl2 = new table('reviewed_qrtly_init_freq');
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$init_yes_no		= $request->get('init_yes_no', '');
	$assessor_comment	= $request->get('assessor_comment', '');
	if($init_yes_no == 'no' )
		$assessor_comment 	= '';

	$tbl1->setValue('id', 0);
	$tbl1->setValue('company_id', $web['id']);
	$tbl1->setValue('yes_no', $init_yes_no);
	$tbl1->setValue('assessor_comment', $assessor_comment);
	$tbl1->save();

	$scan_dt 		= $request->get('scan_dt', array());
	$yes_no 		= $request->get('yes_no', array());
	$re_scan_dt 	= $request->get('re_scan_dt', array());
	$tbl2->delete(array('company_id', 'entity_type'), array($web['id'], 'other'));
	for( $i=0; $i<count($scan_dt); $i++ )
	{
		$tbl2->setValue('id', 0);
		$tbl2->setValue('company_id', $web['id']);
		$tbl2->setValue('entity_type', 'other');
		$tbl2->setValue('scan_dt', $scan_dt[$i]);
		$tbl2->setValue('yes_no', $yes_no[$i]);
		$tbl2->setValue('re_scan_dt', $re_scan_dt[$i]);
		$tbl2->save();
	}
}

$web['current_date'] = date('m-d-Y');
$web['fields'] = array();
$web['fields']['yes_no']['value'] 			= $tbl1->getValue('yes_no');
$web['fields']['assessor_comment']['value'] = $tbl1->getValue('assessor_comment');

$tbl2->cols('t1.*');
$tbl2->condition('WHERE', 't1.company_id', $web['id']);
$tbl2->condition('AND', 't1.entity_type', 'other');
$rows = $tbl2->getList();
$web['fields']['intit_data'] = array();
$no = 0;
foreach($rows as $rw)
{
	$web['fields']['intit_data'][$no] = $rw;
	$web['fields']['intit_data'][$no]['scan_dt'] = $lib->format_date($rw['scan_dt'], 'm-d-Y');
	$web['fields']['intit_data'][$no]['re_scan_dt'] = $lib->format_date($rw['re_scan_dt'], 'm-d-Y');
	$no++;
}
if ( count($web['fields']['intit_data']) == 0 )
	$web['fields']['intit_data'][] = array('scan_dt' => $web['current_date'], 'yes_no' => 'no', 're_scan_dt' => $web['current_date']);

echo $twig->render('assessment-quarterly-res-other-entity.html', array('web' => $web));
