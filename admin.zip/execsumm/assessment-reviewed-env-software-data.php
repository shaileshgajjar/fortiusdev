<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '4.5';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-reviewed-env-second-part.php';
$web['nextscript']	= 'assessment-reviewed-env-sampling-data.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section4';
$web['id']			= $request->get('id', $session->get('cid'));
$web['section_id']		= $request->get('section_id',1);

$web['task']			= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
$web['audit_wizard_id'] 	= $session->get('audit_wizard_id');
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table('reviewed_env_software_details');
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->delete('company_id', $web['id']);
	
	$name 		= $request->get('name', array());
	$version 	= $request->get('version', array());
	$role 		= $request->get('role', array());
	
	$i = 0;
	foreach($name as $val )
	{
		$tbl->setValue('id', 0);
		$tbl->setValue('company_id', $web['id']);
		$tbl->setValue('name', $name[$i]);
		$tbl->setValue('version', $version[$i]);
		$tbl->setValue('role', $role[$i]);
		$tbl->save();
		$i++;	
	}
}

$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl->getList();
$web['env_software'] = array();
foreach($rows as $rw)
	$web['env_software'][] = $rw;
unset($tbl);
if ( count($web['env_software']) == 0 )
	$web['env_software'][] = array('name' => '', 'version' => '', 'role' => '');
	
echo $twig->render('assessment-reviewed-env-software-data.html', array('web' => $web));
