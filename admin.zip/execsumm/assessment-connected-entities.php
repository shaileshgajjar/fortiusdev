<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '3.5';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'network-segmentation-second-part.php';
$web['nextscript']	= 'assessment-other-business-entities.php';
$web['current_section']	= 'section3';
$web['id']			= $request->get('id', $session->get('cid'));

$web['audit_wizard_id'] = $session->get('audit_wizard_id');

$web['task']		= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']		= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']		.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';

$audit_wizard = new table($web['table']);

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);

if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->setValue('connected_ent_other_data', $request->get('connected_ent_other_data',''));
	$tbl->save();
	$connected_entity 		= $request->get('connected_entity', array());
	$discussion_qsa_entity 	= $request->get('discussion_qsa_entity', array());
	
	$tbls = new table('sow_connected_entiities');
	$tbls->delete('company_id', $web['id']);
	$i = 0;
	foreach($connected_entity as $val )
	{
		$entity 		= $connected_entity[$i];
		$discussion 	= $discussion_qsa_entity[$i];
		if($entity != '' || $discussion != '')
		{
			$tbls->setValue('id', 0);
			$tbls->setValue('company_id', $web['id']);
			$tbls->setValue('connected_entity', $entity);
			$tbls->setValue('discussion_qsa_entity', $discussion);
			$tbls->save();
		}
		$i++;	
	}
	unset($tbls);
}

$web['fields'] = array();
$web['fields']['connected_ent_other_data']['value'] 		= $tbl->getValue('connected_ent_other_data');

$tbl = new table('sow_connected_entiities');
$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl->getList();
foreach($rows as $rw )
	$web['fields']['type'][] = $rw;
if ( !isset($web['fields']['type']) )
	$web['fields']['type'][] = array('connected_entity' => '', 'discussion_qsa_entity' => '');

echo $twig->render('assessment-connected-entities.html', array('web' => $web));
