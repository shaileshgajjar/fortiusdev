<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '4.8';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-reviewed-sample-data.php';
$web['nextscript']	= 'assessment-third-party-payment-apps.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section4';
$web['id']			= $request->get('id', $session->get('cid'));
$web['section_id']	= $request->get('section_id',1);

$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
$web['audit_wizard_id']	= $session->get('audit_wizard_id');
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table('ass_other_service_providers');
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$company_name 		= $request->get('company_name', array());
	$shared_data 		= $request->get('shared_data', array());
	$purpose_of_sharing = $request->get('purpose_of_sharing', array());
	$date_of_aoc 		= $request->get('date_of_aoc', array());
	$pci_dss_version 	= $request->get('pci_dss_version', array());

	$tbl->delete('company_id', $web['id']);
	for($i=0; $i<count($company_name); $i++ )
	{
		$tbl->setValue('id', 0);
		$tbl->setValue('company_id', $web['id']);
		$tbl->setValue('company_name', $company_name[$i]);
		$tbl->setValue('shared_data', $shared_data[$i]);
		$tbl->setValue('purpose_of_sharing', $purpose_of_sharing[$i]);
		$ary = explode('-', $date_of_aoc[$i]);
		$tbl->setValue('date_of_aoc', $ary[2].'-'.$ary[0].'-'.$ary[1]);
		$tbl->setValue('pci_dss_version', $pci_dss_version[$i]);
		$tbl->save();
	}
}

$web['current_date'] = date('m-d-Y');
$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl->getList();
$web['fields'] = array();
$no = 0;
foreach($rows as $rw)
{
	$web['fields'][$no] = $rw;
	$ary = explode('-', $rw['date_of_aoc']);
	$web['fields'][$no]['date_of_aoc'] = $ary[1].'-'.$ary[2].'-'.$ary[0];
	$no++;
}
if ( count($web['fields']) == 0 )
	$web['fields'][] = array('company_name' => '', 'shared_data' => '', 'purpose_of_sharing' => '', 'date_of_aoc' => $web['current_date'], 'pci_dss_version' => '');

echo $twig->render('assessment-service-providers-data.html', array('web' => $web));
