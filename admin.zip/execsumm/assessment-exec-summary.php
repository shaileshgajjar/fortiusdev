<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '2.1';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']	= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-timeframe.php';
$web['nextscript']	= 'assessment-sow-summary.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section2';

$web['id']			= $request->get('id', $session->get('cid'));
$web['section_id']	= $request->get('section_id',1);

$web['task']		= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']		= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']		.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$web['audit_wizard_id'] = $session->get('audit_wizard_id');
$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->setValue('nature_of_business', $request->get('nature_of_business', ''));
	$tbl->setValue('executive_summary1', $request->get('executive_summary1', ''));
	$tbl->setValue('executive_summary2', $request->get('executive_summary2', ''));
	$tbl->setValue('executive_summary3', $request->get('executive_summary3', ''));
	$tbl->save();		
}

$web['fields'] = array();
$web['fields']['nature_of_business']['value'] 	= $tbl->getValue('nature_of_business');
$web['fields']['executive_summary1']['value'] 	= $tbl->getValue('executive_summary1');
$web['fields']['executive_summary2']['value']	= $tbl->getValue('executive_summary2');
$web['fields']['executive_summary3']['value'] 	= $tbl->getValue('executive_summary3');

$tbl = new table('network_diagram');
$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$tbl->condition('AND', 't1.section_id', '1');
$rows = $tbl->getList();
$web['wizard_diagrams'] = array();
foreach($rows as $rw)
	$web['wizard_diagrams'][] =  $rw;
unset($tbl);

echo $twig->render('assessment-exec-summary.html', array('web' => $web));
?>
