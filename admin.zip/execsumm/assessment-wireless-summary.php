<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '3.7';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-other-business-entities.php';
$web['nextscript']	= 'assessment-wireless-details.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section3';
$web['id']			= $request->get('id', $session->get('cid'));
$web['section_id']	= $request->get('section_id',1);

$web['task']		= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']		= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']		.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);

if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->setValue('sow_wireless_network_yes', $request->get('sow_wireless_network_yes', ''));
	$tbl->setValue('sow_wireless_network_no', $request->get('sow_wireless_network_no', ''));
	$tbl->save();		
}

$web['fields'] = array();
$web['fields']['sow_wireless_network_yes']['value'] 	= $tbl->getValue('sow_wireless_network_yes');
$web['fields']['sow_wireless_network_no']['value']	 	= $tbl->getValue('sow_wireless_network_no');

echo $twig->render('assessment-wireless-summary.html', array('web' => $web));
