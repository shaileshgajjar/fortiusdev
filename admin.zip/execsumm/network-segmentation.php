<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '3.3';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-environment-summary.php';
$web['nextscript']	= 'network-segmentation-second-part.php';
$web['current_section']	= 'section3';
$web['id']			= $request->get('id', $session->get('cid'));

$web['task']		= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']		= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']		.= ' [ '. $session->get('company_name') .' ]' ;
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
$web['audit_wizard_id'] = $session->get('audit_wizard_id');

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);
$tblseg = new table('network_segmetation');
$tblseg->find('company_id',$web['id']);

if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$segment_used = $request->get('segment_used', 'no');
	$tbl->setValue('segment_used', $segment_used);
	$tbl->save();

	$tblseg->setValue('company_id', $web['id']);
	if($segment_used == 'yes')
	{
		$tblseg->setValue('implemented', $request->get('implemented', ''));
		$tblseg->setValue('technologies', $request->get('technologies', ''));
		$tblseg->setValue('methods_used', $request->get('methods_used', ''));
		$tblseg->setValue('verified_functioning', $request->get('verified_functioning', ''));
		$tblseg->setValue('mechanism', $request->get('mechanism', ''));
	}
	else
	{
		$tblseg->setValue('not_used', $request->get('not_used', ''));
	}
	$tblseg->setValue('tech_included_pci_dss', $request->get('tech_included_pci_dss', ''));
	$tblseg->save(); 	
}

$web['fields'] = array();
$web['fields']['segment_used']['value'] 		= $tbl->getValue('segment_used');
if ( $web['fields']['segment_used']['value'] == '' )
	$web['fields']['segment_used']['value']		= 'no';
$web['fields']['implemented']['value']			= $tblseg->getValue('implemented');
$web['fields']['technologies']['value'] 		= $tblseg->getValue('technologies');
$web['fields']['methods_used']['value'] 		= $tblseg->getValue('methods_used');
$web['fields']['verified_functioning']['value'] = $tblseg->getValue('verified_functioning');
$web['fields']['mechanism']['value'] 			= $tblseg->getValue('mechanism');
$web['fields']['not_used']['value'] 			= $tblseg->getValue('not_used');
$web['fields']['tech_included_pci_dss']['value']= $tblseg->getValue('tech_included_pci_dss');

echo $twig->render('network-segmentation.html', array('web' => $web));

