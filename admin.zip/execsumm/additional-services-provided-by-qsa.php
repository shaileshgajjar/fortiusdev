<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '1.4';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-pci-dss-version.php';
$web['nextscript']	= 'assessment-exec-summary.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section1';

$web['id']				= $request->get('id', $session->get('cid'));
$web['section_id']		= $request->get('section_id',1);
$web['audit_wizard_id']	= $session->get('audit_wizard_id');

$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]' ;

if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->setValue('services_by_qsa', $request->get('services_by_qsa', ''));
	$tbl->setValue('eforts_by_qsa', $request->get('eforts_by_qsa', ''));
	$tbl->save();		
}

$web['fields'] = array();
$web['fields']['services_by_qsa']['value'] 	= $tbl->getValue('services_by_qsa');
$web['fields']['eforts_by_qsa']['value']	= $tbl->getValue('eforts_by_qsa');

echo $twig->render('additional-services-provided-by-qsa.html', array('web' => $web));
?>
