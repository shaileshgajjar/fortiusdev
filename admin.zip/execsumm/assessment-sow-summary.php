<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '3.1';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['prescript']	= 'assessment-exec-summary.php';
$web['nextscript']	= 'assessment-environment-summary.php';
$web['wizardspage']	= 'sow-summary';
$web['current_section']	= 'section3';
$web['id']				= $request->get('id', $session->get('cid'));

$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';

$web['audit_wizard_id'] = $session->get('audit_wizard_id');	

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->setValue('desc_of_sow1', $request->get('desc_of_sow1', ''));
	$tbl->setValue('desc_of_sow2', $request->get('desc_of_sow2', ''));
	$tbl->setValue('desc_of_sow3', $request->get('desc_of_sow3', ''));
	$tbl->setValue('desc_of_sow4', $request->get('desc_of_sow4', ''));
	$tbl->setValue('desc_of_sow5', $request->get('desc_of_sow5', ''));
	$tbl->setValue('desc_of_sow6', $request->get('desc_of_sow6', ''));
	$tbl->save();		
}

$web['fields'] = array();
$web['fields']['desc_of_sow1']['value'] 	= $tbl->getValue('desc_of_sow1');
$web['fields']['desc_of_sow2']['value'] 	= $tbl->getValue('desc_of_sow2');
$web['fields']['desc_of_sow3']['value'] 	= $tbl->getValue('desc_of_sow3');
$web['fields']['desc_of_sow4']['value'] 	= $tbl->getValue('desc_of_sow4');
$web['fields']['desc_of_sow5']['value'] 	= $tbl->getValue('desc_of_sow5');
$web['fields']['desc_of_sow6']['value'] 	= $tbl->getValue('desc_of_sow6');

echo $twig->render('assessment-sow-summary.html', array('web' => $web));
