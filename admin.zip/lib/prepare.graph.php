<?php
function prepareReportGraph($n_settings)
{
	require_once(dirname(__FILE__).'/phpMyGraph5.0.php');
	if($n_settings != '' )
	{
		$complanceArr =  prepareComplianceData($n_settings);
		if( !empty($complanceArr) )
		{
			$graph = new phpMyGraph();
			$graph->parseVerticalColumnGraph($complanceArr['map_axis'], $complanceArr['cfg']);
		}
		
	} 
}
?>