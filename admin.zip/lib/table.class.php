<?php
class table extends coretable
{
	public function setValue($field, $value, $key = '')
	{
		if ( $key == '' )
			$this->data['fields'][$field]['value'] = $value;
		else
		{
			$encryption = new encryption($key);
			$this->data['fields'][$field]['value'] = $encryption->encrypt($value);
		}
	}
	
	public function getValue($field, $key = '')
	{
		if ( $key == '' )
			return $this->data['fields'][$field]['value'];
		else
		{
			$encryption = new encryption($key);
			return $encryption->decrypt($this->data['fields'][$field]['value']);
		}
	}
	
	public function getStructure()
	{
		return $this->data;
	}
}