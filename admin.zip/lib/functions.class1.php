<?php
/*
@name htmlOutput
@usage to  prepare html to for status report
@param (array) $ReceiverDataArr
@returns (array) $htmlOutputArr
*/
error_reporting(E_ALL);
function savedateformat($srcdt, $format)
{
	$return = $srcdt;
	$src = explode('-', $format);
	$ary = explode('-', $srcdt);
	if ( count($ary) > 2 && strlen($ary[0]) < 4 )
	{
		$dt[$src[0]] = $ary[0];
		$dt[$src[1]] = $ary[1];
		$dt[$src[2]] = $ary[2];
		$return = $dt['Y'].'-'.$dt['m'].'-'.$dt['d'];
	}
	return $return;
}

function getfilters($doc_id)
{
	global $session;
	$selected = array();
	$tbl = new table('document_filter');
	$tbl->cols('filter_id');
	$tbl->condition('WHERE', 'document_id', $doc_id);
	$tbl->condition('AND', 'user_id', $session->get('uid'));
	$rows = $tbl->getList();
	foreach($rows as $row)
		$selected[] = $row['filter_id'];
	unset($tbl);

	$tbl = new table('filter');
	$tbl->cols('id');
	$tbl->cols('filter_name');
	$tbl->condition('WHERE', 't1.user_id', $session->get('uid'));
	$str = '';
	$rows = $tbl->getList();
	foreach($rows as $row)
	{
		$str .= '<option value="'.$row['id'].'"';
		if ( in_array($row['id'], $selected) ) $str .= ' selected="selected"';
		$str .= '>'.$row['filter_name'].'</option>';
	}
	unset($tbl);
	return $str;
}

function getdropdown($tblname, $field1, $field2, $fieldvalue = 0, $conditions = array(), $joins = array())
{
	if ( !is_array($fieldvalue) )
		$fieldvalue = array($fieldvalue);
	$fldprint = $field2;
	$ary = explode(' as ', $field2);
	if ( isset($ary[1]) )
		$fldprint = $ary[1];
	
	$tbl = new table($tblname);
	$tbl->cols($field1);
	$tbl->cols($field2);
	
	foreach($conditions as $condition)
	{
		$condition_type = '=';
		if ( isset($condition['condition_type']) )
			$condition_type = $condition['condition_type'];
		$tbl->condition($condition['type'], $condition['field'], $condition['value'], $condition_type);
	}
	foreach($joins as $join)
	{
		$join_type = 'LEFT JOIN';
		if ( isset($join['join_type']) ) $join_type = $join['join_type'];
		$tbl->join($join['table'], $join['field1'], $join['field2'], $join['alias'], $join_type);
	}

	$str = '';
	$rows = $tbl->getList();
	$ary = explode('.', $field1);
	if ( isset($ary[1]) )
		$field1 = $ary[1];
	foreach($rows as $row)
	{
		$str .= '<option value="'.$row[$field1].'"';
		if ( in_array($row[$field1], $fieldvalue) ) $str .= ' selected="selected"';
		//if ( $fieldvalue == $row[$field1] ) $str .= ' selected="selected"';
		$str .= '>'.$row[$fldprint].'</option>';
	}
	unset($tbl);
	return $str;
}

function getUserData()
{
	global $web, $roc_saq, $session;
	if ( !isset($web['inplace_filter']) ) $web['inplace_filter'] = '';
	if ( !isset($web['proc_req_search']) ) $web['proc_req_search'] = '';
	$tbl = new table('document');
	$tbl->cols('t1.*');
	$tbl->cols('p.requirements_id');
	$tbl->cols('p.sub_requirements_id');
	$tbl->cols('p.id AS pid');
	$tbl->cols('p.guidance');
	$tbl->cols('p.usercan');
	$tbl->cols('p.allowdoc');
	$tbl->cols('p.number');
	$tbl->cols('p.title AS ptitle');
	$tbl->cols('p.priority');
	$tbl->cols('t1.id AS doc_id');
	$tbl->cols('sr.title AS srtitle');
	$total_comments = "(SELECT count(id) FROM ".$tbl->getPrefix()."procedure_comment pc WHERE pc.procedure_id = p.id AND pc.company_id = '".$web['company_id']."') as total_comments ";
	$tbl->cols($total_comments);
	$tbl->join($web['version'].$roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p');
	$tbl->join($web['version'].$roc_saq.'sub_requirements', 'sr.id', 't1.sub_requirements_id', 'sr');
	$tbl->condition('WHERE', 'p.requirements_id', $web['requirements_id']);
	$tbl->condition('AND', 't1.company_id',$web['company_id']);
	if ( $web['inplace_filter'] != '' )
		$tbl->condition('AND', 't1.inplace', $web['inplace_filter']);
	if ( $web['proc_req_search'] != '' )
			$tbl->having('p.title', '%'.$web['proc_req_search'].'%', 'LIKE');	
	if ( $session->get('userrole') == 'u' )
	{
		$tbl->cols('dug.user_group_id');
		$tbl->join('document_user_group', 't1.id', 'dug.document_id', 'dug');
		$tbl->condition('AND', 'dug.user_group_id',$session->get('user_group_id'));
	}
	$tbl->orderby('p.requirements_id');
	$tbl->orderby('p.sub_requirements_id');
	$tbl->orderby('p.id');
	$no = 0;
	$rows = $tbl->getList();
	foreach( $rows as $rw)
	{
		$web['rows'][$no] = $rw;
		$web['rows'][$no]['guidance'] = str_replace('"', '&quot;', $web['rows'][$no]['guidance']);
		$web['rows'][$no]['guidance'] = str_replace('not found', '', $web['rows'][$no]['guidance']);
		$tbl_proc_doc = new table('procedure_document');
		$tbl_proc_doc->cols('t1.*');
		$tbl_proc_doc->condition('WHERE', 't1.company_id', $web['company_id']);
		$tbl_proc_doc->condition('AND', 't1.procedure_id', $rw['pid']);
		$rows1 = $tbl_proc_doc->getList();
		$documents = array();
		foreach($rows1 as $rw1)
			$documents[$rw1['id']] = $rw1;
		unset($tbl_proc_doc);
		$web['rows'][$no]['documents'] = $documents;
		$no++;
	}
	unset($tbl);

}
function getAssignTask()
{
	global $web, $roc_saq;
	if ( !isset($web['inplace_filter']) ) $web['inplace_filter'] = '';
	if ( !isset($web['proc_req_search']) ) $web['proc_req_search'] = '';
	$tbl = new table('document');
	$tbl->cols('t1.*');
	$tbl->cols('p.requirements_id');
	$tbl->cols('p.sub_requirements_id');
	$tbl->cols('p.id AS pid');
	$tbl->cols('p.guidance AS Guide');
	$tbl->cols('p.number');
	$tbl->cols('p.title AS ptitle');
	$tbl->cols('p.priority');
	$tbl->cols('p.usercan');
	$tbl->cols('t1.id AS doc_id');
	if ( $web['source'] == 'usergroup' )
		$tbl->cols('dug.id AS dugid');
	if ( $web['source'] == 'assessor' )
		$tbl->cols('da.id AS dugid');
	$total_comments = "(SELECT count(id) FROM ".$tbl->getPrefix()."procedure_comment pc WHERE pc.procedure_id = p.id AND pc.company_id = '".$web['company_id']."') as total_comments ";
	$tbl->cols($total_comments);
	$tbl->join($web['version'].$roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p');
	$tbl->join($web['version'].$roc_saq.'sub_requirements', 'sr.id', 't1.sub_requirements_id', 'sr');
	if ( $web['source'] == 'usergroup' )
		$tbl->join('document_user_group', 'dug.document_id', "t1.id AND dug.user_group_id = '".$web['id']."'", 'dug');
	if ( $web['source'] == 'assessor' )
		$tbl->join('document_assessor', 'da.document_id', "t1.id AND da.assessor_id = '".$web['id']."'", 'da');
	$tbl->condition('WHERE', 'p.requirements_id', $web['requirements_id']);
	$tbl->condition('AND', 't1.user_id', '0');
	$tbl->condition('AND', 't1.company_id',$web['company_id']);
	if ( $web['inplace_filter'] != '' )
		$tbl->condition('AND', 't1.inplace', $web['inplace_filter']);
	if ( $web['proc_req_search'] != '' )
			$tbl->having('p.title', '%'.$web['proc_req_search'].'%', 'LIKE');	
	$tbl->orderby('p.requirements_id');
	$tbl->orderby('p.sub_requirements_id');
	$tbl->orderby('p.id');
	$rows = $tbl->getList();
	unset($tbl);
	$no = 0;
	foreach($rows as $rw)
	{
		$web['rows'][$no] = $rw;
		$no++;
	}
}
function getContentData()
{
	global $web, $roc_saq, $session;
	if ( !isset($web['filter_id']) ) $web['filter_id'] = 0;
	if ( !isset($web['inplace_filter']) ) $web['inplace_filter'] = '';
	if ( !isset($web['proc_req_search']) ) $web['proc_req_search'] = '';
	$tbl = new table('document');
	$tbl->cols('t1.*');
	$tbl->cols('p.requirements_id');
	$tbl->cols('p.sub_requirements_id');
	$tbl->cols('p.id AS pid');
	$tbl->cols('p.guidance');
	$tbl->cols('p.title AS ptitle');
	$tbl->cols('p.number');
	$tbl->cols('p.priority');
	$tbl->cols('t1.id AS doc_id');
	$total_comments = "(SELECT count(id) FROM ".$tbl->getPrefix()."procedure_comment pc WHERE pc.procedure_id = p.id AND pc.company_id = '".$web['company_id']."') as total_comments ";
	$tbl->cols($total_comments);
	$tbl->join($web['version'].$roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p');
	$tbl->join($web['version'].$roc_saq.'sub_requirements', 'sr.id', 't1.sub_requirements_id', 'sr');
	$tbl->condition('WHERE', 'p.requirements_id', $web['requirements_id']);
	$tbl->condition('AND', 't1.company_id',$web['company_id']);
	$tbl->orderby('p.requirements_id');
	if ( $web['inplace_filter'] != '' )
		$tbl->condition('AND', 't1.inplace', $web['inplace_filter']);
		
	if ( $web['proc_req_search'] != '' )
			$tbl->having('p.title', '%'.$web['proc_req_search'].'%', 'LIKE');
	if ( $web['filter_id'] != 0 )
	{
		$tbl->join('document_filter', 'df.document_id', 't1.id', 'df');
		$tbl->condition('AND', 'df.filter_id', $web['filter_id']);
		$tbl->condition('AND', 'df.user_id', $session->get('uid'));
	}
	if ( $session->get('userrole') == 's' )
		$tbl->join('document_assessor', 'da.document_id', "t1.id AND da.assessor_id = '".$session->get('uid')."'", 'da', 'JOIN');
	$rows = $tbl->getList();
	unset($tbl);
	$no = 0;
	foreach($rows as $rw)
	{
		$web['rows'][$no] = $rw;
		$web['rows'][$no]['guidance'] = str_replace('"', '&quot;', $web['rows'][$no]['guidance']);
		$web['rows'][$no]['guidance'] = str_replace('not found', '', $web['rows'][$no]['guidance']);
		$web['rows'][$no]['ccw_completed'] = 'n';
		if ( $web['rows'][$no]['inplace'] == 'C' )
		{
			if ( $rw['constraints'] != '' && $rw['objective'] != '' && $rw['risk'] != '' && $rw['dcontrols'] != '' && $rw['vcontrols'] != '' && $rw['maintenance'] != '' )
				$web['rows'][$no]['ccw_completed'] = 'y';
		}
		if ( $web['rows'][$no]['completion_date'] != '' || $web['rows'][$no]['completion_date'] != '0000-00-00' )
			 $web['rows'][$no]['completion_date'] = $web['rows'][$no]['completion_date'];
		else
			 $web['rows'][$no]['completion_date'] = '';
		$tbl = new table('procedure_document');
		$tbl->cols('t1.*');
		$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
		$tbl->condition('AND', 't1.procedure_id', $rw['pid']);
		$docrows = $tbl->getList();
		
		$documents = array();
		foreach($docrows as $docrw)
		{
			$documents[$docrw['id']] = array();
			$documents[$docrw['id']][] = $docrw['document'];
			$documents[$docrw['id']][] = $docrw['upload_date'];
			$documents[$docrw['id']]['enc_doc'] = base64_encode('q='.$docrw['document'].'&cid='. $web['company_id']);
		}
		unset($tbl);
		$web['rows'][$no]['documents'] = $documents;
		
		$tbl = new table($web['version'].'reporting');
		$tbl->cols('t1.id');
		$tbl->cols('t1.title');
		$tbl->cols('t1.bulet');
		$tbl->cols('dr.reporting_id');
		$tbl->cols('dr.comment AS drc');
		$tbl->join('document_reporting', 'dr.reporting_id' ,'t1.id' ,'dr');
		$tbl->condition('WHERE', 't1.procedure_id', $rw['pid']);
		$web['rows'][$no]['reports'] = array();
		$reprows = $tbl->getList();
		foreach ( $reprows as $reprw )
			$web['rows'][$no]['reports'][$reprw['id']] = $reprw;
		unset($tbl);
		$no++;
	}
}
function writeDocumentReport($action='download')
{
	global $web, $roc_saq, $session;
	include('docxtemplate.class.php');
	$file = __DIR__.'/PCI DSS_v3_1_ROC_Reporting_Template.docx';
	$docx = new DOCXTemplate($file);
	
	//Starts customer details and assessors data
	$tbl = new table('customer');
	$tbl->cols('t1.*');
	$tbl->cols("m.merchant_type, CONCAT(u.first_name, ' ', u.last_name) AS username");
	$tbl->cols('u.mobile');
	$tbl->cols('u.email');
	//$tbl->cols(" IF( pc.company_name !='', pc.company_name, 'Self') AS pcname ");
	$tbl->cols("CONCAT(u_s.first_name, ' ', u_s.last_name) AS qsa");
	$tbl->cols("u_s.email AS qsa_email");
	$tbl->cols("u_s.mobile AS qsa_phone");
	$tbl->cols("u_s.pci_credential AS qsa_credential");
	$tbl->cols("CONCAT(u_q.first_name, ' ', u_q.last_name) AS qa");
	$tbl->cols("u_q.email AS qa_email");
	$tbl->cols("u_q.mobile AS qa_phone");
	$tbl->join('merchant_type', 'm.id', 't1.merchant_type_id', 'm');
	$tbl->join('customer', 'pc.id', 't1.parent_id', 'pc');
	$tbl->join('users', 'u.company_id', 't1.id', 'u');
	$tbl->join('users', 'u_q.id', 't1.qa_id', 'u_q');
	$tbl->join('users', 'u_s.id', 't1.qsa_id', 'u_s');
	$tbl->condition('WHERE', 't1.id', $web['company_id']);
	$rows = $tbl->getList();
	$tbl2 = new table('users');
	$tbl2->cols('t1.*');
	$tbl2->cols("CONCAT(t1.first_name, ' ', t1.last_name) AS contactname");
	$tbl2->condition('WHERE', 't1.company_id', $web['company_id']);
	$tbl2->condition('AND', 't1.userrole', 'c');
	$rows2 = $tbl2->getList();
	
	$docx->set('c.name', $rows[0]['company_name']);
	$docx->set('c.address', $rows[0]['company_address']);
	$docx->set('c.url', $rows[0]['company_url']);
	$docx->set('c.contact', $rows2[0]['contactname']);
	$docx->set('c.phone', $rows2[0]['mobile']);
	$docx->set('c.email', $rows2[0]['email']);
	$docx->set('a.name', $rows[0]['assr_company_name']);
	$docx->set('a.address', $rows[0]['assr_company_address']);
	$docx->set('a.url', $rows[0]['assr_company_url']);
	$docx->set('qsa.name', $rows[0]['qsa']);
	$docx->set('qsa.credentials', $rows[0]['qsa_credential']);
	$docx->set('qsa.phone', $rows[0]['qsa_phone']);
	$docx->set('qsa.email', $rows[0]['qsa_email']);
	$docx->set('qa.name', $rows[0]['qa']);
	$docx->set('qa.phone', $rows[0]['qa_phone']);
	$docx->set('qa.email', $rows[0]['qa_email']);
	//Ends customer details and assessors data
	
	//Starts Timeframe Data placing data from audit_wizard table
	$wztbl = new table($web['version'].'audit_wizard');
	$wztbl->find(array('company_id'),array($web['id']));

	$docx->set('date_of_report', $wztbl->getValue('date_of_report'));
	$docx->set('timeframe', $wztbl->getValue('timeframe'));
	$docx->set('date_spent_onsite', $wztbl->getValue('date_spent_onsite'));
	$docx->set('desc_of_time_spent', $wztbl->getValue('desc_of_time_spent'));
	//Ends Timeframe Data
	$docx->set('pci_dss_version', $wztbl->getValue('pci_dss_version'));
	$docx->set('services_by_qsa', $wztbl->getValue('services_by_qsa'));
	$docx->set('nature_of_business', $wztbl->getValue('nature_of_business'));
	$docx->set('eforts_by_qsa', $wztbl->getValue('eforts_by_qsa'));
	
	//Starts Execcutive summary Data placing data from audit_wizard table
	$docx->set('executive_summary1', $wztbl->getValue('executive_summary1'));
	$docx->set('executive_summary2', $wztbl->getValue('executive_summary2'));
	$docx->set('executive_summary3', $wztbl->getValue('executive_summary3'));
	//Ends Execcutive summary Data
	//Starts Network Diagrams Data Section 1
	$ntd = new table('network_diagram');
	$ntd->cols('t1.*');
	$ntd->condition('WHERE', 't1.company_id', $web['company_id']);
	$ntd->condition('AND', 't1.section_id', '1');
	$rowsdata = $ntd->getList();
	$diagrams = '';
	$dn = 1;
	foreach($rowsdata as $rw)
	{
		$diagrams .= "No. " . $dn . " " . $rw['diagram_path']."\n";
		$dn++;
	}
	$docx->set('diagrams_1', $diagrams);
	//Ends Network Diagrams Data Section 1
	//Starts SOW Description Data placing data from audit_wizard table
	$docx->set('desc_of_sow1', $wztbl->getValue('desc_of_sow1'));
	$docx->set('desc_of_sow2', $wztbl->getValue('desc_of_sow2'));
	$docx->set('desc_of_sow3', $wztbl->getValue('desc_of_sow3'));
	$docx->set('desc_of_sow4', $wztbl->getValue('desc_of_sow4'));
	$docx->set('desc_of_sow5', $wztbl->getValue('desc_of_sow5'));
	$docx->set('desc_of_sow6', $wztbl->getValue('desc_of_sow6'));

	$docx->set('sow_people', $wztbl->getValue('sow_people'));
	$docx->set('sow_technologies', $wztbl->getValue('sow_technologies'));
	$docx->set('sow_other_details', $wztbl->getValue('sow_other_details'));
	$docx->set('sow_process', $wztbl->getValue('sow_process'));
	$docx->set('sow_location_sites', $wztbl->getValue('sow_location_sites'));
	$docx->set('segment_used', $wztbl->getValue('segment_used'));
	//Ends SOW Description Data
	
	//Starts Network Segmentation Data
	$tblseg = new table('network_segmetation');
	$tblseg->find(array('company_id'),array($web['company_id']));
	if($wztbl->getValue('segment_used') == 'yes' )
	{
		$docx->set('not_used','');
		$docx->set('implemented',$tblseg->getValue('implemented'));
		$docx->set('technologies',$tblseg->getValue('technologies'));
		$docx->set('methods_used',$tblseg->getValue('methods_used'));
		$docx->set('verified_functioning',$tblseg->getValue('verified_functioning'));
		$docx->set('mechanism',$tblseg->getValue('mechanism'));
		$docx->set('tech_included_pci_dss',$tblseg->getValue('tech_included_pci_dss'));
	}
	if($wztbl->getValue('segment_used') == 'no' )
	{
		$docx->set('not_used',$tblseg->getValue('not_used'));
		$docx->set('implemented','');
		$docx->set('technologies','');
		$docx->set('methods_used','');
		$docx->set('verified_functioning','');
		$docx->set('mechanism','');		
		$docx->set('tech_included_pci_dss','');
	}
	
	$tbl_n_scope = new table('network_scope_purpose');
	$tbl_n_scope->cols('t1.*');
	$tbl_n_scope->condition('WHERE', 't1.company_id', $web['company_id']);
	$tbl_n_scope->condition('AND', 't1.network_type', 'store_chd');
	$rows = $tbl_n_scope->getList();
	
	for($j=0; $j<10; $j++)
	{
		$docx->set($j.'.network_name',( $rows[$j]['network_name'] ) ? $rows[$j]['network_name'] : '');
		$docx->set($j.'.network_purpose',( $rows[$j]['network_purpose'] ) ? $rows[$j]['network_purpose'] : '');
	}
	$tbl_n_scope = new table('network_scope_purpose');
	$tbl_n_scope->cols('t1.*');
	$tbl_n_scope->condition('WHERE', 't1.company_id', $web['company_id']);
	$tbl_n_scope->condition('AND', 't1.network_type', 'not_store_chd');
	$rows = $tbl_n_scope->getList();
	for($j=0; $j<10; $j++)
	{
		$docx->set($j.'_1_network_name',$rows[$j]['network_name']);
		$docx->set($j.'_1_network_purpose',$rows[$j]['network_purpose']);
	}
	$tbl_n_scope = new table('network_scope_purpose');
	$tbl_n_scope->cols('t1.*');
	$tbl_n_scope->condition('WHERE', 't1.company_id', $web['company_id']);
	$tbl_n_scope->condition('AND', 't1.network_type', 'out_of_scope');
	$rows = $tbl_n_scope->getList();
	for($j=0; $j<10; $j++)
	{
		if( isset($rows[$j]['network_name']) )
			$docx->set($j.'_2_network_name',$rows[$j]['network_name']);
		else
			$docx->set($j.'_2_network_name','');
		if( isset($rows[$j]['network_purpose']) )
			$docx->set($j.'_2_network_purpose',$rows[$j]['network_purpose']);	
		else	
			$docx->set($j.'_2_network_purpose','');
	}
	//Ends Network Segmentation Data
	//Starts Network Connected Entities Data
	$tblentity = new table('sow_connected_entiities');
	$tblentity->cols('t1.*');
	$tblentity->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tblentity->getList();
	for($j=0; $j<10; $j++)
	{
		$docx->set($j."_connected_entity",$rows[$j]['connected_entity']);
		$docx->set($j."_discussion_qsa_entity",$rows[$j]['discussion_qsa_entity']);	
	}
	//Ends Network Connected Entities Data
	//Starts Other Business Entities Data Owned
	$obt = new table('other_business_entities');
	$obt->cols('t1.*');
	$obt->condition('WHERE', 't1.company_id', $web['company_id']);
	$obt->condition('AND', 't1.entity_type', 'indoor');
	$rows = $obt->getList();
	for($j=0; $j<10; $j++)
	{
		$docx->set($j.'_entity_name',$rows[$j]['entity_name']);
		if($rows[$j]['part_or_separate'] == 'part' )
		{
			$docx->set($j.'_part','✔');
			$docx->set($j.'_separate',' ');
		}
		if($rows[$j]['part_or_separate'] == 'separate' )
		{
			$docx->set($j.'_part',' ');
			$docx->set($j.'_separate','✔');
		}			
	}
	//Ends Other Business Entities Data Wholly Owned
	//Starts Other Business Entities Data International 
	$obt = new table('other_business_entities');
	$obt->cols('t1.*');
	$obt->condition('WHERE', 't1.company_id', $web['company_id']);
	$obt->condition('AND', 't1.entity_type', 'international');
	$rows = $obt->getList();
	for($j=0; $j<10; $j++)
	{
		$docx->set($j.'_1_entity_name',$rows[$j]['entity_name']);
		$docx->set('list_countries',$rows[$j]['list_countries']);
		if($rows[$j]['part_or_separate'] == 'part' )
		{
			$docx->set($j.'_1_part','✔'); 
			$docx->set($j.'_1_separate', ' ');
		}
		if($rows[$j]['part_or_separate'] == 'separate' )
		{
			$docx->set($j.'_1_part',' ');
			$docx->set($j.'_1_separate', '✔');
		}	
	}
	//Ends Other Business Entities Data International
	//Starts Wireless Summary Data
	$docx->set('wl_net_yes', $wztbl->getValue('sow_wireless_network_yes'));
	$docx->set('wl_net_no', $wztbl->getValue('sow_wireless_network_no'));
	//Ends Wireless Summary Data
	//Starts Wireless Details Network in scope Data
	$wt_in_scope = new table('wireless_tech_in_scope');
	$wt_in_scope->cols('t1.*');
	$wt_in_scope->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $wt_in_scope->getList();
	for($j=0; $j<10; $j++)
	{
		$docx->set($j.'_wt_inscope',$rows[$j]['wireless_tech']);
		$docx->set($j.'_store_chd',$rows[$j]['used_to_store_chd']);
		$docx->set($j.'_to_cde',$rows[$j]['connected_to_cde']);
		$docx->set($j.'_impact_cde',$rows[$j]['inpact_the_cde']);
	}
	//Ends Wireless Details Data
	//Starts Wireless Details Network not in scope Data
	$wt_in_scope = new table('wireless_tech_not_in_scope');
	$wt_in_scope->cols('t1.*');
	$wt_in_scope->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $wt_in_scope->getList();
	for($j=0; $j<10; $j++)
	{
		$docx->set($j.'_tech',$rows[$j]['tech_not_in_scope']);
		$docx->set($j.'_validated',$rows[$j]['how_validated']);
	}
	//Ends Wireless Details Data
	//Starts Network Diagrams Data Section 1
	$ntd = new table('network_diagram');
	$ntd->cols('t1.*');
	$ntd->condition('WHERE', 't1.company_id', $web['company_id']);
	$ntd->condition('AND', 't1.section_id', '2');
	$rowsdata = $ntd->getList();
	$diagrams = '';
	$dn = 1;
	foreach($rowsdata as $rw)
	{
		$diagrams .= "No. " . $dn . " " . $rw['diagram_path']."\n";
		$dn++;
	}
	$docx->set('diagrams_2', $diagrams);
	//Ends Network Diagrams Data Section 1
	//Starts Reviewed Environments Data 
	$tbl = new table('reviewed_env_chd_flow');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	for($j=0; $j<9; $j++)
	{
		$docx->set($j.'_flow_name',$rows[$j]['event_name']);
		$docx->set($j.'_types_chd',$rows[$j]['types_chd']);
		$docx->set($j.'_how_chd_transmitted',$rows[$j]['how_chd_transmitted']);
	}
	//Ends Reviewed Environments Data
	//Starts Reviewed Environments Data 
	$tbl = new table('reviewed_env_chd_storage');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	for($j=0; $j<9; $j++)
	{
		$docx->set($j.'_data_store',$rows[$j]['data_store']);
		$docx->set($j.'_data_elements_stored',$rows[$j]['data_elements_stored']);
		$docx->set($j.'_data_security',$rows[$j]['data_security']);
		$docx->set($j.'_access_to_data',$rows[$j]['access_to_data']);
	}
	//Ends Reviewed Environments Data
	//Starts Reviewed Environments Data Hardware Details
	$tbl = new table('reviewed_env_hardware_detail');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	for($j=0; $j<9; $j++)
	{
		$docx->set($j.'_type_of_device',$rows[$j]['type_of_device']);
		$docx->set($j.'_vendor',$rows[$j]['vendor']);
		$docx->set($j.'_vendor_role',$rows[$j]['vendor_role']);
	}
	//Ends Reviewed Environments Data Hardware Details
	//Starts Reviewed Environments Data Software Details
	$tbl = new table('reviewed_env_software_details');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	for($j=0; $j<9; $j++)
	{
		$docx->set($j.'_name',$rows[$j]['name']);
		$docx->set($j.'_version',$rows[$j]['version']);
		$docx->set($j.'_role',$rows[$j]['role']);
	}
	//Ends Reviewed Environments Data Software Details
	//Starts Reviewed Environments Data Sampling Details
	$tbl = new table('reviewed_env_sampling');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	$docx->set('sampling_1',$rows[0]['sampling_1']);
	$docx->set('sampling_2',$rows[0]['sampling_2']);
	$docx->set('sampling_3',$rows[0]['sampling_3']);
	$docx->set('sampling_4',$rows[0]['sampling_4']);
	$docx->set('sampling_5',$rows[0]['sampling_5']);
	//Ends Reviewed Environments Data Software Details
	//Starts Sample sets data
	$tbl = new table('assessment_reporting_sample_sets');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$tbl->condition('AND', 't1.set_or_subset', 'parent_set');
	$rows = $tbl->getList();
	for($j=0; $j<5; $j++)
	{
		$docx->set($j.'_sample_name',$rows[$j]['sample_type']);
		$docx->set($j.'_sample_desc',$rows[$j]['sample_type_desc']);
		$docx->set($j.'_p_components',$rows[$j]['components']);
		$docx->set($j.'_p_sampld',$rows[$j]['total_sampled']);
		$docx->set($j.'_p_pop',$rows[$j]['total_population']);
	}
	$tbl = new table('assessment_reporting_sample_sets');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$tbl->condition('AND', 't1.set_or_subset', 'subset');
	$rows = $tbl->getList();
	for($j=0; $j<4; $j++)
	{
		$docx->set($j.'_c_components',$rows[$j]['components']);
		$docx->set($j.'_c_sampld',$rows[$j]['total_sampled']);
		$docx->set($j.'_c_pop',$rows[$j]['total_population']);
	}
	//Ends Sample sets data
	//Starts Service Providers data
	$tbl = new table('ass_other_service_providers');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	for($j=0; $j<9; $j++)
	{
		$docx->set($j.'_cname',$rows[$j]['company_name']);
		$docx->set($j.'_shared_data',$rows[$j]['shared_data']);
		$docx->set($j.'_purpose_of_sharing',$rows[$j]['purpose_of_sharing']);
		$docx->set($j.'_pci_dss_compliance',$rows[$j]['date_of_aoc'] . " " . $rows[$j]['pci_dss_version']);
	}
	//Ends Service Providers data
	//Starts Third party Payment data
	$tbl = new table('third_party_payment_apps');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	for($j=0; $j<9; $j++)
	{
		$docx->set($j.'_app_name',$rows[$j]['app_name']);
		$docx->set($j.'_vofproduct',$rows[$j]['version_of_product']);
		$docx->set($j.'_padssvalidated',$rows[$j]['pa_dss_validated']);
		$docx->set($j.'_p2pe_validated',$rows[$j]['p2pe_validated']);
		$docx->set($j.'_pci_ssc_ref_no',$rows[$j]['pci_ssc_ref_no']);
		$docx->set($j.'_exp_date',$rows[$j]['exp_date']);
	}
	//Ends Third party Payment data
	//Starts Service Providers data
	$tbl = new table('third_party_payment_details');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	if($rows)
	{
		$docx->set('implementation_guide',$rows[$j]['implementation_guide']);
		$docx->set('manual',$rows[$j]['manual']);
		$docx->set('scope_exclusion',$rows[$j]['scope_exclusion']);
		$docx->set('additional_comments',$rows[$j]['additional_comments']);
	}
	//Starts Documentation reviewed data
	$tbl = new table('reviewed_env_docs');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	for($j=0; $j<9; $j++)
	{
		if($rows[$j]['doc_name'] != '')
			$docx->set('ref'.$j, $j+1);
		else
			$docx->set('ref'.$j, '');
		//$docx->set($j.'_doc_name',$rows[$j]['doc_name']);
		$docx->set($j.'_doc_name','Doc-'.($j+1));
		$docx->set($j.'_doc_purpose',$rows[$j]['doc_purpose']);
		$docx->set($j.'_doc_date',$rows[$j]['doc_date']);
	}
	//Ends Documentation reviewed data
	
	//Starts Individual Interviewed data
	$tbl = new table('reviewed_env_individ_interviewed');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	for($j=0; $j<9; $j++)
	{
		$docx->set('int_'.$j, ($rows[$j]['emp_name'] != '') ? ($j+1) : '' );
		//$docx->set($j.'_emp_name',$rows[$j]['emp_name']);
		$docx->set($j.'_emp_name','Int-'.($j+1));
		$docx->set($j.'_emp_role',$rows[$j]['emp_role']);
		$docx->set($j.'_organization',$rows[$j]['organization']);
		$docx->set($j.'_emp_isa',$rows[$j]['emp_isa']);
		$docx->set($j.'_expertise',$rows[$j]['expertise_summary']);
	}
	//Ends Individual Interviewed  data
	
	//Starts Reviewed Managed Services  data
	$tbl = new table('reviewed_managed_services');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	$docx->set('assess_yes_no',$rows[0]['assess_yes_no']);
	$docx->set('detail_1',$rows[0]['detail_1']);
	$docx->set('detail_2',$rows[0]['detail_2']);
	$docx->set('detail_3',$rows[0]['detail_3']);
	$docx->set('detail_4',$rows[0]['detail_4']);
	$docx->set('detail_5',$rows[0]['detail_5']);
	
	//Ends Reviewed Managed Services  data
	
	$docx->set('aw_inplace_yes_no',$wztbl->getValue('inplace_yes_no'));
	$docx->set('aw_nottested_yes_no',$wztbl->getValue('nottested_yes_no'));
	
	
	//Starts Disclosure summary for In Place with Compensating Control Data
	$tbl = new table('reviewed_disclosure_summary');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$tbl->condition('AND', 't1.section', 'inplace');
	$rows = $tbl->getList();
	for($j=0; $j<9; $j++)
	{
		$docx->set($j.'_tested_procedure',$rows[$j]['tested_procedure']);
		$docx->set($j.'_summary',$rows[$j]['summary']);
	}
	//Ends Individual Interviewed  data
	
	//Starts Disclosure summary for In Place with Compensating Control Data
	$tbl = new table('reviewed_disclosure_summary');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$tbl->condition('AND', 't1.section', 'nottested');
	$rows = $tbl->getList();
	for($j=0; $j<9; $j++)
	{
		$docx->set($j.'_1_tested_procedure',$rows[$j]['tested_procedure']);
		$docx->set($j.'_1_summary',$rows[$j]['summary']);
	}
	//Ends Individual Interviewed  data
	//Starts Reviewed Managed Services  data
	$tbl = new table('reviewed_qrtly_results_init');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	$docx->set('qsr_yes_no',$rows[0]['yes_no']);
	$docx->set('qsr_scans',$rows[0]['no_of_scan']);
	$docx->set('qsr_assr',$rows[0]['assessor']);
	$docx->set('qsr_document',$rows[0]['document']);
	$docx->set('qsr_verified',$rows[0]['how_verified']);
	$tbl2 = new table('reviewed_qrtly_init_freq');
	$tbl2->cols('t1.*');
	$tbl2->condition('WHERE', 't1.company_id', $web['company_id']);
	$tbl2->condition('AND', 't1.entity_type', 'init');
	$rows = $tbl2->getList();
	for($j=0; $j<9; $j++)
	{
		$docx->set($j.'_scan_dt',$rows[$j]['scan_dt']);
		$docx->set($j.'_yes_no',$rows[$j]['yes_no']);
		$docx->set($j.'_re_scan_dt',$rows[$j]['re_scan_dt']);
	}
	//Ends Reviewed Managed Services  data
	$tbl = new table('reviewed_qrtly_results_all_other');
	$tbl->cols('t1.*');
	$tbl->condition('WHERE', 't1.company_id', $web['company_id']);
	$rows = $tbl->getList();
	$docx->set('qrty_yes_no',$rows[0]['yes_no']);
	$docx->set('assessor_comment',$rows[0]['assessor_comment']);
	$tbl2 = new table('reviewed_qrtly_init_freq');
	$tbl2->cols('t1.*');
	$tbl2->condition('WHERE', 't1.company_id', $web['company_id']);
	$tbl2->condition('AND', 't1.entity_type', 'other');
	$rows = $tbl2->getList();
	for($j=0; $j<9; $j++)
	{
		$docx->set($j.'_1_scan_dt',$rows[$j]['scan_dt']);
		$docx->set($j.'_1_yes_no',$rows[$j]['yes_no']);
		$docx->set($j.'_1_re_scan_dt',$rows[$j]['re_scan_dt']);
	}
	$docx->set('attested_assessor',$wztbl->getValue('attested_assessor'));
	for($r=1; $r<=12; $r++)
	{
		$tbl = new table('document');
		$tbl->cols('t1.*');
		$tbl->cols('p.requirements_id');
		$tbl->cols('p.sub_requirements_id');
		$tbl->cols('p.id AS pid');
		$tbl->cols('p.guidance');
		$tbl->cols('p.title AS ptitle');
		$tbl->cols('p.number');
		$tbl->cols('p.priority');
		$tbl->cols('t1.id AS doc_id');
		$tbl->cols('sr.title AS stitle');
		$total_comments = "(SELECT count(id) FROM ".$tbl->getPrefix()."procedure_comment pc WHERE pc.procedure_id = p.id AND pc.company_id = '".$web['company_id']."') as total_comments ";
		$tbl->cols($total_comments);
		
		$tbl->join($web['version'].$roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p');
		$tbl->join($web['version'].$roc_saq.'sub_requirements', 'sr.id', 't1.sub_requirements_id', 'sr');
		$tbl->condition('WHERE', 'p.requirements_id', $r);
		$tbl->condition('AND', 't1.company_id',$web['company_id']);
		$tbl->orderby('p.requirements_id');
		$rows = $tbl->getList();
		$no = 0;
		
		foreach($rows as $rw)
		{
			//Inplace logic here	
			$aryreqno = explode(" ",$rw['stitle']);
			$reqno = $aryreqno[0];
			//replace answer column according to inplace value
			($rw['inplace'] == 'Y')? $docx->set($reqno.".ay",'✔') :'';
			($rw['inplace'] == 'C')? $docx->set($reqno.".ac",'✔') :'';	
			($rw['inplace'] == 'N')? $docx->set($reqno.".an",'✔') :'';
			($rw['inplace'] == 'NT')? $docx->set($reqno.".ant",'✔') :'';
			($rw['inplace'] == 'NA')? $docx->set($reqno.".ana",'✔') :'';
			
			$tblr = new table($web['version'].'reporting');
			$tblr->condition('WHERE', 't1.procedure_id', $rw['pid']);
			$tblr->cols('t1.id');
			$tblr->cols('t1.title');
			$tblr->cols('t1.bulet');
			$tblr->cols('dr.reporting_id');
			$tblr->cols('dr.comment AS drc');
			$tblr->join('document_reporting', 'dr.reporting_id' ,'t1.id AND dr.document_id='.$rw['doc_id'] ,'dr');
			$reprows = $tblr->getList();
			$bCnt = 0;
			foreach ( $reprows as $reprw )
			{
				if($reprw['bulet'] == 1)
				{
					$bCnt++;
					$repoStr = 'r'.$rw['number'].'.'.$bCnt;
					$docx->set($repoStr, $reprw['drc']);
				}
			}
			unset($tblr);
		}
		unset($tbl);
	}
	if($action == 'download')
		$docx->downloadAs('PCI DSS_v3_1_ROC_Reporting_Template_'.$web['company_id'].'.docx');
	if($action == 'savedoc')
		$docx->saveAs(APP_PATH.'/uploads/documents/PCI DSS_v3_1_ROC_Reporting_Template_'.$web['company_id'].'.pdf');
}
function sendHtmlReport($n_settings, $admin_data = array())
{   
	global $lib;
	$complanceArr = array();
	$htmlOutputArr = array();
	$templateDataArr = array();
	if( $n_settings != '' )
	{
		$complianceArr =  prepareComplianceData($n_settings);
		if( !empty($complianceArr['rows']) )
		{
			$tableBody = '<tbody>';
			foreach($complianceArr['rows'] as $key => $val )
			{
				$tableBody .= '<tr>';
				$tableBody .= '<td class="text-center">'.$key.'</td> ';
				$tableBody .= '<td class="text-center">'. $val['percentage'] .'</td> ';
				$tableBody .= '<td class="text-center">'. $val['total'] .'</td> ';
				$tableBody .= '<td class="text-center">'. $val['Y'] .'</td> ';
				$tableBody .= '<td class="text-center">'. $val['N'] .'</td> ';
				$tableBody .= '<td class="text-center">'. $val['C'] .'</td> ';
				$tableBody .= '<td class="text-center">'. $val['NA'] .'</td> ';
				$tableBody .= '<td class="text-center">'. $val['NT'] .'</td> ';
				$tableBody .= '<td class="text-center">'. $val['severity'] .'</td> ';
				$tableBody .= '<td class="text-center">'. $val['maxseverity'] .'</td> ';
				$tableBody .= '</tr>';
			}
				$tableBody .= '</tbody>';
				$total = ( $complianceArr['total']['Y'] + $complianceArr['total']['N'] + $complianceArr['total']['C'] + $complianceArr['total']['NT'] );
				$percent = ( $total == 0 ) ? 'NA' : ceil(($complianceArr['total']['Y']+$complianceArr['total']['C'])/$total*100) . '%';
				
				$tfoot  = '<tfoot> <tr class="warning">';

				$tfoot .= '<td class="text-center">Total..</td>';
				$tfoot .= ' <td class="text-center">'. $percent .'</td>';
				$tfoot .= ' <td class="text-center">'. $total .'</td>';
				$tfoot .= ' <td class="text-center">'. $complianceArr['total']['Y'] .'</td>';
				$tfoot .= ' <td class="text-center">'. $complianceArr['total']['N'] .'</td>';
				$tfoot .= ' <td class="text-center">'. $complianceArr['total']['C'] .'</td>';
				$tfoot .= ' <td class="text-center">'. $complianceArr['total']['NA'] .'</td>';
				$tfoot .= ' <td class="text-center">'. $complianceArr['total']['NT'] .'</td>';
				$tfoot .= ' <td class="text-center">'. $complianceArr['total']['severity'] .'</td>';
				$tfoot .= ' <td class="text-center">'. $complianceArr['total']['maxseverity'] .'</td>';
							
				$tfoot .= '</tr>';
				$tfoot .= '</tfoot>';
		}
			
				$duration = array();
				$duration = getReportDuration( $n_settings );
				
				$htmlOutputArr['company_name'] 		= $n_settings['company_name'];
				$htmlOutputArr['assessment_type'] 		= $n_settings['merchant_type'];
				$htmlOutputArr['tableBody'] 			= $tableBody;
				$htmlOutputArr['tfoot'] 				= $tfoot;
				$htmlOutputArr['start_date'] 			= $n_settings['start_date'];
				$htmlOutputArr['compliance_due_date'] 	= $n_settings['compliance_due_date'];
				$htmlOutputArr['frequency'] 	       	= $duration['frequency'];
				$htmlOutputArr['from_to'] 	          = $duration['from_to'];
				$htmlOutputArr['site_dashboard'] 	   	=  ' href='.$_SERVER['HTTP_HOST'] .'/dashboard.php ' ;
					
				$templateDataArr['htmlOutputArr'] 	= array();
				$templateDataArr['htmlOutputArr'] 	= $htmlOutputArr;
				$templateDataArr['receiver_email'] = $n_settings['receiver_email'];
				$templateDataArr['sender_email'] 	= $admin_data['data']['email'] ;
				$templateDataArr['email_subject'] 	= 'This is a '. $duration['frequency'].'  report of Compliance/Severity Status '. $duration['from_to'];
	}
				$f_path =  APP_PATH .'/emailtemplates/html_notification_company_admin.html';
				$lib->send_mail($f_path, $templateDataArr['receiver_email'], $templateDataArr['sender_email'], $templateDataArr['email_subject'],'', $templateDataArr['htmlOutputArr'], false);
}
function sendFrequentlyReport( $receiverDetailArr = array())
{
	global $lib;
	//notifications settings for company admin or company user or qa or qsa
	$tempData = array();
	$nSettingsDataArr = array();
	$tbl = new table('notification_settings');
	$tbl->cols('t1.comp_id');
	$tbl->cols('t1.userrole');
	$tbl->cols('t1.freq');
	$tbl->cols('t1.day');
	$tbl->cols('t1.content');
	$tbl->cols('c.company_name');
	$tbl->cols('u.email AS receiver_email');
	$tbl->join('customer', 'c.id', 't1.comp_id', 'c');
	$tbl->join('users', 'u.id', 't1.users_id', 'u');
	$tbl->condition('WHERE', 't1.comp_id', $receiverDetailArr['id']);
	$tbl->condition('AND', 't1.userrole', 'c');
	$ndata = $tbl->getList();
	unset($tbl);
	foreach ( $ndata as $rw2 )
	{
			$nSettingsDataArr['freq'] 			= $rw2['freq'];
			$nSettingsDataArr['day'] 			= $rw2['day'];
			$nSettingsDataArr['content'] 			= $rw2['content'];
			$nSettingsDataArr['company_name'] 		= $rw2['company_name'];
			$nSettingsDataArr['receiver_email'] 	= $rw2['receiver_email'];
			$nSettingsDataArr['userrole'] 		= $rw2['userrole'];
	}
	$nSettingsDataArr['sender_email'] 	= 'admin@security.com'; //$sender_email;
	if( $nSettingsDataArr['content'] == 'html')	
	{
		$tempData = htmlOutput($receiverDetailArr, $nSettingsDataArr);
		if( !empty($nSettingsDataArr['userrole']) )
		{
			$template = '';
			switch ($nSettingsDataArr['userrole'])  
			{
				case 'c':
					$template = $nSettingsDataArr['content']. '_notification_company_admin';
					break;
				case 'u':
					$template = $nSettingsDataArr['content']. '_notification_company_user';
					break;
				case 'qsa':
					$template = $nSettingsDataArr['content']. '_notification_qsa';
					break;
				case 'qa':
					$template = $nSettingsDataArr['content']. '_notification_qa';
					break;	
			}
				
		}
		$f_path =  APP_PATH .'/emailtemplates/'. $template .'.html';
		$oApp->send_mail($f_path, $nSettingsDataArr['receiver_email'], $nSettingsDataArr['sender_email'], $tempData['email_subject'],'', $tempData['htmlOutputArr'], false);
	}
}
function getReportDuration( $n_settings = array() )
{
	$duration = array();
	if( $n_settings['freq'] == 7 )
		{
			$from_date = date('l  d  F Y', mktime(0, 0, 0, date('m'), date('d')-7, date('Y')));
			$to_date = date('l  d F Y', mktime(0, 0, 0, date('m'), date('d')-1, date('Y')));
			$duration['frequency'] 			= 'Weekly';
			$duration['from_to'] = "From  ". $from_date ." to  ". $to_date . "" ;
		} 
		else 
		{
			$to_date = date('d F  l Y', mktime(0, 0, 0, date('m'), date('d')-1, date('Y')));
			$duration['frequency'] 			= 'Daily';
			$duration['from_to'] = "of Date ". $to_date;
		}
		return $duration;
}
function prepareGraph($n_settings)
{
	require_once(dirname(__FILE__).'/phpMyGraph5.0.php');
	if($n_settings != '' )
	{
		$complanceArr =  prepareComplianceData($n_settings);
		if( !empty($complanceArr) )
		{
			$graph = new phpMyGraph();
			$graph->parseVerticalColumnGraph($complanceArr['map_axis'], $complanceArr['cfg']);
		}
	} 
}
function prepareComplianceData($n_settings)
{
	global $web, $roc_saq, $session;
	global $lib;
	$cArr = array();
	$cArr['rows'] = array();

	$cArr['company_name'] = $n_settings['company_name'];
	$tbl = new table('document');
	$tbl->cols('t1.inplace');
	$tbl->cols('p.requirements_id');
	$tbl->cols('p.sub_requirements_id');
	$tbl->cols('p.id AS pid');
	$tbl->cols('p.priority');
	$tbl->cols('p.id AS pid');
	$tbl->join($web['version'].$roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p');
	$tbl->condition('WHERE', 't1.company_id', $n_settings['comp_id']);
	$tbl->orderby('p.requirements_id');
	$tbl->orderby('p.sub_requirements_id');
	$tbl->orderby('p.id');
	$document_data = $tbl->getList();
	unset($tbl);

	if( $n_settings['content'] == 'html' )
	{	
		$totayary = array('Y'=>0, 'N'=>0, 'C'=>0, 'NA'=>0, 'NT'=>0, 'severity'=>0, 'maxseverity'=>0);
		foreach ( $document_data as $rw )
		{
			if ( !isset($cArr['rows'][$rw['requirements_id']]) )
				$cArr['rows'][$rw['requirements_id']] = array('Y'=>0, 'N'=>0, 'C'=>0, 'NA'=>0, 'NT'=>0, 'severity'=>0, 'maxseverity'=>0, 'total'=>0, 'percentage'=>0);
				$inplace = $rw['inplace'];
				if ( $inplace == '' )
					$inplace = 'NT';
				$cArr['rows'][$rw['requirements_id']][$inplace]++;
				$cArr['rows'][$rw['requirements_id']]['total']++;
				$totayary[$inplace]++;
				$cArr['rows'][$rw['requirements_id']]['maxseverity'] += abs(7-$rw['priority']);
				$totayary['maxseverity'] += abs(7-$rw['priority']);
				if ( $rw['inplace'] == 'Y' || $rw['inplace'] == 'C' || $rw['inplace'] == 'NA' )
				{
					$cArr['rows'][$rw['requirements_id']]['severity'] += abs(7-$rw['priority']);
					$totayary['severity'] += abs(7-$rw['priority']);
				}
		}
		foreach($cArr['rows'] as $k => $v)
		{
			if ( $v['total'] == 0 )
				$cArr['rows'][$k]['percentage'] = 'NA';
			else
				$cArr['rows'][$k]['percentage'] = round(($v['Y']+$v['C'])/$v['total']*100);
		}
		$cArr['total'] = $totayary;
	}
	else
	{
		$totayary = array('Y'=>0, 'N'=>0, 'C'=>0, 'NA'=>0, 'NT'=>0, 'severity'=>0, 'maxseverity'=>0);
		foreach ( $document_data as $rw )
		{
			if ( !isset($cArr['rows'][$rw['requirements_id']]) )
				$cArr['rows'][$rw['requirements_id']] = array('Y'=>0, 'N'=>0, 'C'=>0, 'NA'=>0, 'NT'=>0, 'severity'=>0, 'maxseverity'=>0, 'total'=>0, 'percentage'=>0);
			$inplace = $rw['inplace'];
			if ( $inplace == '' )
				$inplace = 'NT';
			$cArr['rows'][$rw['requirements_id']][$inplace]++;
			$cArr['rows'][$rw['requirements_id']]['total']++;
			$totayary[$inplace]++;
			$cArr['rows'][$rw['requirements_id']]['maxseverity'] += abs(7-$rw['priority']);
			$totayary['maxseverity'] += abs(7-$rw['priority']);
		
			if ( $rw['inplace'] == 'Y' || $rw['inplace'] == 'C' || $rw['inplace'] == 'NA' )
			{
				$cArr['rows'][$rw['requirements_id']]['severity'] += abs(7-$rw['priority']);
				$totayary['severity'] += abs(7-$rw['priority']);
			}
	
		}
	
		$cArr['map_axis'] = array();
		$cArr['total'] = $totayary;
		foreach($cArr['rows'] as $k => $v)
		{
			if ( $v['total'] == 0 )
				$cArr['rows'][$k]['percentage'] = 'NA';
			else
				$cArr['rows'][$k]['percentage'] = round(($v['Y']+$v['C'])/$v['total']*100);
				$cArr['map_axis'][$k] = $cArr['rows'][$k]['percentage'];
		}
		$cArr['compliance_due_date'] 	= $n_settings['compliance_due_date'];
		$cArr['start_date'] 		= $n_settings['start_date'];
		$duration = getReportDuration( $n_settings );
		$cArr['cfg'] = array();        
		$cArr['cfg']['title'] 	= $duration['frequency'] . ' Compliance status report ' . $duration['from_to'] . ' . Company : '. $n_settings['company_name'] ;
		$cArr['cfg']['file-name'] = 'compliance_graph_'.$n_settings['comp_id'].'_'.$n_settings['uid'].'_'.$n_settings['freq'].'_'. date('d_m_y_i');
		$cArr['cfg']['width'] 	= 650;
		$cArr['cfg']['height'] 	= 280;
	}
	return $cArr;
}
function sendCommentReport($admin_data = array())
{
	global $web, $roc_saq, $session, $lib;
	require_once(dirname(__FILE__).'/class.phpmailer.php');
	$mail = new PHPMailer;
	$tbl = new table('users');
	$tbl->cols('t1.id AS uid');
	$tbl->cols('t1.user_group_id AS ug_id');
	$tbl->cols('t1.userrole');
	$tbl->cols('t1.title');
	$tbl->cols('t1.email AS receiver_email');
	$tbl->cols("CONCAT(u.first_name,' ',u.last_name) AS username");
	$tbl->cols('mt.merchant_type');
	$tbl->cols('c.id AS company_id');
	$tbl->cols('c.company_name');
	$tbl->cols('c.start_date');
	$tbl->cols('c.compliance_due_date');
	$tbl->join('customer', 'c.id', 't1.company_id', 'c');
	$tbl->join('merchant_type', 'mt.id', 'c.merchant_type_id', 'mt');
	$tbl->condition('WHERE', 't1.userrole', 'u');
	$tbl->condition('OR', 't1.userrole', 'q');
	$tbl->condition('OR', 't1.userrole', 's');
	$doc_data = $tbl->getList();
	unset($tbl);
	$all_users = array();
	foreach ( $doc_data as $rw2 )
		$all_users[] = $rw2;
	$html = '';
	$html_main_div = '';
	$html_main_div  = '<div id="allcomments" style="height:200px; overflow-y:scroll; margin-top:10px; padding:5px;">';
	$allComments = array();
	foreach( $all_users as $user )
	{	
		$current_user 		= '';
		$current_user_group 	= '';
		$current_user_name 	= '';
		$current_user_title 	= '';
		$current_user_email 	= '';
		if ($user['userrole'] == 'u') 
		{
			$tbl2 = new table('procedure_comment');
			$tbl2->cols('t1.*');
			$tbl2->cols("CONCAT(u.first_name,' ',u.last_name) AS username");
			$tbl2->cols('p.title AS p_title');
			$tbl2->cols('p.number AS p_number');
			$tbl2->join($web['version'].$roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p');
			$tbl2->join('users', 'u.id', 't1.user_id', 'u');
			$tbl2->condition('WHERE', 't1.company_id', $user['company_id']);
			$tbl2->condition('AND', 't1.user_id', $user['uid']);
			$tbl2->condition('AND', '( t1.commented_by', $user['userrole']);
			$tbl2->condition('OR', 't1.commented_to', $user['userrole'].' ) ');
			$tbl2->orderby('t1.id', 'DESC');
			$rows2 = $tbl2->getList();
			unset($rows2);
			$uid = 0;
			foreach($rows2 as $rw)
			{	
				if($rw['comments'])
				{
					$allComments['by_user'][] =  $rw;
					$html .= '<p class="alert-info" style="padding:3px;">'.$rw['username'].' : '.$rw['comment_date'].'</p>';
					$html .= '<p>'.$rw['comments'].'</p>';
					$current_user 		= $user['uid'];
					$current_user_group 	= $user['ug_id'];
					$current_user_name 	= $user['username'];
					$current_user_title 	= $user['title'];
					$current_user_email 	= $user['receiver_email'];
	
				}
				
			}
			$tbl3 = new table('procedure_comment');
			$tbl3->cols('pc.*');
			$tbl3->cols("SELECT pc.*, CONCAT(u.first_name,' ',u.last_name) AS username");
			$tbl3->join('users', 'u.id', 't1.user_id', 'u');
			$tbl3->condition('WHERE', 't1.company_id', $user['company_id']);
			$tbl3->condition('WHERE', 't1.commented_to', 'u');
			$tbl3->condition('WHERE', 't1.commented_by', 'u', '!=');
			$tbl3->orderby('t1.id', 'desc');
			$rows = $tbl3->getList();
			unset($tbl3);
			$uid = 0;
			foreach( $rows as $rw )
			{	
				if($rw['comments'])
				{
					$comment_by = ( $rw['commented_by'] == 's' ) ? 'by_qsa' : 'by_qa' ;
					if($current_user_group)
					{
						$tbl4 = new table('document');
						$tbl4->cols('t1.id AS doc_id');
						$tbl4->cols('dug.*');
						$tbl4->join('document_user_group', 'dug.document_id', 't1.id', 'dug');
						$tbl4->condition('WHERE', 't1.procedure_id', $rw['procedure_id']);
						$tbl4->condition('AND', 't1.company_id', $user['company_id']);
						$tbl4->condition('AND', 'dug.user_group_id', $current_user_group);
						$rows4 = $tbl4->getList();
						unset($tbl4);
						$mathced_group = 0;
						$same_group = 0;
						foreach( $rows4 as $rw4 )
								$same_group = ( $rw4['user_group_id'] == $current_user_group ) ? 1 : 0 ;
						if($same_group == 1)
							$allComments[$comment_by][] =  $rw;
					}
				}
				
			}
			// mrged to sort by id desc
			$all_merge = array_merge($allComments['by_user'], $allComments['by_qsa'], $allComments['by_qa']);
			$html = '<div id="allcomments" style="">';
			foreach($all_merge as $commentsArr)
			{
				$html .= '<p class="alert-info" style="padding:3px;color: #31708f; background-color: #d9edf7; border-color: #bce8f1;">'.$commentsArr['username'].' : '.$commentsArr['comment_date'].'</p>';
				$html .= '<p>'.$commentsArr['comments'].'</p>';
			}
			$html .="</div>";
			if($current_user_email)
			{
				$final_html = '
							<table>
								<tr>
									<td>
									<div class="">
										<h3>Hello, '. ucfirst($current_user_title) ." ". $current_user_name.' </h3>
										<h3>This is a comments report of  '.$user["company_name"].' </h3>
									</div>
									</td>
								</tr>
								<tr>
									<td>
										'.$html.'
									</td>
								</tr>
							</table>';
				
				
				//echo $final_html;
				$mail->setFrom($admin_data['data']['email'], $admin_data['data']['username']);
				//$mail->addReplyTo('admin@security.com', 'Admin');
				$mail->addAddress($current_user_email, $current_user_name);
				$mail->Subject = 'Daily Comment Report  '.$user['company_name'];
				$mail->IsHTML(true);
				$mail->Body = preg_replace('/\[\]/','',$final_html);
				//$mail->AltBody = $body;
			}
				$mail->send();
		}
		elseif ($user['userrole'] == 's')
		{
			$tbl5 = new table('procedure_comment');
			$tbl5->cols('t1.*');
			$tbl5->cols('p.title AS p_title');
			$tbl5->cols('p.number AS p_number');
			$tbl5->cols('c.company_name');
			$tbl5->cols("CONCAT(u.first_name,' ',u.last_name) AS username");
			$tbl5->join('procedure', 'p', 'p.id', 't1.procedure_id');
			$tbl5->join('customer', 'c', 'c.id', 't1.company_id');
			$tbl5->join('users', 'u', 'u.id', 't1.user_id');
			$tbl5->condition('WHERE', ' ( t1.commented_by', $user['userrole']);
			$uerrole_cond = $user['userrole']. ' )';
			$tbl5->condition('OR', ' t1.commented_to', $uerrole_cond);
			$tbl5->orderby('t1.id', 'desc');
			$rows5 = $tbl5->getList();
			$uid = 0;
			foreach($rows5 as $rw)
			{	
				if($rw['comments'])
				{
					$comment_by = ( $rw['commented_by'] == 's' ) ? 'by_qsa' : 'by_qa' ;
					switch($rw['commented_by'])
					{
						case 's' :
							$comment_by = 'by_qsa';
							break;
						case 'q' :
							$comment_by = 'by_qa';
							break;	
						case 'u' :
							$comment_by = 'by_user';
							break;
						case 'a' :
							$comment_by = 'by_admin';
							break;	
					}
					$allComments[$comment_by][] =  $rw;
					$html .= '<p class="alert-info" style="padding:3px;">'.$rw['username'].' : '.$rw['comment_date'].'</p>';
					$html .= '<p>'.$rw['comments'].'</p>';
					$current_user 		= $user['uid'];
					$current_user_group = $user['ug_id'];
					$current_user_name = $user['username'];
					$current_user_title = $user['title'];
					$current_user_email = $user['receiver_email'];

				}
			
			}
			// mrged to sort by id desc
			$all_merge = array_merge($allComments['by_qsa'], $allComments['by_qa'], $allComments['by_user']);
			$html = '<div id="allcomments" style="">';
			foreach($all_merge as $commentsArr)
			{
				$html .= '<p class="alert-info" style="padding:3px;color: #31708f; background-color: #d9edf7; border-color: #bce8f1;"> <strong>' .$commentsArr['company_name']. ' </strong> &nbsp;Procedure #: <b>'.$commentsArr['p_number'].' </b>&nbsp;'.$commentsArr['p_title'].'</p>';
				$html .= '<p class="alert-info" style="padding:3px;color: #31708f; background-color: #d9edf7; border-color: #bce8f1;">'.$commentsArr['username'].' : '.$commentsArr['comment_date'].'</p>';
				$html .= '<p>'.$commentsArr['comments'].'</p>';
			}
			$html .="</div>";
			if($all_merge)
			{
				$final_html = '
						<table>
							<tr>
								<td>
								<div class="">
									<h3>Hello, '. ucfirst($current_user_title) ." ". $current_user_name.' </h3>
									<h3>This is a comments report of  '.$user["company_name"].' </h3>
								</div>
								</td>
							</tr>
							<tr>
								<td>
									'.$html.'
								</td>
							</tr>
						</table>';
				//echo $final_html;
				$mail->setFrom($admin_data['data']['email'], $admin_data['data']['username']);
				//$mail->addReplyTo('admin@security.com', 'Admin');
				$mail->addAddress($current_user_email, $current_user_name);
				$mail->Subject = 'Daily Comment Report  '.$user['company_name'];
				$mail->IsHTML(true);
				$mail->Body = preg_replace('/\[\]/','',$final_html);
				//$mail->AltBody = $body;
			}
			$mail->send();
		}
		elseif ($user['userrole'] == 'q')
		{
			$tbl5 = new table('procedure_comment');
			$tbl5->cols('t1.*');
			$tbl5->cols('p.title AS p_title');
			$tbl5->cols('p.number AS p_number');
			$tbl5->cols('c.company_name');
			$tbl5->cols("CONCAT(u.first_name,' ',u.last_name) AS username");
			$tbl5->join('procedure', 'p', 'p.id', 't1.procedure_id');
			$tbl5->join('customer', 'c', 'c.id', 't1.company_id');
			$tbl5->join('users', 'u', 'u.id', 't1.user_id');
			
			$cond_1_end = " 's' ) ";
			$tbl5->condition('WHERE','(t1.commented_by',$user['userrole']);
			$tbl5->condition('AND','t1.commented_to',$sub_cond_1);
			
			$cond_2_end = " '" . $user['userrole'] . " ' ) ";
			$tbl5->condition('AND','(t1.commented_by','s' );
			$tbl5->condition('AND','t1.commented_to',$cond_2_end );
			
			$cond_3_end = "'u' ) ";
			$tbl5->condition('OR', ' ( t1.commented_by',$user['userrole']);
			$tbl5->condition('AND', '  t1.commented_to',$cond_3_end );
			
			$cond_4_end = " '" . $user['userrole'] . " ' ) ";
			$tbl5->condition('OR','(t1.commented_by','u' );
			$tbl5->condition('AND','t1.commented_to',$cond_4_end );
			$tbl5->orederby('t1.id', 'desc');
			$rows5 = $tbl5->getList();
			unset($tbl5);
			$uid = 0;
			foreach( $rows5 as $rw5 )
			{	
				if($rw['comments'])
				{
					$comment_by = ( $rw5['commented_by'] == 's' ) ? 'by_qsa' : 'by_qa' ;
					switch($rw5['commented_by'])
					{
						case 's' :
							$comment_by = 'by_qsa';
							break;
						case 'q' :
							$comment_by = 'by_qa';
							break;	
						case 'u' :
							$comment_by = 'by_user';
							break;
						case 'a' :
							$comment_by = 'by_admin';
							break;	
					}
					$allComments[$comment_by][] =  $rw5;
				}
			}
		
			// mrged to sort by id desc
			$all_merge = array_merge($allComments['by_qsa'], $allComments['by_qa'], $allComments['by_user']);
			$html = '<div id="allcomments" style="">';
			foreach($all_merge as $commentsArr)
			{
				$html .= '<p class="alert-info" style="padding:3px;color: #31708f; background-color: #d9edf7; border-color: #bce8f1;"> <strong>' .$commentsArr['company_name']. ' </strong> &nbsp;Procedure #: <b>'.$commentsArr['p_number'].' </b>&nbsp;'.$commentsArr['p_title'].'</p>';
				
				$html .= '<p class="alert-info" style="padding:3px;color: #31708f; background-color: #d9edf7; border-color: #bce8f1;">'.$commentsArr['username'].' : '.$commentsArr['comment_date'].'</p>';
				
				$html .= '<p>'.$commentsArr['comments'].'</p>';
			}
			$html .="</div>";
			if($all_merge)
			{
			
				$final_html = '
						<table>
							<tr>
								<td>
								<div class="">
									<h3>Hello, '. ucfirst($current_user_title) ." ". $current_user_name.' </h3>
									<h3>This is a comments report of  '.$user["company_name"].' </h3>
								</div>
								</td>
							</tr>
							<tr>
								<td>
									'.$html.'
								</td>
							</tr>
						</table>';
				$mail->setFrom($admin_data['data']['email'], $admin_data['data']['username']);
				//$mail->addReplyTo('admin@security.com', 'Admin');
				$mail->addAddress($current_user_email, $current_user_name);
				$mail->Subject = 'Daily Comment Report  '.$user['company_name'];
				$mail->IsHTML(true);
				$mail->Body = preg_replace('/\[\]/','',$final_html);
				//$mail->AltBody = $body;
				
			}
				$mail->send();
		}
	}
}
function sendTaskReport($n_settings, $admin_data = array())
{
	global $web, $roc_saq, $session, $lib;
	$user_id 			= $n_settings['uid'];
	$company_id 		= $n_settings['comp_id'];
	$report 			= array();
	$report['data'] 	= array();
	
	$tbl = new table('document');
	$tbl->cols('r.id');
	$tbl->cols('r.title');
	$tbl->join('users', 'u.id', $user_id, 'u');
	$tbl->join('document_user_group', 't1.id', 'dug.document_id', 'dug');
	$tbl->join($web['version'].$roc_saq.'requirements', 'r.id', 't1.requirements_id', 'r');
	$tbl->condition('WHERE', 't1.company_id', $company_id);
	$tbl->groupby('r.id');
	$tbl->groupby('r.title');
	$rows = $tbl->getList();
	unset($tbl);
	$udata['requirements'] = array();
	foreach ( $rows as  $rw )
		$udata['requirements'][$rw['id']] = $rw;
	
	if($udata['requirements'] != '' )
	{
		$udata['total'] = array();
		foreach($udata['requirements'] as $k => $val)
		{
			$tbl2 = new table('users');
			$tbl2->cols('t1.user_group_id');
			$tbl2->cols('d.response');
			$tbl2->cols('d.inplace');
			$tbl2->cols('d.id AS doc_id');
			$tbl2->cols('d.locked');
			$tbl2->cols('d.constraints');
			$tbl2->cols('d.objective');
			$tbl2->cols('d.risk');
			$tbl2->cols('d.dcontrols');
			$tbl2->cols('d.maintenance');
			$tbl2->cols('p.number');
			$tbl2->cols('p.title');
			$tbl2->cols('p.priority');
			$tbl2->cols('p.requirements_id');
			$tbl2->cols('p.sub_requirements_id');
			$tbl2->cols('p.id AS pid');
			$tbl2->cols('sr.title AS srtitle');
			$tbl2->join('document_user_group', 'dug.user_group_id', 't1.user_group_id', 'dug');
			$tbl2->join('document', 'd.id', 'dug.document_id', 'd');
			$tbl2->join($web['version'].$roc_saq.'procedure', 'p.id', 'd.procedure_id', 'p');
			$tbl2->join($web['version'].$roc_saq.'sub_requirements', 'sr.id', 'd.sub_requirements_id', 'sr');
			$tbl2->condition('WHERE', 't1.id', $user_id);
			$tbl2->condition('AND', 'p.requirements_id', $val['id']);
			$tbl2->condition('AND', 'd.company_id', $company_id);
			$rows2 = $tbl2->getList();
			unset($tbl2);
			$udata['requirements'][$k]['total']['assigned'] = 0;
			$udata['requirements'][$k]['total']['completed'] = 0;
			$udata['requirements'][$k]['total']['failed'] = 0;
			$udata['requirements'][$k]['total']['open'] = 0;
			
			foreach ( $rows2 as $rw )
			{
				if($rw['pid'])
				{
					$udata['requirements'][$k]['tasks'][$rw['pid']] = $rw;
					if(($rw['inplace'] == 'Y' && $rw['locked'] == '1' ) || ($rw['inplace'] == 'C' && $rw['locked'] == '1' ))
						$udata['requirements'][$k]['total']['completed']++;
					 elseif($rw['inplace'] == 'N')
						$udata['requirements'][$k]['total']['failed']++;
					 else
						$udata['requirements'][$k]['total']['open']++;
						
					$udata['requirements'][$k]['total']['assigned']++;
				}
			}
		}	
	}
	$total = array();
	$t_a = 0;
	foreach($udata['requirements'] as $k_2 => $v_2)
	{
		if($v_2['total']['assigned'] > 0)
		{
			$t_a += $v_2['total']['assigned'];
			$t_f += $v_2['total']['failed'];
			$t_o += $v_2['total']['open'];
			$t_c += $v_2['total']['completed'];
		}
	}
	$total['assigned'] 	= $t_a;
	$total['failed'] 	= $t_f;
	$total['open'] 	= $t_o;
	$total['completed'] = $t_c;
	$udata['total'] 	= $total;

	$tableBody = '<table width="996px" style="border:1px solid;" >';
	$tableBody .= '<tbody>';
	foreach($udata['requirements'] as $k_1 => $v_1 )
	{	
		if( isset($v_1['tasks']) )
		{
			$tableBody .= '<tr>';
			$tableBody .= '<td class="text-center" colspan="2"> <h3> Requirement #'.$v_1['id'];
			$tableBody .= '&nbsp;&nbsp;'.$v_1['title'].' </h3></td> ';
			$tableBody .= '</tr>'; 
			$tableBody .= '<tr>'; 
			$tableBody .= '<td class="text-center" colspan="2">';
					
			$task_tbl = '<table style="border:1px solid;">';
			$task_tbl .= '<tr><td valilgn="top" width="10%"><b> Number </b></td>';
			$task_tbl .= '<td valilgn="top">';
			$task_tbl .= '<b>Sub-Requirement </b>';
			$task_tbl .= '</td><td valilgn="top" width="15%"> <b> Critical security </h4> </b>';
			$task_tbl .= '</td><td valilgn="top" width="7%"> <b> Status <b> </td></tr>';
			foreach($v_1['tasks'] as $task_details)
			{
				if($task_details['inplace'] == 'Y' && $task_details['locked'] == '1' )
					$task_status = 'Completed';	
				elseif($task_details['inplace'] == 'N')
					$task_status = 'Failed';
				else
					$task_status =  'Open';	
				$task_tbl .= '<tr><td valilgn="top" >' .$task_details['number'].'</td>';
				$task_tbl .= '<td valilgn="top" >';
				$task_tbl .= $task_details['srtitle'];
				$task_tbl .= '</td>';
				$task_tbl .= '<td valilgn="top" width="15%"> ' .$task_details['critical_security']. '</td>';
				$task_tbl .= '<td valilgn="top" width="7%"> ' .$task_status. '</td></tr>';
			}
			$task_tbl .= '</table>';
			$tableBody .= $task_tbl;
		}
	}
	$tableBody .= '</td></tr> ';
	$tableBody .= '<tr><td colspan="2"> ';
	$tableBody .= ' <b>Assigned Taks : </b> '.$udata['total']['assigned'];
	$tableBody .= '&nbsp;&nbsp;<b>Open :</b> '.$udata['total']['open'];
	$tableBody .= '&nbsp;&nbsp;<b>Completed :</b> '.$udata['total']['completed'];
	$tableBody .= '&nbsp;&nbsp;<b>Failed :</b> '.$udata['total']['failed'];
	$tableBody .= '</td> </tr>';
	$tableBody .= '</tbody>';
	$tableBody .= '</table>';

	$duration = array();
	$duration = getReportDuration( $n_settings );
	//print_r($n_settings);
	$htmlOutputArr = array();
	$htmlOutputArr['company_name'] 			= $n_settings['company_name'];
	$htmlOutputArr['assessment_type'] 		= $n_settings['merchant_type'];
	$htmlOutputArr['tableBody'] 			= $tableBody;
	$htmlOutputArr['start_date'] 			= $n_settings['start_date'];
	$htmlOutputArr['compliance_due_date'] 	= $n_settings['compliance_due_date'];
	$htmlOutputArr['frequency'] 	       = $duration['frequency'];
	$htmlOutputArr['from_to'] 	           = $duration['from_to'];
	$htmlOutputArr['site_dashboard'] 	    = ' href='.$_SERVER['HTTP_HOST'] .'/dashboard.php ' ;
		
	$templateDataArr['htmlOutputArr'] 	= array();
	$templateDataArr['htmlOutputArr'] 	= $htmlOutputArr;
	$templateDataArr['receiver_email'] 	= $n_settings['receiver_email'];
	
	$templateDataArr['sender_email'] 		= $admin_data['data']['email'];
	$templateDataArr['email_subject'] 	= 'This is a '. $duration['frequency'].'  tasks updates notification '. $duration['from_to'];
	$f_path =  APP_PATH .'/emailtemplates/task_notification_company_user.html';
	$lib->send_mail($f_path, $templateDataArr['receiver_email'], $templateDataArr['sender_email'], $templateDataArr['email_subject'],'', $templateDataArr['htmlOutputArr'], false);
}
function add_log_history($action='', $log='', $user_id=0, $userrole='', $failed_attempt = false, $email=null)
{
	$fields = array();
	if($user_id == 0 && $failed_attempt == true)
	{
		$fields['user_id']['value'] = $user_id;
		$fields['userrole']['value'] = $userrole;
		$fields['last_login']['value'] = date('Y-m-d H:i:s', mktime(date('H')+5, date('i')+30, date('s'), date('m'), date('d'), date('Y')));
		$fields['comments']['value'] =  ' Login Failed : ' . $email;
		$fields['login_from']['value'] = $_SERVER['REMOTE_ADDR'];
		$login_history = new table('login_history');
		$login_history->savedata($fields);
		unset($login_history);
	}
	else
	{
		$activity = array();
		$activity['ADD'] 			= 'Added';
		$activity['EDIT'] 			= 'Edited';
		$activity['DEL'] 			= 'Deleted';
		$activity['DWN'] 			= 'Downloaded';
		$activity['UP'] 			= 'Uploaded';
		$activity['ASS']			= 'Assigned';
		$activity['CHNG'] 			= 'Changed';
		$activity['LCK'] 			= 'Locked';
		$activity['UNLCK']			= 'Un-Locked';
		$activity['CRT']			= 'Created';
			
		$activity['CMT'] 			= 'Comment';
		$activity['DOC'] 			= 'Document';
		$activity['TASK'] 			= 'Task';
		$activity['N_SET'] 			= 'Notification Settings';
		$activity['SET'] 			= 'Settings';
		
		$activity['MT'] 			= 'Merchant Type';
		$activity['FILTER'] 		= 'Filter';
		$activity['PM'] 			= 'Procedure Merchant';
		$activity['D_M'] 			= 'Duplicate Merchant';
		$activity['CUST'] 			= 'Company';
		$activity['USER'] 			= 'User';
		$activity['COMPUTER']		= 'Computer/Server';
		$activity['GROUP']			= 'Computer Group';
		$activity['ASSR'] 			= 'Assessor';
		$activity['QSA'] 			= 'QSA';
		$activity['QA'] 			= 'QA';
		$activity['ADMIN'] 			= 'ADMIN';
		
		$activity['UG'] 			= 'User Group';
		$activity['EMAIL'] 			= 'Email ID';
		$activity['PWD'] 			= 'Passsword';
		$activity['LOGIN'] 			= 'Logged In';
		$activity['LOGOUT'] 		= 'Logout';
		$activity['PROC'] 			= 'Procedure';
		$activity['PROC_CCW']	 	= 'Procedure CCW Details';
		$activity['PROC_INPLACE']	= 'Procedure Inplace Detail';
		$activity['DR'] 			= 'Document Reports';
		$activity['GLOSS'] 			= 'Glossary Item';
		$activity['SR'] 			= 'Sub-Requirement';
		$activity['REQ'] 			= 'Requirement';
		$activity['PROF'] 			= 'Profile';
		$activity['R_ROC'] 			= 'Reporting ROC';
		$activity['FCDUE'] 			= 'Failed Controls Due Date And Task Re-assignment';
		$activity['READY'] 			= 'Changed to Ready for Review';
		$activity['NREADY'] 		= 'Changed to Not Ready for Review';
		$activity['LOGO'] 			= 'Company Logo';
		
		$fields['user_id']['value'] = $user_id;
		$fields['userrole']['value'] = $userrole;
		$fields['last_login']['value'] = date('Y-m-d H:i:s', mktime(date('H')+5, date('i')+30, date('s'), date('m'), date('d'), date('Y')));
		$fields['comments']['value'] =  ( $action !='' ) ? $activity[$action]. ' ' .$activity[$log] : $activity[$log];
		$fields['login_from']['value'] = $_SERVER['REMOTE_ADDR'];
		$login_history = new table('login_history');
		$login_history->savedata($fields);
		unset($login_history);
	}	
}
function security_encrypt($data, $key='', $base64_safe=true, $shrink=true) {
	   $key = "&/ASD%g/..&FWSF2csvsq2we!%%";
        if ($shrink) $data = base_convert($data, 10, 36);
        $data = @mcrypt_encrypt(MCRYPT_ARCFOUR, $key, $data, MCRYPT_MODE_STREAM);
        if ($base64_safe) $data = str_replace('=', '', base64_encode($data));
        return $data;
}
function security_decrypt($data, $key='', $base64_safe=true, $expand=true) {
		$key = "&/ASD%g/..&FWSF2csvsq2we!%%";
        if ($base64_safe) $data = base64_decode($data.'==');
        $data = @mcrypt_encrypt(MCRYPT_ARCFOUR, $key, $data, MCRYPT_MODE_STREAM);
        if ($expand) $data = base_convert($data, 36, 10);
        return $data;
}
function getFailedControlData($company_id,$docid,$proc_id)
{
	global $web, $roc_saq, $session;
	$return = array();
	$tbl = new table('document');
	$tbl->cols('p.number');
	$tbl->cols('p.title AS ptitle');
	$tbl->cols('c.compliance_due_date');
	$tbl->cols('t1.roc_saq');
	$tbl->cols('t1.user_id');
	$tbl->cols('t1.response');
	$tbl->cols('t1.procedure_id');
	$tbl->cols('t1.inplace');
	$tbl->cols('t1.id AS doc_id');
	$tbl->cols('t1.locked');
	$tbl->cols('t1.completion_date');
	$tbl->cols('t1.updated_on');
	$tbl->cols('t1.reason_of_failure');
	$tbl->cols('t1.ready_for');
	$tbl->join($web['version'].'procedure', 'p.id', 't1.procedure_id', 'p');
	$tbl->join('customer', 'c.id', 't1.company_id', 'c');
	$tbl->join($web['version'].'sub_requirements', 'sr.id', 't1.sub_requirements_id', 'sr');
	$tbl->condition('WHERE', 't1.company_id',$company_id);
	$tbl->condition('AND', 't1.procedure_id',$proc_id);
	$tbl->orderby('p.id');
	$failed_controls 	= $tbl->getList();
	if(!empty($failed_controls))
	{
		$return['ptitle'] 		= $failed_controls[0]['ptitle'];
		$return['number'] 		= $failed_controls[0]['number'];
		$return['reason'] 		= $failed_controls[0]['reason_of_failure'];
		$return['due_date'] 	= $failed_controls[0]['completion_date'];
		$return['updated_on'] 	= $failed_controls[0]['updated_on'];
		$return['inplace'] 		= $failed_controls[0]['inplace'];
		$return['roc_saq'] 		= $failed_controls[0]['roc_saq'];
	}
	return $return;
}
function sendTaskDueReminder($company_id, $docid, $proc_id, $type, $receiver)
{
	global $web, $roc_saq;
	$tbl = new table('document');
	$tbl->cols('t1.*');
	$tbl->cols('p.requirements_id');
	$tbl->cols('p.sub_requirements_id');
	$tbl->cols('p.id AS pid');
	$tbl->cols('p.guidance AS Guide');
	$tbl->cols('p.number');
	$tbl->cols('p.title AS ptitle');
	$tbl->cols('p.priority');
	$tbl->cols('p.usercan');
	$tbl->cols('t1.id AS doc_id');
	$tbl->cols('dug.id AS dugid');
	$tbl->cols('dug.id AS dugid');
	$tbl->join($web['version'].$roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p');
	$tbl->join($web['version'].$roc_saq.'sub_requirements', 'sr.id', 't1.sub_requirements_id', 'sr');
	$tbl->join('document_user_group', 'dug.document_id', "t1.id AND dug.user_group_id = '".$web['id']."'", 'dug');
	$tbl->condition('WHERE', 'p.requirements_id', $web['requirements_id']);
	$tbl->orderby('p.id');
	$rows = $tbl->getList();
	unset($tbl);
	$no = 0;
	foreach($rows as $rw)
	{
		$web['rows'][$no] = $rw;
		$no++;
	}
}
function getQaQsaTasks($task_status, $user, $id=0, $company_id)
{
	global $web, $roc_saq, $lib;
	
	$tbl = new table('customer');
	$tbl->cols('t1.*');
	$tbl->cols('m.merchant_type');
	$tbl->cols('m.roc_saq');
	$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id) as total");
	if ( $user == 's' )
		$tbl->condition("WHERE" ,"t1.qsa_id", $id);
	if ( $user == 'q' )
		$tbl->condition("WHERE" , "t1.qa_id", $id);
	if(  $user == 's' ||  $user == 'q')
	{
		if($task_status == 'inprocess')
			$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND ( ready_for = 'review' OR ready_for = 'q' ) ) as filled");
		if($task_status == 'upcoming')
			$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND ready_for = 'review') as filled");
		if($task_status == 'failed')
			$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND inplace = 'N') as filled");
		if($task_status == 'overdue')
			$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND completion_date < '".date('Y-m-d')."') as filled");		
		$tbl->join('merchant_type', 'm.id', 't1.merchant_type_id', 'm');
		$tbl->condition("AND" ,"t1.id", $company_id);
	}
	if ( $user == 'a' )
	{
		if($task_status == 'inprocess')
			$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND ( ready_for = 'review' OR ready_for = 'q' ) ) as filled");
		if($task_status == 'upcoming')
			$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND ready_for = 'review') as filled");
		if($task_status == 'failed')
			$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND inplace = 'N') as filled");
		if($task_status == 'overdue')
			$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND completion_date < '".date('Y-m-d')."') as filled");
		if($task_status == 'overdue_open')
			$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND inplace != '' AND completion_date < '".date('Y-m-d')."') as filled");	

		$tbl->cols("CONCAT(qsa.first_name, ' ', qsa.last_name) AS qsa_name ");	
		$tbl->cols("CONCAT(qa.first_name, ' ', qa.last_name) AS qa_name ");	
		$tbl->join('merchant_type', 'm.id', 't1.merchant_type_id', 'm');
		$tbl->join('users', 'qsa.id', 't1.qsa_id', 'qsa');
		$tbl->join('users', 'qa.id', 't1.qa_id', 'qa');
		$tbl->orderby('total', 'desc');
	}
	//$tbl->condition('AND', 'u.userrole', 'c');
	$rows = $tbl->getList();
	unset($tbl);
	$no = 0;
	$web[$task_status] = array();
	foreach( $rows as $rw )
	{
		//$web[$task_status][$no] = $rw;
		$web[$task_status][$no]['compliance_due_date'] = $lib->format_date($rw['compliance_due_date'], 'd M Y');
		$web[$task_status][$no]['values'] = '';
		$web[$task_status][$no]['maps'] = '';
		$web[$task_status][$no]['percentage'] = 0;
		$web[$task_status][$no]['roc_saq'] = strtoupper($rw['roc_saq']);
		if ( $rw['total'] > 0 )
			$web[$task_status][$no]['percentage'] = ( isset($rw['filled']) && $rw['filled'] > 0 )? number_format($rw['filled'] / $rw['total'] * 100, 2, '.', '') : 0;
		$web[$task_status][$no]['class'] = '';
		if ( date('Ymd') > $lib->format_date($rw['compliance_due_date'], 'Ymd') )
			$web[$task_status][$no]['class'] = ' class="danger"';
		if ( $web[$task_status][$no]['percentage'] == 100 )
			$web[$task_status][$no]['class'] = ' class="success"';
		if ( $user == 'a' )
		{
			$web[$task_status][$no]['qsa_name'] = $rw['qsa_name'];
			$web[$task_status][$no]['qa_name']  = $rw['qa_name'];
		}		
		$web[$task_status][$no]['company_id']  	= $rw['id'];
		$web[$task_status][$no]['filled']  	  	= $rw['filled'];
		$web[$task_status][$no]['total']  		= $rw['total'];
		$no++;
	}
	
	return $web[$task_status] ;
}
function getUserWiseTasks($task_status, $user, $group_id, $cid, $range='')
{
	global $web, $roc_saq, $lib;  
	$return = array();
	

	$tbl = new table('document');
	$tbl->cols('t1.inplace');
	$tbl->cols('t1.id AS docid');
	$tbl->cols('t1.requirements_id');
	$tbl->cols('t1.procedure_id');
	$tbl->cols('t1.completion_date');
	$tbl->cols('t1.user_id');
	$tbl->cols('t1.updated_on');
	$tbl->cols('r.id');
	$tbl->cols('p.title');
	$tbl->cols('p.number');
	$tbl->cols('p.priority');
	$tbl->cols('ug.user_group_name');
	$tbl->join($web['version'].$roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p', 'JOIN');
	$tbl->join($web['version'].$roc_saq.'requirements', 'r.id', 't1.requirements_id', 'r', 'JOIN');
	$tbl->condition('WHERE', 't1.company_id', $cid);
	$tbl->join('document_user_group', 'dug.document_id', 't1.id', 'dug', 'JOIN');
	$tbl->join('user_group', 'ug.id', 'dug.user_group_id', 'ug', 'JOIN');
	$tbl->condition('AND', 'dug.user_group_id', $group_id);
	


	if($task_status == 'upcoming' )
	{
		if($range == 'thisweek')
		{
			$startdate = "this monday";
			 if (date('N') !== '1')
				 $startdate .= " last week";
			 $day = strtotime('this week');
			$monday = strtotime('next saturday', $day);
			$first_day = date('Y-m-d', $day); 
			$last_day = date('Y-m-d', $monday);
			
		}
		if($range == 'nextweek')
		{
			$startdate = "last monday";
			 if (date('N') !== '1')
				 $startdate .= " last week";
			 $day = strtotime('next week'); 
			$monday = strtotime('next saturday', $day);
			$first_day = date('Y-m-d', $day); 
			$last_day = date('Y-m-d', $monday);
		}
		if($range == 'nextmonth' )
		{
			$nextmonth = strtotime('next month'); 
			$first_day = date('Y-m-01', $nextmonth);
			$last_day  = date('Y-m-t', $nextmonth);
			
		}
		$tbl->condition('AND', 't1.inplace', 'N', '!=');
		$tbl->condition('AND', ' t1.completion_date', $first_day, '>');
		$tbl->condition('AND', 't1.completion_date', $last_day , '<');	
	}
	if($task_status == 'overdue' )
	{

		$today = date('Y-m-d');
		$tbl->condition('AND', 't1.completion_date', $today , '<');	
	
	}

	$rows = $tbl->getList();
	unset($tbl);
	$totayary = array('Y'=>0, 'N'=>0, 'C'=>0, 'NA'=>0, 'NT'=>0, 'severity'=>0, 'maxseverity'=>0);
	$web['tasks'] = array();
	$failed = array();
	$web['fc'] = array();
	foreach ( $rows as $rw )
	{
		if ( !isset($web['tasks'][$rw['requirements_id']]) )
			$web['tasks'][$rw['requirements_id']] = array('Y'=>0, 'N'=>0, 'C'=>0, 'NA'=>0, 'NT'=>0, 'severity'=>0, 'maxseverity'=>0, 'total'=>0, 'percentage'=>0);
		$inplace = $rw['inplace'];
		if ( $inplace == '' )
			$inplace = 'NT';
		if ( $inplace == 'N' )	
			$failed[$rw['requirements_id']]['procedure'][] = "'".$rw['procedure_id']."'";
		if ( $inplace == 'N' )	
		{
			$web['fc'][$rw['procedure_id']]['docid'] 	= $rw['docid'];
			$web['fc'][$rw['procedure_id']]['rid'] 		= $rw['requirements_id'];
			$web['fc'][$rw['procedure_id']]['number'] 	= $rw['number'];
			$web['fc'][$rw['procedure_id']]['title'] 	= $rw['title'];
			$web['fc'][$rw['procedure_id']]['cdate'] 	= $rw['completion_date'];
			$web['fc'][$rw['procedure_id']]['user_group_name'] 	= $rw['user_group_name'];
			$web['fc'][$rw['procedure_id']]['priority'] 	= $rw['priority'];
			$web['fc'][$rw['procedure_id']]['user_id'] 	= $rw['user_id'];
			$web['fc'][$rw['procedure_id']]['updated_on']  = $rw['updated_on'];
		}
		if($task_status == 'failed')
		{
			$web['tasks'] = $web['fc'];
		}
		else
		{
			$web['tasks'][$rw['requirements_id']]['updated_on'] = $rw['updated_on'];
			$web['tasks'][$rw['requirements_id']][$inplace]++;
			$web['tasks'][$rw['requirements_id']]['total']++;
			$web['tasks'][$rw['requirements_id']]['user_group_name']= $rw['user_group_name'];
			$web['tasks'][$rw['requirements_id']]['cdate']= $rw['completion_date'];	
			if($task_status == 'upcoming' )
			{
				$datediff = (strtotime($rw['completion_date']) - strtotime(date('Y-m-d')));
				$days_to_go = floor($datediff/(60*60*24));
				$web['tasks'][$rw['requirements_id']]['days_to_go'] = $days_to_go;
			}
	
		}
	}
	return $web['tasks'] ;
}
function getCompanyWiseTasks($task_status, $company_id)
{
	global $web, $roc_saq, $lib;  
	
	$tbl = new table('customer');
	$tbl->cols('t1.*');
	$tbl->cols('m.merchant_type');
	$tbl->cols('m.roc_saq');
	$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id) as total");
	
	if($task_status == 'completed')
		$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND (inplace = 'Y' OR inplace = 'N' OR inplace = 'C' OR inplace = 'NA' OR inplace = 'NT' ) ) as filled");
	if($task_status == 'inprocess')
		$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND ( ready_for = 'review' OR ready_for = 'q' ) ) as filled");	
	if($task_status == 'upcoming')
		$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND ready_for = 'review') as filled");
	if($task_status == 'failed')
		$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND inplace = 'N') as filled");
	if($task_status == 'overdue')
		$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND completion_date < '".date('Y-m-d')."') as filled");
	if($task_status == 'overdue_open')
		$tbl->cols("(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND inplace != '' AND completion_date < '".date('Y-m-d')."') as filled");	

	$tbl->cols("CONCAT(qsa.first_name, ' ', qsa.last_name) AS qsa_name ");	
	$tbl->cols("CONCAT(qa.first_name, ' ', qa.last_name) AS qa_name ");	
	$tbl->join('merchant_type', 'm.id', 't1.merchant_type_id', 'm');
	$tbl->join('users', 'qsa.id', 't1.qsa_id', 'qsa');
	$tbl->join('users', 'qa.id', 't1.qa_id', 'qa');
	$tbl->condition("WHERE" ,"t1.id", $company_id);
	$tbl->orderby('total', 'desc');
		
	$rows = $tbl->getList();
	unset($tbl);
	$no = 0;
	$web[$task_status] = array();
	foreach( $rows as $rw )
	{
		//$web[$task_status][$no] = $rw;
		$web[$task_status][$no]['compliance_due_date'] = $lib->format_date($rw['compliance_due_date'], 'd M Y');
		$web[$task_status][$no]['values'] = '';
		$web[$task_status][$no]['maps'] = '';
		$web[$task_status][$no]['percentage'] = 0;
		$web[$task_status][$no]['roc_saq'] = strtoupper($rw['roc_saq']);
		if ( $rw['total'] > 0 )
			$web[$task_status][$no]['percentage'] = ( isset($rw['filled']) && $rw['filled'] > 0 )? number_format($rw['filled'] / $rw['total'] * 100, 2, '.', '') : 0;
		$web[$task_status][$no]['class'] = '';
		if ( date('Ymd') > $lib->format_date($rw['compliance_due_date'], 'Ymd') )
			$web[$task_status][$no]['class'] = ' class="danger"';
		if ( $web[$task_status][$no]['percentage'] == 100 )
			$web[$task_status][$no]['class'] = ' class="success"';
		$web[$task_status][$no]['qsa_name'] = $rw['qsa_name'];
		$web[$task_status][$no]['qa_name']  = $rw['qa_name'];		
		$web[$task_status][$no]['company_id']  	= $rw['id'];
		$web[$task_status][$no]['filled']  	  	= $rw['filled'];
		$web[$task_status][$no]['total']  		= $rw['total'];
		$no++;
	}
	
	return $web[$task_status] ;
}
?>