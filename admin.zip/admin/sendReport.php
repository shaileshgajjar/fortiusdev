<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(dirname(__FILE__).'/../lib/class.phpmailer.php');
require(dirname(__FILE__).'/../lib/prepare.graph.php');
require_once(dirname(__FILE__).'/../lib/phpMyGraph5.0.php');
require_once(dirname(__FILE__).'/../lib/sparkpost-api.php');
error_reporting(0);
$mail = new PHPMailer;
	global $lib;
	$today = getdate();
		//print_r($today);
		//notifications settings for company admin company user qsa and qa
		$tbl = new table('users');
		$tbl->cols("t1.email AS admin_email");
		$tbl->cols("CONCAT(t1.first_name,' ',t1.last_name) AS username");
		$tbl->condition("WHERE", "t1.userrole", "a");
		$tbl->condition("AND", "t1.username", "Admin");
		$admin_data = $tbl->getList();
		$admin['data']= array();
		
		unset($tbl);
		foreach( $admin_data as $rw3 )
		{
			$admin['data']['username'] = $web['settings']['assr_company_name']['value'];
			$admin['data']['email'] = $web['settings']['assr_company_email']['value'];
			$admin['data']['sparkpost_end_url'] = $web['settings']['sparkpost_end_url']['value'];
			$admin['data']['sparkpost_key'] = $web['settings']['sparkpost_key']['value'];
		}
		
		$tempData = array();
		$nSettingsDataArr = array();
		$tbl = new table('notification_settings');
		$tbl->cols("t1.users_id AS uid");		
		$tbl->cols("t1.comp_id");		
		$tbl->cols("t1.userrole");		
		$tbl->cols("t1.freq");		
		$tbl->cols("t1.time_to_send");		
		$tbl->cols("t1.content");		
		$tbl->cols("c.start_date");		
		$tbl->cols("c.compliance_due_date");		
		$tbl->cols("c.company_name");		
		$tbl->cols("u.email AS receiver_email");		
		$tbl->cols("CONCAT(u.first_name,' ',u.last_name) AS username");		
		$tbl->cols("mt.merchant_type");
		$tbl->join("customer", "c.id", "t1.comp_id", "c");		
		$tbl->join("merchant_type", "mt.id", "c.merchant_type_id", "mt");		
		$tbl->join("users", "u.id", "t1.users_id", "u");		
		$n_data = $tbl->getList();
		
		$users['n_settings']= array();
		$nSettingsDataArr = array();
		
		foreach( $n_data as $rw2)
			$users['n_settings']['userrole'] = $rw2;
			
		if($users['n_settings'] != '')
		{	
			foreach( $users['n_settings'] as $settings )
			{	// sending Projects status report to Company Admin as per their notifications settings
				
				if ($settings['userrole'] == 'c') 
				{
					//exit($settings['content']);
				  switch ($settings['content'])
				   {
					case 'html':
						sendHtmlReport($settings, $admin);
						break;
					case 'graph':   
							$headings = array();
							$graph  = 'compliance_graph_'.$settings['comp_id'].'_'.$settings['uid'].'_'.$settings['freq'].'_'. date('d_m_y_i').".png";
							$f_path =  APP_PATH .'emailtemplates/graph_notification_company_admin.html';
							
							$headings = getReportDuration($settings);
							$headings['company_name']           = $settings['company_name'];
							$headings['assessment_type']        = $settings['merchant_type'];
							$headings['start_date']             = $settings['start_date'];
							$headings['compliance_due_date']    = $settings['compliance_due_date'];
							//$receiver = $admin['data']['email'];
							$receiver = "shailesh.gajjar83@gmail.com";
							$sender = $admin['data']['email'];
			   				$html['frequency'] = $headings['frequency'];
			   				$html['company_name'] = $settings['company_name'];
			   				$html['assessment_type'] = $settings['merchant_type'];
			   				$html['start_date'] = $settings['start_date'];
			   				$html['compliance_due_date'] = $settings['compliance_due_date'];
							
							$mail->IsHTML(true);
							$mail->Body = preg_replace('/\[\]/','',$body);
						
							prepareReportGraph($settings);
							$mail->addAttachment(APP_PATH .'uploads/graphs/'.$graph);
							$html_content = get_mail_content($f_path, $html, false);
							$sparkpost = new sparkPostApi('https://api.sparkpost.com/api/v1/transmissions','1a0d96ca1f592c636d7e2e2736a45687085c25b3');
							$sparkpost-> from(array('email' => $sender,'name' => 'Support at PCI Comply'));
							$sparkpost-> subject($Subject);
							$sparkpost-> html($html_content);
							$sparkpost->setTo(array('shailesh.gajjar83@gmail.com',$receiver));
							$sparkpost->setReplyTo('support@pcicomply.com');
							try{
								$sparkpost->send();
								print "Message Sent";
							} 
							catch (Exception $e) {
								print $e;	
							}
							$sparkpost->close();
							//$lib->send_mail($f_path, $receiver, $sender, $Subject,'', $html, false);
							unlink(APP_PATH .'uploads/graphs/'.$graph);
							
							break; 
				   }
				}
				elseif($settings['userrole'] == 's' || $settings['userrole'] == 'q')
				{
					
				}
				elseif($settings['userrole'] == 'u' )
				{
					sendTaskReport($settings, $admin);
					
				}
			}
		}
sendCommentReport($admin);
?>