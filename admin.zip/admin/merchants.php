<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['pagetitle']				= $web['company'].' - Merchant';
$web['table']					= 'merchant';
$web['page']					= 'masters';
$web['subpage']					= 'merchants';
$web['editscript']				= 'merchant.php';
$web['listscript']				= 'merchants.php';
$_SESSION['backscript']			= '';


$web['search']['company_name']	= 'Company Name';
$web['search']['email']			= 'Email';

$web['title']	= 'Merchant';
$web['id']		= $request->get('id', '');
$web['task']	= $request->get('task', '');
$web['err']		= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'company_name');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'rowid');
$web['ot']	= $request->get('ot', 'asc');

//$web['msg']	= $request->get('msg', '');

$tbl = new table($web['table']);
if ( $web['task'] == 'delete' )
{
	$removeid	= $request->get('removeid', '');
	$tbl->delete('id', $removeid, 'in');
	add_log_history('DEL', 'MER', $session->get('uid'), $session->get('userrole'));
}

$tbl->cols('t1.id');
$tbl->cols('t1.company_name');
$tbl->cols('t1.dba');
$tbl->cols('t1.contact_name');
$tbl->cols('t1.business_address');
$tbl->cols('t1.isa_name');
$tbl->cols('t1.telephone');
$tbl->cols('t1.email');

if ( $web['sk'] != "" )
	$tbl->having($web['sb'], '%'.$web['sk'].'%', 'LIKE');
$tbl->orderby($web['ob'], $web['ot']);

$web['rows'] = $tbl->getList($web['pg'], $web['en']);
$web['total_pages'] = $tbl->getPages();
$web['rectitle'] = '<span>&nbsp;&nbsp;[No records]</span>';
if ( $tbl->getTotal() > 0 )
	$web['rectitle'] = '<span>&nbsp;&nbsp;[' . $tbl->getStart() . ' to ' . $tbl->getEnd() . ' out of ' . $tbl->getTotal() . ']</span>';
unset($tbl);

echo $twig->render('merchants.html', array('web' => $web));
