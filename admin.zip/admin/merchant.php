<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$listscripts = explode("/", $_SERVER["HTTP_REFERER"]);
$web['pagetitle']	= $web['company'].' - Merchant';
$web['table']		= 'merchant';
$web['page']		= 'masters';
$web['subpage']		= 'merchants';
$web['editscript']	= 'merchant.php';
$web['listscript']	= 'merchants.php';
$web['nextscript']	= '/merchants/assessment-timeframe.php';
$web['id']			= $request->get('id', '0');
$web['task']		= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']		= 'Merchant '.($web['id'] == '0' ? 'New' : 'Edit');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', '');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$web['fields'] = array();



$web['tbl'] = new table($web['table']);
if ( $web['id'] > 0 )
	$web['tbl']->load($web['id']);
	
	
if ( $web['task'] == 'save' || $web['task'] == 'continue' )
{
	$web['err'] = '';
	foreach($web['fields'] as $key => $value)
	
		$web['tbl']->setValue($key, $request->get($key, ''));
	$tbl = new table($web['table']);
	$found = $tbl->find('email', $request->get('email', ''));
	
	if ( $found && $web['id'] != $tbl->getValue('id') )
		$web['err'] = 'User is already exists with same email address';
	unset($tbl);
	
	if ( $web['err'] == '' )
	{
		$pwd = $request->get('pwd', '');
		if ( $pwd != '' )
			$web['tbl']->setValue('pwd', md5($pwd));
			$web['tbl']->setValue('userrole', 'm');
		$web['tbl']->save();
		$act = ($web['id'] == 0)?'ADD':'EDIT';
		add_log_history($act, 'MER', $session->get('uid'), $session->get('userrole'));
		
		if ( $pwd != '' )
		$web['tbl']->setValue('company_name', $request->get('company_name', ''));
		$web['tbl']->setValue('dba', $request->get('dba', ''));
		$web['tbl']->setValue('contact_name', $request->get('contact_name', ''));
		$web['tbl']->setValue('title', $request->get('title', ''));
		$web['tbl']->setValue('isa_name', $request->get('isa_name', ''));
		$web['tbl']->setValue('telephone', $request->get('telephone', ''));
		$web['tbl']->setValue('email', $request->get('email', ''));
		$web['tbl']->setValue('business_address', $request->get('business_address', ''));
		$web['tbl']->setValue('city', $request->get('city', ''));
		$web['tbl']->setValue('state', $request->get('state', ''));
		$web['tbl']->setValue('country', $request->get('country', ''));
		$web['tbl']->setValue('zip_code', $request->get('zip_code', ''));
		$web['tbl']->setValue('company_url', $request->get('company_url', ''));
		$web['tbl']->save();
		
	}
		
	
		$act = ($web['id'] == 0)?'ADD':'EDIT';
		add_log_history($act, 'MER', $session->get('uid'), $session->get('userrole'));
			
		if( $web['task'] == 'continue' )
		$session->set('company_name', $request->get('company_name') );
	
}
	
$web['fields'] = array();
$web['fields']['company_name']['value'] 	= $web['tbl']->getValue('company_name');
$web['fields']['dba']['value']	= $web['tbl']->getValue('dba');
$web['fields']['contact_name']['value']	= $web['tbl']->getValue('contact_name');
$web['fields']['telephone']['value']	= $web['tbl']->getValue('telephone');
$web['fields']['email']['value']	= $web['tbl']->getValue('email');

echo $twig->render('merchant.html', array('web' => $web));

