<?php
require(dirname(__FILE__).'/../config/config.new.php');
add_log_history('', 'LOGOUT', $session->get('uid'), $session->get('userrole'));
$session->set('uid', '');
$session->set('username', '');
$session->set('userrole', '');
header("Location: index.php");
exit;
?>
