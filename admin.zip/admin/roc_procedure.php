<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

// added to set version static for temporary purpose 
$web['version'] 	= $request->get('version', 'v32_');
$web['endpage']		= 'proc';
$web['id']			= $request->get('id', '0');
$web['pagetitle']	= $web['company'].' - Testing Procedure [ROC]';
$web['table']		= 'procedure';
$web['title']		= 'Testing Procedure [ROC] '.($web['id'] == '0' ? 'New' : 'Edit');
$web['editscript']	= 'roc_procedure.php';
$web['listscript']	= 'roc_procedures.php';
$web['type']		= '';
$web['roc_saq']		= 'roc';
require('procedure.php');
?>
