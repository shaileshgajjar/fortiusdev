<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['pagetitle']				= $web['company'].' - Admin';
$web['table']					= 'users';
$web['page']					= 'masters';
$web['subpage']					= 'admins';
$web['editscript']				= 'admin.php';
$web['listscript']				= 'admins.php';

$web['id']						= $request->get('id', '0');
$web['task']					= $request->get('task', '');
$web['err']						= $request->get('err', '');
$web['title']					= 'Admin '.($web['id'] == '0' ? 'New' : 'Edit');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'assessor_type');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$web['fields'] = array();
$web['fields']['email']				= array('value' => '');
$web['fields']['title']				= array('value' => '');
$web['fields']['first_name']		= array('value' => '');
$web['fields']['last_name']			= array('value' => '');
$web['fields']['company_name']		= array('value' => '');
$web['fields']['pci_credential']	= array('value' => '');
$web['fields']['mobile']			= array('value' => '');

$web['tbl'] = new table($web['table']);
if ( $web['id'] > 0 )
	$web['tbl']->load($web['id']);

if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	foreach($web['fields'] as $key => $value)
		$web['tbl']->setValue($key, $request->get($key, ''));
	$tbl = new table($web['table']);
	$found = $tbl->find('email', $request->get('email', ''));
	if ( $found && $web['id'] != $tbl->getValue('id') )
		$web['err'] = 'User is already exists with same email address';
	unset($tbl);

	if ( $web['err'] == '' )
	{
		$pwd = $request->get('pwd', '');
		if ( $pwd != '' )
			$web['tbl']->setValue('pwd', md5($pwd));
		$web['tbl']->setValue('userrole', 'a');
		$web['tbl']->save();
		$act = ($web['id'] == 0)?'ADD':'EDIT';
		add_log_history($act, 'ADMIN', $session->get('uid'), $session->get('userrole'));
	}
}

foreach($web['fields'] as $key => $value)
	$web['fields'][$key]['value'] = $web['tbl']->getValue($key);
unset($web['tbl']);

echo $twig->render('admin.html', array('web' => $web));
?>
