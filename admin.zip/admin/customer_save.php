$tbl_users = new table('users');
	$fields = array('email', 'company_id', 'uerrole');
	$value = array($request->get('email'), $web['id'], 'c');
	$web['err'] = '';
	$found = $tbl->find($fields, $value);
	if ( $found || ( $found && $web['id'] != $tbl->getValue('id') )
		$web['err'] = 'User is already exists with same email address';

	if ( $web['err'] == '' )
	{
		$tbl->load($web['id']);
		$pwd = $request->get('pwd', '');
		if ( $pwd != '' )
			$web['fields']['pwd']['value']	= md5($pwd);
		$tbl->savedata($web['fields']);
		$act = ($web['id'] == 0)?'ADD':'EDIT';
		add_log_history($act, 'ASSR', $session->get('uid'), 'a');
		$response->redirect($web['listscript']);
	}
	$web['err'] = '';
	$uid = 0;
	$sql  = "SELECT id,company_id FROM ".$oApp->prefix.'users';
	$sql .= " WHERE email = '".$email."' ";
	if ( $web['id'] != 0 )
		$sql .= " AND id != '".$web['id']."'";
	$rs = $oApp->db_query($sql);
	if ( $rw = $oApp->db_assoc($rs) )
		$uid = $rw['id'];
	$oApp->db_free($rs);
	if ( $web['id'] == 0 && $uid > 0)
		$web['err'] = 'User is already exists with same email address';
	if ( $web['err'] == '' )
	{
		$dtary = explode('-', $web['fields']['compliance_due_date']['value']);
		$web['fields']['compliance_due_date']['value'] = $dtary[0].'-'.$dtary[2].'-'.$dtary[1];
		$dtary = explode('-', $web['fields']['start_date']['value']);
		$web['fields']['start_date']['value'] = $dtary[0].'-'.$dtary[2].'-'.$dtary[1];
		$dtary = explode('-', $web['fields']['end_date']['value']);
		$web['fields']['end_date']['value'] = $dtary[0].'-'.$dtary[2].'-'.$dtary[1];
		$primary_id = $oApp->db_save_record($web['table'], $web['id'], $web['fields']);
		

		$sql = "SELECT id FROM ".$oApp->prefix."document WHERE company_id = '" .$primary_id. "'";
		$rs = $oApp->db_query($sql);
		$saverecord = false;
		if ( !$rw = $oApp->db_assoc($rs) )
			$saverecord = true;
		$oApp->db_free($rs);
		if ( $saverecord )
		{
			$sql = "SELECT roc_saq FROM ".$oApp->prefix."merchant_type WHERE id = '".$web['fields']['merchant_type_id']['value']."' ";
			$rs = $oApp->db_query($sql);
			if ( $rw  = $oApp->db_assoc($rs) )
				$merchant_type = $rw['roc_saq'];
			$oApp->db_free($rs);
			if($merchant_type == 'saq')
			{
				$sql  = "SELECT pm.procedure_id, p.requirements_id, p.sub_requirements_id";
				$sql .= " FROM ".$oApp->prefix.'procedure_merchant pm';
				$sql .= " JOIN ".$oApp->prefix."procedure p ON p.id = pm.procedure_id";
				$sql .= " WHERE pm.merchant_id = '".$web['fields']['merchant_type_id']['value']."'";
			}
			else
				$sql  = "SELECT id AS procedure_id, requirements_id, sub_requirements_id FROM ".$oApp->prefix."procedure";
			$rs = $oApp->db_query($sql);
			$fieldsDoc = array();
			while ( $rw = $oApp->db_assoc($rs) )
			{
				$fieldsDoc['company_id']['value']	= $primary_id;
				$fieldsDoc['procedure_id']['value'] = $rw['procedure_id'];
				$fieldsDoc['requirements_id']['value'] = $rw['requirements_id'];
				$fieldsDoc['sub_requirements_id']['value'] = $rw['sub_requirements_id'];
				$fieldsDoc['roc_saq']['value'] = $merchant_type;
				$oApp->db_save_record('document', 0, $fieldsDoc);
			}
		}
		$custId = 0;
		$usersFlds = array();
		$sql3  = "SELECT id FROM ".$oApp->prefix.'users';
		$sql3 .= " WHERE company_id = '".$primary_id."'  AND userrole='c' ";
		//exit($sql3);
		$rs3 = $oApp->db_query($sql3);
		if ( $rw3 = $oApp->db_assoc($rs3) )
			$custId = $rw3['id'];
		$pwd = $request->get('pwd', '');
			if($pwd)
			$usersFlds['pwd']['value'] 	= md5($pwd);
		$usersFlds['company_id']['value'] 		= $primary_id;
		$usersFlds['title']['value'] 			= $request->get('title', '');
		$usersFlds['first_name']['value'] 		= $request->get('first_name', '');
		$usersFlds['last_name']['value'] 		= $request->get('last_name', '');
		$usersFlds['email']['value'] 			= $request->get('email', '');
		$usersFlds['mobile']['value'] 			= $request->get('mobile', '');
		$usersFlds['userrole']['value'] 		= 'c';
		$oApp->db_save_record('users', $custId, $usersFlds);
		$act = ($custId == 0 ) ? 'ADD' : 'EDIT';
		add_log_history($act, 'CUST', $_SESSION['uid'], 'a');
	}