<?php
$web['table']					= $web['version'].$web['table'];
$web['title']					= str_replace('_', ' ', $web['version']).$web['title'];
$web['page']					= 'masters';
$web['subpage']					= 'sub_requirements';
$web['search']['t1.ref']		= 'Ref';
$web['search']['t1.title']		= 'PCI DSS Requirement';
$web['search']['requirement']	= 'Requirement';

$web['id']		= $request->get('id', '');
$web['task']	= $request->get('task', '');
$web['err']		= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'ref');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'rowid');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
if ( $web['task'] == 'delete' )
{
	$removeid	= $request->get('removeid', '');
	$tbl->delete('id', $removeid, 'in');
	add_log_history('DEL', 'SR', $session->get('uid'), $session->get('userrole'));
}

$tbl->cols('t1.*');
$tbl->cols('r.title AS requirement');
$tbl->join($web['version'].$web['type'].'requirements', 'r.id', 't1.requirements_id', 'r');
if ( $web['sk'] != "" )
	$tbl->having($web['sb'], '%'.$web['sk'].'%', 'LIKE');
$tbl->orderby($web['ob'], $web['ot']);

$web['rows'] = $tbl->getList($web['pg'], $web['en']);
$web['total_pages'] = $tbl->getPages();
$web['rectitle'] = '<span>&nbsp;&nbsp;[No records]</span>';
if ( $tbl->getTotal() > 0 )
	$web['rectitle'] = '<span>&nbsp;&nbsp;[' . $tbl->getStart() . ' to ' . $tbl->getEnd() . ' out of ' . $tbl->getTotal() . ']</span>';
unset($tbl);
echo $twig->render('sub_requirements.html', array('web' => $web));
?>
