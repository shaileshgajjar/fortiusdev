<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['addbtnshow']				= '0';
$web['pagetitle']				= $web['company'].' - Data';
$web['table']					= 'customer';
$web['page']					= 'inputs';
$web['editscript']				= 'fill-data.php';
$web['listscript']				= 'list-data.php';
$_SESSION['backscript']			= '';

$web['search']['merchant_type']	= 'Assessment Type';
$web['search']['company_name']	= 'Company Name';
$web['search']['contact_name']	= 'Contact Name';
$web['search']['telephone']		= 'Telephone';
$web['search']['email']			= 'Email';

$web['title']	= 'Data';
$web['id']		= $request->get('id', '');
$web['task']	= $request->get('task', '');
$web['err']		= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'title');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'rowid');
$web['ot']	= $request->get('ot', 'asc');

$web['msg']	= $request->get('msg', '');
//exit('here');

$tbl = new table($web['table']);
$tbl->cols('t1.*');
$tbl->cols('m.merchant_type');
$tbl->cols("CONCAT(u.first_name, ' ', u.last_name) AS username" );
$tbl->cols('u.mobile');
$tbl->cols('u.email');
$tbl->cols('(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id) AS total');
$tbl->cols('(SELECT COUNT(id) FROM document d WHERE d.company_id = t1.id AND inplace <> "" )  AS filled');
$tbl->join('merchant_type', 'm.id', 't1.merchant_type_id', 'm');
$tbl->join('users', 'u.company_id', 't1.id', 'u');
if ( $web['sk'] != "" )
	$tbl->condition('AND', $web['sb'], '%'.trim($web['sk']).'%', 'LIKE');
$tbl->condition('AND','u.userrole','c');
$tbl->orderby($web['ob'], $web['ot']);

$rows	= $tbl->getList($web['pg'], $web['en']);
$total	= $tbl->getTotal();
$web['total_pages'] = $tbl->getPages();
$web['rectitle'] = '<span>&nbsp;&nbsp;[No records]</span>';
if ( $tbl->getTotal() > 0 )
	$web['rectitle'] = '<span>&nbsp;&nbsp;[' . $tbl->getStart() . ' to ' . $tbl->getEnd() . ' out of ' . $tbl->getTotal() . ']</span>';
$no = 0;
foreach ( $rows as $rw)
{
	$web['rows'][$no] = $rw;
	$web['rows'][$no]['class'] = '';
	if ( date('Ymd') > $lib->format_date($rw['compliance_due_date'], 'Ymd') )
		$web['rows'][$no]['class'] = ' class="danger"';
	$web['rows'][$no]['compliance_due_date'] = $lib->format_date($rw['compliance_due_date'], 'd M Y');
	$web['rows'][$no]['percentage'] = 0;
	if ( $rw['total'] > 0 )
		$web['rows'][$no]['percentage'] = round($rw['filled'] / $rw['total'] * 100);
	if ( $web['rows'][$no]['percentage'] == 100 )
		$web['rows'][$no]['class'] = ' class="success"';
	$no++;
}

echo $twig->render('list-data.html', array('web' => $web));
?>