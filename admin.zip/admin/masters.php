<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");
$web['pagetitle']	= 'Security System - Masters';
$web['page']		= 'masters';
$web['title']		= 'Masters';

echo $twig->render('masters.html', array('web' => $web));
?>
