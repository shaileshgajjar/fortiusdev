<?php

/* front-list-data.html */
class __TwigTemplate_9f2f65fe917b11e1d25c8e0fc4d31d11 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-front-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-front-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t\t\t";
        // line 10
        $this->env->loadTemplate("_new-panel.html")->display($context);
        // line 11
        echo "\t\t\t<div class=\"table-responsive\">
\t\t\t\t<table class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t   <thead>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t <th class=\"text-center\"><input type=\"checkbox\" name=\"chkall\" onclick=\"dochkall(this.form)\" /></th>
\t\t\t\t\t\t <th class=\"text-center\">";
        // line 16
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Sr.#", 1 => "rowid", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 17
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Assessment Type", 1 => "merchant_type", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 18
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Company Name", 1 => "company_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 19
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Contact Name", 1 => "contact_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 20
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Telephone", 1 => "mobile", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 21
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Email", 1 => "email", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th class=\"text-center\">Action</th>
\t\t\t\t\t\t ";
        // line 23
        if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u"))) {
            // line 24
            echo "\t\t\t\t\t\t <th class=\"text-center\">Reports</th>
\t\t\t\t\t\t ";
        }
        // line 26
        echo "\t\t\t\t\t  </tr>
\t\t\t\t   </thead>
\t\t\t\t   <tbody>
\t\t\t\t\t  ";
        // line 29
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 30
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td class=\"text-center\"><input type=\"checkbox\" name=\"removeid[]\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "\" /></td>
\t\t\t\t\t\t <td class=\"text-center\">";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "rowid"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "merchant_type"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "contact_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "mobile"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "email"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td class=\"text-center\">
\t\t\t\t\t\t <button type=\"button\" title=\"Fill Data\" onclick=\"edit('";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "editscript"), "html", null, true);
            echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t ";
            // line 40
            if (((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s")) || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "i"))) {
                // line 41
                echo "\t\t\t\t\t\t <button type=\"button\" onclick=\"loadcompanies('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
                echo "');\" data-toggle=\"modal\" data-target=\"#div-filter\" title=\"Copy Filter to\" class=\"btn btn-primary btn-xs\"><span class=\"fa fa-filter\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t ";
            }
            // line 43
            echo "\t\t\t\t\t\t </td>
\t\t\t\t\t\t ";
            // line 44
            if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u"))) {
                // line 45
                echo "\t\t\t\t\t\t <td class=\"text-center\">
\t\t\t\t\t\t\t<button type=\"button\" onclick=\"report('";
                // line 46
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "', 'report-compliance.php');\" class=\"btn btn-success btn-xs btn-report\" title=\"Compliance/Sevirity\"><span class=\"glyphicon glyphicon-signal\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t<button type=\"button\" onclick=\"report('";
                // line 47
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "', 'report-priority.php');\" class=\"btn btn-warning btn-xs btn-report\" title=\"Priority\"><span class=\"glyphicon glyphicon-signal\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t </td>
\t\t\t\t\t\t ";
            }
            // line 50
            echo "\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 52
        echo "\t\t\t\t\t  ";
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows")) == 0)) {
            // line 53
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td colspan=\"11\">No Records</td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        // line 57
        echo "\t\t\t\t   </tbody>
\t\t\t\t   <tfoot>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t<td colspan=\"11\"></td>
\t\t\t\t\t  </tr>
\t\t\t\t   </tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
<div class=\"modal fade\" id=\"div-filter\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
\t\t\t\t<h4 class=\"modal-title\" id=\"filter-title\">Copy Filter from</h4>
\t\t\t</div>
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div id=\"filter-content\">
\t\t\t\t\t<label for=\"company_id\">Copy Filter to</label>
\t\t\t\t\t<input type=\"hidden\" name=\"from_id\" id=\"from_id\" value=\"\" />
\t\t\t\t\t<select name=\"company_id\" id=\"company_id\" class=\"form-controls\">
\t\t\t\t\t</select>
\t\t\t\t</div>
\t\t\t\t<div id=\"filter-update\" style=\"display:none;\">
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"modal-footer\">
\t\t\t\t<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
\t\t\t\t<button type=\"button\" id=\"save-filter\" onclick=\"copyfilter();\" class=\"btn btn-success\">Save</button>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
";
    }

    // line 93
    public function block_footer($context, array $blocks = array())
    {
        // line 94
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<script src=\"/assets/js/list.js\"></script>
\t<script type=\"text/javascript\">
\tfunction loadcompanies(id, company_name)
\t{
\t\t\$('#filter-content').show();
\t\t\$('#filter-update').hide();
\t\t\$('#filter-title').html('Copy Filter from '+company_name);
\t\t\$('#from_id').val(id);
\t\ttheurl = '/loadcompanies.php';
\t\tformfields = 'id='+id;
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\t\$('#company_id').html(data);
\t\t});
\t}
\t
\tfunction copyfilter()
\t{
\t\t\$('#filter-content').hide();
\t\t\$('#filter-update').show();
\t\ttheurl = '/copyfilter.php';
\t\tformfields = 'from_id='+\$('#from_id').val()+'&company_id='+\$('#company_id').val();
\t\t\$('#filter-update').html('Processing please wait!..');
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\t\$('#filter-update').html('Done..');
\t\t\t\$('#save-filter').prop('disabled', true);
\t\t});
\t}
\t</script>
";
    }

    public function getTemplateName()
    {
        return "front-list-data.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  223 => 94,  220 => 93,  181 => 57,  175 => 53,  172 => 52,  165 => 50,  159 => 47,  155 => 46,  152 => 45,  150 => 44,  147 => 43,  139 => 41,  137 => 40,  131 => 39,  126 => 37,  122 => 36,  118 => 35,  114 => 34,  110 => 33,  106 => 32,  102 => 31,  99 => 30,  95 => 29,  90 => 26,  86 => 24,  84 => 23,  79 => 21,  75 => 20,  71 => 19,  67 => 18,  63 => 17,  59 => 16,  52 => 11,  50 => 10,  46 => 9,  41 => 7,  37 => 6,  32 => 3,  29 => 2,);
    }
}
