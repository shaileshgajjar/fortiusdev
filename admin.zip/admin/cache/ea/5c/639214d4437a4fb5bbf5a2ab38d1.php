<?php

/* _front-header.html */
class __TwigTemplate_ea5c639214d4437a4fb5bbf5a2ab38d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t\t<!-- #section:basics/navbar.layout -->
\t\t<div id=\"navbar\" class=\"navbar navbar-default navbar-collapse h-navbar navbar-fixed-top\">
\t\t\t<div class=\"navbar-container\" id=\"navbar-container\">
\t\t\t\t
\t\t\t\t<div class=\"navbar-header pull-left\">
\t\t\t\t\t<!-- #section:basics/navbar.layout.brand -->
\t\t\t\t\t<a href=\"/dashboard.php\" class=\"navbar-brand\">
\t\t\t\t\t\t<small>
\t\t\t\t\t\t\t";
        // line 9
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c")) {
            // line 10
            echo "\t\t\t\t\t\t\t<i class=\"fa fa-laptop\"></i>
\t\t\t\t\t\t\t<!-- <img id=\"companylogo\" width=\"30px\" height=\"30px\" class=\"nav-user-photo\" src=\"/../../uploads/logos/";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "company_logo"), "method"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "company_name"), "method"), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "company_name"), "method"), "html", null, true);
            echo "\" /> -->
\t\t\t\t\t\t\t<span>";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "company_name"), "method"), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t";
        } else {
            // line 14
            echo "\t\t\t\t\t\t\t<i class=\"fa fa-user\"></i>
\t\t\t\t\t\t\t<span>";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "username"), "method"), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t";
        }
        // line 17
        echo "\t\t\t\t\t\t</small>
\t\t\t\t\t</a>

\t\t\t\t\t<!-- /section:basics/navbar.layout.brand -->

\t\t\t\t\t<!-- #section:basics/navbar.toggle -->
\t\t\t\t\t<button class=\"pull-right navbar-toggle navbar-toggle-img collapsed\" type=\"button\" data-toggle=\"collapse\" data-target=\".navbar-buttons,.navbar-menu\">
\t\t\t\t\t\t<span class=\"sr-only\">Toggle user menu</span>
\t\t\t\t\t\t";
        // line 25
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "users_avtar"), "value") != "")) {
            // line 26
            echo "\t\t\t\t\t\t\t\t<img id=\"mobprofilepic\" src=\"/uploads/avtars/";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "users_avtar"), "value"), "html", null, true);
            echo "\" alt=\"Avtar\" title=\"Avtar\" />
\t\t\t\t\t\t";
        } else {
            // line 28
            echo "\t\t\t\t\t\t\t\t<img id=\"mobprofilepic\" src=\"/assets/avatars/avatar4.png\" alt=\"Avtar\" title=\"Avtar\" />
\t\t\t\t\t\t";
        }
        // line 30
        echo "\t\t\t\t\t</button>

\t\t\t\t\t<button class=\"pull-right navbar-toggle collapsed\" type=\"button\" data-toggle=\"collapse\" data-target=\"#sidebar\">
\t\t\t\t\t\t<span class=\"sr-only\">Toggle sidebar</span>

\t\t\t\t\t\t<span class=\"icon-bar\"></span>

\t\t\t\t\t\t<span class=\"icon-bar\"></span>

\t\t\t\t\t\t<span class=\"icon-bar\"></span>
\t\t\t\t\t</button>

\t\t\t\t\t<!-- /section:basics/navbar.toggle -->
\t\t\t\t\t\t
\t\t\t\t</div>
\t\t\t\t
\t\t\t\t<!-- #section:basics/navbar.dropdown -->
\t\t\t\t<div class=\"navbar-buttons navbar-header pull-right  collapse navbar-collapse\" role=\"navigation\">
\t\t\t\t\t<ul class=\"nav ace-nav\">
\t\t\t\t\t\t<!-- #section:basics/navbar.user_menu -->
\t\t\t\t\t\t<li class=\"light-blue user-min\">
\t\t\t\t\t\t\t<input type=\"hidden\" name=\"lastid\" id=\"lastid\" value=\"\"> 
\t\t\t\t\t\t\t<a href=\"#\" data-toggle=\"modal\" onclick=\"getlatestchats('";
        // line 52
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method"), "html", null, true);
        echo "');\" data-target=\"#latest-chats\">
\t\t\t\t\t\t\t <span title=\"\" class=\"badge notifications\"></span>
\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-bell\"> </i>
\t\t\t\t\t\t\t</a>\t\t\t\t\t\t\t\t
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"light-blue user-min\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"light-blue user-min\">
\t\t\t\t\t\t\t<a data-toggle=\"dropdown\" href=\"#\" class=\"dropdown-toggle\">
\t\t\t\t\t\t\t\t";
        // line 62
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "users_avtar"), "value") != "")) {
            // line 63
            echo "\t\t\t\t\t\t\t\t\t\t<img id=\"profilepic\" class=\"nav-user-photo\" src=\"/../../uploads/avtars/";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "users_avtar"), "value"), "html", null, true);
            echo "\" alt=\"Avtar\" title=\"Avtar\" />
\t\t\t\t\t\t\t\t";
        } else {
            // line 65
            echo "\t\t\t\t\t\t\t\t\t\t<img id=\"profilepic\" class=\"nav-user-photo\" src=\"/assets/avatars/avatar4.png\" alt=\"Avtar\" title=\"Avtar\" />
\t\t\t\t\t\t\t\t";
        }
        // line 67
        echo "\t\t\t\t\t\t\t\t<span class=\"user-info\">
\t\t\t\t\t\t\t\t\t<small>Welcome,</small>
\t\t\t\t\t\t\t\t\t";
        // line 69
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "username"), "method"), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t</span>

\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-caret-down\"></i>
\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t<ul class=\"user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0);\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-globe\"></i>
\t\t\t\t\t\t\t\t\t\t";
        // line 79
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "get_remote", array(), "method"), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t<li class=\"divider\"></li>

\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"/login_history.php\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-clock-o\"></i>
\t\t\t\t\t\t\t\t\t\tLogs
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t";
        // line 92
        if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u"))) {
            // line 93
            echo "\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\" data-toggle=\"modal\" onclick=\"getsettings('";
            // line 94
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method"), "html", null, true);
            echo "');\" data-target=\"#email_settings\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-cog\"></i>
\t\t\t\t\t\t\t\t\t\tSettings
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
            // line 99
            if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c")) {
                // line 100
                echo "\t\t\t\t\t\t\t\t";
            }
            // line 101
            echo "\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\" data-toggle=\"modal\" onclick=\"get_groups('";
            // line 102
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "');\" data-target=\"#join_group\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-cog\"></i>
\t\t\t\t\t\t\t\t\t\tJoin Group
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
        }
        // line 108
        echo "
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\" data-toggle=\"modal\" data-target=\"#profile\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-user\"></i>
\t\t\t\t\t\t\t\t\t\tProfile
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\" data-toggle=\"modal\" data-target=\"#upload_avtar\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-user\"></i>
\t\t\t\t\t\t\t\t\t\tChange Profile Picture
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
        // line 121
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c")) {
            // line 122
            echo "\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\" data-toggle=\"modal\" data-target=\"#upload_logo\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-user\"></i>
\t\t\t\t\t\t\t\t\t\tChange Logo
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
        }
        // line 129
        echo "\t\t\t\t\t\t\t\t";
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u")) {
            // line 130
            echo "\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\" data-toggle=\"modal\" data-target=\"#general-comments\" onclick=\"get_gen_comment('";
            // line 131
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "company_id"), "value"), "html", null, true);
            echo "', '0','u', 'Admin');\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-edit\"></i>
\t\t\t\t\t\t\t\t\t\tComment
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
        }
        // line 137
        echo "\t\t\t\t\t\t\t\t<li class=\"divider\"></li>

\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"/logout.php\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-power-off\"></i>
\t\t\t\t\t\t\t\t\t\tLogout
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</li>

\t\t\t\t\t\t<!-- /section:basics/navbar.user_menu -->
\t\t\t\t\t</ul>
\t\t\t\t</div>

\t\t\t</div><!-- /.navbar-container -->
\t\t</div>
\t\t<!-- /section:basics/navbar.layout -->";
    }

    public function getTemplateName()
    {
        return "_front-header.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  230 => 137,  221 => 131,  218 => 130,  215 => 129,  206 => 122,  204 => 121,  189 => 108,  180 => 102,  177 => 101,  174 => 100,  172 => 99,  164 => 94,  161 => 93,  159 => 92,  126 => 67,  122 => 65,  116 => 63,  101 => 52,  77 => 30,  67 => 26,  65 => 25,  55 => 17,  50 => 15,  47 => 14,  42 => 12,  31 => 10,  19 => 1,  272 => 154,  268 => 153,  231 => 119,  201 => 91,  198 => 90,  193 => 79,  143 => 79,  139 => 5,  136 => 4,  130 => 69,  127 => 244,  123 => 242,  120 => 241,  117 => 240,  114 => 62,  111 => 238,  108 => 237,  105 => 236,  102 => 235,  99 => 234,  96 => 233,  93 => 232,  90 => 231,  88 => 90,  84 => 88,  82 => 87,  73 => 28,  71 => 79,  63 => 73,  57 => 70,  53 => 68,  51 => 67,  43 => 61,  41 => 60,  36 => 57,  34 => 11,  29 => 9,  27 => 4,  22 => 1,);
    }
}
