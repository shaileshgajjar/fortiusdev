<?php

/* customer.html */
class __TwigTemplate_406176c8957bc8bef0698ff039018880 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") || (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "continue") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == "")))) {
            // line 4
            echo "\t";
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save")) {
                // line 5
                echo "\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
                echo "\">
\t";
            }
            // line 6
            echo "\t
\t";
            // line 7
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "continue")) {
                // line 8
                echo "\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
                echo "\">
\t";
            }
            // line 9
            echo "\t
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"company_name\" id=\"company_name\" value=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "company_name"), "value"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"customer.php\" />
</form>
";
        } else {
            // line 23
            echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"customer.php\" />
\t\t\t<div class=\"widget-box widget-color-blue\">
\t\t\t\t<!-- #section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-header\">
\t\t\t\t\t<h5 class=\"widget-title smaller lighter\">
\t\t\t\t\t\t<i class=\"ace-icon fa fa-edit\"></i>
\t\t\t\t\t\t";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
            echo "
\t\t\t\t\t</h5>
\t\t\t\t</div>

\t\t\t\t<!-- /section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-body\">
\t\t\t\t\t<div class=\"widget-main\">
\t\t\t\t\t\t";
            // line 55
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") != "")) {
                // line 56
                echo "\t\t\t\t\t\t<div class=\"alert alert-danger\" role=\"alert\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err"), "html", null, true);
                echo "</div>
\t\t\t\t\t\t";
            }
            // line 58
            echo "\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">Client Details</div>
\t\t\t\t\t\t";
            // line 60
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id") == 0)) {
                // line 61
                echo "\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessment Version</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<select required id=\"assessment_version\" name=\"assessment_version\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t<option value=\"v31_\"";
                // line 65
                if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assessment_version"), "value") == "v31_")) {
                    echo " selected=\"selected\"";
                }
                echo ">Version 3.1</option>
\t\t\t\t\t\t\t\t\t<option value=\"v32_\"";
                // line 66
                if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assessment_version"), "value") == "v32_")) {
                    echo " selected=\"selected\"";
                }
                echo ">Version 3.2</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t ";
            } else {
                // line 71
                echo "\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessment Version</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t";
                // line 74
                if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assessment_version"), "value") == "v31_")) {
                    // line 75
                    echo "\t\t\t\t\t\t\t\t\t<input class=\"form-control\" autocomplete=\"off\" type=\"text\" value=\"Version 3.1\" readonly/>
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"assessment_version\" id=\"assessment_version\" value=\"";
                    // line 76
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assessment_version"), "value"), "html", null, true);
                    echo "\" />
\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assessment_version"), "value") == "v32_")) {
                    // line 78
                    echo "\t\t\t\t\t\t\t\t\t<input class=\"form-control\" autocomplete=\"off\" type=\"text\" value=\"Version 3.2\" readonly/>
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"assessment_version\" id=\"assessment_version\" value=\"";
                    // line 79
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assessment_version"), "value"), "html", null, true);
                    echo "\" />
\t\t\t\t\t\t\t\t";
                }
                // line 81
                echo "\t\t\t\t\t\t\t  
\t\t\t\t\t\t\t   
\t\t\t\t\t\t\t </div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            }
            // line 86
            echo "\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessment Type</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t";
            // line 89
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id") == 0)) {
                // line 90
                echo "\t\t\t\t\t\t\t\t<select required id=\"merchant_type_id\" name=\"merchant_type_id\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t";
                // line 91
                echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "merchant_types");
                echo "
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t   ";
            } else {
                // line 94
                echo "\t\t\t\t\t\t\t   <input class=\"form-control\" autocomplete=\"off\" type=\"text\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "m_type"), "html", null, true);
                echo "\" readonly/>
\t\t\t\t\t\t\t   <input type=\"hidden\" name=\"merchant_type_id\" id=\"merchant_type_id\" value=\"";
                // line 95
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "merchant_type_id"), "value"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t    ";
            }
            // line 97
            echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessor QSA(s)</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\" style=\"padding:0px;\">
\t\t\t\t\t\t\t\t";
            // line 102
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "qsas"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["qsa"]) {
                // line 103
                echo "\t\t\t\t\t\t\t\t\t<div class=\"col-sm-3\">
\t\t\t\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t\t\t\t<input";
                // line 105
                if (in_array($this->getAttribute((isset($context["qsa"]) ? $context["qsa"] : null), "id"), $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "selectedqsas"))) {
                    echo " checked=\"checked\"";
                }
                echo " type=\"checkbox\" name=\"qsas[]\" id=\"qsas";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["qsa"]) ? $context["qsa"] : null), "id"), "html", null, true);
                echo "\" class=\"ace\" />
\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"> ";
                // line 106
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["qsa"]) ? $context["qsa"] : null), "first_name"), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["qsa"]) ? $context["qsa"] : null), "last_name"), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['qsa'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 110
            echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessor QA</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<div id=\"qa_list\">
\t\t\t\t\t\t\t\t\t<select required id=\"qa_id\" name=\"qa_id\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t<option value=\"0\">Select QA</option>
\t\t\t\t\t\t\t\t\t\t";
            // line 118
            echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "qas");
            echo "
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"company_name\" id=\"company_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\trequired type=\"text\" value=\"";
            // line 127
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "company_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company Address</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"company_address\" id=\"company_address\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\trequired type=\"text\" value=\"";
            // line 134
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "company_address"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company URL</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"company_url\" id=\"company_url\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\ttype=\"url\" value=\"";
            // line 141
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "company_url"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Title</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<select required id=\"title\" name=\"title\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t<option value=\"mr\"";
            // line 148
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "title"), "value") == "mr")) {
                echo " selected=\"selected\"";
            }
            echo ">Mr.</option>
\t\t\t\t\t\t\t\t\t<option value=\"mrs\"";
            // line 149
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "title"), "value") == "mrs")) {
                echo " selected=\"selected\"";
            }
            echo ">Mrs.</option>
\t\t\t\t\t\t\t\t\t<option value=\"miss\"";
            // line 150
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "title"), "value") == "miss")) {
                echo " selected=\"selected\"";
            }
            echo ">Miss.</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Contact First Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"first_name\" id=\"first_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\ttype=\"text\" value=\"";
            // line 158
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "first_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Contact Last Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"last_name\" id=\"last_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\ttype=\"text\" value=\"";
            // line 165
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "last_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Contact Phone</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"mobile\" id=\"mobile\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\ttype=\"text\" value=\"";
            // line 172
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "mobile"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Compliance Due Date</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t<label for=\"compliance_due_date\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>
\t\t\t\t\t\t\t\t<input id=\"compliance_due_date\" type=\"text\" name=\"compliance_due_date\" class=\"date-picker form-control\" value=\"";
            // line 181
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "compliance_due_date"), "value"), "html", null, true);
            echo "\"  />
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Start Date</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" id=\"start_date\" type=\"text\" name=\"start_date\" value=\"";
            // line 189
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "start_date"), "value"), "html", null, true);
            echo "\" readonly/>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">End Date</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" id=\"end_date\" type=\"text\" name=\"end_date\" value=\"";
            // line 197
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "end_date"), "value"), "html", null, true);
            echo "\" readonly/>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">Login Details</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Email</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"email\" id=\"email\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\ttype=\"email\" value=\"";
            // line 206
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "email"), "value"), "html", null, true);
            echo "\" required />
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Password</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"pwd\" id=\"pwd\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\t\t";
            // line 214
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id") == 0)) {
                // line 215
                echo "\t\t\t\t\t\t\t\t\t\trequired
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 217
            echo "\t\t\t\t\t\t\t\t\t\ttype=\"password\" value=\"\" placeholder=\"Enter password\" pattern=\"(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!,@,#,\$,%,&,*,\\(,\\)]).{8,}\" 
\t\t\t\t\t\t\t\t\t\tdata-bv-regexp-message=\"Minimum 8 char includes one capital, one number and one special char ! @ # \$ % & * ( )\" />
\t\t\t\t\t\t\t\t\t<div class=\"pull-left\">[Keep blank to do not change]</div>
\t\t\t\t\t\t\t\t\t<div style=\"clear:both;\"></div>
\t\t\t\t\t\t\t\t\t<small id=\"errpwd\" style=\"display:block; color:#a94442; margin-bottom:10px; margin-top:5px;\">Minimum 8 char includes one capital, one number and one special char ! @ # \$ % &amp; * ( )</small>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">Assessor Company</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"assr_company_name\" id=\"assr_company_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\treadonly type=\"text\" value=\"";
            // line 229
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assr_company_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company Address</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"assr_company_address\" id=\"assr_company_address\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\treadonly type=\"text\" value=\"";
            // line 236
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assr_company_address"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company URL</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"assr_company_url\" id=\"assr_company_url\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\treadonly type=\"url\" value=\"";
            // line 243
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assr_company_url"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<div class=\"col-lg-10 col-lg-offset-2\">
\t\t\t\t\t\t\t\t<button type=\"submit\" title=\"Save\" class=\"btn btn-success\"><span class=\"glyphicon glyphicon-ok\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t\t<button type=\"button\" title=\"Cancel\" class=\"btn btn-danger\" onclick=\"this.form.action='";
            // line 249
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "'; this.form.submit();\"><span class=\"glyphicon glyphicon-arrow-left\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
";
        }
    }

    // line 262
    public function block_footer($context, array $blocks = array())
    {
        // line 263
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
<script type=\"text/javascript\">
";
        // line 268
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") || (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "continue") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == "")))) {
            // line 269
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 273
            echo "\$(document).ready(function() {
    \$('#frm').bootstrapValidator();
\t\$( \"#pwd\" ).keyup(function() {
\t\tif ( \$('#pwd').val() == '' )
\t\t\t\$('#errpwd').show();
\t\telse
\t\t\t\$('#errpwd').hide();
\t});
\t\$(\".date-picker\").datepicker({
\t\tformat: 'mm-dd-yyyy'
\t}).on('changeDate', function(ev){
\t\t\$(\".datepicker\").hide();
\t});
});
";
        }
        // line 288
        echo "function loadqsa(id)
{
\tif ( id != '' )
\t{
\t\ttheurl = 'loadqsa.php?id='+id;
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t
\t\t\t\$('#qa_id').html(data);
\t\t});
\t}
}
function gotowizards()
{
\t\$('#frm').bootstrapValidator();
\t\$('#task').val('continue');
}
</script>
";
    }

    public function getTemplateName()
    {
        return "customer.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  574 => 288,  557 => 273,  551 => 269,  549 => 268,  540 => 263,  537 => 262,  520 => 249,  511 => 243,  501 => 236,  491 => 229,  477 => 217,  473 => 215,  471 => 214,  460 => 206,  448 => 197,  437 => 189,  426 => 181,  414 => 172,  404 => 165,  394 => 158,  381 => 150,  375 => 149,  369 => 148,  359 => 141,  349 => 134,  339 => 127,  327 => 118,  317 => 110,  297 => 106,  287 => 105,  283 => 103,  266 => 102,  259 => 97,  254 => 95,  249 => 94,  243 => 91,  240 => 90,  238 => 89,  233 => 86,  226 => 81,  221 => 79,  218 => 78,  213 => 76,  210 => 75,  208 => 74,  203 => 71,  193 => 66,  187 => 65,  181 => 61,  179 => 60,  175 => 58,  169 => 56,  167 => 55,  157 => 48,  147 => 41,  143 => 40,  139 => 39,  135 => 38,  130 => 36,  126 => 35,  122 => 34,  118 => 33,  114 => 32,  110 => 31,  100 => 23,  93 => 19,  89 => 18,  85 => 17,  81 => 16,  77 => 15,  73 => 14,  69 => 13,  65 => 12,  61 => 11,  57 => 10,  54 => 9,  48 => 8,  46 => 7,  43 => 6,  37 => 5,  34 => 4,  32 => 3,  29 => 2,);
    }
}
