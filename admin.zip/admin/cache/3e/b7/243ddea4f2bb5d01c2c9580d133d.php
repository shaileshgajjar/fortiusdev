<?php

/* merchants.html */
class __TwigTemplate_3eb7243ddea4f2bb5d01c2c9580d133d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"entity\" id=\"entity\" value=\"\" />
\t\t\t";
        // line 11
        $this->env->loadTemplate("_new-panel.html")->display($context);
        // line 12
        echo "\t\t\t<div class=\"table-responsive\">
\t\t\t\t<!--";
        // line 13
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "msg") != "")) {
            // line 14
            echo "\t\t\t\t<div id=\"orderform-success-alert\" class=\"alert alert-success\">  Download link sent to your email ID registered with us.  </div>
\t\t\t\t";
        }
        // line 15
        echo " -->
\t\t\t\t<table id=\"simple-table\" class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t   <thead>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t <th class=\"text-center\">
\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"ace\" />
\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t </th>
\t\t\t\t\t\t <th class=\"text-center text-nowrap\">";
        // line 25
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Sr.#", 1 => "rowid", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 26
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Company Name", 1 => "company_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 27
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "DBA", 1 => "dba", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 28
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "ISA Name", 1 => "isa_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 29
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Contact Name", 1 => "contact_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 30
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Telephone", 1 => "telephone", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 31
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Email", 1 => "email", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 32
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Business Address", 1 => "business_address", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t  <th class=\"text-center text-nowrap\">Action</th>
\t\t\t\t\t\t
\t\t\t\t\t  </tr>
\t\t\t\t   </thead>
\t\t\t\t   <tbody>
\t\t\t\t\t  ";
        // line 38
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 39
            echo "\t\t\t\t\t  <tr";
            echo $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "class");
            echo ">
\t\t\t\t\t\t <td class=\"text-center\">
\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"removeid[]\" class=\"ace\" value=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t </td>
\t\t\t\t\t\t <td class=\"text-center text-nowrap\">";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "rowid"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "dba"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "isa_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "contact_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "telephone"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 52
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "email"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "business_address"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td class=\"text-center text-nowrap\">
\t\t\t\t\t\t <button type=\"button\" title=\"Edit\" onclick=\"edit('";
            // line 55
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "editscript"), "html", null, true);
            echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t </td>
\t\t\t\t\t\t 
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 60
        echo "\t\t\t\t\t  ";
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows")) == 0)) {
            // line 61
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td colspan=\"11\">No Records</td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        // line 65
        echo "\t\t\t\t   </tbody>
\t\t\t\t   <tfoot>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t<td class=\"text-center\"><button type=\"button\" title=\"Delete\" onclick=\"delconfirm(this.form);\" class=\"btn btn-danger\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></button></td>
\t\t\t\t\t\t<td colspan=\"11\"></td>
\t\t\t\t\t  </tr>
\t\t\t\t   </tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
<!--<div class=\"modal fade\" id=\"loading\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Processing..</h4>
\t\t\t</div>
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div id=\"proc-guidance\">
\t\t\t\t\t<p> Please wait!! </p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>-->
";
    }

    // line 92
    public function block_footer($context, array $blocks = array())
    {
        // line 93
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
<script src=\"/admin/js/list.js\"></script>
<script>
\$(document).ready(function() {
\t\$('#loading').modal('hide');
\t\$('div.alert-success').fadeOut(6000);
 });
</script>
";
    }

    public function getTemplateName()
    {
        return "merchants.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  217 => 93,  214 => 92,  184 => 65,  178 => 61,  175 => 60,  162 => 55,  157 => 53,  153 => 52,  149 => 51,  145 => 50,  141 => 49,  137 => 48,  133 => 47,  129 => 46,  122 => 42,  115 => 39,  111 => 38,  102 => 32,  98 => 31,  94 => 30,  90 => 29,  86 => 28,  82 => 27,  78 => 26,  74 => 25,  62 => 15,  58 => 14,  56 => 13,  53 => 12,  51 => 11,  46 => 9,  41 => 7,  37 => 6,  32 => 3,  29 => 2,);
    }
}
