<?php

/* assessment-reviewed-managed-service-providers.html */
class __TwigTemplate_3d143cf0189d2fd738f5932758c7acec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 15
            echo "<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />

\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 34
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 35
            echo "      <!-- Tab panes -->
\t\t<div class=\"tab-content tab_border\">
            <div class=\"screen7_inner_part widget-box widget-color-blue\">
                <div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i> 4 Reviewed Environment </h4>
                </div>
                <div class=\"widget-body\">
                \t<div class=\"widget-main widget_main_extra_part\">
                    \t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.12\tManaged service providers</div>
                        <div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\tFor managed service provider (MSP) reviews, the assessor must clearly identify which requirements in this document apply to the MSP (and are included in the review), and which are not included in the review and are the responsibility of the MSP’s customers to include in their reviews. Include information about which of the MSP’s IP addresses are scanned as part of the MSP’s quarterly vulnerability scans, and which IP addresses are the responsibility of the MSP’s customers to include in their own quarterly scans:
\t\t\t\t\t\t</div>
                    \t<div class=\"screen9_table_block_part screen10_extra screen11_part\">
                            <div class=\"assesment_reiview_env_soft_data_bg screen_field_part\">
                                <table class=\"table table-striped\">
                                  <tbody>
                                    <tr>
                                        <td class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Identify whether the entity being assessed is a managed services provider.(yes/no)</strong></td>
\t\t\t\t\t\t\t\t\t\t<td align=\"center\">
\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock pull-left\" >
\t\t\t\t\t\t\t\t\t\t\t<input value=\"1\" id=\"assess_yes_no-1-1\" ";
            // line 55
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), 0), "assess_yes_no") == "yes")) {
                echo " checked=\"checked\"";
            }
            echo " name=\"assess_yes_no1\" data-size=\"large\" data-handle-width=\"50\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"assess_yes_no\" id=\"assess_yes_no1\" value=\"";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), 0), "assess_yes_no"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</td>
                                    </tr>
                                    <tr>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>If YES then please fill the below information and if NO then fill NA below:</strong></td>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"></td>
                                    </tr>
                                    <tr>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>List the requirements that apply to the MSP and are included in thia assessment.</strong></td>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"detail_1\" class=\"form-control \" rows=\"2\">";
            // line 66
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), 0), "detail_1"), "html", null, true);
            echo "</textarea></td>
                                    </tr>
                                    <tr>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>List the requirements that are the responsibility of the MSP' customers (and have not been included in this assessment).</strong></td>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"detail_2\" class=\"form-control\" rows=\"2\">";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), 0), "detail_2"), "html", null, true);
            echo "</textarea></td>
                                    </tr>
                                    <tr>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Provide the name of the assessor who attests taht the testing of these requirements and/or responsibilities of the MSP is accurately represented in the signed Attestation of Compliance.</strong></td>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"detail_3\" class=\"form-control\" rows=\"2\">";
            // line 74
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), 0), "detail_3"), "html", null, true);
            echo "</textarea></td>
                                    </tr>
                                    <tr>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Identify which of the MSP's IP addresses are scanned as part of the MSP's Quarterly vulnerability scans.</strong></td>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"detail_4\" class=\"form-control yes_no\" rows=\"2\">";
            // line 78
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), 0), "detail_4"), "html", null, true);
            echo "</textarea></td>
                                    </tr>
                                    <tr>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Identify which of the MSP's IP addresses are the responsibility of the MSP's customers.</strong></td>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"detail_5\" class=\"form-control \"  rows=\"2\">";
            // line 82
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), 0), "detail_5"), "html", null, true);
            echo "</textarea></td>
                                    </tr>
                                  </tbody>
                                </table>
                            </div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 89
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button> 
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</form>
</div>
";
        }
    }

    // line 98
    public function block_footer($context, array $blocks = array())
    {
        // line 99
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script src=\"/assets/js/chosen.jquery.js\"></script>
\t<link href=\"/assets/css/bootstrap-switch.css\" type=\"text/css\" rel=\"stylesheet\">
\t<script src=\"/assets/js/bootstrap-switch.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 111
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 112
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 116
            echo "\$(document).ready(function() {
\t\$('#frm').bootstrapValidator();
\t\$(\".switch\").bootstrapSwitch();
\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\tary = \$(this).attr('id').split('-');
\t\tval = state ? 'yes' : 'no';
\t\t\$('#'+ary[0]+ary[2]).val(val);
\t});
});
";
        }
        // line 126
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "assessment-reviewed-managed-service-providers.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  252 => 126,  240 => 116,  234 => 112,  232 => 111,  216 => 99,  213 => 98,  200 => 89,  190 => 82,  183 => 78,  176 => 74,  169 => 70,  162 => 66,  149 => 56,  143 => 55,  121 => 35,  119 => 34,  114 => 32,  109 => 30,  105 => 29,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  80 => 22,  71 => 15,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
