<?php

/* loaddocuments.html */
class __TwigTemplate_c789db4f9d88ad71e912fa7d0e736d3d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t<table class=\"table table-bordered table-hover table-striped table-condensed\">
\t   <thead>
\t\t  <tr>
\t\t\t <th class=\"text-center\">Select</th>
\t\t\t <th>Documents</th>
\t\t</tr>
\t   </thead>
\t   <tbody>
\t\t ";
        // line 9
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "documents"));
        foreach ($context['_seq'] as $context["_key"] => $context["documents"]) {
            // line 10
            echo "\t\t<tr>
\t\t\t <td class=\"text-center\"><input type=\"radio\" name=\"radioupdoc\" id=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["documents"]) ? $context["documents"] : null), "id"), "html", null, true);
            echo "\" onclick=\"copydocumentforprocedure('";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["documents"]) ? $context["documents"] : null), "id"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["documents"]) ? $context["documents"] : null), "document"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["documents"]) ? $context["documents"] : null), "company_id"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["documents"]) ? $context["documents"] : null), "procedure_id"), "html", null, true);
            echo "');\"/></td>
\t\t\t <td>";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["documents"]) ? $context["documents"] : null), "document"), "html", null, true);
            echo "</td>
\t\t</tr>
\t\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['documents'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 15
        echo "\t   </tbody>
\t</table>
";
    }

    public function getTemplateName()
    {
        return "loaddocuments.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 15,  48 => 12,  36 => 11,  33 => 10,  29 => 9,  19 => 1,);
    }
}
