<?php

/* _kanban-grid.html */
class __TwigTemplate_fbd9bf710df513f5364e4b6a5f5214b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"kanban_board\">
<div class=\"col-lg-15\">
\t  <div class=\"panel\">
\t\t<div class=\"panel-heading\" >
\t\t";
        // line 5
        $context["count"] = "0";
        // line 6
        echo "\t\t
\t\t";
        // line 7
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "customers"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 8
            echo "\t\t\t";
            $context["company_id"] = $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id");
            // line 9
            echo "\t\t\t";
            $context["div_width"] = $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage");
            // line 10
            echo "\t\t\t\t\t";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage") > "85")) {
                // line 11
                echo "\t\t\t\t\t\t";
                $context["div_width"] = "86";
                // line 12
                echo "\t\t\t\t\t";
            }
            echo "\t
\t\t\t<div class=\"board_block_bg col-sm-3  \" >
\t\t\t<div class=\"col-lg-16 tasks\" onclick=\"javascript:edit('";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', 'fill-data.php');\" ><strong>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
            echo "</strong></div>
\t\t\t\t\t<div class=\"board_block_part\">
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"board_block_inner_part\">
\t\t\t\t\t\t\t<div class=\"profile_pic\"></div>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Assessment Type:</strong> ";
            // line 19
            echo twig_escape_filter($this->env, strtoupper($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "merchant_type")), "html", null, true);
            echo " </span>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Compliance Due Date:</strong> ";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "compliance_due_date"), "html", null, true);
            echo " </span>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"><strong>Completed </strong><small>[";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "filled"), "html", null, true);
            echo " <i> Out-of </i> ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total"), "html", null, true);
            echo "]  </small></span>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"time_manage_main completed\">
\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
            echo "%</small></span>
\t\t\t\t\t\t\t\t<div class=\"time_manage_comp\" style=\"width: ";
            // line 25
            echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
            echo "%;\" data-fill=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
            echo "%\">
\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
            // line 29
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ipt"));
            foreach ($context['_seq'] as $context["_key"] => $context["row1"]) {
                // line 30
                echo "\t\t\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "company_id") == (isset($context["company_id"]) ? $context["company_id"] : null))) {
                    // line 31
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["div_width"] = $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage");
                    // line 32
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage") > "85")) {
                        // line 33
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        $context["div_width"] = "85";
                        // line 34
                        echo "\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 35
                    echo "\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong> In Process Tasks </strong> <small>[ ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "filled"), "html", null, true);
                    echo " <i> Out-of </i> ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "total"), "html", null, true);
                    echo " ]</small> </span>
\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_main inprogress\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small>";
                    // line 38
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage"), "html", null, true);
                    echo "</small></span>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_ip\" style=\"width: ";
                    // line 39
                    echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
                    echo "%;\" data-fill=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage"), "html", null, true);
                    echo "%\">
\t\t\t\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 43
                echo "\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row1'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 44
            echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
            // line 45
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "uct"));
            foreach ($context['_seq'] as $context["key_id"] => $context["row1"]) {
                // line 46
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
                // line 47
                if (($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "company_id") == (isset($context["company_id"]) ? $context["company_id"] : null))) {
                    // line 48
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["div_width"] = $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage");
                    // line 49
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage") > "85")) {
                        // line 50
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        $context["div_width"] = "85";
                        // line 51
                        echo "\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 52
                    echo "\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"><strong> Upcoming Tasks</strong> <small>[ ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "filled"), "html", null, true);
                    echo " <i> Out-of </i> ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "total"), "html", null, true);
                    echo "  ]</small> </span>
\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_main upcoming\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small>";
                    // line 55
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage"), "html", null, true);
                    echo "</small></span>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_uc\" style=\"width: ";
                    // line 56
                    echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
                    echo "%;\" data-fill=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage"), "html", null, true);
                    echo "%\">
\t\t\t\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 60
                echo "\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key_id'], $context['row1'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 61
            echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
            // line 62
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ft"));
            foreach ($context['_seq'] as $context["_key"] => $context["row1"]) {
                // line 63
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
                // line 64
                if (($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "company_id") == (isset($context["company_id"]) ? $context["company_id"] : null))) {
                    // line 65
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["div_width"] = $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage");
                    // line 66
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage") > "85")) {
                        // line 67
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        $context["div_width"] = "85";
                        // line 68
                        echo "\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 69
                    echo "\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Failed Tasks </strong><small>[ ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "filled"), "html", null, true);
                    echo " <i> Out-of </i> ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "total"), "html", null, true);
                    echo "  ]</small> </span>
\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_main failed\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small>";
                    // line 72
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage"), "html", null, true);
                    echo "</small></span>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_failed\" style=\"width: ";
                    // line 73
                    echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
                    echo "%;\" data-fill=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage"), "html", null, true);
                    echo "%\">
\t\t\t\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 77
                echo "\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row1'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 78
            echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
            // line 79
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "odt"));
            foreach ($context['_seq'] as $context["key_id"] => $context["row1"]) {
                // line 80
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
                // line 81
                if (($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "company_id") == (isset($context["company_id"]) ? $context["company_id"] : null))) {
                    // line 82
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["div_width"] = $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage");
                    // line 83
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage") > "85")) {
                        // line 84
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        $context["div_width"] = "85";
                        // line 85
                        echo "\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 86
                    echo "\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"><strong> Over Due Tasks </strong><small>[ ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "filled"), "html", null, true);
                    echo " <i> Out-of </i> ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "total"), "html", null, true);
                    echo "  ]</small> </span>
\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_main overdue\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small>";
                    // line 89
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage"), "html", null, true);
                    echo "</small></span>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_od\" style=\"width: ";
                    // line 90
                    echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
                    echo "%;\" data-fill=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage"), "html", null, true);
                    echo "%\">
\t\t\t\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 94
                echo "\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key_id'], $context['row1'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 95
            echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
            // line 96
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "odo"));
            foreach ($context['_seq'] as $context["key_id"] => $context["row1"]) {
                // line 97
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
                // line 98
                if (($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "company_id") == (isset($context["company_id"]) ? $context["company_id"] : null))) {
                    // line 99
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["div_width"] = $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage");
                    // line 100
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage") > "85")) {
                        // line 101
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        $context["div_width"] = "85";
                        // line 102
                        echo "\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 103
                    echo "\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"><strong> Over Due Open Tasks </strong><small>[ ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "filled"), "html", null, true);
                    echo " <i> Out-of </i> ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "total"), "html", null, true);
                    echo "  ]</small> </span>
\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_main overdue\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small>";
                    // line 106
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage"), "html", null, true);
                    echo "</small></span>
\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_od\" style=\"width: ";
                    // line 108
                    echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
                    echo "%;\" data-fill=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), "percentage"), "html", null, true);
                    echo "%\">
\t\t\t\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 112
                echo "\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key_id'], $context['row1'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 113
            echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t
\t\t\t\t\t\t\t<!--<span class=\"pull-right \" data-target=\"#section_4\" data-toggle=\"collapse\" title=\"Click to Expand/Collapse below section\" aria-expanded=\"true\"><small>View All</small></span>\t-->\t\t\t\t
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- <div class=\"board_block_part inner_section collapse out\" id=\"section_4\">
\t\t\t\t\t\t<div class=\"inner_section\"></div>
\t\t\t\t\t</div>\t-->
\t\t\t</div>
\t\t\t";
            // line 122
            $context["count"] = ((isset($context["count"]) ? $context["count"] : null) + 1);
            // line 123
            echo "\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 124
        echo "
\t\t
\t</div>
   </div>
</div>

";
    }

    public function getTemplateName()
    {
        return "_kanban-grid.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  366 => 124,  360 => 123,  358 => 122,  347 => 113,  341 => 112,  332 => 108,  327 => 106,  318 => 103,  315 => 102,  312 => 101,  309 => 100,  306 => 99,  304 => 98,  301 => 97,  297 => 96,  288 => 94,  279 => 90,  275 => 89,  263 => 85,  260 => 84,  257 => 83,  254 => 82,  249 => 80,  245 => 79,  242 => 78,  236 => 77,  227 => 73,  223 => 72,  214 => 69,  211 => 68,  208 => 67,  205 => 66,  202 => 65,  200 => 64,  193 => 62,  190 => 61,  184 => 60,  175 => 56,  171 => 55,  162 => 52,  159 => 51,  153 => 49,  150 => 48,  148 => 47,  141 => 45,  123 => 39,  119 => 38,  110 => 35,  107 => 34,  98 => 31,  95 => 30,  82 => 25,  66 => 20,  62 => 19,  43 => 11,  34 => 8,  30 => 7,  25 => 5,  354 => 229,  338 => 218,  321 => 206,  308 => 198,  294 => 95,  280 => 180,  266 => 86,  252 => 81,  237 => 152,  225 => 145,  212 => 137,  197 => 63,  185 => 120,  172 => 112,  157 => 102,  132 => 43,  118 => 78,  104 => 33,  90 => 60,  59 => 39,  102 => 61,  73 => 48,  50 => 23,  46 => 12,  40 => 10,  38 => 18,  19 => 1,  164 => 85,  161 => 84,  156 => 50,  106 => 4,  100 => 114,  94 => 112,  91 => 29,  85 => 49,  83 => 81,  74 => 74,  58 => 64,  54 => 62,  52 => 14,  44 => 55,  42 => 54,  37 => 9,  35 => 50,  27 => 6,  22 => 1,  152 => 58,  149 => 57,  145 => 46,  138 => 44,  129 => 47,  125 => 46,  121 => 45,  117 => 44,  113 => 7,  109 => 5,  105 => 41,  101 => 32,  97 => 113,  89 => 51,  84 => 37,  81 => 47,  78 => 24,  75 => 45,  72 => 73,  70 => 21,  64 => 67,  60 => 29,  32 => 3,  29 => 46,);
    }
}
