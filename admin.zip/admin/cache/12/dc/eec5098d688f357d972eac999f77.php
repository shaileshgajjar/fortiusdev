<?php

/* assessment-reviewed-environment.html */
class __TwigTemplate_12dceec5098d688f357d972eac999f77 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 15
            echo "\t<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 34
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 35
            echo "      <!-- Tab panes -->
\t\t      <div class=\"tab-content tab_border\">
      
         <div role=\"tabpanel\" class=\"tab-pane active\" id=\"screen1\">
\t\t
            <div class=\"widget-box widget-color-blue widget_main_extra_part\">
            \t<div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i>4 Reviewed Environment</h4>
                </div>
                
                <div class=\"widget-body\">
                \t<div class=\"widget-main widget_main_extra_part\">
                    \t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.1\tDetailed network diagram(s)</div>
                        
                    \t<div class=\"screen5_discription_part screen_14_discription_extra\">
                            <p>Provide one or more drtailed diagrams to illustrate each communication/connection point between in scope network/environments/facilities. Diagrams should include the following:</p>
                            <ul>
                                <li>All boundaries of the cardholder data environment</li>
                                <li>Any network segmentation points which are used to reduce scope of the assessment</li>
                                <li>Boundaries between trusted and untrusted networks</li>
                                <li>wireless and wired network</li>
                                <li>All other connection points applicable to the assessment</li>
                            </ul>
                             <div onclick=\"initupload();\" data-target=\"#upload\" data-toggle=\"modal\" class=\"btn btn-primary primary_btn_extra\"><span><i class=\"fa fa-plus\"></i></span> Add high-level network diagram </div> 
\t\t\t\t\t\t<div class=\"btn btn-info primary_btn_extra collapsed\" title=\"Show/Hide Uploaded Files\" data-toggle=\"collapse\" data-target=\"#section_1\" aria-expanded=\"false\"> Show/Hide Uploaded Files
\t\t\t\t\t</div>
\t\t\t\t\t<div id=\"section_1\" class=\"collapse in\">
\t\t\t\t\t\t <ol id=\"diagramslist\" class=\"\"> 
\t\t\t\t\t\t\t";
            // line 63
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "wizard_diagrams"));
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 64
                echo "\t\t\t\t\t\t\t<li id=\"list_";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "diagram_path"), "html", null, true);
                echo " Date : ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "upload_date"), "html", null, true);
                echo " &nbsp;&nbsp;&nbsp;<span onclick=\"javasctipt: removethis('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "','";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_id"), "html", null, true);
                echo "')\" ><i class=\"fa fa-trash trash-icon\" title=\"Remove\"></i></span></li>
\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 66
            echo "\t\t\t\t\t\t</ol>
\t\t\t\t\t</div>
\t\t\t\t\t\t
                        </div>
                       
                           <div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.2\tDescription of cardholder data flows</div> 
                           <div class=\"screen9_table_block_part screen10_extra screen11_part ass_review_envi_table_border\">
                                <h5>For each wireless technology in scope, identify following:</h5>
                                <div class=\"table-responsive\">
                                    <table class=\"table table-striped\" id=\"tbl1\">
                                 <thead>
                                        <tr>
                                            <th class=\"col-md-2 col-sm-2 col-xs-2\">Cardholder data flows </th>
                                            <th class=\"col-md-3 col-sm-3 col-xs-3\">Types of CHD involved(for example, full track, PAN, expiry</th>
                                            <th class=\"col-md-7 col-sm-7 col-xs-7\">Describe how cardholder data is transmitted and/or processed</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        ";
            // line 84
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "pre"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 85
                echo "\t\t\t\t\t\t\t\t\t\t<tr>
                                          <td><strong>";
                // line 86
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "cap"), $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0")), "html", null, true);
                echo "</strong><input type=\"hidden\" name=\"pre_event_name[]\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "cap"), $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0")), "html", null, true);
                echo "\"></td>
                                          <td><textarea class=\"form-control\" rows=\"2\" name=\"pre_types_chd[]\" placeholder=\"";
                // line 87
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "cap"), $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0")), "html", null, true);
                echo "\" >";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "types_chd"), "html", null, true);
                echo "</textarea></td>
                                          <td><textarea class=\"form-control\" rows=\"2\" name=\"pre_how_chd_transmitted[]\">";
                // line 88
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "how_chd_transmitted"), "html", null, true);
                echo "</textarea></td>
                                        </tr>
\t\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 91
            echo "                                      </tbody>
                                      </tbody>
                                    </table>
                                  </div>
                            <div class=\"screen9_table_block_part screen10_extra screen11_part\">
                                <h5>Identify all other data flows, as applicable (add rows as needed)</h5>
                                <div class=\"table-responsive\">
                                    <table class=\"table table-striped\" id=\"tbl2\">
                                      <thead>
                                        <tr>&nbsp;</tr>
                                      </thead>
                                      <tbody>
\t\t\t\t\t\t\t\t\t\t";
            // line 103
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "post"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                echo "\t  
                                            <tr>
                                              <td class=\"col-md-3 col-sm-3 col-xs-4\"><strong> Other (Describe):</strong><br /> <textarea name=\"post_event_name[]\" class=\"form-control\" rows=\"2\" placeholder=\"Enter here\">";
                // line 105
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "event_name"), "html", null, true);
                echo "</textarea></td>
                                              <td class=\"col-md-3 col-sm-3 col-xs-4\"><br /><textarea name=\"post_types_chd[]\" class=\"form-control\" rows=\"2\" placeholder=\"Enter here\">";
                // line 106
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "types_chd"), "html", null, true);
                echo "</textarea></td>
                                              <td class=\"col-md-6 col-sm-6 col-xs-4\"><br /><textarea name=\"post_how_chd_transmitted[]\"class=\"form-control\" rows=\"2\" placeholder=\"Enter here\">";
                // line 107
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "how_chd_transmitted"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 108
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 109
                    echo "                                                &nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 111
                    echo "                                                &nbsp;&nbsp;&nbsp;
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 113
                echo "                                              </td>
                                            </tr>
                                        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 116
            echo "                                      </tbody>
                                    </table>
\t\t\t\t\t\t\t\t\t<div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow('tbl2');\" > Add New </div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t
                            </div>
\t\t\t\t\t\t\t<table class=\"table table-striped\">
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\tOther details regarding the flow of CHD, if applicable:
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-6 col-sm-6 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t\t\t <textarea placeholder=\"Please Enter here\" rows=\"2\" class=\"form-control\" id=\"card_holder_chd\" name=\"card_holder_chd\">";
            // line 130
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "card_holder_chd"), "value"), "html", null, true);
            echo "</textarea></td></textarea>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
                                </tbody></table>
                        </div>
                        <button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 136
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
                   <button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button>
                    </div>
                </div>
            </div>
        </div>
      </div>
\t  </form>
    </div>
";
            // line 145
            $this->env->loadTemplate("_upload-diagram-reviewed-env.html")->display($context);
            echo " 
";
        }
    }

    // line 148
    public function block_footer($context, array $blocks = array())
    {
        // line 149
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 155
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 156
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 160
            echo "\$(document).ready(function() {
   
\t\$('#frm').bootstrapValidator();
\t//\$(\".switch\").bootstrapSwitch();
\t\$(\"#tbl2\").on('click','.remCF',function(){
\t\t\$(this).parent().parent().remove();
\t});
});
";
        }
        // line 169
        echo "
function initupload()
{
\t\$('#statusdiagram').hide();
\t\$('#diagram').val('');
\t\$('.bar').css({'width' : '0%'});
\t\$('.percent').html('0%');
\t\$('#statusdiagram').html('');
}

function addrow(tbl_id)
{
\tif(tbl_id == 'tbl2')
\t{
\t\thtml = '';
\t\thtml = html + '<tr>';
\t\thtml = html + '\t<td class=\"col-md-3 col-sm-3 col-xs-4\"><strong>Other (Describe):</strong><br />';
\t\thtml = html + '\t\t<textarea name=\"event_name[]\" class=\"form-control\" rows=\"3\" placeholder=\"Enter here\"></textarea>';
\t\thtml = html + '\t</td>';
\t\thtml = html + '\t<td class=\"col-md-3 col-sm-3 col-xs-4\"><br />';
\t\thtml = html + '\t\t<textarea name=\"types_chd[]\" class=\"form-control\" rows=\"3\" placeholder=\"Enter here\"></textarea>';
\t\thtml = html + '\t</td>';
\t\thtml = html + '\t<td class=\"col-md-6 col-sm-6 col-xs-4\"><br />';
\t\thtml = html + '\t\t<textarea name=\"how_chd_transmitted[]\"class=\"form-control\" rows=\"3\" placeholder=\"Enter here\"></textarea> &nbsp; ';
\t\thtml = html + '\t\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>';
\t\thtml = html + '\t</td>';
\t\thtml = html + '</tr>';
\t\t\$(\"#\"+tbl_id).append(html);
\t}
}
function removethis(did, cid)
{
\tif ( did != '' )
\t{
\t\ttheurl = '/remove-diagram.php?did='+did+'&cid='+cid;
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\t\$('li#list_'+did).remove();
\t\t\t
\t\t});
\t}
}
</script>
";
    }

    public function getTemplateName()
    {
        return "assessment-reviewed-environment.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  392 => 169,  381 => 160,  375 => 156,  373 => 155,  363 => 149,  360 => 148,  353 => 145,  341 => 136,  332 => 130,  316 => 116,  300 => 113,  296 => 111,  292 => 109,  290 => 108,  286 => 107,  282 => 106,  278 => 105,  258 => 103,  244 => 91,  227 => 88,  221 => 87,  215 => 86,  212 => 85,  195 => 84,  175 => 66,  158 => 64,  154 => 63,  124 => 35,  122 => 34,  117 => 32,  113 => 31,  109 => 30,  105 => 29,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  80 => 22,  71 => 15,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
