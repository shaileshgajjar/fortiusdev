<?php

/* getcontentuser.html */
class __TwigTemplate_796ff99d67923b17fbde4c814b56710e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t\t\t\t\t\t\t<div class=\"number alert alert-warning\" title=\"Click to Expand / Collapse All Sections\" data-toggle=\"collapse\" data-target=\".collapse\">&nbsp;<span class=\" pull-right alert-warning\"><b>Expand/Collapse All</b></span></div>
\t\t\t\t\t\t\t<div id=\"req";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
        echo "\" class=\"item\">
\t\t\t\t\t\t\t";
        // line 3
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 4
            echo "\t\t\t\t\t\t\t\t";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "usercan") == "1")) {
                // line 5
                echo "\t\t\t\t\t\t\t\t";
                $context["bgclass"] = "alert-info";
                // line 6
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "Y")) {
                    // line 7
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["bgclass"] = "alert-success";
                    // line 8
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 9
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "N")) {
                    // line 10
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["bgclass"] = "alert-danger";
                    // line 11
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 12
                echo "\t\t\t\t\t\t\t\t<div class=\"number alert ";
                echo twig_escape_filter($this->env, (isset($context["bgclass"]) ? $context["bgclass"] : null), "html", null, true);
                echo "\" title=\"Click to Expand/Collapse below section\" data-toggle=\"collapse\" data-target=\"#section_";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "number"), "html", null, true);
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locked") == "1")) {
                    echo " <span class=\" glyphicon glyphicon-lock text-danger\"></span>";
                }
                echo " <span class=\" pull-right glyphicon glyphicon-minus alert-success\"></span> <div class=\"pull-right\">/</div> <span class=\"pull-right glyphicon glyphicon-plus alert-success\" ></span></div>
\t\t\t\t\t\t\t\t<div id=\"section_";
                // line 13
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                echo "\" class=\"collapse\">
\t\t\t\t\t\t\t\t<div class=\"title\">
\t\t\t\t\t\t\t\t\t";
                // line 15
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "ptitle"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t";
                // line 16
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "guidance") != "")) {
                    // line 17
                    echo "\t\t\t\t\t\t\t\t\t<br />
\t\t\t\t\t\t\t\t\t<span class=\"alert alert-warning\">(";
                    // line 18
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "guidance"), "html", null, true);
                    echo ")</span>
\t\t\t\t\t\t\t\t\t";
                }
                // line 20
                echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
                // line 21
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "allowdoc") == "1")) {
                    // line 22
                    echo "\t\t\t\t\t\t\t\t<div class=\"documents pull-left\">
\t\t\t\t\t\t\t\t\t";
                    // line 23
                    $context["disabled"] = "";
                    // line 24
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["readonly"] = "";
                    // line 25
                    echo "\t\t\t\t\t\t\t\t\t";
                    if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locked") == "1")) {
                        // line 26
                        echo "\t\t\t\t\t\t\t\t\t\t";
                        $context["disabled"] = " disabled";
                        // line 27
                        echo "\t\t\t\t\t\t\t\t\t\t";
                        $context["readonly"] = " readonly";
                        // line 28
                        echo "\t\t\t\t\t\t\t\t\t";
                    }
                    // line 29
                    echo "\t\t\t\t\t\t\t\t\t<div class=\"dropdown\" id=\"dropdown";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                    echo "\">
\t\t\t\t\t\t\t\t\t\t<button ";
                    // line 30
                    if (((twig_length_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "documents")) == 0) || ($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locekd") == "1"))) {
                        echo " disabled";
                    }
                    echo " class=\"btn btn-default\" id=\"dLabel\" type=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
\t\t\t\t\t\t\t\t\t\tDocuments
\t\t\t\t\t\t\t\t\t\t<span class=\"caret\"></span>
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t<ul class=\"dropdown-menu\" role=\"menu\" aria-labelledby=\"dLabel\">
\t\t\t\t\t\t\t\t\t\t\t";
                    // line 35
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "documents"));
                    foreach ($context['_seq'] as $context["key"] => $context["f"]) {
                        // line 36
                        echo "\t\t\t\t\t\t\t\t\t\t\t  ";
                        $context["fileName"] = $this->getAttribute((isset($context["f"]) ? $context["f"] : null), "document");
                        // line 37
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<li><a class=\"pull-left\" href=\"/uploads/documents/";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
                        echo "/";
                        echo twig_escape_filter($this->env, (isset($context["fileName"]) ? $context["fileName"] : null), "html", null, true);
                        echo "\" target=\"_blank\">";
                        echo twig_escape_filter($this->env, (isset($context["fileName"]) ? $context["fileName"] : null), "html", null, true);
                        echo "&nbsp;&nbsp;&nbsp;&nbsp;<span class=\"glyphicon glyphicon-save\"></span></a> <small > Date: ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["f"]) ? $context["f"] : null), "upload_date"), "html", null, true);
                        echo " </small> ";
                        if ((($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locked") == "") || ($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locked") == "0"))) {
                            echo " <a href=\"javascript:deletedoc('";
                            echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                            echo "', '";
                            echo twig_escape_filter($this->env, (isset($context["fileName"]) ? $context["fileName"] : null), "html", null, true);
                            echo "', '";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
                            echo "', '";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                            echo "');\" class=\"pull-right\">  <span class=\"glyphicon glyphicon-remove text-danger\"></span></a> ";
                        }
                        echo "</li>
\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 38
                        $context["fileName"] = "";
                        // line 39
                        echo "\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['key'], $context['f'], $context['_parent'], $context['loop']);
                    $context = array_merge($_parent, array_intersect_key($context, $_parent));
                    // line 40
                    echo "\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"comments pull-left\">
\t\t\t\t\t\t\t\t\t<button type=\"button\" ";
                    // line 44
                    echo twig_escape_filter($this->env, (isset($context["extra"]) ? $context["extra"] : null), "html", null, true);
                    echo " ";
                    if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locked") == "1")) {
                        echo " disabled ";
                    }
                    echo " onclick=\"setvalueu('";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                    echo "');\" title=\"Upload\" data-toggle=\"modal\" data-target=\"#upload\" class=\"btn btn-primary\"><span class=\"glyphicon glyphicon-open\"></span></button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
                }
                // line 47
                echo "\t\t\t\t\t\t\t\t<div class=\"comments pull-left\">
\t\t\t\t\t\t\t\t\t<button  ";
                // line 48
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locked") == "1")) {
                    echo " disabled ";
                }
                echo " type=\"button\" id=\"btn-comment";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                echo "\" onclick=\"setvalue('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
                echo "','s', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "qa_id"), "html", null, true);
                echo "');\" title=\"Comment to QSA\" data-toggle=\"modal\" data-target=\"#div-comment\"  class=\"btn btn-comments ";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total_comments") == 0)) {
                    echo "btn-default";
                } else {
                    echo "btn-success";
                }
                echo "\"><span class=\"glyphicon glyphicon-user\"></span></button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"lockunlock pull-left\" id=\"";
                // line 50
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t<label title=\"Check to Ready for review\" for=\"switch";
                // line 51
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "\"> <input";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "ready_for") == "review")) {
                    echo " checked ";
                }
                echo " value=\"1\" onchange=\"setready('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "');\" id=\"switch";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "\" data-size=\"large\" data-handle-width=\"50\" data-on-color=\"danger\" data-off-color=\"success\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\" > Ready for Review </label>
\t\t\t\t\t\t\t\t\t<div id=\"val";
                // line 52
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "\" ></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div style=\"clear:both;\"></div>
\t\t\t\t\t\t\t\t";
            }
            // line 57
            echo "\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 58
        echo "\t\t\t\t\t\t\t</div>";
    }

    public function getTemplateName()
    {
        return "getcontentuser.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  237 => 58,  231 => 57,  223 => 52,  211 => 51,  207 => 50,  184 => 48,  181 => 47,  169 => 44,  163 => 40,  157 => 39,  155 => 38,  132 => 37,  129 => 36,  125 => 35,  115 => 30,  110 => 29,  107 => 28,  104 => 27,  101 => 26,  98 => 25,  95 => 24,  93 => 23,  90 => 22,  88 => 21,  85 => 20,  80 => 18,  77 => 17,  75 => 16,  71 => 15,  66 => 13,  54 => 12,  51 => 11,  48 => 10,  45 => 9,  42 => 8,  39 => 7,  36 => 6,  33 => 5,  30 => 4,  26 => 3,  22 => 2,  19 => 1,);
    }
}
