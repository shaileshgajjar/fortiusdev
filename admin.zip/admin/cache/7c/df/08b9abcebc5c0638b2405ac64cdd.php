<?php

/* assessors.html */
class __TwigTemplate_7cdf08b9abcebc5c0638b2405ac64cdd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"company_id\" id=\"company_id\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"source\" id=\"source\" value=\"assessor\" />
\t\t\t";
        // line 12
        $this->env->loadTemplate("_new-panel.html")->display($context);
        // line 13
        echo "\t\t\t<div class=\"table-responsive\">
\t\t\t\t<table id=\"simple-table\" class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t   <thead>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t <th class=\"text-center\">
\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"ace\" />
\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t </th>
\t\t\t\t\t\t <th class=\"text-center\">";
        // line 23
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Sr.#", 1 => "rowid", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 24
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Assessor Type", 1 => "qa_qsa", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 25
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "First Name", 1 => "first_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 26
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Last Name", 1 => "last_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 27
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "PCI Credential", 1 => "pci_credential", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 28
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Email", 1 => "email", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 29
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Telephone", 1 => "mobile", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th class=\"text-center\">Action</th>
\t\t\t\t\t  </tr>
\t\t\t\t   </thead>
\t\t\t\t   <tbody>
\t\t\t\t\t  ";
        // line 34
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 35
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td class=\"text-center\">
\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"removeid[]\" class=\"ace\" value=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t </td>
\t\t\t\t\t\t <td class=\"text-center\">";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "rowid"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 43
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "qa_qsa") == "qsa")) {
                echo " QSA ";
            } elseif (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "qa_qsa") == "qa")) {
                echo " QA ";
            }
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "first_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "last_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pci_credential"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "email"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "mobile"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td class=\"text-left\" style=\"width:80px;\">
\t\t\t\t\t\t\t<button type=\"button\" title=\"Edit\" onclick=\"edit('";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "editscript"), "html", null, true);
            echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t";
            // line 51
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "qa_qsa") == "qsa")) {
                // line 52
                echo "\t\t\t\t\t\t\t<div type=\"button\" title=\"Assign Task\" class=\"btn btn-primary btn-xs menustart\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\" onclick=\"assigntask('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "' ,'assigntasks.php', 'assessor',' ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_id"), "html", null, true);
                echo " ');\"></span>
\t\t\t\t\t\t\t\t<ul class=\"ulmenu\">
\t\t\t\t\t\t\t\t\t";
                // line 54
                echo getcompany($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"));
                echo "
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t<!--  onclick=\"assigntask('";
                // line 56
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "' ,'assigntasks.php', 'assessor');\" -->
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
            }
            // line 59
            echo "\t\t\t\t\t\t </td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 62
        echo "\t\t\t\t\t  ";
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows")) == 0)) {
            // line 63
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td colspan=\"11\">No Records</td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        // line 67
        echo "\t\t\t\t   </tbody>
\t\t\t\t   <tfoot>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t<td class=\"text-center\"><button type=\"button\" title=\"Delete\" onclick=\"delconfirm(this.form);\" class=\"btn btn-danger\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></button></td>
\t\t\t\t\t\t<td colspan=\"11\"></td>
\t\t\t\t\t  </tr>
\t\t\t\t   </tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
";
    }

    // line 80
    public function block_footer($context, array $blocks = array())
    {
        // line 81
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
<script src=\"/admin/js/list.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "assessors.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  207 => 81,  204 => 80,  188 => 67,  182 => 63,  179 => 62,  171 => 59,  165 => 56,  160 => 54,  152 => 52,  150 => 51,  144 => 50,  139 => 48,  135 => 47,  131 => 46,  127 => 45,  123 => 44,  115 => 43,  111 => 42,  104 => 38,  99 => 35,  95 => 34,  87 => 29,  83 => 28,  79 => 27,  75 => 26,  71 => 25,  67 => 24,  63 => 23,  51 => 13,  49 => 12,  41 => 7,  37 => 6,  32 => 3,  29 => 2,);
    }
}
