<?php

/* report-compliance.html */
class __TwigTemplate_ca676319b1555d55994f44e569b4d2b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"pid\" id=\"pid\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pid"), "html", null, true);
        echo "\" />
\t\t\t<div class=\"widget-box widget-color-blue\">
\t\t\t\t<!-- #section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-header\">
\t\t\t\t\t<h5 class=\"widget-title smaller lighter\">
\t\t\t\t\t\t<i class=\"ace-icon fa fa-edit\"></i>
\t\t\t\t\t\t";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
        echo " - Company Name : <b>";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_name"), "html", null, true);
        echo "</b>, Assessment Type : <b>";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "merchant_type"), "html", null, true);
        echo "</b>
\t\t\t\t\t</h5>
\t\t\t\t</div>

\t\t\t\t<!-- /section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-body\">
\t\t\t\t\t<div class=\"widget-main\">
\t\t\t\t\t\t<div class=\"col-lg-7\">
\t\t\t\t\t\t\t<div class=\"table-responsive table-report\">
\t\t\t\t\t\t\t<table class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t\t\t\t   <thead>
\t\t\t\t\t\t\t\t  <tr>
\t\t\t\t\t\t\t\t\t <th class=\"text-center\">&nbsp;</th>
\t\t\t\t\t\t\t\t\t <th class=\"text-center success\" colspan=\"7\">Compliance Status</th>
\t\t\t\t\t\t\t\t\t <th class=\"text-center danger\" colspan=\"2\">SEVERITY</th>
\t\t\t\t\t\t\t\t  </tr>
\t\t\t\t\t\t\t\t  <tr class=\"warning\">
\t\t\t\t\t\t\t\t\t <th class=\"text-center\">PCI-DSS<br/>Requirements</th>
\t\t\t\t\t\t\t\t\t <th class=\"text-center\">%<br/>Compliance</th>
\t\t\t\t\t\t\t\t\t <th class=\"text-center\"># of<br/>Requirements</th>
\t\t\t\t\t\t\t\t\t <th class=\"text-center\">#<br/>In Place</th>
\t\t\t\t\t\t\t\t\t <th class=\"text-center\"># Not<br/>In Place</th>
\t\t\t\t\t\t\t\t\t <th class=\"text-center\"># Compensating</th>
\t\t\t\t\t\t\t\t\t <th class=\"text-center\"># Not<br/>Applicable</th>
\t\t\t\t\t\t\t\t\t <th class=\"text-center\"># Not<br/>Tested</th>
\t\t\t\t\t\t\t\t\t <th class=\"text-center\">Severity</th>
\t\t\t\t\t\t\t\t\t <th class=\"text-center\">Max Severity</th>
\t\t\t\t\t\t\t\t  </tr>
\t\t\t\t\t\t\t   </thead>
\t\t\t\t\t\t\t   <tbody>
\t\t\t\t\t\t\t\t  ";
        // line 55
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["key"] => $context["row"]) {
            // line 56
            echo "\t\t\t\t\t\t\t\t  <tr>
\t\t\t\t\t\t\t\t\t <td class=\"text-center\"><a href=\"javascript:filldata('";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
            echo "', 'fill-data.php');\">";
            echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
            echo "</a></td>
\t\t\t\t\t\t\t\t\t <td class=\"text-center\">";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t <td class=\"text-center\">";
            // line 59
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t <td class=\"text-center\">";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "Y"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t <td class=\"text-center\">";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "N"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t <td class=\"text-center\">";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "C"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t <td class=\"text-center\">";
            // line 63
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "NA"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t <td class=\"text-center\">";
            // line 64
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "NT"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t <td class=\"text-center\">";
            // line 65
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "severity"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t <td class=\"text-center\">";
            // line 66
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "maxseverity"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t  </tr>
\t\t\t\t\t\t\t\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 69
        echo "\t\t\t\t\t\t\t   </tbody>
\t\t\t\t\t\t\t   <tfoot>
\t\t\t\t\t\t\t\t  <tr class=\"warning\">
\t\t\t\t\t\t\t\t\t";
        // line 72
        $context["total"] = (((($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "Y") + $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "N")) + $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "C")) + $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "NA")) + $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "NT"));
        // line 73
        echo "\t\t\t\t\t\t\t\t\t";
        if (((isset($context["total"]) ? $context["total"] : null) == 0)) {
            // line 74
            echo "\t\t\t\t\t\t\t\t\t\t";
            $context["percnt"] = "NA";
            // line 75
            echo "\t\t\t\t\t\t\t\t\t";
        } else {
            // line 76
            echo "\t\t\t\t\t\t\t\t\t\t";
            $context["percnt"] = (appround(((($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "Y") + $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "C")) / (isset($context["total"]) ? $context["total"] : null)) * 100)) . "%");
            // line 77
            echo "\t\t\t\t\t\t\t\t\t";
        }
        // line 78
        echo "\t\t\t\t\t\t\t\t\t<td class=\"text-center\">Total..</td>
\t\t\t\t\t\t\t\t\t<td class=\"text-center\">";
        // line 79
        echo twig_escape_filter($this->env, (isset($context["percnt"]) ? $context["percnt"] : null), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td class=\"text-center\">";
        // line 80
        echo twig_escape_filter($this->env, (isset($context["total"]) ? $context["total"] : null), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td class=\"text-center\">";
        // line 81
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "Y"), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td class=\"text-center\">";
        // line 82
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "N"), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td class=\"text-center\">";
        // line 83
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "C"), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td class=\"text-center\">";
        // line 84
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "NA"), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td class=\"text-center\">";
        // line 85
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "NT"), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td class=\"text-center\">";
        // line 86
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "severity"), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td class=\"text-center\">";
        // line 87
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total"), "maxseverity"), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t  </tr>
\t\t\t\t\t\t\t   </tfoot>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-5 \">
\t\t\t\t\t\t\t<div id=\"chart1\"></div>
\t\t\t\t\t\t\t<div class=\"hide-link\">&nbsp;&nbsp;</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<div class=\"col-lg-11\">
\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-info\" onclick=\"this.form.action='";
        // line 99
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
        echo "'; this.form.submit();\"><span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t   </div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
";
    }

    // line 109
    public function block_footer($context, array $blocks = array())
    {
        // line 110
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
<script src=\"/assets/js/list.js\"></script>
<script type=\"text/javascript\">
\$(document).ready(function(){
\t\$(function () {
\t\t\$('#chart1').highcharts({
\t\t\tchart: {
\t\t\t\ttype: 'bar'
\t\t\t},
\t\t\ttitle: {
\t\t\t\ttext: ''
\t\t\t},
\t\t\txAxis: {
\t\t\t\tcategories: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']
\t\t\t},
\t\t\tyAxis: {
\t\t\t\tmin: 0,
\t\t\t\ttitle: {
\t\t\t\t\ttext: ''
\t\t\t\t}
\t\t\t},
\t\t\ttooltip: {
\t\t\tformatter: function() {
\t\t\t\treturn ' Completed <b> '+this.y+' % </b> of Requirement #'+ this.x;
\t\t\t}
\t\t},
\t\t\tlegend: {
\t\t\t\treversed: true
\t\t\t},
\t\t\tplotOptions: {
\t\t\t\tseries: {
\t\t\t\t\tstacking: 'normal'
\t\t\t\t}
\t\t\t},
\t\t\tseries: [{
\t\t\t\tname: 'Completed',
\t\t\t\t//data: [5, 3, 4, 7, 2, 1, 1, 1, 1, 1, 1, 1]
\t\t\t\tdata: [";
        // line 147
        echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "label");
        echo "],
\t\t\t\tpointWidth: 28
\t\t\t}]
\t\t});
\t});
\t
});
</script>
<script src=\"../assets/js/highcharts/highcharts.js\"></script>
<script src=\"../assets/js/highcharts/highcharts-more.js\"></script>
<style type=\"text/css\">
#chart1 {
  width: 500px;
  height: 348x;
  margin: -10px auto 0 auto;
}
div.hide-link {
    background-color: #FFF;
    left: 72%;
    margin-bottom: -7px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 1px;
    position: absolute;
    top: 92%;
    width: 160px;
    height: 15%;
}
</style>
";
    }

    public function getTemplateName()
    {
        return "report-compliance.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  303 => 147,  262 => 110,  259 => 109,  245 => 99,  230 => 87,  226 => 86,  222 => 85,  218 => 84,  214 => 83,  210 => 82,  206 => 81,  202 => 80,  198 => 79,  195 => 78,  192 => 77,  189 => 76,  186 => 75,  183 => 74,  180 => 73,  178 => 72,  173 => 69,  164 => 66,  160 => 65,  156 => 64,  152 => 63,  148 => 62,  144 => 61,  140 => 60,  136 => 59,  132 => 58,  124 => 57,  121 => 56,  117 => 55,  80 => 25,  71 => 19,  67 => 18,  62 => 16,  58 => 15,  54 => 14,  50 => 13,  46 => 12,  42 => 11,  32 => 3,  29 => 2,);
    }
}
