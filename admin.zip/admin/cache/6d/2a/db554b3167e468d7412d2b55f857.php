<?php

/* assessment-reviewed-env-second-part.html */
class __TwigTemplate_6d2adb554b3167e468d7412d2b55f857 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 15
            echo "\t<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 34
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 35
            echo "      <!-- Tab panes -->
\t\t    <div class=\"tab-content tab_border\">
\t\t\t<div role=\"tabpanel\" class=\"tab-pane active\" id=\"screen1\">
\t\t
            <div class=\"screen7_inner_part widget-box widget-color-blue\">
                <div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i>4 Reviewed Environment</h4>
                </div>
                <div class=\"widget-body\">
                \t<div class=\"widget-main widget_main_extra_part\">
                    \t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.3\tCardholder data storage</div>
                        <div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\tIdentify and list all databases, tables, and files storing cardholder data and provide the following details.
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t<span class=\"label_note\"><b>Note:</b> &nbsp; The list of files and tables that store cardholder data in the table below must be supported by an inventory created (or obtained from the client) and retained by the assessor in the work papers.</span>
\t\t\t\t\t</div>
                    \t<div class=\"screen9_table_block_part screen10_extra screen11_part\">
                            <div class=\"table-responsive screen_field_part\">
                                <table class=\"table table-striped\" id=\"tbl1\">
                                  <thead>
                                    <tr>
                                        <th class=\"col-md-2 col-sm-3 col-xs-3\">Data Store(database, etc.)</th>
                                        <th class=\"col-md-2 col-sm-3 col-xs-3\">File(s) and/or Table(s)</th>
                                        <th class=\"col-md-3 col-sm-3 col-xs-3\">Cardholder data elements stored (PAN, expiry, any elements of SAD)</th>
                                        <th class=\"col-md-3 col-sm-3 col-xs-3\">How data is secured (for example, use of encryption, access controls, truncation, etc.)</th>
                                        <th class=\"col-md-3 col-sm-3 col-xs-3\">How access to data stores is logged (for example, enterprise log management solution, etc.)</th>
                                    </tr>
                                  </thead>
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t";
            // line 65
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "env_chd_flow"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 66
                echo "\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td><textarea class=\"form-control\" rows=\"2\" name=\"data_store[]\">";
                // line 67
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "data_store"), "html", null, true);
                echo "</textarea></td>
\t\t\t\t\t\t\t\t\t\t<td><textarea class=\"form-control\" rows=\"2\" name=\"data_file[]\">";
                // line 68
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "data_file"), "html", null, true);
                echo "</textarea></td>
\t\t\t\t\t\t\t\t\t\t<td><textarea class=\"form-control\" rows=\"2\" name=\"data_elements_stored[]\"  >";
                // line 69
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "data_elements_stored"), "html", null, true);
                echo "</textarea></td>
\t\t\t\t\t\t\t\t\t\t<td><textarea class=\"form-control\" rows=\"2\" name=\"data_security[]\">";
                // line 70
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "data_security"), "html", null, true);
                echo "</textarea></td>
\t\t\t\t\t\t\t\t\t\t<td><textarea class=\"form-control\" rows=\"2\" name=\"access_to_data[]\">";
                // line 71
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "access_to_data"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t";
                // line 72
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 73
                    echo "\t\t\t\t\t\t\t\t\t\t&nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t";
                }
                // line 75
                echo "\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 78
            echo "\t\t\t\t\t\t\t\t\t</tbody>
                                </table>
                              </div>
                              <div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow('tbl1');\" > Add New </div>
                        </div>                
                        <div class=\"screen9_table_block_part screen10_extra screen11_part\">
\t\t\t\t\t\t \t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.4 Critical hardware in use in the cardholder data environment</div>
\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\tIdentify and list all types of hardware in the cardholder environment, including network components, servers and other mainframes, devices performing security functions, end-user devices (such as laptops and workstations), virtualized devices (if applicable) and any other critical hardware – including homegrown components. For each item in the list, provide details for the hardware as indicated below. Add rows, as needed.
\t\t\t\t\t</div>\t\t
                           
                            <div class=\"table-responsive\">
                                <table class=\"table table-striped\" id=\"tbl2\">
                                  <thead>
                                    <tr>
\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-4 center\" colspan=\"3\" >
\t\t\t\t\t\t\t\t\t\tCritical Hardware
\t\t\t\t\t\t\t\t\t  </th>
\t\t\t\t\t\t\t\t\t  <th class=\"col-md-4 center\" colspan=\"2\" >
\t\t\t\t\t\t\t\t\t\tCritical Software
\t\t\t\t\t\t\t\t\t  </th>
\t\t\t\t\t\t\t\t\t  <th class=\"col-md-4 center\" rowspan=\"2\">Role/Functionality</th>
                                    </tr>
\t\t\t\t\t\t\t\t\t<tr class=\"center\"><th class=\"center\">Type of Device <br />(for example, firewall, server, IDS, etc.)</th><th class=\"center\">Vendor</th><th class=\"center\">Make/Model</th><th class=\"center\">Name of Software Product</th><th class=\"center\">Version or Release</th></tr>
\t\t\t\t\t\t\t\t\t\t
                                  </thead>
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t";
            // line 105
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "hardware_detail"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                echo "\t  
                                    <tr>
                                        <td><textarea class=\"form-control\" rows=\"2\" name=\"type_of_device[]\">";
                // line 107
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "type_of_device"), "html", null, true);
                echo "</textarea></td>
                                        <td><textarea class=\"form-control\" rows=\"2\" name=\"vendor[]\" >";
                // line 108
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "vendor"), "html", null, true);
                echo "</textarea></td>
                                        <td><textarea class=\"form-control\" rows=\"2\" name=\"vendor_role[]\">";
                // line 109
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "vendor_role"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t<td><textarea class=\"form-control\" rows=\"2\" name=\"software_product[]\" >";
                // line 111
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "software_product"), "html", null, true);
                echo "</textarea></td>
\t\t\t\t\t\t\t\t\t\t<td><textarea class=\"form-control\" rows=\"2\" name=\"software_version[]\" >";
                // line 112
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "software_version"), "html", null, true);
                echo "</textarea></td>
\t\t\t\t\t\t\t\t\t\t<td><textarea class=\"form-control\" rows=\"2\" name=\"func_role[]\" >";
                // line 113
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "func_role"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t";
                // line 114
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 115
                    echo "\t\t\t\t\t\t\t\t\t\t&nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t";
                }
                // line 117
                echo "\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 120
            echo "\t\t\t\t\t\t\t\t\t</tbody>
                                </table>
                              </div>
                              <div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow('tbl2');\" > Add New </div>
                        </div>
                        <button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 125
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
            \t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button> 
                    </div>
                </div>
                
            </div>

\t\t\t</div>
\t\t\t</div>
\t</form>
    </div>
";
        }
    }

    // line 138
    public function block_footer($context, array $blocks = array())
    {
        // line 139
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 145
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 146
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 150
            echo "\$(document).ready(function() {
   
\t\$('#frm').bootstrapValidator();
    \$(\"#tbl1\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t \$(\"#tbl2\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
});
";
        }
        // line 161
        echo "
function addrow(tbl_id)
{
\t\tformfields = 'tbl_id='+tbl_id;
\t\tif(tbl_id == 'tbl1' )
\t\t{
\t\t\thtml = '';
\t\t\thtml = html + '<tr>';
\t\t\thtml = html + '\t<td><textarea class=\"form-control\" rows=\"3\" name=\"data_store[]\" required></textarea></td>';
\t\t\thtml = html + '\t<td><textarea class=\"form-control\" rows=\"3\" name=\"data_file[]\" required></textarea></td>';
\t\t\thtml = html + '\t<td><textarea class=\"form-control\" rows=\"3\" name=\"data_elements_stored[]\" required></textarea></td>';
\t\t\thtml = html + '\t<td><textarea class=\"form-control\" rows=\"3\" name=\"data_security[]\" required></textarea></td>';
\t\t\thtml = html + '\t<td>';
\t\t\thtml = html + '\t\t<textarea class=\"form-control\" rows=\"3\" name=\"access_to_data[]\" required></textarea>';
\t\t\thtml = html + '\t\t&nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>';
\t\t\thtml = html + '\t</td>';
\t\t\thtml = html + '</tr>';
\t\t\t\$(\"#\"+tbl_id).append(html);
\t\t}
\t\tif(tbl_id == 'tbl2' )
\t\t{
\t\t\thtml = '';
\t\t\thtml = html + '<tr>';
\t\t\thtml = html + '\t<td><textarea class=\"form-control\" rows=\"3\" name=\"type_of_device[]\"></textarea></td>';
\t\t\thtml = html + '\t<td><textarea class=\"form-control\" rows=\"3\" name=\"vendor[]\" ></textarea></td>';
\t\t\thtml = html + '\t<td>';
\t\t\thtml = html + '\t\t<textarea class=\"form-control\" rows=\"3\" name=\"vendor_role[]\"></textarea>';
\t\t\thtml = html + '\t</td>';
\t\t\thtml = html + '\t<td>';
\t\t\thtml = html + '\t\t<textarea class=\"form-control\" rows=\"3\" name=\"software_product[]\"></textarea>';
\t\t\thtml = html + '\t</td>';
\t\t\thtml = html + '\t<td>';
\t\t\thtml = html + '\t\t<textarea class=\"form-control\" rows=\"3\" name=\"software_version[]\"></textarea>';
\t\t\thtml = html + '\t</td>';
\t\t\thtml = html + '\t<td>';
\t\t\thtml = html + '\t\t<textarea class=\"form-control\" rows=\"3\" name=\"func_role[]\"></textarea>';
\t\t\thtml = html + '\t\t&nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>';
\t\t\thtml = html + '\t</td>';
\t\t\thtml = html + '</tr>';
\t\t\t\$(\"#\"+tbl_id).append(html);\t\t\t\t\t
\t\t}
\t\t//
}
</script>
";
    }

    public function getTemplateName()
    {
        return "assessment-reviewed-env-second-part.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  372 => 161,  359 => 150,  353 => 146,  351 => 145,  341 => 139,  338 => 138,  321 => 125,  314 => 120,  298 => 117,  294 => 115,  292 => 114,  288 => 113,  284 => 112,  280 => 111,  275 => 109,  271 => 108,  267 => 107,  247 => 105,  218 => 78,  202 => 75,  198 => 73,  196 => 72,  192 => 71,  188 => 70,  184 => 69,  180 => 68,  176 => 67,  173 => 66,  156 => 65,  124 => 35,  122 => 34,  117 => 32,  113 => 31,  109 => 30,  105 => 29,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  80 => 22,  71 => 15,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
