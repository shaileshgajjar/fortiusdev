<?php

/* _profile-avtar.html */
class __TwigTemplate_6d12cf52e87914788a5efb5560bff4f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<style type=\"text/css\">
\t.progress { position:relative; width:400px; border: 1px solid #ddd; border-radius: 3px; margin:55px 0px 0px 0px; height:27px; }
\t.bar { background-color: #5cb85c; width:0%; height:27px; border-radius: 3px; }
\t.percent { position:absolute; display:inline-block; top:3px; left:48%; }
\t#status { margin-bottom:0px; margin-top:10px; padding:10px; }
\tinput[type=\"file\"] { margin-top:5px; }
</style>
<div class=\"modal fade\" id=\"upload_avtar\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"myModalLabel\">Upload Avtar</h4>
      </div>
      <div class=\"modal-body\">
        <form id=\"frmupload\" name=\"frmupload\" method=\"post\" action=\"/save-profile.php\" enctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"avtarsave\" />
\t\t\t<input type=\"file\" name=\"myfile\" id=\"myfile\" style=\"height:30px; cursor:pointer;\" class=\"pull-left\" />
\t\t\t<button type=\"submit\" class=\"btn btn-success pull-left\">Upload</button>
\t\t</form>
\t\t<div class=\"progress\">
\t\t\t<div class=\"bar\"></div >
\t\t\t<div class=\"percent\">0%</div >
\t\t</div>
\t\t<div id=\"status\" class=\"alert\"></div>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
<script src=\"/assets/js/jquery.form.js\"></script>
<script type=\"text/javascript\">
(function() {
\"use strict\";   
var bar = \$('.bar');
var percent = \$('.percent');
var status = \$('#status');
var res = '';
var resary = {};
var pid = '';
var html = '';

\$('#frmupload').ajaxForm({
    beforeSend: function(xhr) {
        status.empty();
\t\tstatus.removeClass('alert-danger');
        var percentVal = '0%';
        bar.width(percentVal)
        percent.html(percentVal);
\t\tvar ext = \$('#myfile').val().split('.').pop().toLowerCase();
\t\tif(\$.inArray(ext, ['jpg', 'gif', 'png', 'jpeg']) == -1) {
\t\t\tstatus.addClass('alert-danger');
\t\t\tstatus.html('Error: jpg, gif, png, jpeg files are allowed.');
\t\t\txhr.abort();
\t\t}
    },
    uploadProgress: function(event, position, total, percentComplete) {
        var percentVal = percentComplete + '%';
        bar.width(percentVal)
        percent.html(percentVal);
    },
    success: function() {
        var percentVal = '100%';
        bar.width(percentVal)
        percent.html(percentVal);
    },
\tcomplete: function(xhr) {
\t\tres = xhr.responseText;
\t\tresary = res.split(\"\\n\");
\t\tstatus.removeClass('alert-danger');
\t\tstatus.addClass('alert-success');
\t\tstatus.html(resary[0]);
\t\t\$('#status').show();
\t\tvar d = new Date();
\t\t\$('#mobprofilepic').attr('src', '/uploads/avtars/'+resary[1]+\"?\"+d.getTime());
\t\t\$('#profilepic').attr('src', '/uploads/avtars/'+resary[1]+\"?\"+d.getTime());
\t}
});

";
        // line 82
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "inputs")) {
            // line 83
            echo "var statusdoc = \$('#statusdoc');
\$('#frmdocupload').ajaxForm({
    beforeSend: function(xhr) {
        statusdoc.empty();
        var percentVal = '0%';
        bar.width(percentVal)
        percent.html(percentVal);
\t\tvar ext = \$('#mydoc').val().split('.').pop().toLowerCase();
\t\tif(\$.inArray(ext, ['php', 'js']) != -1) {
\t\t\tstatusdoc.addClass('alert-danger');
\t\t\tstatusdoc.html('Error: php, js files are not allowed.');
\t\t\txhr.abort();
\t\t}
    },
    uploadProgress: function(event, position, total, percentComplete) {
        var percentVal = percentComplete + '%';
        bar.width(percentVal)
        percent.html(percentVal);
    },
    success: function() {
        var percentVal = '100%';
        bar.width(percentVal)
        percent.html(percentVal);
    },
\tcomplete: function(xhr) {
\t\tres = xhr.responseText;
\t\tresary = res.split(\"\\n\");
\t\tstatusdoc.addClass('alert-success');
\t\tstatusdoc.html(resary[0]);
\t\t\$('#statusdoc').show();
\t\tpid = \$('#cnou').val();
\t\thtml = resary[1];
\t\t\$('#dropdown'+pid).html(html);
\t}
});
";
        }
        // line 119
        if ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "wizardspage")) {
            // line 120
            echo "\t";
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "wizardspage") == "exec-summary")) {
                // line 121
                echo "\tvar statusdiagram = \$('#statusdiagram');
\t\$('#frmdiagram').ajaxForm({
\t\tbeforeSend: function(xhr) {
\t\t\tstatusdiagram.empty();
\t\t\tvar percentVal = '0%';
\t\t\tbar.width(percentVal)
\t\t\tpercent.html(percentVal);
\t\t\tvar ext = \$('#diagram').val().split('.').pop().toLowerCase();
\t\t\tif(\$.inArray(ext, ['php', 'js']) != -1) {
\t\t\t\tstatusdiagram.addClass('alert-danger');
\t\t\t\tstatusdiagram.html('Error: php, js files are not allowed.');
\t\t\t\txhr.abort();
\t\t\t}
\t\t},
\t\tuploadProgress: function(event, position, total, percentComplete) {
\t\t\tvar percentVal = percentComplete + '%';
\t\t\tbar.width(percentVal)
\t\t\tpercent.html(percentVal);
\t\t},
\t\tsuccess: function() {
\t\t\tvar percentVal = '100%';
\t\t\tbar.width(percentVal)
\t\t\tpercent.html(percentVal);
\t\t},
\t\tcomplete: function(xhr) {
\t\t\tres = xhr.responseText;
\t\t\tresary = res.split(\"\\n\");
\t\t\tstatusdiagram.addClass('alert-success');
\t\t\tstatusdiagram.html(resary[0]);
\t\t\t\$('#statusdiagram').show();
\t\t\t\$('#diagramslist').html(resary[1]);
\t\t}
\t});
\t";
            }
        }
        // line 156
        echo "
})();
</script>
";
    }

    public function getTemplateName()
    {
        return "_profile-avtar.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 121,  144 => 120,  142 => 119,  65 => 30,  79 => 47,  69 => 40,  49 => 26,  39 => 19,  366 => 124,  360 => 123,  358 => 122,  347 => 113,  341 => 112,  332 => 108,  327 => 106,  318 => 103,  315 => 102,  312 => 101,  309 => 100,  306 => 99,  304 => 98,  301 => 97,  297 => 96,  288 => 94,  279 => 90,  275 => 89,  263 => 85,  260 => 84,  257 => 83,  254 => 82,  249 => 80,  245 => 79,  242 => 78,  236 => 77,  227 => 73,  223 => 72,  214 => 69,  211 => 68,  208 => 67,  205 => 66,  202 => 65,  200 => 64,  193 => 62,  190 => 61,  184 => 156,  175 => 56,  171 => 55,  162 => 52,  159 => 51,  153 => 49,  150 => 48,  148 => 47,  141 => 45,  123 => 39,  119 => 38,  110 => 35,  107 => 34,  98 => 31,  95 => 30,  82 => 25,  66 => 20,  62 => 19,  43 => 11,  34 => 8,  30 => 7,  25 => 5,  354 => 229,  338 => 218,  321 => 206,  308 => 198,  294 => 95,  280 => 180,  266 => 86,  252 => 81,  237 => 152,  225 => 145,  212 => 137,  197 => 63,  185 => 120,  172 => 112,  157 => 102,  132 => 43,  118 => 78,  104 => 83,  90 => 60,  59 => 33,  102 => 82,  73 => 48,  50 => 23,  46 => 21,  40 => 20,  38 => 18,  19 => 1,  164 => 85,  161 => 84,  156 => 50,  106 => 4,  100 => 114,  94 => 112,  91 => 29,  85 => 44,  83 => 81,  74 => 74,  58 => 64,  54 => 62,  52 => 22,  44 => 55,  42 => 54,  37 => 9,  35 => 50,  27 => 6,  22 => 1,  152 => 58,  149 => 57,  145 => 46,  138 => 44,  129 => 47,  125 => 46,  121 => 45,  117 => 44,  113 => 7,  109 => 5,  105 => 41,  101 => 32,  97 => 113,  89 => 54,  84 => 37,  81 => 47,  78 => 24,  75 => 37,  72 => 73,  70 => 21,  64 => 67,  60 => 29,  32 => 3,  29 => 46,);
    }
}
