<?php

/* assessment-wireless-details.html */
class __TwigTemplate_7bcf34662a84695ac9d06078b671775c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 15
            echo "\t<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 34
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 35
            echo "      <!-- Tab panes -->
        <div class=\"tab-content tab_border\">
\t\t<div role=\"tabpanel\" class=\"tab-pane active\" id=\"screen1\">
            <div class=\"screen7_inner_part widget-box widget-color-blue\">
                <div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i>3 Description of SOW &amp; Approach Taken</h4>
                </div>
                
                <div class=\"widget-body\">
                \t<div class=\"widget-main widget_main_extra_part\">
                    \t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">3.8 Wireless details</div>
\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\tFor each wireless technology in scope, identify following:
\t\t\t\t\t</div>
                    \t<div class=\"screen9_table_block_part screen10_extra screen11_part\">
                           
                            <div class=\"table-responsive\">
                                <table class=\"table table-striped\" id=\"tbl1\">
                                  <tbody>
                                    <tr>
                                      <td class=\"col-md-4\" rowspan=\"2\"><strong>Identified wireless technology</strong></td>
                                      <td colspan=\"3\"><strong>For eash wireless technology in scope, identify the following (yes/no):</strong></td>
                                    </tr>
                                    <tr>
                                      <td><strong>Whether the technology is used to store, process or transmit CHD</strong></td>
                                      <td><strong>Whether the technology is connected to or part of the CDE</strong></td>
                                      <td><strong>Whether the technology could impact the security of the CDE1</strong></td>
                                    </tr>
\t\t\t\t\t\t\t\t\t";
            // line 63
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "in_scope"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 64
                echo "                                    <tr>
\t\t\t\t\t\t\t\t\t\t<td><input name=\"wireless_tech[]\" type=\"text\" value=\"";
                // line 65
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "wireless_tech"), "html", null, true);
                echo "\" class=\"form-control\"></td>
                                        <td align=\"center\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock\">
\t\t\t\t\t\t\t\t\t\t\t<input ";
                // line 68
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "used_to_store_chd") == "yes")) {
                    echo " checked=\"checked\"";
                }
                echo " value=\"1\" id=\"used_to_store_chd-1-";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" name=\"used_to_store_chd1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"used_to_store_chd[]\" id=\"used_to_store_chd";
                // line 69
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "used_to_store_chd"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</td>
                                        <td align=\"center\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock\">
\t\t\t\t\t\t\t\t\t\t\t<input ";
                // line 74
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "connected_to_cde") == "yes")) {
                    echo " checked=\"checked\"";
                }
                echo " value=\"1\" id=\"connected_to_cde-1-";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" name=\"connected_to_cde1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\"> 
\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"connected_to_cde[]\" id=\"connected_to_cde";
                // line 75
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "connected_to_cde"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t<td align=\"center\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock\">
\t\t\t\t\t\t\t\t\t\t\t\t<input ";
                // line 80
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inpact_the_cde") == "yes")) {
                    echo " checked=\"checked\"";
                }
                echo " value=\"1\" id=\"inpact_the_cde-1-";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" name=\"inpact_the_cde1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\" />
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"inpact_the_cde[]\" id=\"inpact_the_cde";
                // line 81
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inpact_the_cde"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 82
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 83
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t&nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 85
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t&nbsp;&nbsp;&nbsp;
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 87
                echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</td>
                                    </tr>
\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 90
            echo "\t\t\t
                                  </tbody>
                                </table>
                              </div>
                              <div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow('tbl1');\" > Add New </div>
                        </div>
                        
                        <div class=\"screen9_table_block_part screen10_extra screen11_part\">
                            <h5>Wireless technology not in scope for this assessment:</h5>
                            <div class=\"table-responsive\">
                                <table class=\"table table-striped\" id=\"tbl2\">
                                  <thead>
                                    <tr>
                                        <th class=\"col-md-6 col-sm-6 col-xs-6\">Identified wireless technology(not in scope)</th>
                                        <th class=\"col-md-6 col-sm-6 col-xs-6\">Describe hoe the wireless technology was validataed by the assessor to be not in scope.</th>
                                    </tr>
                                  </thead>
                                  <tbody>
\t\t\t\t\t\t\t\t\t";
            // line 108
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "not_in_scope"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 109
                echo "                                    <tr>
                                      <td class=\"col-md-6 col-sm-6 col-xs-6 widget_textarea_extra\"><textarea name=\"tech_not_in_scope[]\" class=\"form-control\" rows=\"2\" required>";
                // line 110
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "tech_not_in_scope"), "html", null, true);
                echo "</textarea></td>
                                      <td class=\"col-md-6 col-sm-6 col-xs-6 widget_textarea_extra\"><textarea name=\"how_validated[]\" class=\"form-control\" rows=\"2\" required>";
                // line 111
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "how_validated"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t  ";
                // line 112
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    echo " <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a> ";
                }
                // line 113
                echo "\t\t\t\t\t\t\t\t\t  </td>
                                    </tr>
\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 115
            echo "\t
                                  </tbody>
                                </table>
                              </div>
                              <div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow('tbl2');\" > Add New </div>
                        </div>
                        <button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 121
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
             \t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button>
                    </div>
                </div>
            </div>
        </div>
      </div>
\t  </form>
    </div>
";
        }
    }

    // line 132
    public function block_footer($context, array $blocks = array())
    {
        // line 133
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script src=\"/assets/js/chosen.jquery.js\"></script>
\t<link href=\"/assets/css/bootstrap-switch.css\" type=\"text/css\" rel=\"stylesheet\">
\t<script src=\"/assets/js/bootstrap-switch.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 142
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 143
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 147
            echo "var chkno = ";
            echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "in_scope")), "html", null, true);
            echo ";
\$(document).ready(function() {
   
\t\$('#frm').bootstrapValidator();
\t\$(\".switch\").bootstrapSwitch();
    \$(\"#tbl1\").on('click','.remCF',function(){
        \$(this).parent().parent().parent().remove();
    });
\t \$(\"#tbl2\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\tary = \$(this).attr('id').split('-');
\t\tval = state ? 'yes' : 'no';
\t\t\$('#'+ary[0]+ary[2]).val(val);
\t});
});
function addrow(tbl_id)
{
\tif(tbl_id == 'tbl1')
\t{
\t\thtml = '';
\t\thtml = html + '<tr>';
\t\thtml = html + '<td><input name=\"wireless_tech[]\" type=\"text\" class=\"form-control\"></td>';
\t\thtml = html + '<td align=\"center\"> <div class=\"lockunlock\">';
\t\thtml = html + '<input value=\"1\" id=\"used_to_store_chd-1-'+chkno+'\" name=\"used_to_store_chd1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">';
\t\thtml = html + '<input type=\"hidden\" id=\"used_to_store_chd'+chkno+'\" name=\"used_to_store_chd[]\" value=\"no\" />';
\t\thtml = html + '</div></td>';
\t\thtml = html + '<td align=\"center\"> <div class=\"lockunlock\">';
\t\thtml = html + '<input  value=\"1\" id=\"connected_to_cde-1-'+chkno+'\" name=\"connected_to_cde1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">';
\t\thtml = html + '<input type=\"hidden\" id=\"connected_to_cde'+chkno+'\" name=\"connected_to_cde[]\" value=\"no\" />';
\t\thtml = html + '</div></td>';
\t\thtml = html + '<td align=\"center\"> <div class=\"lockunlock\">';
\t\thtml = html + '<input value=\"1\" id=\"inpact_the_cde-1-'+chkno+'\" name=\"inpact_the_cde1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">';
\t\thtml = html + '<input type=\"hidden\" id=\"inpact_the_cde'+chkno+'\" name=\"inpact_the_cde[]\" value=\"no\" />';
\t\thtml = html + '&nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a></div></td>';
\t\t\$(\"#\"+tbl_id).append(html);
\t\t\$(\".switch\").bootstrapSwitch();
\t\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\t\tary = \$(this).attr('id').split('-');
\t\t\tval = state ? 'yes' : 'no';
\t\t\t\$('#'+ary[0]+ary[2]).val(val);
\t\t});
\t\tchkno++;
\t}
\tif(tbl_id == 'tbl2')
\t{
\t\t\$(\"#\"+tbl_id).append('<tr><td class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"tech_not_in_scope[]\" class=\"form-control\" rows=\"3\" required></textarea></td><td class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"how_validated[]\" class=\"form-control\" rows=\"3\" required></textarea>&nbsp; &nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a></td></tr>');
\t\t\$(\".switch\").bootstrapSwitch();
\t}
}
";
        }
        // line 199
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "assessment-wireless-details.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  428 => 199,  372 => 147,  366 => 143,  364 => 142,  351 => 133,  348 => 132,  333 => 121,  325 => 115,  309 => 113,  305 => 112,  301 => 111,  297 => 110,  294 => 109,  277 => 108,  257 => 90,  240 => 87,  236 => 85,  232 => 83,  230 => 82,  224 => 81,  216 => 80,  206 => 75,  198 => 74,  188 => 69,  180 => 68,  174 => 65,  171 => 64,  154 => 63,  124 => 35,  122 => 34,  117 => 32,  113 => 31,  109 => 30,  105 => 29,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  80 => 22,  71 => 15,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
