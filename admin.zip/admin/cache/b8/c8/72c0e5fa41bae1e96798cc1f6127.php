<?php

/* _wizards-nav-tabs.html */
class __TwigTemplate_b8c872c0e5fa41bae1e96798cc1f6127 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"\" >

\t<ul class=\"nav nav-tabs\" role=\"tablist\">
\t\t<li role=\"presentation\" ";
        // line 4
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "current_section") == "section1")) {
            echo "  class=\"hover active\" ";
        }
        echo " onclick=\"jumpto('assessment-timeframe.php');\" ><span>1 :</span><p>Contact Information and<br />Report Date </p></li>
\t\t<li role=\"presentation\" ";
        // line 5
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "current_section") == "section2")) {
            echo "  class=\"active\" ";
        }
        echo "  onclick=\"jumpto('assessment-exec-summary.php');\"><span>2 :</span><p> Summary<br />Overview </p></li>
\t\t<li role=\"presentation\" ";
        // line 6
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "current_section") == "section3")) {
            echo "  class=\"active\" ";
        }
        echo " onclick=\"jumpto('assessment-sow-summary.php');\" ><span>3 :</span><p> Description of Scope of Work<br />and Approach Taken</p></li>
\t\t<li role=\"presentation\" ";
        // line 7
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "current_section") == "section4")) {
            echo "  class=\"active\" ";
        }
        echo "onclick=\"jumpto('assessment-reviewed-environment.php');\"  ><span>4 :</span><p> Details about<br />Reviewed Environment</p></li>
\t\t<li role=\"presentation\" ";
        // line 8
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "current_section") == "section5")) {
            echo "  class=\"active\" ";
        }
        echo " onclick=\"jumpto('assessment-quarterly-result-initial.php');\" ><span>5 :</span><p> Quarterly Scan<br />Results</p></li>
\t</ul>

</div>
\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t&nbsp;
\t </div>
\t<div class=\"col-md-12 col-sm-12 col-xs-12 pull-left\">
\t\t<h3 class=\"block_title\">Go To :</h3>
\t\t<div class=\"btn-group\">
\t\t\t<select id=\"searchby\" name=\"sb\" class=\"selectpicker\" onchange=\"jumpto(this.value);\">
\t\t\t\t";
        // line 19
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "wizards_pages"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 20
            echo "\t\t\t\t\t<option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "page"), "html", null, true);
            echo "\"";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "section_no") == $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subsection"))) {
                echo " selected=\"selected\"";
            }
            echo "> ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "section_no"), "html", null, true);
            echo "</option>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 22
        echo "\t\t\t</select>
\t\t</div>
\t</div>";
    }

    public function getTemplateName()
    {
        return "_wizards-nav-tabs.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 22,  68 => 20,  64 => 19,  48 => 8,  42 => 7,  36 => 6,  30 => 5,  24 => 4,  19 => 1,);
    }
}
