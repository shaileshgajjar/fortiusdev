<?php

/* _front-latest-chats.html */
class __TwigTemplate_5be8e69f8a3f8dbabf9ede1b1852d0eb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal fade \" id=\"latest-chats\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog latest-chats-main pull-right\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
\t\t\t<span aria-hidden=\"true\">&times;</span>
\t\t</button>
        <h4 class=\"modal-title\" id=\"clabel\"> </h4>
      </div>
      <div class=\"modal-body\">
\t\t<div id=\"chats-thread\" style=\"height:200px; overflow-y:scroll; margin-top:10px; padding:5px;\"></div>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
<script type=\"text/javascript\">
function getlatestchats(current_user)
{
\t
\tflds = 'current_user='+current_user;
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: '/get-latest-chats.php',
\t\tdata: flds,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data1) {
\t\t\$('div#chats-thread').html(data1);
\t\t\$('span.notifications').text('');
\t});\t
}
</script>";
    }

    public function getTemplateName()
    {
        return "_front-latest-chats.html";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
