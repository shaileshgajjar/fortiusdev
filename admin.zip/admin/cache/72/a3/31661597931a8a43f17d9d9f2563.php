<?php

/* _front-settings.html */
class __TwigTemplate_72a331661597931a8a43f17d9d9f2563 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal fade\" id=\"email_settings\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Email Notifications Settings
\t\t\t\t\t";
        // line 7
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_name") != "")) {
            // line 8
            echo "\t\t\t\t\t [ ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_name"), "html", null, true);
            echo " ]
\t\t\t\t\t";
        }
        // line 10
        echo "\t\t\t\t</h4>
\t\t\t</div>
\t\t\t<form class=\"form-horizontal bv-form\" name=\"frmsettings\" id=\"frmsettings\" method=\"post\" action=\"\"
\t\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\">
\t\t\t\t<input type=\"hidden\" name=\"task\" value=\"save_notification\" >
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Frequency</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<div class=\" label-inputs pull-left\">
\t\t\t\t\t\t\t<select required id=\"freq\" name=\"freq\" class=\"form-control\" onchange=\"showhidedow(this.value);\">
\t\t\t\t\t\t\t\t<option value=\"1\"";
        // line 24
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "freq"), "value") == "1")) {
            echo " selected=\"selected\"";
        }
        echo ">Daily</option>
\t\t\t\t\t\t\t\t<option value=\"7\"";
        // line 25
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "freq"), "value") == "7")) {
            echo " selected=\"selected\"";
        }
        echo ">Weekly</option>
\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t";
        // line 30
        $context["extra"] = " style=\"display:none;\"";
        // line 31
        echo "\t\t\t\t";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "freq"), "value") == "7")) {
            // line 32
            echo "\t\t\t\t\t";
            $context["extra"] = " style=\"display:block;\"";
            // line 33
            echo "\t\t\t\t";
        }
        // line 34
        echo "\t\t\t\t<div";
        echo (isset($context["extra"]) ? $context["extra"] : null);
        echo " class=\"form-group\" id=\"day_sel\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Day of week </label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<div class=\" label-inputs pull-left\">
\t\t\t\t\t\t\t<select required id=\"day\" name=\"day\" class=\"form-control\" >
\t\t\t\t\t\t\t\t<option value=\"mon\"";
        // line 39
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "day"), "value") == "mon")) {
            echo " selected=\"selected\"";
        }
        echo ">Monday</option>
\t\t\t\t\t\t\t\t<option value=\"tue\"";
        // line 40
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "day"), "value") == "tue")) {
            echo " selected=\"selected\"";
        }
        echo ">Tuesday</option>
\t\t\t\t\t\t\t\t<option value=\"wed\"";
        // line 41
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "day"), "value") == "wed")) {
            echo " selected=\"selected\"";
        }
        echo ">Wednesday</option>
\t\t\t\t\t\t\t\t<option value=\"thu\"";
        // line 42
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "day"), "value") == "thu")) {
            echo " selected=\"selected\"";
        }
        echo ">Thursday</option>
\t\t\t\t\t\t\t\t<option value=\"fri\"";
        // line 43
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "day"), "value") == "fri")) {
            echo " selected=\"selected\"";
        }
        echo ">Friday</option>
\t\t\t\t\t\t\t\t<option value=\"sat\"";
        // line 44
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "day"), "value") == "sat")) {
            echo " selected=\"selected\"";
        }
        echo ">Saturday</option>
\t\t\t\t\t\t\t\t<option value=\"sun\"";
        // line 45
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "day"), "value") == "sun")) {
            echo " selected=\"selected\"";
        }
        echo ">Sunday</option>
\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\" id=\"time_to_send_hr\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Time </label>
\t\t\t\t\t<div class=\"col-lg-2\">
\t\t\t\t\t\t<div class=\" label-inputs pull-left\">
\t\t\t\t\t\t\t<select required id=\"hours\" name=\"hours\" class=\"form-control\" >
\t\t\t\t\t\t\t\t<option value=\"\"";
        // line 55
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "hh"), "value") == "")) {
            echo " selected=\"selected\"";
        }
        echo ">Hours</option>
\t\t\t\t\t\t\t\t";
        // line 56
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(1, 24));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 57
            echo "\t\t\t\t\t\t\t\t\t";
            if (((isset($context["i"]) ? $context["i"] : null) < 10)) {
                // line 58
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context["hh"] = ("0" . (isset($context["i"]) ? $context["i"] : null));
                // line 59
                echo "\t\t\t\t\t\t\t\t\t";
            } else {
                // line 60
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context["hh"] = (isset($context["i"]) ? $context["i"] : null);
                // line 61
                echo "\t\t\t\t\t\t\t\t\t";
            }
            // line 62
            echo "\t\t\t\t\t\t\t\t\t<option value=\"";
            echo twig_escape_filter($this->env, (isset($context["hh"]) ? $context["hh"] : null), "html", null, true);
            echo "\"";
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "hh"), "value") == (isset($context["hh"]) ? $context["hh"] : null))) {
                echo " selected=\"selected\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, (isset($context["hh"]) ? $context["hh"] : null), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 64
        echo "\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-lg-2\">
\t\t\t\t\t\t<div class=\" label-inputs pull-left\">
\t\t\t\t\t\t\t<select required id=\"minutes\" name=\"minutes\" class=\"form-control\" >
\t\t\t\t\t\t\t\t<option value=\"\"";
        // line 70
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "mm"), "value") == "")) {
            echo " selected=\"selected\"";
        }
        echo ">Minutes</option>
\t\t\t\t\t\t\t\t<option value=\"00\"";
        // line 71
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "mm"), "value") == "00")) {
            echo " selected=\"selected\"";
        }
        echo ">00</option>
\t\t\t\t\t\t\t\t<option value=\"15\"";
        // line 72
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "mm"), "value") == "15")) {
            echo " selected=\"selected\"";
        }
        echo ">15</option>
\t\t\t\t\t\t\t\t<option value=\"30\"";
        // line 73
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "mm"), "value") == "30")) {
            echo " selected=\"selected\"";
        }
        echo ">30</option>
\t\t\t\t\t\t\t\t<option value=\"45\"";
        // line 74
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "mm"), "value") == "45")) {
            echo " selected=\"selected\"";
        }
        echo ">45</option>
\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t";
        // line 79
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c")) {
            // line 80
            echo "\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Content Type</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<div class=\"radio\"> 
\t\t\t\t\t\t  <label><input type=\"radio\" name=\"content\" value=\"graph\"";
            // line 84
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "content"), "value") == "graph")) {
                echo " checked=\"checked\"";
            }
            echo ">Graph</label>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"radio\">
\t\t\t\t\t\t  <label><input type=\"radio\" name=\"content\" value=\"html\"";
            // line 87
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "content"), "value") == "html")) {
                echo " checked=\"checked\"";
            }
            echo ">Html [Grid Form]</label>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t";
        }
        // line 92
        echo "\t\t\t\t<div class=\"form-group has-feedback\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Alternate Email ID</label>
\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t<input type=\"text\" name=\"alternate_email_id\" id=\"alternate_email_id\" class=\"form-control\" placeholder=\"Second or Alternate Email ID\" title=\"If provided then notification email will send to this email also\" autofill=\"off\" value=\"";
        // line 95
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "n_settings"), "alternate_email_id"), "value"), "html", null, true);
        echo "\" >
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"modal-footer\">
\t\t\t\t<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
\t\t\t\t<button type=\"submit\" onclick=\"savesettings();\" data-dismiss=\"modal\" class=\"btn btn-primary\">Save changes</button>
\t\t\t</div>
\t\t\t</form>
\t\t</div>
\t</div>
</div>
<script type=\"text/javascript\">
function showhidedow(val)
{
\tif ( val == 1 )
\t\t\$('#day_sel').hide();
\telse
\t\t\$('#day_sel').show();
}
function savesettings()
{
\tformfields = \$('#frmsettings').serialize() + \"&settings=notification\";
\t
\ttheurl = '/savesettings.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t
\t});
}
</script>
";
    }

    public function getTemplateName()
    {
        return "_front-settings.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  246 => 92,  210 => 74,  204 => 73,  186 => 70,  160 => 61,  157 => 60,  154 => 59,  111 => 43,  99 => 41,  93 => 40,  78 => 34,  69 => 31,  57 => 25,  155 => 134,  412 => 158,  409 => 157,  389 => 148,  387 => 147,  381 => 146,  368 => 140,  364 => 139,  357 => 138,  355 => 137,  350 => 134,  347 => 133,  336 => 127,  322 => 123,  316 => 121,  312 => 120,  309 => 119,  303 => 117,  292 => 114,  286 => 112,  278 => 110,  276 => 109,  268 => 103,  265 => 102,  260 => 101,  249 => 98,  244 => 95,  240 => 93,  226 => 87,  222 => 80,  218 => 85,  196 => 77,  192 => 71,  178 => 64,  174 => 68,  170 => 67,  156 => 60,  123 => 45,  119 => 47,  105 => 42,  98 => 38,  96 => 37,  90 => 33,  75 => 33,  71 => 25,  62 => 21,  49 => 15,  43 => 13,  40 => 20,  36 => 11,  30 => 10,  255 => 99,  241 => 140,  228 => 84,  214 => 124,  212 => 84,  181 => 105,  162 => 94,  131 => 76,  102 => 59,  87 => 39,  66 => 30,  45 => 19,  38 => 15,  33 => 13,  217 => 127,  208 => 121,  202 => 119,  193 => 170,  191 => 111,  176 => 103,  164 => 91,  161 => 90,  151 => 58,  148 => 57,  146 => 82,  117 => 44,  113 => 46,  101 => 39,  77 => 30,  73 => 28,  67 => 30,  65 => 30,  55 => 25,  50 => 15,  47 => 14,  34 => 11,  31 => 10,  19 => 1,  198 => 72,  195 => 113,  190 => 80,  140 => 7,  136 => 5,  133 => 77,  127 => 49,  124 => 130,  121 => 129,  118 => 68,  115 => 127,  112 => 126,  109 => 55,  103 => 53,  100 => 122,  97 => 121,  94 => 120,  91 => 119,  89 => 91,  85 => 44,  83 => 88,  74 => 81,  72 => 32,  64 => 74,  58 => 20,  54 => 69,  52 => 22,  44 => 62,  42 => 12,  37 => 58,  35 => 10,  27 => 7,  22 => 1,  771 => 414,  760 => 407,  709 => 358,  700 => 352,  664 => 318,  662 => 317,  659 => 316,  642 => 301,  636 => 300,  630 => 298,  620 => 296,  610 => 294,  607 => 293,  605 => 292,  602 => 291,  598 => 290,  594 => 289,  579 => 276,  570 => 274,  560 => 272,  550 => 270,  548 => 269,  545 => 268,  541 => 267,  537 => 266,  522 => 253,  513 => 251,  510 => 250,  500 => 248,  490 => 246,  487 => 245,  484 => 244,  480 => 243,  476 => 242,  461 => 229,  452 => 227,  442 => 225,  432 => 223,  430 => 222,  427 => 221,  423 => 220,  419 => 219,  404 => 206,  395 => 150,  385 => 202,  375 => 145,  373 => 199,  370 => 198,  366 => 197,  362 => 196,  330 => 125,  328 => 165,  320 => 122,  317 => 159,  306 => 151,  295 => 115,  293 => 141,  283 => 133,  281 => 132,  274 => 129,  271 => 128,  263 => 123,  261 => 122,  257 => 100,  254 => 119,  251 => 95,  248 => 117,  245 => 116,  242 => 115,  239 => 114,  236 => 87,  233 => 112,  230 => 111,  220 => 79,  209 => 122,  205 => 79,  201 => 78,  194 => 93,  188 => 90,  185 => 89,  183 => 88,  179 => 104,  175 => 86,  171 => 85,  167 => 92,  163 => 62,  159 => 89,  153 => 133,  144 => 56,  141 => 77,  138 => 55,  135 => 75,  132 => 74,  130 => 69,  126 => 72,  120 => 70,  116 => 69,  110 => 65,  106 => 124,  104 => 60,  82 => 42,  79 => 41,  76 => 40,  51 => 24,  48 => 20,  46 => 21,  32 => 3,  29 => 8,);
    }
}
