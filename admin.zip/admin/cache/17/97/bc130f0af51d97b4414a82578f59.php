<?php

/* getdocumentlist.html */
class __TwigTemplate_1797bc130f0af51d97b4414a82578f59 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 2
            echo "<tr>
\t<td class=\"text-center\">
\t\t<label class=\"pos-rel\">
\t\t\t<input type=\"checkbox\" name=\"removeid[]\" class=\"ace\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<span class=\"lbl\"></span>
\t\t</label>
\t</td>
\t<td class=\"text-center\">";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "</td>
\t<td>";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "document"), "html", null, true);
            echo "</td>
\t<td>";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "upload_date"), "html", null, true);
            echo "</td>
</tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 14
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows")) == 0)) {
            // line 15
            echo "<tr>
\t<td colspan=\"8\">No Records</td>
</tr>
";
        }
        // line 19
        echo "||||
";
        // line 20
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(1, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total_pages")));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 21
            echo "\t<option value=";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            if (((isset($context["i"]) ? $context["i"] : null) == $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"))) {
                echo " selected=\"selected\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "</option>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
    }

    public function getTemplateName()
    {
        return "getdocumentlist.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 21,  63 => 20,  60 => 19,  54 => 15,  52 => 14,  43 => 11,  39 => 10,  35 => 9,  28 => 5,  23 => 2,  19 => 1,);
    }
}
