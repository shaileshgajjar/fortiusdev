<?php

/* dashboard.html */
class __TwigTemplate_cbdbfcb9aba5d093852fdb86979a0b6f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"\" />
</form>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t<div class=\"col-xs-12\">
\t\t\t\t\t\t\t\t\t\t<div class=\"table-header navbar\">
\t\t\t\t\t\t\t\t\t\t\tCustomer List
\t\t\t\t\t\t\t\t\t\t\t<!-- <div class=\"pull-right add-btn\"><button type=\"button\" title=\"New\" class=\"btn btn-success btn-xs\" onclick=\"edit('0', 'customer.php');\"><span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\"></span></button></div> -->
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"table-responsive\">
\t\t\t\t\t\t\t\t\t\t<table id=\"simple-table\" class=\"table table-striped table-bordered table-hover\">
\t\t\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>Company Name</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>Assessment Type</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>Version</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>Assessment QSA</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>Assessment QA</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>Contact Name</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>Telephone</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>Email</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>Compliance Due Date</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>Completed</th>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t</thead>

\t\t\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 30
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "customers"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 31
            echo "\t\t\t\t\t\t\t\t\t\t\t\t<tr";
            echo $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "class");
            echo ">
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 33
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_logo") != "")) {
                // line 34
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                $context["company_logo"] = ("/uploads/logos/" . $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_logo"));
                // line 35
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 36
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                $context["company_logo"] = "/assets/images/no-image.jpg";
                // line 37
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 38
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:edit('";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', 'customer.php');\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img id=\"companylogo\" width=\"30px\" height=\"30px\" class=\"nav-user-photo\" src=\"";
            // line 39
            echo twig_escape_filter($this->env, (isset($context["company_logo"]) ? $context["company_logo"] : null), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "username"), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "username"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
            echo "</a></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "merchant_type"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td> ";
            // line 42
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "assessment_version") == "v31_")) {
                echo " 3.1 ";
            } else {
                echo " 3.2 ";
            }
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 43
            echo twig_escape_filter($this->env, getqsas($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "qa"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "username"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "mobile"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "email"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "compliance_due_date"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
            echo "%</td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 52
        echo "\t\t\t\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t\t</div><!-- /.table-responsive -->
\t\t\t\t\t\t\t\t\t</div><!-- /.span -->
\t\t\t\t\t\t\t\t</div><!-- /.row -->
\t\t\t\t\t\t\t\t";
        // line 57
        $this->env->loadTemplate("_kanban-grid.html")->display($context);
    }

    // line 59
    public function block_footer($context, array $blocks = array())
    {
        // line 60
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<script src=\"/assets/js/list.js\"></script>
\t<link rel=\"stylesheet\" href=\"/assets/css/kanbanview.css\">\t
";
    }

    public function getTemplateName()
    {
        return "dashboard.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  161 => 60,  158 => 59,  154 => 57,  147 => 52,  138 => 49,  134 => 48,  130 => 47,  126 => 46,  122 => 45,  118 => 44,  114 => 43,  106 => 42,  102 => 41,  98 => 40,  90 => 39,  85 => 38,  82 => 37,  79 => 36,  76 => 35,  73 => 34,  71 => 33,  65 => 31,  61 => 30,  32 => 3,  29 => 2,);
    }
}
