<?php

/* _upload-diagram.html */
class __TwigTemplate_baed21aab83e2693dcd77f00df8ad848 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- Upload Document Div -->
<div class=\"modal fade\" id=\"upload\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"myModalLabel\">Upload Diagram</h4>
      </div>
      <div class=\"modal-body\">
        <form id=\"frmdiagram\" name=\"frmdiagram\" method=\"post\" action=\"/save-diagram.php\" enctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"savediagram\" />
\t\t\t<input type=\"hidden\" name=\"section_id\" id=\"section_id\" value=\"1\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"file\" name=\"diagram\" id=\"diagram\" style=\"height:30px; cursor:pointer;\" class=\"pull-left\" />
\t\t\t<button type=\"submit\" class=\"btn btn-success pull-left\">Upload</button>
\t\t</form>
\t\t<div class=\"progress\">
\t\t\t<div class=\"bar\"></div >
\t\t\t<div class=\"percent\">0%</div >
\t\t</div>
\t\t<div id=\"statusdiagram\" class=\"alert\"></div>
\t  </div>
      <div class=\"modal-footer\">
\t\t<button type=\"button\" class=\"btn btn-success\" data-dismiss=\"modal\" onclick=\"submitForm();\">Save</button>
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- End upload Doc -->";
    }

    public function getTemplateName()
    {
        return "_upload-diagram.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 13,  19 => 1,  306 => 157,  289 => 142,  283 => 138,  281 => 137,  269 => 129,  266 => 128,  259 => 125,  246 => 115,  241 => 112,  222 => 110,  218 => 109,  197 => 91,  184 => 81,  168 => 68,  150 => 53,  132 => 37,  130 => 36,  125 => 34,  121 => 33,  117 => 32,  113 => 31,  109 => 30,  104 => 28,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  75 => 16,  69 => 13,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
