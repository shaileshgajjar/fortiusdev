<?php

/* _front-comment-to-admin.html */
class __TwigTemplate_c9062c52c07e88a6461e429b274f3317 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal fade\" id=\"general-comments\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"clabel\"> </h4>
      </div>
      <div class=\"modal-body\">
\t\t<input type=\"hidden\" name=\"company_id\" id=\"company_id\" value=\"\"> 
\t\t<input type=\"hidden\" name=\"to_user_id\" id=\"to_user_id\" value=\"\"> 
\t\t<input type=\"hidden\" name=\"commented_by\" id=\"commented_by\" value=\"\"> 
\t\t<input type=\"hidden\" name=\"commented_to\" id=\"commented_to\" value=\"\"> 
\t\t<input type=\"hidden\" name=\"sent_to_role\" id=\"sent_to_role\" value=\"\"> 
\t\t<input type=\"hidden\" name=\"room_id\" id=\"room_id\" value=\"\"> 
\t\t
\t  <textarea name=\"gen_comment\" class=\"form-control\" rows=\"5\" id=\"gen_comment\"></textarea>
\t\t<div id=\"comment-thread\" style=\"height:200px; overflow-y:scroll; margin-top:10px; padding:5px;\"></div>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
\t\t<button type=\"button\" onclick=\"save_gen_comment('gen_comment',0);\" data-dismiss=\"modal\" class=\"btn btn-primary\">Save changes</button>
      </div>
    </div>
  </div>
</div>
<script type=\"text/javascript\">
function get_gen_comment(company_id, to_user_id, commented_by, username)
{
\t\$('input#room_id').val('');
\tvar sent_from_id = ";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method"), "html", null, true);
        echo ";
\tcreatechatroom(company_id,commented_by, sent_from_id, to_user_id);
\t
\t
\t
}
// we call this function only once when user clicks on Chat icon to start texting to selected user or group
function createchatroom(company_id, sent_from_role, sent_from_id, sent_to_id){
\tif(sent_from_role == 'c' )
\t\tvar sent_to_role = 'u';
\telse
\t\tvar sent_to_role = 'c';

\tvar current_user = ";
        // line 43
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method"), "html", null, true);
        echo ";
\tformfields = 'company_id='+company_id+'&sent_from_id='+sent_from_id+'&sent_from_role='+sent_from_role+'&sent_to_id='+sent_to_id+'&sent_to_role=u&chat_type=1';
\ttheurl = '/createchatroom.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(response) {
\t\tflds = 'room_id='+response+'&current_user='+current_user;
\t\t\$('input#room_id').val(response);
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: '/general-comments.php',
\t\t\tdata: flds,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data1) {
\t\t\t\$('div#comment-thread').html(data1);
\t\t});
\t});
}
</script>";
    }

    public function getTemplateName()
    {
        return "_front-comment-to-admin.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  66 => 43,  50 => 30,  19 => 1,);
    }
}
