<?php

/* front-dashboard.html */
class __TwigTemplate_a68b655ce446d1f548e91b9d29d62a40 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-front-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-front-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<script type=\"text/javascript\">
function BrowserCheck()
{
    var N= navigator.appName, ua= navigator.userAgent, tem;
    var M= ua.match(/(opera|chrome|safari|firefox|msie|trident)\\/?\\s*(\\.?\\d+(\\.\\d+)*)/i);
    if(M && (tem= ua.match(/version\\/([\\.\\d]+)/i))!= null) {M[2]=tem[1];}
    M= M? [M[1], M[2]]: [N, navigator.appVersion,'-?'];
    return M;
}
</script>
<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t";
        // line 15
        if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u"))) {
            // line 16
            echo "\t\t\t";
            if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c")) {
                // line 17
                echo "\t\t\t<div class=\"col-lg-7\">
\t\t\t\t<div class=\"panel panel-primary\">
\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\tAudit Completion
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t<div id=\"chart1\"></div>
\t\t\t\t\t\t<div class=\"hide-link c1\">&nbsp;&nbsp;</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"col-lg-5\">
\t\t\t\t<div class=\"panel panel-primary\">
\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\tCompliance / Severity
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t<div id=\"chart2\"></div>
\t\t\t\t\t\t<div class=\"hide-link c2\">&nbsp;&nbsp;</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t";
            }
            // line 40
            echo "\t\t";
        }
        // line 41
        echo "\t\t";
        if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q"))) {
            // line 42
            echo "\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"\" />
\t\t</form>
\t\t<div class=\"col-lg-12\">
\t\t\t<div class=\"panel panel-primary\">
\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\tCustomer List
\t\t\t\t</div>
\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t<div class=\"table-responsive\">
\t\t\t\t\t<table class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t\t   <thead>
\t\t\t\t\t\t  <tr class=\"warning\">
\t\t\t\t\t\t\t <th>Company Name</th>
\t\t\t\t\t\t\t <th>Assessment Type</th>
\t\t\t\t\t\t\t <th>Contact Name</th>
\t\t\t\t\t\t\t <th>Telephone</th>
\t\t\t\t\t\t\t <th>Email</th>
\t\t\t\t\t\t\t <th>Compliance Due Date</th>
\t\t\t\t\t\t\t <th class=\"text-center\">Completed</th>
\t\t\t\t\t\t\t ";
            // line 62
            if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s")) {
                // line 63
                echo "\t\t\t\t\t\t\t <th class=\"text-center\">Action</th>
\t\t\t\t\t\t\t ";
            }
            // line 65
            echo "\t\t\t\t\t\t\t <!-- <th class=\"text-center\">Completed</th> -->
\t\t\t\t\t\t  </tr>
\t\t\t\t\t   </thead>
\t\t\t\t\t   <tbody>
\t\t\t\t\t\t  ";
            // line 69
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "customers"));
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 70
                echo "\t\t\t\t\t\t  <tr";
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "class");
                echo ">
\t\t\t\t\t\t\t <td align=\"left\">
\t\t\t\t\t\t\t\t<a href=\"javascript:edit('";
                // line 72
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "', 'fill-data.php');\">
\t\t\t\t\t\t\t\t";
                // line 73
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_logo") != "")) {
                    // line 74
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["company_logo"] = ("/uploads/logos/" . $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_logo"));
                    // line 75
                    echo "\t\t\t\t\t\t\t\t";
                } else {
                    // line 76
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["company_logo"] = "/assets/images/no-image.jpg";
                    // line 77
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 78
                echo "\t\t\t\t\t\t\t\t<img id=\"companylogo\" width=\"30px\" height=\"30px\" class=\"nav-user-photo\" src=\"";
                echo twig_escape_filter($this->env, (isset($context["company_logo"]) ? $context["company_logo"] : null), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "username"), "html", null, true);
                echo "\" title=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "username"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t";
                // line 79
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t <td>";
                // line 82
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "merchant_type"), "html", null, true);
                echo "</td>
\t\t\t\t\t\t\t <td>";
                // line 83
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "username"), "html", null, true);
                echo "</td>
\t\t\t\t\t\t\t <td>";
                // line 84
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "mobile"), "html", null, true);
                echo "</td>
\t\t\t\t\t\t\t <td>";
                // line 85
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "email"), "html", null, true);
                echo "</td>
\t\t\t\t\t\t\t <td>";
                // line 86
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "compliance_due_date"), "html", null, true);
                echo "</td>
\t\t\t\t\t\t\t <td class=\"text-center\">";
                // line 87
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
                echo "%</td>
\t\t\t\t\t\t\t ";
                // line 88
                if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s")) {
                    // line 89
                    echo "\t\t\t\t\t\t\t\t<td class=\"text-center\">
\t\t\t\t\t\t\t\t\t<button type=\"button\" name=\"btnes\" id=\"btnes\" onclick=\"startexecsumm('";
                    // line 90
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                    echo "');\" class=\"btn btn-sm\"><i class=\"fa fa-share-square-o\"></i></button>
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t ";
                }
                // line 93
                echo "\t\t\t\t\t\t\t <!-- <td><span id=\"c";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "\">Loading..</span></td>
\t\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t\t\$(function() {
\t\t\t\t\t\t\t\tvar myvalues = [";
                // line 96
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "values");
                echo "];
\t\t\t\t\t\t\t\tvar maps = { map: { ";
                // line 97
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "maps");
                echo " } };
\t\t\t\t\t\t\t\t\$('#c";
                // line 98
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "').sparkline(myvalues, { type: 'bar', tooltipSuffix:'%' });
\t\t\t\t\t\t\t});
\t\t\t\t\t\t\t</script> -->
\t\t\t\t\t\t  </tr>
\t\t\t\t\t\t  ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 103
            echo "\t\t\t\t\t   </tbody>
\t\t\t\t\t</table>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t\t
\t\t";
        }
        // line 111
        echo "\t\t";
        if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q"))) {
            // line 112
            echo "\t\t\t";
            $this->env->loadTemplate("_front-kanban-grid.html")->display($context);
            // line 113
            echo "\t\t";
        }
        // line 114
        echo "\t\t";
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u")) {
            // line 115
            echo "\t\t\t";
            $this->env->loadTemplate("_front-kanban-grid-users.html")->display($context);
            // line 116
            echo "\t\t";
        }
        // line 117
        echo "\t\t";
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c")) {
            // line 118
            echo "\t\t\t";
            $this->env->loadTemplate("_front-kanban-grid-company.html")->display($context);
            // line 119
            echo "\t\t";
        }
        // line 120
        echo "\t</div>
</div>
";
        // line 122
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s")) {
            // line 123
            echo "<form name=\"frmes\" id=\"frmes\" method=\"post\" action=\"/execsumm/assessment-timeframe.php\">
\t<input type=\"hidden\" name=\"id\" id=\"company_id\" value=\"\" />
</form>
";
        }
    }

    // line 128
    public function block_footer($context, array $blocks = array())
    {
        // line 129
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<script src=\"/assets/js/list.js\"></script>
<link rel=\"stylesheet\" href=\"/assets/css/kanbanview.css\">
";
        // line 132
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s")) {
            // line 133
            echo "<script type=\"text/javascript\">
function startexecsumm(id)
{
\t\$('#company_id').val(id);
\t\$('#frmes').submit();
}
</script>
";
        }
        // line 141
        if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u"))) {
            // line 142
            echo "<script type=\"text/javascript\">
function filluserdata(requirements_id, fl)
{
\tdocument.frm.requirements_id.value = requirements_id;
\tdocument.frm.action = fl;
\tdocument.frm.target = '_self';
\tdocument.frm.submit();\t
}
\$(document).ready(function(){
\t";
            // line 151
            if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u")) {
                echo " 
\t\tvar sum = 0;
\t\t\$('span.row-total').each(function() {
\t\t\tsum += Number(\$(this).text());
\t\t});
\t\t\$(\"span#uc-total\").html(sum);
\t\t\$(\"span#uc-total\").attr('title', 'Found ' + sum + ' Tasks');
\t";
            }
            // line 159
            echo "
\t";
            // line 160
            if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c")) {
                echo " 
\t\t// commented by shailesh on date 29 april 15 ro prevent from javascript error
\t\t/*\$('.selectpicker').selectpicker({
\t\t\tstyle: 'btn-info'
\t\t});*/
\t";
                // line 165
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "s1") != "")) {
                    // line 166
                    echo "\t\t  \$(function () {
\t\t\t\$('#chart1').highcharts({
\t\t\t\tchart: {
\t\t\t\t\ttype: 'bubble',
\t\t\t\t\tplotBorderWidth: 1,
\t\t\t\t\tzoomType: 'xy'
\t\t\t\t},

\t\t\t\ttitle: {
\t\t\t\t\ttext: ''
\t\t\t\t},

\t\t\t\txAxis: {
\t\t\t\t\t title: {text: 'Requirements'},    
\t\t\t\t\tgridLineWidth: 1
\t\t\t\t},

\t\t\t\tyAxis: {
\t\t\t\t\ttitle: {text: 'Procedures'},   
\t\t\t\t\tstartOnTick: false,
\t\t\t\t\tendOnTick: false
\t\t\t\t},
\t\t\t\ttooltip: {
\t\t\t\t\tformatter: function() {
\t\t\t\t\t\treturn ' <b> ' + this.y + '</b> Procedures '+ this.series.name+' of Requirement #'+this.x;
\t\t\t\t\t}
\t\t\t\t},
\t\t\t\tseries: [{
\t\t\t\t\tname:'Y',
\t\t\t\t\tdata: [
\t\t\t\t\t\t";
                    // line 196
                    $context["i"] = 1;
                    echo " 
\t\t\t\t\t\t";
                    // line 197
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["controls"]) ? $context["controls"] : null));
                    foreach ($context['_seq'] as $context["_key"] => $context["req"]) {
                        // line 198
                        echo "\t\t\t\t\t\t\t
\t\t\t\t\t\t\t";
                        // line 199
                        if (((isset($context["i"]) ? $context["i"] : null) < 12)) {
                            // line 200
                            echo "\t\t\t\t\t\t\t\t[";
                            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "Y"), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "Y"), "html", null, true);
                            echo "],
\t\t\t\t\t\t\t";
                        } else {
                            // line 202
                            echo "\t\t\t\t\t\t\t\t[";
                            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "Y"), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "Y"), "html", null, true);
                            echo "]
\t\t\t\t\t\t\t";
                        }
                        // line 204
                        echo "\t\t\t\t\t\t\t";
                        $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
                        echo " 
\t\t\t\t\t\t";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['req'], $context['_parent'], $context['loop']);
                    $context = array_merge($_parent, array_intersect_key($context, $_parent));
                    // line 206
                    echo "\t\t\t\t\t],
\t\t\t\t\tmarker: {
\t\t\t\t\t\tfillColor: {
\t\t\t\t\t\t\tradialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
\t\t\t\t\t\t\tstops: [
\t\t\t\t\t\t\t\t[0, 'rgba(59,201,34,0.5)'],
\t\t\t\t\t\t\t\t[1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0.5).get('rgba')]
\t\t\t\t\t\t\t]
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t}, {
\t\t\t\t\tname:'N',\t\t\t\t\t
\t\t\t\t\tdata: [
\t\t\t\t\t\t";
                    // line 219
                    $context["i"] = 1;
                    echo " 
\t\t\t\t\t\t";
                    // line 220
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "controls"));
                    foreach ($context['_seq'] as $context["_key"] => $context["req"]) {
                        // line 221
                        echo "\t\t\t\t\t\t\t
\t\t\t\t\t\t\t";
                        // line 222
                        if (((isset($context["i"]) ? $context["i"] : null) < 12)) {
                            // line 223
                            echo "\t\t\t\t\t\t\t\t[";
                            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "N"), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "N"), "html", null, true);
                            echo "],
\t\t\t\t\t\t\t";
                        } else {
                            // line 225
                            echo "\t\t\t\t\t\t\t\t[";
                            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "N"), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "N"), "html", null, true);
                            echo "]
\t\t\t\t\t\t\t";
                        }
                        // line 227
                        echo "\t\t\t\t\t\t\t";
                        $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
                        echo " 
\t\t\t\t\t\t";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['req'], $context['_parent'], $context['loop']);
                    $context = array_merge($_parent, array_intersect_key($context, $_parent));
                    // line 229
                    echo "\t\t\t\t\t],
\t\t\t\t\tmarker: {
\t\t\t\t\t\tfillColor: {
\t\t\t\t\t\t\tradialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
\t\t\t\t\t\t\tstops: [
\t\t\t\t\t\t\t\t[0, 'rgba(201,34,59,0.5)'],
\t\t\t\t\t\t\t\t[1, Highcharts.Color(Highcharts.getOptions().colors[1]).setOpacity(0.5).get('rgba')]
\t\t\t\t\t\t\t]
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t},{
\t\t\t\t\tname:'CCW',\t\t\t\t\t
\t\t\t\t\tdata: [
\t\t\t\t\t\t";
                    // line 242
                    $context["i"] = 1;
                    echo " 
\t\t\t\t\t\t";
                    // line 243
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "controls"));
                    foreach ($context['_seq'] as $context["_key"] => $context["req"]) {
                        // line 244
                        echo "\t\t\t\t\t\t\t";
                        if (($this->getAttribute((isset($context["req"]) ? $context["req"] : null), "C") > 0)) {
                            // line 245
                            echo "\t\t\t\t\t\t\t\t";
                            if (((isset($context["i"]) ? $context["i"] : null) < 12)) {
                                // line 246
                                echo "\t\t\t\t\t\t\t\t\t[";
                                echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                                echo ", ";
                                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "C"), "html", null, true);
                                echo ", ";
                                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "C"), "html", null, true);
                                echo "],
\t\t\t\t\t\t\t\t";
                            } else {
                                // line 248
                                echo "\t\t\t\t\t\t\t\t\t[";
                                echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                                echo ", ";
                                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "C"), "html", null, true);
                                echo ", ";
                                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "C"), "html", null, true);
                                echo "]
\t\t\t\t\t\t\t\t";
                            }
                            // line 250
                            echo "\t\t\t\t\t\t\t";
                        }
                        // line 251
                        echo "\t\t\t\t\t\t\t";
                        $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
                        echo " 
\t\t\t\t\t\t";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['req'], $context['_parent'], $context['loop']);
                    $context = array_merge($_parent, array_intersect_key($context, $_parent));
                    // line 253
                    echo "\t\t\t\t\t],
\t\t\t\t\tmarker: {
\t\t\t\t\t\tfillColor: {
\t\t\t\t\t\t\tradialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
\t\t\t\t\t\t\tstops: [
\t\t\t\t\t\t\t\t[0, 'rgba(34,59,201,0.5)'],
\t\t\t\t\t\t\t\t[1, Highcharts.Color(Highcharts.getOptions().colors[1]).setOpacity(0.5).get('rgba')]
\t\t\t\t\t\t\t]
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t},{
\t\t\t\t\tname:'NT',\t\t\t\t\t
\t\t\t\t\tdata: [
\t\t\t\t\t\t";
                    // line 266
                    $context["i"] = 1;
                    echo " 
\t\t\t\t\t\t";
                    // line 267
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "controls"));
                    foreach ($context['_seq'] as $context["_key"] => $context["req"]) {
                        // line 268
                        echo "\t\t\t\t\t\t\t
\t\t\t\t\t\t\t";
                        // line 269
                        if (((isset($context["i"]) ? $context["i"] : null) < 12)) {
                            // line 270
                            echo "\t\t\t\t\t\t\t\t[";
                            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NT"), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NT"), "html", null, true);
                            echo "],
\t\t\t\t\t\t\t";
                        } else {
                            // line 272
                            echo "\t\t\t\t\t\t\t\t[";
                            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NT"), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NT"), "html", null, true);
                            echo "]
\t\t\t\t\t\t\t";
                        }
                        // line 274
                        echo "\t\t\t\t\t\t\t";
                        $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
                        echo " 
\t\t\t\t\t\t";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['req'], $context['_parent'], $context['loop']);
                    $context = array_merge($_parent, array_intersect_key($context, $_parent));
                    // line 276
                    echo "\t\t\t\t\t],
\t\t\t\t\tmarker: {
\t\t\t\t\t\tfillColor: {
\t\t\t\t\t\t\tradialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
\t\t\t\t\t\t\tstops: [
\t\t\t\t\t\t\t\t[0, 'rgba(124,181,236,0.5)'],
\t\t\t\t\t\t\t\t[1, Highcharts.Color(Highcharts.getOptions().colors[1]).setOpacity(0.5).get('rgba')]
\t\t\t\t\t\t\t]
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t},{
\t\t\t\t\tname:'NA',\t\t\t\t\t
\t\t\t\t\tdata: [
\t\t\t\t\t\t";
                    // line 289
                    $context["i"] = 1;
                    echo " 
\t\t\t\t\t\t";
                    // line 290
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "controls"));
                    foreach ($context['_seq'] as $context["_key"] => $context["req"]) {
                        // line 291
                        echo "\t\t\t\t\t\t\t
\t\t\t\t\t\t\t";
                        // line 292
                        if (($this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NA") > 0)) {
                            // line 293
                            echo "\t\t\t\t\t\t\t";
                            if (((isset($context["i"]) ? $context["i"] : null) < 12)) {
                                // line 294
                                echo "\t\t\t\t\t\t\t\t[";
                                echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                                echo ", ";
                                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NA"), "html", null, true);
                                echo ", ";
                                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NA"), "html", null, true);
                                echo "],
\t\t\t\t\t\t\t";
                            } else {
                                // line 296
                                echo "\t\t\t\t\t\t\t\t[";
                                echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                                echo ", ";
                                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NA"), "html", null, true);
                                echo ", ";
                                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NA"), "html", null, true);
                                echo "]
\t\t\t\t\t\t\t";
                            }
                            // line 298
                            echo "\t\t\t\t\t\t\t";
                            $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
                            echo " 
\t\t\t\t\t\t\t";
                        }
                        // line 300
                        echo "\t\t\t\t\t\t";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['req'], $context['_parent'], $context['loop']);
                    $context = array_merge($_parent, array_intersect_key($context, $_parent));
                    // line 301
                    echo "\t\t\t\t\t],
\t\t\t\t\tmarker: {
\t\t\t\t\t\tfillColor: {
\t\t\t\t\t\t\tradialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
\t\t\t\t\t\t\tstops: [
\t\t\t\t\t\t\t\t[0, 'rgba(105,105,255,0.5)'],
\t\t\t\t\t\t\t\t[1, Highcharts.Color(Highcharts.getOptions().colors[1]).setOpacity(0.5).get('rgba')]
\t\t\t\t\t\t\t]
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t},]

\t\t\t});
\t\t});
\t";
                }
                // line 316
                echo "\t
\t";
                // line 317
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "s2") != "")) {
                    // line 318
                    echo "\t\t\$(function () {
\t\t\t\t\$('#chart2').highcharts({
\t\t\t\t\tchart: {
\t\t\t\t\t\ttype: 'bar'
\t\t\t\t\t},
\t\t\t\t\ttitle: {
\t\t\t\t\t\ttext: ''
\t\t\t\t\t},
\t\t\t\t\txAxis: {
\t\t\t\t\t\tcategories: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
\t\t\t\t\t\ttitle: {text: 'Requirements'}
\t\t\t\t\t},
\t\t\t\t\tyAxis: {
\t\t\t\t\t\tmin: 0,
\t\t\t\t\t\ttitle: {
\t\t\t\t\t\t\ttext: ''
\t\t\t\t\t\t}
\t\t\t\t\t},
\t\t\t\t\ttooltip: {
\t\t\t\t\tformatter: function() {
\t\t\t\t\t\treturn ' Completed <b> '+this.y+' % </b> of Requirement #'+ this.x;
\t\t\t\t\t}
\t\t\t\t},
\t\t\t\t\tlegend: {
\t\t\t\t\t\treversed: true
\t\t\t\t\t},
\t\t\t\t\tplotOptions: {
\t\t\t\t\t\tseries: {
\t\t\t\t\t\t\tstacking: 'normal'
\t\t\t\t\t\t}
\t\t\t\t\t},
\t\t\t\t\tseries: [{
\t\t\t\t\t\tname: 'Completed',
\t\t\t\t\t\t//data: [5, 3, 4, 7, 2, 1, 1, 1, 1, 1, 1, 1]
\t\t\t\t\t\tdata: [";
                    // line 352
                    echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "label2");
                    echo "],
\t\t\t\t\t\tpointWidth: 28
\t\t\t\t\t}]
\t\t\t\t});
\t\t\t});
\t";
                }
                // line 358
                echo "\t/*
\t
\t\t\$(function () {

    // Make monochrome colors and set them as default for all pies
    Highcharts.getOptions().plotOptions.pie.colors = (function () {
        var colors = [],
            base = Highcharts.getOptions().colors[0],
            i;

        for (i = 0; i < 10; i += 1) {
            // Start out with a darkened base color (negative brighten), and end
            // up with a much brighter color
            colors.push(Highcharts.Color(base).brighten((i - 3) / 7).get());
        }
        return colors;
    }());

    // Build the chart
    \$('#chart3').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: ''
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    }
                }
            }
        },
        series: [{
            name: \"Priority\",
            colorByPoint: true,
            data: [ 
\t\t\t\t";
                // line 407
                echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pie_new");
                echo "
\t\t\t\t]
        }]
    });
});
*/
\t
  ";
            }
            // line 414
            echo "\t
});
</script>
<script src=\"/assets/js/jqplot/jquery.jqplot.js\"></script>
<script src=\"/assets/js/jqplot/jqplot.barRenderer.js\"></script>
<script src=\"/assets/js/jqplot/jqplot.pieRenderer.js\"></script>
<script src=\"/assets/js/jqplot/jqplot.categoryAxisRenderer.js\"></script>
<script src=\"/assets/js/jqplot/jqplot.pointLabels.js\"></script>
<link rel=\"stylesheet\" href=\"/assets/js/jqplot/jquery.jqplot.css\">
<script src=\"/assets/js/highcharts/highcharts.js\"></script>
<script src=\"/assets/js/highcharts/highcharts-more.js\"></script>
<style type=\"text/css\">
div.hide-link {
    background-color: #FFF;
    margin-bottom: -7px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 1px;
    position: absolute;
    top: 80%;
    width: 138px;
    height: 15%;
}
div.c1 {
   left: 80%;
}
div.c2 {
   left: 72%;
}
div.c3 {
   left: 64%;
}
.datepicker{z-index:1151 !important;}
</style>
";
        }
    }

    public function getTemplateName()
    {
        return "front-dashboard.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  771 => 414,  760 => 407,  709 => 358,  700 => 352,  664 => 318,  662 => 317,  659 => 316,  642 => 301,  636 => 300,  630 => 298,  620 => 296,  610 => 294,  607 => 293,  605 => 292,  602 => 291,  598 => 290,  594 => 289,  579 => 276,  570 => 274,  560 => 272,  550 => 270,  548 => 269,  545 => 268,  541 => 267,  537 => 266,  522 => 253,  513 => 251,  510 => 250,  500 => 248,  490 => 246,  487 => 245,  484 => 244,  480 => 243,  476 => 242,  461 => 229,  452 => 227,  442 => 225,  432 => 223,  430 => 222,  427 => 221,  423 => 220,  419 => 219,  404 => 206,  395 => 204,  385 => 202,  375 => 200,  373 => 199,  370 => 198,  366 => 197,  362 => 196,  330 => 166,  328 => 165,  320 => 160,  317 => 159,  306 => 151,  295 => 142,  293 => 141,  283 => 133,  281 => 132,  274 => 129,  271 => 128,  263 => 123,  261 => 122,  257 => 120,  254 => 119,  251 => 118,  248 => 117,  245 => 116,  242 => 115,  239 => 114,  236 => 113,  233 => 112,  230 => 111,  220 => 103,  209 => 98,  205 => 97,  201 => 96,  194 => 93,  188 => 90,  185 => 89,  183 => 88,  179 => 87,  175 => 86,  171 => 85,  167 => 84,  163 => 83,  159 => 82,  153 => 79,  144 => 78,  141 => 77,  138 => 76,  135 => 75,  132 => 74,  130 => 73,  126 => 72,  120 => 70,  116 => 69,  110 => 65,  106 => 63,  104 => 62,  82 => 42,  79 => 41,  76 => 40,  51 => 17,  48 => 16,  46 => 15,  32 => 3,  29 => 2,);
    }
}
