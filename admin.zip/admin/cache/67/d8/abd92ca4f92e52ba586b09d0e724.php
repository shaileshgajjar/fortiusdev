<?php

/* subsidiary.html */
class __TwigTemplate_67d8abd92ca4f92e52ba586b09d0e724 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") || (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "continue") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == "")))) {
            // line 4
            echo "\t";
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save")) {
                // line 5
                echo "\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
                echo "\">
\t";
            }
            // line 6
            echo "\t
\t";
            // line 7
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "continue")) {
                // line 8
                echo "\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
                echo "\">
\t";
            }
            // line 9
            echo "\t
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
\t<input type=\"hidden\" name=\"parent_id\" id=\"parent_id\" value=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "parent_id"), "html", null, true);
            echo "\" />
\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"subsidiary.php\" />
</form>
";
        } else {
            // line 22
            echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"parent_id\" id=\"parent_id\" value=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "parent_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"subsidiary.php\" />
\t\t\t<div class=\"widget-box widget-color-blue\">
\t\t\t\t<!-- #section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-header\">
\t\t\t\t\t<h5 class=\"widget-title smaller lighter\">
\t\t\t\t\t\t<i class=\"ace-icon fa fa-edit\"></i>
\t\t\t\t\t\t";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
            echo "
\t\t\t\t\t</h5>
\t\t\t\t</div>

\t\t\t\t<!-- /section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-body\">
\t\t\t\t\t<div class=\"widget-main\">
\t\t\t\t\t\t";
            // line 54
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") != "")) {
                // line 55
                echo "\t\t\t\t\t\t<div class=\"alert alert-danger\" role=\"alert\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err"), "html", null, true);
                echo "</div>
\t\t\t\t\t\t";
            }
            // line 57
            echo "\t\t\t\t\t\t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">Client Details</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Customer </label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<input type=\"text\" value=\"";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pcompany"), "name"), "html", null, true);
            echo "\" class=\"form-control\" readonly>
\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"parent_id\" id=\"parent_id\" value=\"";
            // line 63
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "parent_id"), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessment Type</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<select required id=\"merchant_type_id\" name=\"merchant_type_id\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t";
            // line 71
            echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "merchant_types");
            echo "
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessor QSA</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<input type=\"text\" value=\"";
            // line 79
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pcompany"), "qsa_name"), "html", null, true);
            echo "\" class=\"form-control\" readonly>
\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"qsa_id\" id=\"qsa_id\" value=\"";
            // line 80
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pcompany"), "qsa"), "html", null, true);
            echo "\">
\t\t\t\t\t\t
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessor QA</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<div id=\"qa_list\">
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" value=\"";
            // line 89
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pcompany"), "qa_name"), "html", null, true);
            echo "\" class=\"form-control\" readonly>
\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"qa_id\" id=\"qa_id\" value=\"";
            // line 90
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pcompany"), "qa"), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"company_name\" id=\"company_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\trequired type=\"text\" value=\"";
            // line 99
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "company_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company Address</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"company_address\" id=\"company_address\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\trequired type=\"text\" value=\"";
            // line 106
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "company_address"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company URL</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"company_url\" id=\"company_url\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\ttype=\"url\" value=\"";
            // line 113
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "company_url"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Title</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<select required id=\"title\" name=\"title\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t<option value=\"mr\"";
            // line 120
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "title"), "value") == "mr")) {
                echo " selected=\"selected\"";
            }
            echo ">Mr.</option>
\t\t\t\t\t\t\t\t\t<option value=\"mrs\"";
            // line 121
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "title"), "value") == "mrs")) {
                echo " selected=\"selected\"";
            }
            echo ">Mrs.</option>
\t\t\t\t\t\t\t\t\t<option value=\"miss\"";
            // line 122
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "title"), "value") == "miss")) {
                echo " selected=\"selected\"";
            }
            echo ">Miss.</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Contact First Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"first_name\" id=\"first_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\ttype=\"text\" value=\"";
            // line 130
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "first_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Contact Last Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"last_name\" id=\"last_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\ttype=\"text\" value=\"";
            // line 137
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "last_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Contact Phone</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"mobile\" id=\"mobile\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\ttype=\"text\" value=\"";
            // line 144
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "mobile"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Compliance Due Date</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t<label for=\"compliance_due_date\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>
\t\t\t\t\t\t\t\t<input id=\"compliance_due_date\" type=\"text\" name=\"compliance_due_date\" class=\"date-picker form-control\" value=\"";
            // line 153
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "compliance_due_date"), "value"), "html", null, true);
            echo "\"  />
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Start Date</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" id=\"start_date\" type=\"text\" name=\"start_date\" value=\"";
            // line 161
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "start_date"), "value"), "html", null, true);
            echo "\" readonly/>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">End Date</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" id=\"end_date\" type=\"text\" name=\"end_date\" value=\"";
            // line 169
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "end_date"), "value"), "html", null, true);
            echo "\" readonly/>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">Login Details</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Email</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"email\" id=\"email\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\ttype=\"email\" value=\"";
            // line 178
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "users"), "email"), "value"), "html", null, true);
            echo "\" required />
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Password</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"pwd\" id=\"pwd\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\t\t";
            // line 186
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id") == 0)) {
                // line 187
                echo "\t\t\t\t\t\t\t\t\t\trequired
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 189
            echo "\t\t\t\t\t\t\t\t\t\ttype=\"password\" value=\"\" placeholder=\"Enter password\" pattern=\"(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!,@,#,\$,%,&,*,\\(,\\)]).{8,}\" 
\t\t\t\t\t\t\t\t\t\tdata-bv-regexp-message=\"Minimum 8 char includes one capital, one number and one special char ! @ # \$ % & * ( )\" />
\t\t\t\t\t\t\t\t\t<div class=\"pull-left\">[Keep blank to do not change]</div>
\t\t\t\t\t\t\t\t\t<div style=\"clear:both;\"></div>
\t\t\t\t\t\t\t\t\t<small id=\"errpwd\" style=\"display:block; color:#a94442; margin-bottom:10px; margin-top:5px;\">Minimum 8 char includes one capital, one number and one special char ! @ # \$ % &amp; * ( )</small>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">Assessor Company</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"assr_company_name\" id=\"assr_company_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\treadonly type=\"text\" value=\"";
            // line 201
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assr_company_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company Address</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"assr_company_address\" id=\"assr_company_address\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\treadonly type=\"text\" value=\"";
            // line 208
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assr_company_address"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company URL</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"assr_company_url\" id=\"assr_company_url\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\treadonly type=\"url\" value=\"";
            // line 215
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assr_company_url"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<div class=\"col-lg-10 col-lg-offset-2\">
\t\t\t\t\t\t\t\t<button type=\"submit\" title=\"Save\" class=\"btn btn-success\"><span class=\"glyphicon glyphicon-ok\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t\t<button type=\"button\" title=\"Cancel\" class=\"btn btn-danger\" onclick=\"this.form.action='";
            // line 221
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "'; this.form.submit();\"><span class=\"glyphicon glyphicon-arrow-left\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn  btn-success pull-right\" onclick=\"gotowizards();\"> Next <span><i class=\"fa fa-arrow-right\"></i></span></button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
";
        }
    }

    // line 233
    public function block_footer($context, array $blocks = array())
    {
        // line 234
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/datepicker3.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
<script type=\"text/javascript\">
";
        // line 239
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") || (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "continue") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == "")))) {
            // line 240
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 244
            echo "\$(document).ready(function() {
    \$('#frm').bootstrapValidator();
\t\$( \"#pwd\" ).keyup(function() {
\t\tif ( \$('#pwd').val() == '' )
\t\t\t\$('#errpwd').show();
\t\telse
\t\t\t\$('#errpwd').hide();
\t});
\t\$(\".date-picker\").datepicker({
\t\tformat: 'mm-dd-yyyy'
\t}).on('changeDate', function(ev){
\t\t\$(\".datepicker\").hide();
\t});
});
";
        }
        // line 259
        echo "function loadqsaqa(id)
{
\tif ( id != '' )
\t{
\t\ttheurl = '/admin/loadqsaqa.php?id='+id;
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\t\$('#qa_id').html(data);
\t\t});
\t\ttheurl = '/admin/loadqsaqa.php?id='+id;
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\t\$('#qa_id').html(data);
\t\t});
\t}
}
function gotowizards()
{
\t\$('#frm').bootstrapValidator();
\t\$('#task').val('continue');
\t
}
</script>
";
    }

    public function getTemplateName()
    {
        return "subsidiary.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  470 => 259,  453 => 244,  447 => 240,  445 => 239,  436 => 234,  433 => 233,  417 => 221,  408 => 215,  398 => 208,  388 => 201,  374 => 189,  370 => 187,  368 => 186,  357 => 178,  345 => 169,  334 => 161,  323 => 153,  311 => 144,  301 => 137,  291 => 130,  278 => 122,  272 => 121,  266 => 120,  256 => 113,  246 => 106,  236 => 99,  224 => 90,  220 => 89,  208 => 80,  204 => 79,  193 => 71,  182 => 63,  178 => 62,  171 => 57,  165 => 55,  163 => 54,  153 => 47,  143 => 40,  139 => 39,  135 => 38,  131 => 37,  126 => 35,  122 => 34,  118 => 33,  114 => 32,  110 => 31,  106 => 30,  96 => 22,  89 => 18,  85 => 17,  81 => 16,  77 => 15,  73 => 14,  69 => 13,  65 => 12,  61 => 11,  57 => 10,  54 => 9,  48 => 8,  46 => 7,  43 => 6,  37 => 5,  34 => 4,  32 => 3,  29 => 2,);
    }
}
