<?php

/* assessment-quarterly-result-initial.html */
class __TwigTemplate_c0c20c288f0cbdf42723764f928f9add extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 15
            echo "<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 34
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 35
            echo "      <!-- Tab panes -->
\t<div class=\"tab-content tab_border\">
\t\t<div role=\"tabpanel\" class=\"tab-pane active\" id=\"screen1\">
            <div class=\"screen7_inner_part widget-box widget-color-blue\">
                <div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i> 5.\tQuarterly Scan Results </h4>
                </div>
                <div class=\"widget-body\"> 
                \t<div class=\"widget-main widget_main_extra_part\">
                    \t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">5.1\tQuarterly scan results –initial PCI DSS compliance validation</div>
                    \t<div class=\"screen9_table_block_part screen10_extra screen11_part\">
                            <div class=\"table-responsive screen_field_part\">
\t\t\t\t\t\t\t\t<table class=\"table table-striped\">
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Is this the assessed entity's initial PCI DSS Compliance validation?(yes/no)</strong></td>
\t\t\t\t\t\t\t\t\t\t\t<td  class=\"col-md-6 col-sm-6 col-xs-6\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<input id=\"init_yes_no-1-1\" value=\"1\" ";
            // line 53
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "yes_no"), "value") == "yes")) {
                echo " checked=\"checked\"";
            }
            echo " name=\"init_yes_no1\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\"> 
\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"init_yes_no\" id=\"init_yes_no1\" value=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "yes_no"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t\t</table>
                                <table class=\"table table-striped result_data\" id=\"result_data\"";
            // line 60
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "yes_no"), "value") == "no")) {
                echo " style=\"display:none;\"";
            }
            echo ">
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\"  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>
\t\t\t\t\t\t\t\t\t\t\tIf\"yes,\" complete the remainder of Table 5.1 below. If\"no,\" proceed to Table 5.2 filling NA to below table.</strong>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Identify how many external quarterly ASV scans were performed within the last 12 months:</strong></td>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6\">
\t\t\t\t\t\t\t\t\t\t\t\t<select name=\"no_of_scan\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 71
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable(range(1, 5));
            foreach ($context['_seq'] as $context["_key"] => $context["scan"]) {
                // line 72
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
                echo twig_escape_filter($this->env, (isset($context["scan"]) ? $context["scan"] : null), "html", null, true);
                echo "\" ";
                if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "no_of_scan"), "value") == (isset($context["scan"]) ? $context["scan"] : null))) {
                    echo " selected=\"selected\"";
                }
                echo ">";
                echo twig_escape_filter($this->env, (isset($context["scan"]) ? $context["scan"] : null), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['scan'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 74
            echo "\t\t\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t</tbody>
                                </table>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 result_data\"";
            // line 80
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "yes_no"), "value") == "no")) {
                echo " style=\"display:none;\"";
            }
            echo ">
\t\t\t\t\t\t\t\tSummarize the four most recent quarterly ASV scan results in the Summary Overview as well as in comments at Requirement 11.2.2
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 result_data\"";
            // line 83
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "yes_no"), "value") == "no")) {
                echo " style=\"display:none;\"";
            }
            echo ">
\t\t\t\t\t\t\t\t<span class=\"label_note\"><b>Note:</b> &nbsp;It is not required that four passing quarterly scans must be completed for initial PCI DSS compliance if the assessor verified:
\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t\t<li>The most recent scan result was a passing scan,</li>
\t\t\t\t\t\t\t\t\t\t<li>The entity has documented policies and procedures requiring quarterly scanning going forward, and</li>
\t\t\t\t\t\t\t\t\t\t<li>Any vulnerabilities noted in the initial scan have been corrected as shown in a re-scan.</li>
\t\t\t\t\t\t\t\t\t\t<li>For subsequent years after the initial PCI DSS review, four passing quarterly scans must have occurred.</li>
\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"table-responsive\">
                                <table class=\"table table-striped result_data\" id=\"tbl1\"";
            // line 94
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "yes_no"), "value") == "no")) {
                echo " style=\"display:none;\"";
            }
            echo ">
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td colspan=\"3\"><strong>For each quaeterly ASV scan performed within the last 12 months, identify:</strong></td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-3 col-sm-3 col-xs-3\"><strong>Date of the scan(s)</strong></td>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-3 col-sm-3 col-xs-3\"><strong>Name of ASV that performed the scan</strong></td>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-3 col-sm-3 col-xs-3\"><strong>were any vulnerabilities found that resulted in a failed initial scan?(yes/no)</strong></td>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-3 col-sm-3 col-xs-3\"><strong>For all scans resulting in a Fail, provide sate(s) of re-scans showing that the vulnerabilities have been corrected</strong></td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t";
            // line 105
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "intit_data"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 106
                echo "\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-3 col-sm-3 col-xs-3\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"input-group\" >
\t\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"scan_dt";
                // line 109
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>
\t\t\t\t\t\t\t\t\t\t\t\t\t<input readonly type=\"text\" name=\"scan_dt[]\" id=\"scan_dt";
                // line 110
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" class=\"date-picker form-control\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "scan_dt"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td  class=\"col-md-3 col-sm-3 col-xs-3\">
\t\t\t\t\t\t\t\t\t\t\t\t<textarea name=\"asv_scan[]\" class=\"form-control\" rows=\"2\" placeholder=\"Name of ASV scan\">";
                // line 114
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "asv_scan"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-3 col-sm-3 col-xs-3\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<input id=\"yes_no-1-";
                // line 118
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"1\" ";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "yes_no") == "yes")) {
                    echo " checked=\"checked\"";
                }
                echo " name=\"yes_no1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"yes_no[]\" id=\"yes_no";
                // line 119
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "yes_no"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-3 col-sm-3 col-xs-3\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"re_scan_dt";
                // line 124
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>
\t\t\t\t\t\t\t\t\t\t\t\t\t<input readonly type=\"text\" name=\"re_scan_dt[]\" id=\"re_scan_dt";
                // line 125
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" class=\"date-picker form-control\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "re_scan_dt"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 127
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 128
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t&nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove subset\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 130
                echo "\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 133
            echo "\t\t\t\t\t\t\t\t\t</tbody>
                                </table>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn btn-primary primary_add_btn pull-right result_data\" onclick=\"addrow('tbl1');\"";
            // line 136
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "yes_no"), "value") == "no")) {
                echo " style=\"display:none;\"";
            }
            echo "> Add New </div>
                        </div>
                        <div class=\"col-md-12 col-sm-12 col-xs-12 screen24_table_block result_data\"";
            // line 138
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "yes_no"), "value") == "no")) {
                echo " style=\"display:none;\"";
            }
            echo ">
\t\t\t\t\t\t\t<div class=\"col-md-8 col-sm-8 col-xs-12 screen_24_padding\"><strong>Provide the name of the assessor who attests that the most resent scan result was verfied to be a passing scan.</strong></div>
\t\t\t\t\t\t\t<div class=\"col-md-4 col-sm-4 col-xs-12 screen24_right_part\"><input name=\"assessor\" type=\"text\" value=\"";
            // line 140
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assessor"), "value"), "html", null, true);
            echo "\" class=\"form-control\" required></div>
                        </div>
                        <div class=\"col-md-12 col-sm-12 col-xs-12 screen24_table_block result_data\"";
            // line 142
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "yes_no"), "value") == "no")) {
                echo " style=\"display:none;\"";
            }
            echo ">
\t\t\t\t\t\t\t<div class=\"col-md-8 col-sm-8 col-xs-12 screen_24_padding\"><strong>Identify the name of the document the assessor verified to include the entity's documented policies and procedures requiring quarterly scanning going forward.</strong></div>
\t\t\t\t\t\t\t<div class=\"col-md-4 col-sm-4 col-xs-12 screen24_right_part\"><input name=\"document\" value=\"";
            // line 144
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "document"), "value"), "html", null, true);
            echo "\" type=\"text\"  class=\"form-control\" required></div>
                        </div>
                        <div class=\"col-md-12 col-sm-12 col-xs-12 screen24_table_block result_data\"";
            // line 146
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "yes_no"), "value") == "no")) {
                echo " style=\"display:none;\"";
            }
            echo ">
\t\t\t\t\t\t\t<div class=\"col-md-8 col-sm-8 col-xs-12 screen_24_padding\"><strong>Describe how the assessor verified any vulnerabilities noted in the initial scan have been corrected, as shown in a re-scan.</strong></div>
\t\t\t\t\t\t\t<div class=\"col-md-4 col-sm-4 col-xs-12 screen24_right_part\"><textarea name=\"how_verified\" class=\"form-control\" rows=\"2\" required>";
            // line 148
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "how_verified"), "value"), "html", null, true);
            echo "</textarea></div>
                        </div>
\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen24_table_block result_data\"";
            // line 150
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "yes_no"), "value") == "no")) {
                echo " style=\"display:none;\"";
            }
            echo ">
\t\t\t\t\t\t\t<div class=\"col-md-8 col-sm-8 col-xs-12 screen_24_padding\"><strong>Assessor comments, if applicable:</strong></div>
\t\t\t\t\t\t\t<div class=\"col-md-4 col-sm-4 col-xs-12 screen24_right_part\"><textarea name=\"assessor_comments\" class=\"form-control\" rows=\"2\" >";
            // line 152
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "assessor_comments"), "value"), "html", null, true);
            echo "</textarea></div>
                        </div>
\t\t\t\t\t\t<button class=\"btn btn-danger new_success pull-left \" onclick=\"previous_step('";
            // line 154
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button> 
                    </div>
                </div>
            </div>
        </div>
\t</div>
\t</form>
</div>
";
        }
    }

    // line 165
    public function block_footer($context, array $blocks = array())
    {
        // line 166
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script src=\"/assets/js/chosen.jquery.js\"></script>
\t<link href=\"/assets/css/bootstrap-switch.css\" type=\"text/css\" rel=\"stylesheet\">
\t<script src=\"/assets/js/bootstrap-switch.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 178
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 179
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 183
            echo "rowno = ";
            echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "intit_data")), "html", null, true);
            echo ";
\$(document).ready(function() {
\t\$('#frm').bootstrapValidator();
\t\$(\".switch\").bootstrapSwitch();
    \$(\"#tbl1\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\tary = \$(this).attr('id').split('-');
\t\tval = state ? 'yes' : 'no';
\t\t\$('#'+ary[0]+ary[2]).val(val);
\t\tif ( ary[0] == 'init_yes_no' )
\t\t{
\t\t\tif ( val == 'yes' )
\t\t\t\t\$('.result_data').show();
\t\t\telse
\t\t\t\t\$('.result_data').hide();
\t\t}
\t});
\t\$('body').on('focus',\".date-picker\", function(){
\t\t\$(this).datepicker({format: 'mm-dd-yyyy'});
\t}).on('changeDate', function(ev){
\t\t\$(\".datepicker\").hide();
\t});
});
function addrow(tbl_id)
{
\thtml = '';
\thtml = html + '<tr>';
\thtml = html + '\t<td class=\"col-md-3 col-sm-3 col-xs-3\">';
\thtml = html + '\t\t<div class=\"input-group\" >';
\thtml = html + '\t\t\t<label for=\"scan_dt'+rowno+'\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>';
\thtml = html + '\t\t\t<input readonly type=\"text\" name=\"scan_dt[]\" id=\"scan_dt'+rowno+'\" class=\"date-picker form-control\" value=\"";
            // line 215
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "current_date"), "html", null, true);
            echo "\" />';
\thtml = html + '\t\t</div>';
\thtml = html + '\t</td>';
\thtml = html + '\t<td class=\"col-md-3 col-sm-3 col-xs-3\">';
\thtml = html + '\t\t\t<textarea name=\"asv_scan[]\" class=\"form-control\" rows=\"2\" placeholder=\"Name of ASV scan\"></textarea>';
\thtml = html + '\t</td>';
\thtml = html + '\t<td class=\"col-md-3 col-sm-3 col-xs-3\">';
\thtml = html + '\t\t<div class=\"lockunlock\">';
\thtml = html + '\t\t\t<input id=\"yes_no-1-'+rowno+'\" value=\"1\" name=\"yes_no1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">';
\thtml = html + '\t\t\t<input type=\"hidden\" name=\"yes_no[]\" id=\"yes_no'+rowno+'\" value=\"no\" />';
\thtml = html + '\t\t</div>';
\thtml = html + '\t</td>';
\thtml = html + '\t<td class=\"col-md-4 col-sm-4 col-xs-4\">';
\thtml = html + '\t\t<div class=\"input-group\">';
\thtml = html + '\t\t\t<label for=\"re_scan_dt'+rowno+'\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>';
\thtml = html + '\t\t\t<input readonly type=\"text\" name=\"re_scan_dt[]\" id=\"re_scan_dt'+rowno+'\" class=\"date-picker form-control\" value=\"";
            // line 230
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "current_date"), "html", null, true);
            echo "\" />';
\thtml = html + '\t\t</div>';
\thtml = html + '\t\t&nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove subset\" ><i class=\"fa fa-trash\"></i></a>';
\thtml = html + '\t</td>';
\thtml = html + '</tr>';
\t\$(\"#\"+tbl_id).append(html);
\t\$(\".switch\").bootstrapSwitch();
\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\tary = \$(this).attr('id').split('-');
\t\tval = state ? 'yes' : 'no';
\t\t\$('#'+ary[0]+ary[2]).val(val);
\t});
\trowno++;
}
";
        }
        // line 245
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "assessment-quarterly-result-initial.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  509 => 245,  491 => 230,  473 => 215,  437 => 183,  431 => 179,  429 => 178,  413 => 166,  410 => 165,  395 => 154,  390 => 152,  383 => 150,  378 => 148,  371 => 146,  366 => 144,  359 => 142,  354 => 140,  347 => 138,  340 => 136,  335 => 133,  319 => 130,  315 => 128,  313 => 127,  306 => 125,  302 => 124,  292 => 119,  284 => 118,  277 => 114,  268 => 110,  264 => 109,  259 => 106,  242 => 105,  226 => 94,  210 => 83,  202 => 80,  194 => 74,  179 => 72,  175 => 71,  159 => 60,  150 => 54,  144 => 53,  124 => 35,  122 => 34,  117 => 32,  113 => 31,  109 => 30,  105 => 29,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  80 => 22,  71 => 15,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
