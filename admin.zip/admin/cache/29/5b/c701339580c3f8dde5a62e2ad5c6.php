<?php

/* v32_assessment-service-providers-data.html */
class __TwigTemplate_295bc701339580c3f8dde5a62e2ad5c6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 15
            echo "<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 34
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 35
            echo "      <!-- Tab panes -->
\t\t<div class=\"tab-content tab_border\">
            <div class=\"screen7_inner_part widget-box widget-color-blue\">
                <div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i>  4 Reviewed Environment  </h4>
                </div>
                <div class=\"widget-body\">
                \t<div class=\"widget-main widget_main_extra_part\">
                    <div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.7\tService providers and other third parties with which the entity shares cardholder data</div>
\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\tFor each service provider or third party, provide
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t<span class=\"label_note\"><b>Note:</b> &nbsp; These entities are subject to PCI DSS Requirement 12.8.</span>
\t\t\t\t\t</div>
                    \t<div class=\"screen9_table_block_part screen10_extra screen11_part\">
                            <div class=\"table-responsive screen_field_part\">
                                <table class=\"table table-striped assesment_service_provide_data_extra\" id=\"tbl1\">
\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-12\">Company Name</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-12\">What data is shared (for example, PAN, expiry date, etc.)</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-12\">The purpose for sharing the data (for example, third-party storage, transaction processing, etc.)</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-12\">Date of AOC</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-12\">Status og PCI DSS Compliance version</th>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t";
            // line 63
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                echo "\t  
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td><input name=\"company_name[]\" type=\"text\" class=\"form-control\" placeholder=\"Company Name\" value=\"";
                // line 65
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
                echo "\"></td>
\t\t\t\t\t\t\t\t\t\t\t<td><textarea name=\"shared_data[]\" class=\"form-control\" rows=\"2\" placeholder=\"What data is shared (for example, PAN, Expiry date, etc.)\">";
                // line 66
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "shared_data"), "html", null, true);
                echo "</textarea></td>
\t\t\t\t\t\t\t\t\t\t\t<td><textarea  name=\"purpose_of_sharing[]\" class=\"form-control\" rows=\"2\" placeholder=\"The purposr for sharing the data (for example, third-party storage, transaction processing, etc.)\">";
                // line 67
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "purpose_of_sharing"), "html", null, true);
                echo "</textarea></td>
\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"date_of_aoc_";
                // line 70
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>
\t\t\t\t\t\t\t\t\t\t\t\t\t<input readonly type=\"text\" name=\"date_of_aoc[]\" id=\"date_of_aoc_";
                // line 71
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" class=\"date-picker form-control\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "date_of_aoc"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td><textarea name=\"pci_dss_version[]\" class=\"form-control\" rows=\"2\" placeholder=\"3.1\">";
                // line 74
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pci_dss_version"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t\t";
                // line 75
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 76
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 78
                echo "\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 80
            echo "\t
\t\t\t\t\t\t\t\t\t</tbody>
                                </table>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow('tbl1');\" > Add New </div>
                        </div>
\t\t\t\t\t\t<button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 86
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button> 
                    </div>
                </div>
            </div>
\t\t</div>
\t</form>
</div>
";
        }
    }

    // line 96
    public function block_footer($context, array $blocks = array())
    {
        // line 97
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 106
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 107
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 111
            echo "rowno = ";
            echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields")), "html", null, true);
            echo ";
\$(document).ready(function() {
\t\$('#frm').bootstrapValidator();
    \$(\"#tbl1\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t
\t\$('body').on('focus',\".date-picker\", function(){
\t\t\$(this).datepicker({format: 'mm-dd-yyyy'});
\t}).on('changeDate', function(ev){
\t\t\$(\".datepicker\").hide();
\t});
});

function addrow(tbl_id)
{
\thtml = '';
\thtml = html + '<tr>';
\thtml = html + '\t<td><input name=\"company_name[]\" type=\"text\" class=\"form-control\" placeholder=\"Company Name\"></td>';
\thtml = html + '\t<td><textarea name=\"shared_data[]\" class=\"form-control\" rows=\"2\" placeholder=\"What data is shared (for example, PAN, Expiry date, etc.)\"></textarea></td>';
\thtml = html + '\t<td><textarea  name=\"purpose_of_sharing[]\" class=\"form-control\" rows=\"2\" placeholder=\"The purposr for sharing the data (for example, third-party storage, transaction processing, etc.)\"></textarea></td>';
\thtml = html + '\t<td>';
\thtml = html + '\t\t<div class=\"input-group\">';
\thtml = html + '\t\t\t<label for=\"date_of_aoc_'+rowno+'\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>';
\thtml = html + '\t\t\t<input readonly type=\"text\" name=\"date_of_aoc[]\" id=\"date_of_aoc_'+rowno+'\" class=\"date-picker form-control\" value=\"";
            // line 135
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "current_date"), "html", null, true);
            echo "\" required/>';
\thtml = html + '\t\t</div>';
\thtml = html + '\t</td>';
\thtml = html + '\t<td><textarea name=\"pci_dss_version[]\" class=\"form-control\" rows=\"2\" placeholder=\"3.1\"></textarea>';
\thtml = html + '\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>';
\thtml = html + '\t</td>';
\thtml = html + '</tr>';
\t\$(\"#\"+tbl_id).append(html);
\trowno++;
}
";
        }
        // line 146
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "v32_assessment-service-providers-data.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  314 => 146,  300 => 135,  272 => 111,  266 => 107,  264 => 106,  251 => 97,  248 => 96,  234 => 86,  226 => 80,  210 => 78,  206 => 76,  204 => 75,  200 => 74,  192 => 71,  188 => 70,  182 => 67,  178 => 66,  174 => 65,  154 => 63,  124 => 35,  122 => 34,  117 => 32,  113 => 31,  109 => 30,  105 => 29,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  80 => 22,  71 => 15,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
