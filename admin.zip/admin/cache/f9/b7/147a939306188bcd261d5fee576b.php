<?php

/* customers.html */
class __TwigTemplate_f9b7147a939306188bcd261d5fee576b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"parent_id\" id=\"parent_id\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"entity\" id=\"entity\" value=\"\" />
\t\t\t";
        // line 12
        $this->env->loadTemplate("_new-panel.html")->display($context);
        // line 13
        echo "\t\t\t<div class=\"table-responsive\">
\t\t\t\t<!--";
        // line 14
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "msg") != "")) {
            // line 15
            echo "\t\t\t\t<div id=\"orderform-success-alert\" class=\"alert alert-success\">  Download link sent to your email ID registered with us.  </div>
\t\t\t\t";
        }
        // line 16
        echo " -->
\t\t\t\t<table id=\"simple-table\" class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t   <thead>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t <th class=\"text-center\">
\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"ace\" />
\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t </th>
\t\t\t\t\t\t <th class=\"text-center text-nowrap\">";
        // line 26
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Sr.#", 1 => "rowid", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 27
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Assessment Type", 1 => "merchant_type", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <!-- <th>";
        // line 28
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Assessor QSA", 1 => "qsa", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 29
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Assessor QA", 1 => "qa", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th> -->
\t\t\t\t\t\t <th>";
        // line 30
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Company Name", 1 => "company_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 31
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Parent Company", 1 => "pcname", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 32
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Contact Name", 1 => "username", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 33
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Telephone", 1 => "mobile", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 34
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Email", 1 => "email", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 35
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Compliance Due Date", 1 => "compliance_due_date", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th class=\"text-center text-nowrap\">Action</th>
\t\t\t\t\t\t <th class=\"text-center text-nowrap\">Reports</th>
\t\t\t\t\t  </tr>
\t\t\t\t   </thead>
\t\t\t\t   <tbody>
\t\t\t\t\t  ";
        // line 41
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 42
            echo "\t\t\t\t\t  <tr";
            echo $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "class");
            echo ">
\t\t\t\t\t\t <td class=\"text-center\">
\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"removeid[]\" class=\"ace\" value=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t </td>
\t\t\t\t\t\t <td class=\"text-center text-nowrap\">";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "rowid"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "merchant_type"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <!-- <td>";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "qsa"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 52
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "qa"), "html", null, true);
            echo "</td> -->
\t\t\t\t\t\t <td>";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pcname"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 55
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "username"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "mobile"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "email"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "compliance_due_date"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td class=\"text-center text-nowrap\">
\t\t\t\t\t\t ";
            // line 60
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "parent_id") == "0")) {
                // line 61
                echo "\t\t\t\t\t\t <button type=\"button\" title=\"Edit\" onclick=\"edit('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "editscript"), "html", null, true);
                echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t<button type=\"button\" title=\"Add Subsidiary\" onclick=\"edit_subsidiary('";
                // line 62
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "', 0, '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subsidiary"), "html", null, true);
                echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\">
\t\t\t\t\t\t";
            } else {
                // line 64
                echo "\t\t\t\t\t\t\t<button type=\"button\" title=\"Edit\" onclick=\"edit_subsidiary('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "parent_id"), "html", null, true);
                echo "', ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo ", '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subsidiary"), "html", null, true);
                echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button>\t\t\t\t\t\t
\t\t\t\t\t\t ";
            }
            // line 66
            echo "\t\t\t\t\t\t <button type=\"button\" title=\"Go to wizard\" onclick=\"startwizard('";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "','";
            echo $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "ver_no");
            echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"menu-icon fa fa-pencil-square-o\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t </td>
\t\t\t\t\t\t <td class=\"text-center text-nowrap\">
\t\t\t\t\t\t\t<button type=\"button\" onclick=\"report('";
            // line 69
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', 'report-compliance.php');\" class=\"btn btn-success btn-xs btn-report\" title=\"Compliance/Sevirity\"><span class=\"glyphicon glyphicon-signal\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t<button type=\"button\" onclick=\"report('";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', 'report-priority.php');\" class=\"btn btn-warning btn-xs btn-report\" title=\"Priority\"><span class=\"glyphicon glyphicon-signal\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t<!--<button data-toggle=\"modal\" data-dismis=\"modal\" data-target=\"#loading\" id=\"backup-btn\" type=\"button\" onclick=\"report('";
            // line 71
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', 'backup.php');\" class=\"btn btn-success btn-xs\" title=\"Backup\"><span class=\"fa fa-download\" aria-hidden=\"true\"></span></button>-->
\t\t\t\t\t\t </td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 75
        echo "\t\t\t\t\t  ";
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows")) == 0)) {
            // line 76
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td colspan=\"11\">No Records</td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        // line 80
        echo "\t\t\t\t   </tbody>
\t\t\t\t   <tfoot>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t<td class=\"text-center\"><button type=\"button\" title=\"Delete\" onclick=\"delconfirm(this.form);\" class=\"btn btn-danger\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></button></td>
\t\t\t\t\t\t<td colspan=\"11\"></td>
\t\t\t\t\t  </tr>
\t\t\t\t   </tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
<!--<div class=\"modal fade\" id=\"loading\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Processing..</h4>
\t\t\t</div>
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div id=\"proc-guidance\">
\t\t\t\t\t<p> Please wait!! </p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>-->
";
    }

    // line 107
    public function block_footer($context, array $blocks = array())
    {
        // line 108
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
<script src=\"/admin/js/list.js\"></script>
<script>
\$(document).ready(function() {
\t\$('#loading').modal('hide');
\t\$('div.alert-success').fadeOut(6000);
 });
</script>
";
    }

    public function getTemplateName()
    {
        return "customers.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  271 => 108,  268 => 107,  238 => 80,  232 => 76,  229 => 75,  219 => 71,  215 => 70,  211 => 69,  202 => 66,  192 => 64,  185 => 62,  178 => 61,  176 => 60,  171 => 58,  167 => 57,  163 => 56,  159 => 55,  155 => 54,  151 => 53,  147 => 52,  143 => 51,  139 => 50,  135 => 49,  128 => 45,  121 => 42,  117 => 41,  108 => 35,  104 => 34,  100 => 33,  96 => 32,  92 => 31,  88 => 30,  84 => 29,  80 => 28,  76 => 27,  72 => 26,  60 => 16,  56 => 15,  54 => 14,  51 => 13,  49 => 12,  41 => 7,  37 => 6,  32 => 3,  29 => 2,);
    }
}
