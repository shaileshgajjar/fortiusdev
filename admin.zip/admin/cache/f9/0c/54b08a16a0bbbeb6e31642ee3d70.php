<?php

/* procedure.html */
class __TwigTemplate_f90c54b08a16a0bbbeb6e31642ee3d70 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save")) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 13
            echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<div class=\"widget-box widget-color-blue\">
\t\t\t\t<!-- #section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-header\">
\t\t\t\t\t<h5 class=\"widget-title smaller lighter\">
\t\t\t\t\t\t<i class=\"ace-icon fa fa-edit\"></i>
\t\t\t\t\t\t";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
            echo "
\t\t\t\t\t</h5>
\t\t\t\t</div>

\t\t\t\t<!-- /section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-body\">
\t\t\t\t\t<div class=\"widget-main\">
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Select Requirement</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<select onchange=\"refresh_sub(this.value);\" required id=\"requirements_id\" name=\"requirements_id\" class=\"form-control selectpicker\">
\t\t\t\t\t\t\t\t\t";
            // line 45
            echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements");
            echo "
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t";
            // line 47
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id") == 0)) {
                // line 48
                echo "\t\t\t\t\t\t\t\t";
            } else {
                // line 49
                echo "\t\t\t\t\t\t\t\t\t<!-- <input type=\"hidden\" name=\"requirements_id\" id=\"requirements_id\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "requirements_id"), "value"), "html", null, true);
                echo "\" /> -->
\t\t\t\t\t\t\t\t";
            }
            // line 51
            echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Select Sub Requirement</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<select required id=\"sub_requirements_id\" name=\"sub_requirements_id\" class=\"form-control selectpicker\">
\t\t\t\t\t\t\t\t\t";
            // line 57
            echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sub_requirements");
            echo "
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t";
            // line 59
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id") == 0)) {
                // line 60
                echo "\t\t\t\t\t\t\t\t";
            } else {
                // line 61
                echo "\t\t\t\t\t\t\t\t\t<!-- <input type=\"hidden\" name=\"sub_requirements_id\" id=\"sub_requirements_id\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "sub_requirements_id"), "value"), "html", null, true);
                echo "\" /> -->
\t\t\t\t\t\t\t\t";
            }
            // line 63
            echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Testing Procedure</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<textarea class=\"form-control\" name=\"title\" id=\"title\" required>";
            // line 68
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "title"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Priority</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<select id=\"priority\" name=\"priority\">
\t\t\t\t\t\t\t\t\t";
            // line 76
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable(range(1, 6));
            foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
                // line 77
                echo "\t\t\t\t\t\t\t\t\t\t<option value=\"";
                echo twig_escape_filter($this->env, (isset($context["p"]) ? $context["p"] : null), "html", null, true);
                echo "\"";
                if (((isset($context["p"]) ? $context["p"] : null) == $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "priority"), "value"))) {
                    echo " selected=\"selected\"";
                }
                echo ">";
                echo twig_escape_filter($this->env, (isset($context["p"]) ? $context["p"] : null), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 79
            echo "\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Guidance</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<textarea class=\"form-control\" name=\"guidance\" id=\"guidance\" >";
            // line 86
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "guidance"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">User can?</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<div class=\"checkbox\">
\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"ace\" name=\"usercan\" id=\"usercan\" value=\"1\"";
            // line 95
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "usercan"), "value") == "1")) {
                echo " checked=\"checked\"";
            }
            echo "/>
\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Allow doc upload?</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<div class=\"checkbox\">
\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"ace\" name=\"allowdoc\" id=\"allowdoc\" value=\"1\"";
            // line 107
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "allowdoc"), "value") == "1")) {
                echo " checked=\"checked\"";
            }
            echo "/>
\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t";
            // line 114
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "roc_saq") == "saq")) {
                // line 115
                echo "\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Merchant Types</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t";
                // line 118
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "merchants"));
                foreach ($context['_seq'] as $context["_key"] => $context["merchant"]) {
                    // line 119
                    echo "\t\t\t\t\t\t\t\t<div class=\"checkbox\">
\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t<input name=\"merchant_ids[]\" type=\"checkbox\" class=\"ace\" value=\"";
                    // line 121
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["merchant"]) ? $context["merchant"] : null), "id"), "html", null, true);
                    echo "\"";
                    if (twig_in_filter($this->getAttribute((isset($context["merchant"]) ? $context["merchant"] : null), "id"), $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "selectedm"))) {
                        echo " checked=\"checked\"";
                    }
                    echo " />
\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"> ";
                    // line 122
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["merchant"]) ? $context["merchant"] : null), "merchant_type"), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['merchant'], $context['_parent'], $context['loop']);
                $context = array_merge($_parent, array_intersect_key($context, $_parent));
                // line 126
                echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            }
            // line 129
            echo "\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<div class=\"col-lg-10 col-lg-offset-2\">
\t\t\t\t\t\t\t\t<button type=\"submit\" title=\"Save\" class=\"btn btn-success\"><span class=\"glyphicon glyphicon-ok\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t\t<button type=\"button\" title=\"Cancel\" class=\"btn btn-danger\" onclick=\"this.form.action='";
            // line 132
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "'; this.form.submit();\"><span class=\"glyphicon glyphicon-arrow-left\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
";
        }
    }

    // line 143
    public function block_footer($context, array $blocks = array())
    {
        // line 144
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
<script type=\"text/javascript\">
";
        // line 147
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save")) {
            // line 148
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 152
            echo "\$(document).ready(function() {
    \$('#frm').bootstrapValidator();
});
function refresh_sub(id)
{
\t//var formfields = \$(\"#frmnews\").serialize();
\tformfields = 'id='+id+'&tp=";
            // line 158
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "type"), "html", null, true);
            echo "&vr=";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "version"), "html", null, true);
            echo "';
\ttheurl = 'refresh_sub.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t
\t\t\$('#sub_requirements_id').html(data);
\t\t\$('.selectpicker').selectpicker('refresh');
\t});
}
";
        }
        // line 173
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "procedure.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  354 => 173,  334 => 158,  326 => 152,  320 => 148,  318 => 147,  311 => 144,  308 => 143,  293 => 132,  288 => 129,  283 => 126,  273 => 122,  265 => 121,  261 => 119,  257 => 118,  252 => 115,  250 => 114,  238 => 107,  221 => 95,  209 => 86,  200 => 79,  185 => 77,  181 => 76,  170 => 68,  163 => 63,  157 => 61,  154 => 60,  152 => 59,  147 => 57,  139 => 51,  133 => 49,  130 => 48,  128 => 47,  123 => 45,  109 => 34,  100 => 28,  95 => 26,  91 => 25,  87 => 24,  83 => 23,  79 => 22,  75 => 21,  65 => 13,  59 => 10,  55 => 9,  51 => 8,  47 => 7,  43 => 6,  39 => 5,  34 => 4,  32 => 3,  29 => 2,);
    }
}
