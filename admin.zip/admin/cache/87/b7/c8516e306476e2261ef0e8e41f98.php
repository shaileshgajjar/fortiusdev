<?php

/* assessor.html */
class __TwigTemplate_87b7c8516e306476e2261ef0e8e41f98 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 13
            echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<div class=\"widget-box widget-color-blue\">
\t\t\t\t<!-- #section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-header\">
\t\t\t\t\t<h5 class=\"widget-title smaller lighter\">
\t\t\t\t\t\t<i class=\"ace-icon fa fa-edit\"></i>
\t\t\t\t\t\t";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
            echo "
\t\t\t\t\t</h5>
\t\t\t\t</div>

\t\t\t\t<!-- /section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-body\">
\t\t\t\t\t<div class=\"widget-main\">
\t\t\t\t\t\t";
            // line 41
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") != "")) {
                // line 42
                echo "\t\t\t\t\t\t<div class=\"alert alert-danger\" role=\"alert\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err"), "html", null, true);
                echo "</div>
\t\t\t\t\t\t";
            }
            // line 44
            echo "\t\t\t\t\t\t<div class=\"col-lg-12 alert alert-success\">Login Details</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">User Name/Email ID</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"email\" id=\"email\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\t\trequired
\t\t\t\t\t\t\t\t\t\ttype=\"email\" value=\"";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "email"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Password</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"pwd\" id=\"pwd\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\t\t";
            // line 57
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id") == 0)) {
                // line 58
                echo "\t\t\t\t\t\t\t\t\t\trequired
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 60
            echo "\t\t\t\t\t\t\t\t\t\ttype=\"password\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "pwd"), "html", null, true);
            echo "\" placeholder=\"Enter password\" pattern=\"(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!,@,#,\$,%,&,*,\\(,\\)]).{8,}\" 
\t\t\t\t\t\t\t\t\t\tdata-bv-regexp-message=\"Minimum 8 char includes one capital, one number and one special char ! @ # \$ % & * ( )\" />
\t\t\t\t\t\t\t\t\t<div class=\"pull-left\">[Keep blank to do not change]</div>
\t\t\t\t\t\t\t\t\t<div style=\"clear:both;\"></div>
\t\t\t\t\t\t\t\t\t<small id=\"errpwd\" style=\"display:block; color:#a94442; margin-bottom:10px; margin-top:5px;\">Minimum 8 char includes one capital, one number and one special char ! @ # \$ % &amp; * ( )</small>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-lg-12 alert alert-success\">Assessor Details</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessor Type</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<select required id=\"userrole\" name=\"userrole\" class=\"form-control selectpicker\">
\t\t\t\t\t\t\t\t\t<option value=\"s\"";
            // line 72
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userrole"), "value") == "s")) {
                echo " selected=\"selected\"";
            }
            echo ">Assessor QSA</option>
\t\t\t\t\t\t\t\t\t<option value=\"q\"";
            // line 73
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userrole"), "value") == "q")) {
                echo " selected=\"selected\"";
            }
            echo ">Assessor QA</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Title</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<select required id=\"title\" name=\"title\" class=\"form-control selectpicker\">
\t\t\t\t\t\t\t\t\t<option value=\"mr\"";
            // line 81
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "title"), "value") == "mr")) {
                echo " selected=\"selected\"";
            }
            echo ">Mr.</option>
\t\t\t\t\t\t\t\t\t<option value=\"mrs\"";
            // line 82
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "title"), "value") == "mrs")) {
                echo " selected=\"selected\"";
            }
            echo ">Mrs.</option>
\t\t\t\t\t\t\t\t\t<option value=\"miss\"";
            // line 83
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "title"), "value") == "miss")) {
                echo " selected=\"selected\"";
            }
            echo ">Miss.</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessor First Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"first_name\" id=\"first_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\trequired type=\"text\" value=\"";
            // line 91
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "first_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessor Last Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"last_name\" id=\"last_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\trequired type=\"text\" value=\"";
            // line 98
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "last_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">PCI Credential</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"pci_credential\" id=\"pci_credential\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\trequired type=\"text\" value=\"";
            // line 105
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "pci_credential"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Assessor Phone</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"mobile\" id=\"mobile\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\ttype=\"text\" value=\"";
            // line 112
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "mobile"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<div class=\"col-lg-10 col-lg-offset-2\">
\t\t\t\t\t\t\t\t<button type=\"submit\" title=\"Save\" class=\"btn btn-success\"><span class=\"glyphicon glyphicon-ok\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t\t<button type=\"button\" title=\"Cancel\" class=\"btn btn-danger\" onclick=\"this.form.action='";
            // line 118
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "'; this.form.submit();\"><span class=\"glyphicon glyphicon-arrow-left\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
";
        }
    }

    // line 129
    public function block_footer($context, array $blocks = array())
    {
        // line 130
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
<script type=\"text/javascript\">
";
        // line 133
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 134
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 138
            echo "\$(document).ready(function() {
    \$('#frm').bootstrapValidator();
\t\$( \"#pwd\" ).keyup(function() {
\t\tif ( \$('#pwd').val() == '' )
\t\t\t\$('#errpwd').show();
\t\telse
\t\t\t\$('#errpwd').hide();
\t});
});
";
        }
        // line 148
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "assessor.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  295 => 148,  283 => 138,  277 => 134,  275 => 133,  268 => 130,  265 => 129,  250 => 118,  241 => 112,  231 => 105,  221 => 98,  211 => 91,  198 => 83,  192 => 82,  186 => 81,  173 => 73,  167 => 72,  151 => 60,  147 => 58,  145 => 57,  135 => 50,  127 => 44,  121 => 42,  119 => 41,  109 => 34,  100 => 28,  95 => 26,  91 => 25,  87 => 24,  83 => 23,  79 => 22,  75 => 21,  65 => 13,  59 => 10,  55 => 9,  51 => 8,  47 => 7,  43 => 6,  39 => 5,  34 => 4,  32 => 3,  29 => 2,);
    }
}
