<?php

/* _front-profile.html */
class __TwigTemplate_181fc175b7ff095a0bed4efdca353bfb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t<div class=\"modal fade\" id=\"profile\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Edit Profile</h4>
\t\t\t</div>
\t\t\t<form class=\"form-horizontal bv-form\" name=\"frmprofile\" id=\"frmprofile\" method=\"post\" action=\"\"
\t\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"profilesave\" />
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Title</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<select required id=\"title\" name=\"title\" class=\"form-control selectpicker\">
\t\t\t\t\t\t\t<option value=\"mr\"";
        // line 20
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "title"), "value") == "mr")) {
            echo " selected=\"selected\"";
        }
        echo ">Mr.</option>
\t\t\t\t\t\t\t<option value=\"mrs\"";
        // line 21
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "title"), "value") == "mrs")) {
            echo " selected=\"selected\"";
        }
        echo ">Mrs.</option>
\t\t\t\t\t\t\t<option value=\"miss\"";
        // line 22
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "title"), "value") == "miss")) {
            echo " selected=\"selected\"";
        }
        echo ">Miss.</option>
\t\t\t\t\t\t</select>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">First Name</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"first_name\" id=\"first_name\" autocomplete=\"off\"
\t\t\t\t\t\t\trequired type=\"text\" value=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "first_name"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Last Name</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"last_name\" id=\"last_name\" autocomplete=\"off\"
\t\t\t\t\t\t\trequired type=\"text\" value=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "last_name"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Mobile</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"mobile\" id=\"mobile\" autocomplete=\"off\"
\t\t\t\t\t\t\ttype=\"url\" value=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "mobile"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"modal-footer\">
\t\t\t\t<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
\t\t\t\t<button type=\"submit\" onclick=\"saveprofile();\" data-dismiss=\"modal\" class=\"btn btn-primary\">Save changes</button>
\t\t\t</div>
\t\t\t</form>
\t\t</div>
\t</div>
\t</div>
<script type=\"text/javascript\">
function saveprofile()
{
\tformfields = \$('#frmprofile').serialize();
\ttheurl = '/save-profile.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t});
}
</script>
";
    }

    public function getTemplateName()
    {
        return "_front-profile.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  412 => 158,  409 => 157,  389 => 148,  387 => 147,  381 => 146,  368 => 140,  364 => 139,  357 => 138,  355 => 137,  350 => 134,  347 => 133,  336 => 127,  322 => 123,  316 => 121,  312 => 120,  309 => 119,  303 => 117,  292 => 114,  286 => 112,  278 => 110,  276 => 109,  268 => 103,  265 => 102,  260 => 101,  249 => 98,  244 => 95,  240 => 93,  226 => 87,  222 => 86,  218 => 85,  196 => 77,  192 => 75,  178 => 69,  174 => 68,  170 => 67,  156 => 60,  123 => 48,  119 => 47,  105 => 40,  98 => 38,  96 => 37,  90 => 33,  75 => 37,  71 => 25,  62 => 21,  49 => 15,  43 => 13,  40 => 20,  36 => 11,  30 => 10,  255 => 99,  241 => 140,  228 => 132,  214 => 124,  212 => 84,  181 => 105,  162 => 94,  131 => 76,  102 => 59,  87 => 49,  66 => 30,  45 => 19,  38 => 15,  33 => 13,  217 => 127,  208 => 121,  202 => 119,  193 => 112,  191 => 111,  176 => 103,  164 => 91,  161 => 90,  151 => 59,  148 => 58,  146 => 82,  117 => 59,  113 => 46,  101 => 39,  77 => 30,  73 => 28,  67 => 26,  65 => 30,  55 => 25,  50 => 15,  47 => 14,  34 => 11,  31 => 10,  19 => 1,  198 => 92,  195 => 113,  190 => 80,  140 => 7,  136 => 5,  133 => 77,  127 => 49,  124 => 130,  121 => 129,  118 => 68,  115 => 127,  112 => 126,  109 => 55,  103 => 53,  100 => 122,  97 => 121,  94 => 120,  91 => 119,  89 => 91,  85 => 44,  83 => 88,  74 => 81,  72 => 80,  64 => 74,  58 => 20,  54 => 69,  52 => 22,  44 => 62,  42 => 12,  37 => 58,  35 => 14,  27 => 4,  22 => 1,  771 => 414,  760 => 407,  709 => 358,  700 => 352,  664 => 318,  662 => 317,  659 => 316,  642 => 301,  636 => 300,  630 => 298,  620 => 296,  610 => 294,  607 => 293,  605 => 292,  602 => 291,  598 => 290,  594 => 289,  579 => 276,  570 => 274,  560 => 272,  550 => 270,  548 => 269,  545 => 268,  541 => 267,  537 => 266,  522 => 253,  513 => 251,  510 => 250,  500 => 248,  490 => 246,  487 => 245,  484 => 244,  480 => 243,  476 => 242,  461 => 229,  452 => 227,  442 => 225,  432 => 223,  430 => 222,  427 => 221,  423 => 220,  419 => 219,  404 => 206,  395 => 150,  385 => 202,  375 => 145,  373 => 199,  370 => 198,  366 => 197,  362 => 196,  330 => 125,  328 => 165,  320 => 122,  317 => 159,  306 => 151,  295 => 115,  293 => 141,  283 => 133,  281 => 132,  274 => 129,  271 => 128,  263 => 123,  261 => 122,  257 => 100,  254 => 119,  251 => 118,  248 => 117,  245 => 116,  242 => 115,  239 => 114,  236 => 113,  233 => 112,  230 => 111,  220 => 103,  209 => 122,  205 => 79,  201 => 78,  194 => 93,  188 => 90,  185 => 89,  183 => 88,  179 => 104,  175 => 86,  171 => 85,  167 => 92,  163 => 65,  159 => 89,  153 => 79,  144 => 56,  141 => 77,  138 => 76,  135 => 75,  132 => 74,  130 => 69,  126 => 72,  120 => 70,  116 => 69,  110 => 65,  106 => 124,  104 => 60,  82 => 42,  79 => 41,  76 => 40,  51 => 17,  48 => 20,  46 => 21,  32 => 3,  29 => 9,);
    }
}
