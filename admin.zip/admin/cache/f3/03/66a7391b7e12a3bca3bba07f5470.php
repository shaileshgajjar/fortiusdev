<?php

/* front-users.html */
class __TwigTemplate_f30366a7391b7e12a3bca3bba07f5470 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-front-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-front-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t\t\t";
        // line 10
        $this->env->loadTemplate("_new-panel.html")->display($context);
        // line 11
        echo "\t\t\t<div class=\"table-responsive\">
\t\t\t\t<table class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t   <thead>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t <th class=\"text-center\"><input type=\"checkbox\" name=\"chkall\" onclick=\"dochkall(this.form)\" /></th>
\t\t\t\t\t\t <th class=\"text-center\">";
        // line 16
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Sr.#", 1 => "rowid", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 17
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "User Group Name", 1 => "user_group_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 18
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Email ID", 1 => "email", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 19
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "First Name", 1 => "first_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 20
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Last Name", 1 => "last_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th class=\"text-center\">Action</th>
\t\t\t\t\t  </tr>
\t\t\t\t   </thead>
\t\t\t\t   <tbody>
\t\t\t\t\t  ";
        // line 25
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 26
            echo "\t\t\t\t\t  ";
            $context["chkbox"] = "";
            // line 27
            echo "\t\t\t\t\t  ";
            $context["active_row"] = "";
            // line 28
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t ";
            // line 29
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id") == $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method"))) {
                // line 30
                echo "\t\t\t\t\t\t\t";
                $context["active_row"] = "success";
                // line 31
                echo "\t\t\t\t\t\t ";
            }
            // line 32
            echo "\t\t\t\t\t\t <td class=\"text-center ";
            echo twig_escape_filter($this->env, (isset($context["active_row"]) ? $context["active_row"] : null), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t";
            // line 33
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id") != $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method"))) {
                // line 34
                echo "\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"removeid[]\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t ";
            }
            // line 36
            echo "\t\t\t\t\t\t  </td>
\t\t\t\t\t\t
\t\t\t\t\t\t <td class=\"text-center ";
            // line 38
            echo twig_escape_filter($this->env, (isset($context["active_row"]) ? $context["active_row"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "rowid"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td class=\"";
            // line 39
            echo twig_escape_filter($this->env, (isset($context["active_row"]) ? $context["active_row"] : null), "html", null, true);
            echo "\"> ";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_group_name") != "")) {
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_group_name"), "html", null, true);
                echo " ";
            } else {
                echo " No Group ";
            }
            echo "</td>
\t\t\t\t\t\t <td class=\"";
            // line 40
            echo twig_escape_filter($this->env, (isset($context["active_row"]) ? $context["active_row"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "email"), "html", null, true);
            echo " </td>
\t\t\t\t\t\t <td class=\"";
            // line 41
            echo twig_escape_filter($this->env, (isset($context["active_row"]) ? $context["active_row"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "first_name"), "html", null, true);
            echo " </td>
\t\t\t\t\t\t <td class=\"";
            // line 42
            echo twig_escape_filter($this->env, (isset($context["active_row"]) ? $context["active_row"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "last_name"), "html", null, true);
            echo " </td>
\t\t\t\t\t\t <td class=\"text-center ";
            // line 43
            echo twig_escape_filter($this->env, (isset($context["active_row"]) ? $context["active_row"] : null), "html", null, true);
            echo "\"><button type=\"button\" title=\"Edit\" onclick=\"edit('";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "editscript"), "html", null, true);
            echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t ";
            // line 44
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id") != $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method"))) {
                // line 45
                echo "\t\t\t\t\t\t ";
                $context["company_id"] = $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "company_id"), "method");
                // line 46
                echo "\t\t\t\t\t\t\t<button type=\"button\" title=\"Comment to this user\" data-toggle=\"modal\" data-target=\"#general-comments\" onclick=\"get_gen_comment('";
                echo twig_escape_filter($this->env, (isset($context["company_id"]) ? $context["company_id"] : null), "html", null, true);
                echo "','";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "','c', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "first_name"), "html", null, true);
                echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"fa fa-comments\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t ";
            }
            // line 48
            echo "\t\t\t\t\t\t </td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 51
        echo "\t\t\t\t\t  ";
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows")) == 0)) {
            // line 52
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td colspan=\"8\">No Records</td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        // line 56
        echo "\t\t\t\t   </tbody>
\t\t\t\t   <tfoot>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t<td class=\"text-center\"><button type=\"button\" title=\"Delete\" onclick=\"delconfirm(this.form);\" class=\"btn btn-danger\"><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></button></td>
\t\t\t\t\t\t<td colspan=\"8\"></td>
\t\t\t\t\t  </tr>
\t\t\t\t   </tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
";
    }

    // line 69
    public function block_footer($context, array $blocks = array())
    {
        // line 70
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
<script src=\"/assets/js/list.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "front-users.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  216 => 70,  213 => 69,  197 => 56,  191 => 52,  188 => 51,  180 => 48,  170 => 46,  167 => 45,  165 => 44,  157 => 43,  151 => 42,  145 => 41,  139 => 40,  127 => 39,  121 => 38,  117 => 36,  111 => 34,  109 => 33,  104 => 32,  101 => 31,  98 => 30,  96 => 29,  93 => 28,  90 => 27,  87 => 26,  83 => 25,  75 => 20,  71 => 19,  67 => 18,  63 => 17,  59 => 16,  52 => 11,  50 => 10,  46 => 9,  41 => 7,  37 => 6,  32 => 3,  29 => 2,);
    }
}
