<?php

/* _front-side-bar.html */
class __TwigTemplate_59e84cad199773c5abddebedf8fa8fc4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t\t\t<!-- #section:basics/sidebar.horizontal -->
\t\t\t<div id=\"sidebar\" class=\"sidebar h-sidebar navbar-collapse collapse sidebar-fixed\">

\t\t\t\t<div class=\"sidebar-shortcuts\" id=\"sidebar-shortcuts\">
\t\t\t\t\t<div class=\"sidebar-shortcuts-large\" id=\"sidebar-shortcuts-large\">
\t\t\t\t\t\t<a href=\"/login_history.php\"  class=\"btn btn-success\" title=\"Logs\">
\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-signal\"></i>\t\t
\t\t\t\t\t\t</a>
\t\t\t\t\t\t
\t\t\t\t\t\t<button class=\"btn btn-info\" data-toggle=\"modal\" data-target=\"#profile\" title=\"Edit Profile\">
\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-pencil\"> </i>
\t\t\t\t\t\t</button>
\t\t\t\t\t\t";
        // line 13
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c")) {
            // line 14
            echo "\t\t\t\t\t\t<!-- #section:basics/sidebar.layout.shortcuts -->
\t\t\t\t\t\t<button class=\"btn btn-warning\" data-toggle=\"modal\" onclick=\"get_groups('";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "');\" data-target=\"#join_group\" title=\"Join Group\">
\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-users\"></i>
\t\t\t\t\t\t</button>
\t\t\t\t\t\t";
        }
        // line 19
        echo "\t\t\t\t\t\t";
        if (((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s")) || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u"))) {
            // line 20
            echo "\t\t\t\t\t\t<!-- #section:basics/sidebar.layout.shortcuts -->
\t\t\t\t\t\t<button class=\"btn btn-info\" data-toggle=\"modal\" data-target=\"#upload_avtar\" title=\"Edit Profile Picture\">
\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-user\"> </i>
\t\t\t\t\t\t</button>
\t\t\t\t\t\t";
        }
        // line 25
        echo "\t\t\t\t\t\t";
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c")) {
            // line 26
            echo "\t\t\t\t\t\t<button class=\"btn btn-danger\" data-toggle=\"modal\" onclick=\"getsettings('";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method"), "html", null, true);
            echo "');\" data-target=\"#email_settings\" title=\"Settings\">
\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-cogs\"></i>
\t\t\t\t\t\t</button>
\t\t\t\t\t\t";
        }
        // line 30
        echo "\t\t\t\t\t\t<!-- #section:basics/sidebar.layout.shortcuts -->
\t\t\t\t\t\t<a href=\"/logout.php\"  class=\"btn btn-success\" title=\"Log-out\">
\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-power-off\"></i>\t\t
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<!-- /section:basics/sidebar.layout.shortcuts -->
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"sidebar-shortcuts-mini\" id=\"sidebar-shortcuts-mini\">
\t\t\t\t\t\t<span class=\"btn btn-success\"></span>

\t\t\t\t\t\t<span class=\"btn btn-info\"></span>

\t\t\t\t\t\t<span class=\"btn btn-warning\"></span>

\t\t\t\t\t\t<span class=\"btn btn-danger\"></span>
\t\t\t\t\t</div>
\t\t\t\t</div><!-- /.sidebar-shortcuts -->

\t\t\t\t<ul class=\"nav nav-list\">
\t\t\t\t\t<li class=\"hover";
        // line 49
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "dashboard")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t<a href=\"/dashboard.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-tachometer\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Dashboard </span>
\t\t\t\t\t\t</a>

\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t</li>

\t\t\t\t\t
\t\t\t\t\t";
        // line 59
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c")) {
            // line 60
            echo "\t\t\t\t\t<li class=\"hover";
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "usergroup")) {
                echo " active";
            }
            echo "\">
\t\t\t\t\t\t<a href=\"/usergroups.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-users\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> User Groups </span>
\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<b class=\"arrow\"></b>\t
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"hover";
            // line 68
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "users")) {
                echo " active";
            }
            echo "\">
\t\t\t\t\t\t<a href=\"/users.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-user\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Users </span>
\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t</li>
\t\t\t\t\t\t";
            // line 76
            if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "parent_id"), "method") == 0)) {
                // line 77
                echo "\t\t\t\t\t\t\t<li class=\"hover";
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "subsidiaries")) {
                    echo " active";
                }
                echo "\">
\t\t\t\t\t\t\t\t<a href=\"/subsidiaries.php\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-share-alt\"></i>
\t\t\t\t\t\t\t\t\t<span class=\"menu-text\"> Subsidiaries </span>
\t\t\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t";
            }
            // line 86
            echo "\t\t\t\t\t<!--<li class=\"hover";
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "computer_group")) {
                echo " active";
            }
            echo "\">
\t\t\t\t\t\t<a href=\"/computer-groups.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-laptop\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Computer Group </span>
\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"hover";
            // line 94
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "computer")) {
                echo " active";
            }
            echo "\">
\t\t\t\t\t\t<a href=\"/computers.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-laptop\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Computer/Server </span>
\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t</li>-->
\t\t\t\t\t";
        }
        // line 103
        echo "
\t\t\t\t\t";
        // line 104
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u")) {
            // line 105
            echo "\t\t\t\t\t<li class=\"hover";
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "documents")) {
                echo " active";
            }
            echo "\">
\t\t\t\t\t\t<a href=\"/user-data.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-file-text-o\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Documents </span>
\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"hover";
            // line 113
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "bulkupload")) {
                echo " active";
            }
            echo "\">
\t\t\t\t\t\t<a href=\"/bulk-upload.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-upload\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Bulk Upload </span>
\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t</li>
\t\t\t\t\t";
        }
        // line 122
        echo "\t\t\t\t\t
\t\t\t\t\t";
        // line 123
        if (((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q")) || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "i"))) {
            // line 124
            echo "\t\t\t\t\t<li class=\"hover";
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "filters")) {
                echo " active";
            }
            echo "\">
\t\t\t\t\t\t<a href=\"/filters.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-filter\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Filters </span>
\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"hover";
            // line 132
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "inputs")) {
                echo " active";
            }
            echo "\">
\t\t\t\t\t\t<a href=\"/list-data.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-table\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Data Input </span>
\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"hover";
            // line 140
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "bulkupload")) {
                echo " active";
            }
            echo "\">
\t\t\t\t\t\t<a href=\"/bulk-upload.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-upload\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Bulk Upload </span>
\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t</li>
\t\t\t\t\t";
        }
        // line 149
        echo "\t\t\t\t</ul><!-- /.nav-list -->

\t\t\t</div>
\t\t\t<!-- /section:basics/sidebar.horizontal -->
";
    }

    public function getTemplateName()
    {
        return "_front-side-bar.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  255 => 149,  241 => 140,  228 => 132,  214 => 124,  212 => 123,  181 => 105,  162 => 94,  131 => 76,  102 => 59,  87 => 49,  66 => 30,  45 => 19,  38 => 15,  33 => 13,  217 => 127,  208 => 121,  202 => 119,  193 => 112,  191 => 111,  176 => 103,  164 => 91,  161 => 90,  151 => 84,  148 => 86,  146 => 82,  117 => 59,  113 => 57,  101 => 52,  77 => 30,  73 => 28,  67 => 26,  65 => 25,  55 => 25,  50 => 15,  47 => 14,  34 => 11,  31 => 10,  19 => 1,  198 => 92,  195 => 113,  190 => 80,  140 => 7,  136 => 5,  133 => 77,  127 => 131,  124 => 130,  121 => 129,  118 => 68,  115 => 127,  112 => 126,  109 => 55,  103 => 53,  100 => 122,  97 => 121,  94 => 120,  91 => 119,  89 => 91,  85 => 89,  83 => 88,  74 => 81,  72 => 80,  64 => 74,  58 => 26,  54 => 69,  52 => 68,  44 => 62,  42 => 12,  37 => 58,  35 => 14,  27 => 4,  22 => 1,  771 => 414,  760 => 407,  709 => 358,  700 => 352,  664 => 318,  662 => 317,  659 => 316,  642 => 301,  636 => 300,  630 => 298,  620 => 296,  610 => 294,  607 => 293,  605 => 292,  602 => 291,  598 => 290,  594 => 289,  579 => 276,  570 => 274,  560 => 272,  550 => 270,  548 => 269,  545 => 268,  541 => 267,  537 => 266,  522 => 253,  513 => 251,  510 => 250,  500 => 248,  490 => 246,  487 => 245,  484 => 244,  480 => 243,  476 => 242,  461 => 229,  452 => 227,  442 => 225,  432 => 223,  430 => 222,  427 => 221,  423 => 220,  419 => 219,  404 => 206,  395 => 204,  385 => 202,  375 => 200,  373 => 199,  370 => 198,  366 => 197,  362 => 196,  330 => 166,  328 => 165,  320 => 160,  317 => 159,  306 => 151,  295 => 142,  293 => 141,  283 => 133,  281 => 132,  274 => 129,  271 => 128,  263 => 123,  261 => 122,  257 => 120,  254 => 119,  251 => 118,  248 => 117,  245 => 116,  242 => 115,  239 => 114,  236 => 113,  233 => 112,  230 => 111,  220 => 103,  209 => 122,  205 => 120,  201 => 96,  194 => 93,  188 => 90,  185 => 89,  183 => 88,  179 => 104,  175 => 86,  171 => 85,  167 => 92,  163 => 83,  159 => 89,  153 => 79,  144 => 78,  141 => 77,  138 => 76,  135 => 75,  132 => 74,  130 => 69,  126 => 72,  120 => 70,  116 => 69,  110 => 65,  106 => 124,  104 => 60,  82 => 42,  79 => 41,  76 => 40,  51 => 17,  48 => 20,  46 => 15,  32 => 3,  29 => 9,);
    }
}
