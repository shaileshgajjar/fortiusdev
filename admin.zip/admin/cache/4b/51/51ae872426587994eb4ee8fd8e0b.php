<?php

/* assigntasks.html */
class __TwigTemplate_4b5151ae872426587994eb4ee8fd8e0b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save")) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"company_id\" id=\"company_id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"requirements_id\" id=\"requirements_id\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 16
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\tdata-bv-message=\"This value is not valid\"
\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\tenctype=\"multipart/form-data\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t<input type=\"hidden\" name=\"group_id\" id=\"group_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"chk_all\" id=\"chk_all\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "chk_all"), "html", null, true);
            echo "\" />
\t<input type=\"hidden\" name=\"company_id\" id=\"company_id\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"source\" id=\"source\" value=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "source"), "html", null, true);
            echo "\" />
\t<div class=\"col-lg-12\" style=\"margin-top:15px;\">
\t\t<div class=\"panel panel-primary\">
\t\t\t<div class=\"panel-heading\">
\t\t\t\t<div>";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
            echo " - Assign Task - <b>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "source_name"), "html", null, true);
            echo "</b></div>
\t\t\t</div>
\t\t\t<div class=\"panel-body\">
\t\t\t\t<div id=\"sticky-anchor\"></div>
\t\t\t\t<div class=\"form-group\" id=\"sticky\">
\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t<input type=\"checkbox\" name=\"chkall\" onclick=\"dochkall(this.checked);\" />
\t\t\t\t\t\t<button type=\"button\" onclick=\"savedata('continue');\" class=\"btn btn-success\">Save &amp; Continue</button>
\t\t\t\t\t\t<button type=\"button\" onclick=\"savedata('save');\" class=\"btn btn-success\">Save &amp; Exit</button>
\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-danger\" onclick=\"this.form.action='";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "'; this.form.submit();\">Cancel</button>
\t\t\t\t\t\t<div class=\"pull-right col-lg-3\">
\t\t\t\t\t\t\t<button type=\"button\" onclick=\"\$('#task').val(''); this.form.submit();\" class=\"pull-right btn btn-comments btn-xs btn-success  glyphicon glyphicon-search\" style=\" margin-left: 5px;  margin-top: 5px;padding-bottom: 4px; padding-left: 6px; padding-right: 8px; padding-top: 3px;\" title=\"Search\" ></button>
\t\t\t\t\t\t\t<input type=\"text\" style=\"width:86%; margin-top:5px;;\" autocomplete=\"off\" class=\"form-control\" placeholder=\"Search within requirement\" name=\"proc_req_search\" id=\"proc_req_search\" value=\"";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "proc_req_search"), "html", null, true);
            echo "\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t<select style=\"margin-top:5px;margin-left:5px;\" onchange=\"\$('#task').val(''); this.form.submit();\" name=\"inplace_filter\" id=\"inplace_filter\" class=\"form-control selectpicker\">
\t\t\t\t\t\t\t\t<option value=\"\">Filter By</option>
\t\t\t\t\t\t\t\t<option value=\"Y\"";
            // line 55
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "Y")) {
                echo " selected=\"selected\"";
            }
            echo ">Y</option>
\t\t\t\t\t\t\t\t<option value=\"N\"";
            // line 56
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "N")) {
                echo " selected=\"selected\"";
            }
            echo ">N</option>
\t\t\t\t\t\t\t\t<option value=\"C\"";
            // line 57
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "C")) {
                echo " selected=\"selected\"";
            }
            echo ">C</option>
\t\t\t\t\t\t\t\t<option value=\"NT\"";
            // line 58
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "NT")) {
                echo " selected=\"selected\"";
            }
            echo ">NT</option>
\t\t\t\t\t\t\t\t<option value=\"NA\"";
            // line 59
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "NA")) {
                echo " selected=\"selected\"";
            }
            echo ">NA</option>
\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div role=\"tabpanel\">
\t\t\t\t\t<!-- Nav tabs -->
\t\t\t\t\t<div id=\"security-inputs\">
\t\t\t\t\t<select name=\"requirements_id\" id=\"requirements_id\" class=\"form-control\" onchange=\"getassigntaks(this.value);\">
\t\t\t\t\t\t";
            // line 68
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements"));
            foreach ($context['_seq'] as $context["_key"] => $context["requirement"]) {
                // line 69
                echo "\t\t\t\t\t\t<option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\"";
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id") == $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"))) {
                    echo " selected=\"selected\"";
                }
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "rtitle"), "html", null, true);
                echo "</option>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['requirement'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 71
            echo "\t\t\t\t\t</select>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- Nav tabs -->
\t\t\t\t\t<!-- Tab panes -->
\t\t\t\t\t<div class=\"tab-content\">
\t\t\t\t\t";
            // line 76
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["requirement"]) {
                // line 77
                echo "\t\t\t\t\t\t";
                $context["extra"] = "";
                // line 78
                echo "\t\t\t\t\t\t";
                $context["data"] = "n";
                // line 79
                echo "\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id") == $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"))) {
                    // line 80
                    echo "\t\t\t\t\t\t\t";
                    $context["extra"] = " active";
                    // line 81
                    echo "\t\t\t\t\t\t\t";
                    $context["data"] = "y";
                    // line 82
                    echo "\t\t\t\t\t\t";
                }
                // line 83
                echo "\t\t\t\t\t\t<div role=\"tabpanel\" class=\"all-tabs tab-pane";
                echo twig_escape_filter($this->env, (isset($context["extra"]) ? $context["extra"] : null), "html", null, true);
                echo "\" id=\"tab";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t<p class=\"description alert alert-warning\"><b>Description : </b>";
                // line 84
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "description"), "html", null, true);
                echo "</p>
\t\t\t\t\t\t\t<input type=\"hidden\" id=\"data";
                // line 85
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\" name=\"data";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, (isset($context["data"]) ? $context["data"] : null), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t<div id=\"req";
                // line 86
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\" class=\"item\">
\t\t\t\t\t\t\t";
                // line 87
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id") == $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"))) {
                    // line 88
                    echo "\t\t\t\t\t\t\t\t";
                    $this->env->loadTemplate("getassigntasks.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
                    // line 89
                    echo "\t\t\t\t\t\t\t";
                }
                // line 90
                echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['requirement'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 93
            echo "\t\t\t\t\t</div>
\t\t\t\t\t<!-- Tab panes -->
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\" style=\"margin:0px;\">
\t\t\t\t\t<div class=\"col-lg-11\">
\t\t\t\t\t\t<input type=\"checkbox\" name=\"chkall\" onclick=\"dochkall(this.checked);\" />
\t\t\t\t\t\t<button type=\"button\" onclick=\"savedata('continue');\" class=\"btn btn-success\">Save &amp; Continue</button>
\t\t\t\t\t\t<button type=\"button\" onclick=\"savedata('save');\" class=\"btn btn-success\">Save &amp; Exit</button>
\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-danger\" onclick=\"this.form.action='";
            // line 101
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "'; this.form.submit();\">Cancel</button>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</form>
<div class=\"modal fade\" id=\"loading\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Processing..</h4>
\t\t\t</div>
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div id=\"proc-guidance\">
\t\t\t\t\t<p>Loading.. Please wait!!</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
";
        }
    }

    // line 124
    public function block_footer($context, array $blocks = array())
    {
        // line 125
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
";
        // line 126
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save")) {
            // line 127
            echo "<script type=\"text/javascript\">
\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
</script>
";
        } else {
            // line 133
            echo "<script type=\"text/javascript\">
function savedata(task)
{
\t\$('#task').val(task);
\t\$('#frm').submit();
}

function getassigntaks(id)
{
\t\$('.all-tabs').hide();
\t\$('#requirements_id').val(id);
\tif ( \$('#data'+id).val() == 'n' )
\t{
\t\t\$('#loading').modal('show');
\t\t\$('#data'+id).val('y');
\t\tformfields = 'requirements_id='+id+'&roc_saq=roc&id=";
            // line 148
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "'+'&source='+\$('#source').val();
\t\ttheurl = 'getassigntasks.php';
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\t\$('#req'+id).html(data);
\t\t\t\$('#loading').modal('hide');
\t\t});
\t}
\t\$('#tab'+id).show();
}

function sticky_relocate() {
    var window_top = \$(window).scrollTop();
    var div_top = \$('#sticky-anchor').offset().top;
    if (window_top > div_top-135) {
        \$('#sticky').addClass('stick');
    } else {
        \$('#sticky').removeClass('stick');
    }
}

\$(function () {
    \$(window).scroll(sticky_relocate);
    sticky_relocate();
});

function dochkall(chk)
{
\t\$(\".assignchk\"+\$('#requirements_id').val()).prop(\"checked\", chk)
}
</script>
";
        }
    }

    public function getTemplateName()
    {
        return "assigntasks.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  383 => 148,  366 => 133,  358 => 127,  356 => 126,  351 => 125,  348 => 124,  321 => 101,  311 => 93,  295 => 90,  292 => 89,  289 => 88,  287 => 87,  283 => 86,  275 => 85,  271 => 84,  264 => 83,  261 => 82,  258 => 81,  255 => 80,  252 => 79,  249 => 78,  246 => 77,  229 => 76,  222 => 71,  207 => 69,  203 => 68,  189 => 59,  183 => 58,  177 => 57,  171 => 56,  165 => 55,  157 => 50,  151 => 47,  137 => 38,  130 => 34,  126 => 33,  122 => 32,  118 => 31,  114 => 30,  110 => 29,  105 => 27,  101 => 26,  97 => 25,  93 => 24,  89 => 23,  85 => 22,  77 => 16,  71 => 13,  67 => 12,  63 => 11,  59 => 10,  55 => 9,  51 => 8,  47 => 7,  43 => 6,  39 => 5,  34 => 4,  32 => 3,  29 => 2,);
    }
}
