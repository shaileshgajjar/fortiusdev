<?php

/* assessment-reviewed-docs.html */
class __TwigTemplate_5309bcde3754507dafb86d8a3cd70346 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 15
            echo "<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 34
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 35
            echo "      <!-- Tab panes -->
\t\t<div class=\"tab-content tab_border\">
            <div class=\"screen7_inner_part widget-box widget-color-blue\">
                <div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i> 4 Reviewed Environment </h4>
                </div>
                <div class=\"widget-body\">
                \t<div class=\"widget-main widget_main_extra_part\">
                    \t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.10\tDocumentation reviewed</div>
\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t\tIdentify and list all reviewed documents. Include the following:
\t\t\t\t\t\t</div>
                    \t<div class=\"screen9_table_block_part screen10_extra screen11_part\">
                            <div class=\"table-responsive screen_field_part\">
                                <table class=\"table table-striped\" id=\"tbl1\">
\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">Reference Number</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-3 col-sm-2 col-xs-2\">Document Name (including version, if applicable)</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-4 col-sm-2 col-xs-2\">Brief description of document purpose</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-3 col-sm-2 col-xs-2\">Document date</th>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t";
            // line 59
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "docs"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 60
                echo "\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td><strong>Doc - ";
                // line 61
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index"), "html", null, true);
                echo "</strong></td>
\t\t\t\t\t\t\t\t\t\t\t<td><textarea name=\"doc_name[]\" placeholder=\"Document Name\" class=\"form-control\" rows=\"2\">";
                // line 62
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_name"), "html", null, true);
                echo "</textarea></td>
\t\t\t\t\t\t\t\t\t\t\t<td><textarea name=\"doc_purpose[]\" placeholder=\"Brief description of document purpose\" class=\"form-control\" rows=\"2\">";
                // line 63
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_purpose"), "html", null, true);
                echo "</textarea></td>
\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"doc_date_";
                // line 66
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>
\t\t\t\t\t\t\t\t\t\t\t\t\t<input readonly type=\"text\" name=\"doc_date[]\" id=\"doc_date_";
                // line 67
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" class=\"date-picker form-control\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_date"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 69
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 70
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 71
                echo "\t\t
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 74
            echo "\t\t
\t\t\t\t\t\t\t\t\t</tbody>
                                </table>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow('tbl1');\" > Add New </div>
                        </div>
                        <div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.11 Individuals interviewed</div>
\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t\tIdentify and list the individuals interviewed. Include the following:
\t\t\t\t\t\t</div>
                        <div class=\"screen9_table_block_part screen10_extra screen11_part\">
                            <div class=\"table-responsive screen20_part\">
                                <table class=\"table table-striped\" id=\"tbl2\" >
\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">Reference Number</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">Employee Name</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">Role/Job Title</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">Organization</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">Is this person an ISA?(yes/no)</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">Summary of Topics Covered / Areas or Systems of Expertise(high-level summary only)</th>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t";
            // line 98
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "individ"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 99
                echo "\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td><strong>Int - ";
                // line 100
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index"), "html", null, true);
                echo "</strong></td>
\t\t\t\t\t\t\t\t\t\t\t<td><input name=\"emp_name[]\" type=\"text\" class=\"form-control\" placeholder=\"Employee Name\" value=\"";
                // line 101
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "emp_name"), "html", null, true);
                echo "\"></td>
\t\t\t\t\t\t\t\t\t\t\t<td><input name=\"emp_role[]\" type=\"text\" class=\"form-control\" placeholder=\"Role/Job Title\" value=\"";
                // line 102
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "emp_role"), "html", null, true);
                echo "\"></td>
\t\t\t\t\t\t\t\t\t\t\t<td><input name=\"organization[]\"type=\"text\" class=\"form-control\" placeholder=\"Organization\" value=\"";
                // line 103
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "organization"), "html", null, true);
                echo "\"></td>
\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<input id=\"emp_isa-1-";
                // line 106
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"1\" ";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "emp_isa") == "yes")) {
                    echo " checked=\"checked\"";
                }
                echo " name=\"emp_isa1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"emp_isa[]\" id=\"emp_isa";
                // line 107
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "emp_isa"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td><textarea name=\"expertise_summary[]\" class=\"form-control\" placeholder=\"Summary\" rows=\"2\">";
                // line 110
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "expertise_summary"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t\t";
                // line 111
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 112
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 113
                echo "\t\t
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 117
            echo "\t\t\t\t\t\t\t\t\t</tbody>
                                </table>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow('tbl2');\" > Add New </div>
                        </div>
\t\t\t\t\t\t<button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 122
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button>
                    </div>
                </div>
            </div>
        </div>
\t</form>
</div>
";
        }
    }

    // line 132
    public function block_footer($context, array $blocks = array())
    {
        // line 133
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script src=\"/assets/js/chosen.jquery.js\"></script>
\t<link href=\"/assets/css/bootstrap-switch.css\" type=\"text/css\" rel=\"stylesheet\">
\t<script src=\"/assets/js/bootstrap-switch.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 145
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 146
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 150
            echo "num1 = row1 = ";
            echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "docs")), "html", null, true);
            echo ";
num2 = row2 = ";
            // line 151
            echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "individ")), "html", null, true);
            echo ";
\$(document).ready(function() {
\t\$('#frm').bootstrapValidator();
\t\$(\".switch\").bootstrapSwitch();
    \$(\"#tbl1\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
\t\tvar t = 1;
\t\t\$(\"#tbl1 tbody tr\").each(function() {
\t\t\t\$(this).children('td:first-child').text(\"Doc - \"+t);
\t\t\t\$(this).children('td:first-child').css(\"font-weight\",\"bold\");
\t\t\tt = Number(t+1);
\t\t});
\t\tnum1 = t-1;
    });
\t\$(\"#tbl2\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
\t\tvar q = 1;
\t\t\$(\"#tbl2 tbody tr\").each(function() {
\t\t\t\$(this).children('td:first-child').text(\"Int - \"+q);
\t\t\t\$(this).children('td:first-child').css(\"font-weight\",\"bold\");
\t\t\tq = Number(q+1);
\t\t});
\t\tnum2 = q-1;
    });
\t\$('body').on('focus',\".date-picker\", function(){
\t\t\$(this).datepicker({format: 'mm-dd-yyyy'});
\t}).on('changeDate', function(ev){
\t\t\$(\".datepicker\").hide();
\t});
\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\tary = \$(this).attr('id').split('-');
\t\tval = state ? 'yes' : 'no';
\t\t\$('#'+ary[0]+ary[2]).val(val);
\t});
});

function addrow(tbl_id)
{
\tif(tbl_id == 'tbl1' )
\t{
\t\tnum1++;
\t\thtml = '';
\t\thtml = html + '<tr>';
\t\thtml = html + '\t<td><strong>Doc - '+num1+'</strong></td>';
\t\thtml = html + '\t<td><textarea name=\"doc_name[]\" placeholder=\"Document Name\" class=\"form-control\" rows=\"2\"></textarea></td>';
\t\thtml = html + '\t<td><textarea name=\"doc_purpose[]\" placeholder=\"Brief description of document purpose\" class=\"form-control\" rows=\"2\"></textarea></td>';
\t\thtml = html + '\t<td>';
\t\thtml = html + '\t\t<div class=\"input-group\">';
\t\thtml = html + '\t\t\t<label for=\"doc_date_'+row1+'\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>';
\t\thtml = html + '\t\t\t<input readonly type=\"text\" name=\"doc_date[]\" id=\"doc_date_'+row1+'\" class=\"date-picker form-control\" value=\"";
            // line 200
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "current_date"), "html", null, true);
            echo "\" />';
\t\thtml = html + '\t\t</div>';
\t\thtml = html + '\t\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>';
\t\thtml = html + '\t</td>';
\t\thtml = html + '</tr>';
\t\t\$(\"#\"+tbl_id).append(html);\t
\t\trow1++;
\t}
\tif(tbl_id == 'tbl2' )
\t{
\t\tnum2++;
\t\thtml = '';
\t\thtml = html + '<tr>';
\t\thtml = html + '\t<td><strong>Int - '+num2+'</strong></td>';
\t\thtml = html + '\t<td><input name=\"emp_name[]\" type=\"text\" class=\"form-control\" placeholder=\"Employee Name\" value=\"\"></td>';
\t\thtml = html + '\t<td><input name=\"emp_role[]\" type=\"text\" class=\"form-control\" placeholder=\"Role/Job Title\" value=\"\"></td>';
\t\thtml = html + '\t<td><input name=\"organization[]\"type=\"text\" class=\"form-control\" placeholder=\"Organization\" value=\"\"></td>';
\t\thtml = html + '\t<td>';
\t\thtml = html + '\t\t<div class=\"lockunlock\">';
\t\thtml = html + '\t\t\t<input id=\"emp_isa-1-'+row2+'\" value=\"1\" name=\"emp_isa1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">';
\t\thtml = html + '\t\t\t<input type=\"hidden\" name=\"emp_isa[]\" id=\"emp_isa'+row2+'\" value=\"no\" />';
\t\thtml = html + '\t\t</div>';
\t\thtml = html + '\t</td>';
\t\thtml = html + '\t<td><textarea name=\"expertise_summary[]\" class=\"form-control\" placeholder=\"Summary\" rows=\"2\"></textarea>';
\t\thtml = html + '\t\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\"><i class=\"fa fa-trash\"></i></a>';
\t\thtml = html + '\t</td>';
\t\thtml = html + '</tr>';
\t\t\$(\"#\"+tbl_id).append(html);\t
\t\t\$(\".switch\").bootstrapSwitch();
\t\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\t\tary = \$(this).attr('id').split('-');
\t\t\tval = state ? 'yes' : 'no';
\t\t\t\$('#'+ary[0]+ary[2]).val(val);
\t\t});
\t\trow2++;
\t}
}
";
        }
        // line 238
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "assessment-reviewed-docs.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  471 => 238,  430 => 200,  378 => 151,  373 => 150,  367 => 146,  365 => 145,  349 => 133,  346 => 132,  332 => 122,  325 => 117,  308 => 113,  304 => 112,  302 => 111,  298 => 110,  290 => 107,  282 => 106,  276 => 103,  272 => 102,  268 => 101,  264 => 100,  261 => 99,  244 => 98,  218 => 74,  201 => 71,  197 => 70,  195 => 69,  188 => 67,  184 => 66,  178 => 63,  174 => 62,  170 => 61,  167 => 60,  150 => 59,  124 => 35,  122 => 34,  117 => 32,  113 => 31,  109 => 30,  105 => 29,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  80 => 22,  71 => 15,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
