<?php

/* network-segmentation-second-part.html */
class __TwigTemplate_d0971648b3814fb320e81bb50592e435 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 16
            echo "\t<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 35
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 36
            echo "      <!-- Tab panes -->
        <div class=\"tab-content tab_border\">
      
     
      
       <div role=\"tabpanel\" class=\"tab-pane active\" id=\"screen1\">
            
            <div class=\"screen7_inner_part widget-box widget-color-blue\">
            \t<div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i> 3 Description of SOW &amp; Approach Taken </h4>
                </div>
                
            \t<div class=\"widget-body\">
                \t<div class=\"widget-main widget_main_extra_part\">
\t\t\t\t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">3.4 Network segment details</div>
                    \t<div class=\"screen9_table_block_part\">
                            <h5>Describe all networks that store, process and/or transmit CHD:</h5>
                            <div class=\"table-responsive\">
                                <table class=\"table table-striped\" id=\"tbl1\">
                                  <thead>
                                    <tr>
                                      <th>Network Name(In Scope)</th>
                                      <th>Functional/Purpose of Network</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                ";
            // line 62
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "store_chd"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 63
                echo "                                    <tr>
                                      <td><div class=\"col-md-9 col-sm-9 col-xs-9\"><input name=\"store_chd[]\" type=\"text\" class=\"form-control\" value=\"";
                // line 64
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "network_name"), "html", null, true);
                echo "\"  > </div></td>
                                      <td><div class=\"col-md-9 col-sm-9 col-xs-9\"><input name=\"store_chd_purpose[]\" type=\"text\" class=\"form-control\" value=\"";
                // line 65
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "purpose"), "html", null, true);
                echo "\"  >  </div>
\t\t\t\t\t\t\t\t\t  ";
                // line 66
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    echo "<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>";
                }
                // line 67
                echo "\t\t\t\t\t\t\t\t\t  </td>
                                    </tr>
                                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 70
            echo "                                  </tbody>
                                </table>
                              </div>
                              <div class=\"btn btn-primary primary_add_btn pull-right\" id=\"addbtn1\" onclick=\"addrow('tbl1');\" > Add New </div>
                        </div>
                        
                        <div class=\"screen9_table_block_part\">
                            <h5>Describe all neworks that do not store, process and/or transmit CHD, but are scope (e.g., connected to the CDE or provide management functions to the CDE):</h5>
                            <div class=\"table-responsive\">
                                <table class=\"table table-striped\" id=\"tbl2\">
                                  <thead>
                                    <tr>
                                      <th>Network Name(In Scope)</th>
                                      <th>Functional Purpose of Network</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                ";
            // line 87
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "not_store_chd"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 88
                echo "                                   <tr>
                                      <td><div class=\"col-md-9 col-sm-9 col-xs-9\"><input name=\"not_store_chd[]\" type=\"text\" class=\"form-control\" value=\"";
                // line 89
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "network_name"), "html", null, true);
                echo "\"  > </div></td>
                                      <td><div class=\"col-md-9 col-sm-9 col-xs-9\"><input name=\"not_store_chd_purpose[]\" type=\"text\" class=\"form-control\" value=\"";
                // line 90
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "purpose"), "html", null, true);
                echo "\"  ></div>
\t\t\t\t\t\t\t\t\t  ";
                // line 91
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    echo "<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a> ";
                }
                // line 92
                echo "\t\t\t\t\t\t\t\t\t  </td>
                                    </tr>
\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 95
            echo "                                  </tbody>
                                </table>
                              </div>
                              <div class=\"btn btn-primary primary_add_btn pull-right\" id=\"addbtn2\" onclick=\"addrow('tbl2');\" > Add New </div>
                        </div>
                        
                        <div class=\"screen9_table_block_part\">
                            <h5>Describe any networks confirmed to be out of scope:</h5>
                            <div class=\"table-responsive\">
                                <table class=\"table table-striped\" id=\"tbl3\">
                                  <thead>
                                    <tr>
                                      <th>Network Name(In Scope)</th>
                                      <th>Functional Purpose of Network</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                ";
            // line 112
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "out_of_scope"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 113
                echo "                                    <tr>
                                        <td><div class=\"col-md-9 col-sm-9 col-xs-9\"><input name=\"out_of_scope[]\" type=\"text\" class=\"form-control\" placeholder=\"Network 1\" value=\"";
                // line 114
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "network_name"), "html", null, true);
                echo "\"  > </div></td>
                                        <td><div class=\"col-md-9 col-sm-9 col-xs-9\"><input name=\"out_of_scope_purpose[]\" type=\"text\" class=\"form-control\" placeholder=\"Purpose of Network 1\"  value=\"";
                // line 115
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "purpose"), "html", null, true);
                echo "\"   ></div>
\t\t\t\t\t\t\t\t\t\t";
                // line 116
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    echo "<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a> ";
                }
                // line 117
                echo "\t\t\t\t\t\t\t\t\t\t</td>
                                    </tr>
                                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 119
            echo " 
                                  </tbody>
                                </table>
                              </div>
                              <div class=\"btn btn-primary primary_add_btn pull-right\" id=\"addbtn3\" onclick=\"addrow('tbl3');\" > Add New </div>
                        </div>
                         <button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 125
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t \t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\" id=\"validateBtn\" >Next <span><i class=\"fa fa-arrow-right\" ></i></span> </button>
                    </div>
                </div>
            
            </div>
            
        </div>
      </div>
   
\t  </form>
    </div>
    


";
        }
    }

    // line 142
    public function block_footer($context, array $blocks = array())
    {
        // line 143
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 149
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 150
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 154
            echo "\$(document).ready(function() {
   
\t\$('#frm').bootstrapValidator();
    \$(\"#tbl1\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t \$(\"#tbl2\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t \$(\"#tbl3\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
});
";
        }
        // line 168
        echo "function addrow(tbl_id)
{
\t\$('#validateBtn').prop('disabled', false);
\tif(tbl_id == 'tbl1')
\t{
\t\t\$(\"#\"+tbl_id).append('<tr><td><div class=\"col-lg-9\"><input name=\"store_chd[]\" type=\"text\" class=\"form-control\" placeholder=\" \"></div> </td><td><div class=\"col-lg-9\"><input name=\"store_chd_purpose[]\" type=\"text\" class=\"form-control\" placeholder=\" \"></div> &nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a></td></tr>');
\t}
\tif(tbl_id == 'tbl2')
\t{
\t\t\$(\"#\"+tbl_id).append('<tr><td><div class=\"col-lg-9\"><input name=\"not_store_chd[]\" type=\"text\" class=\"form-control\" placeholder=\" \"> </div> </td><td><div class=\"col-lg-9\"><input name=\"not_store_chd_purpose[]\" type=\"text\" class=\"form-control\" placeholder=\" \"></div> &nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a></td></tr>');
\t}
\tif(tbl_id == 'tbl3')
\t{
\t\t\$(\"#\"+tbl_id).append('<tr><td><div class=\"col-lg-9\"><input name=\"out_of_scope[]\" type=\"text\" class=\"form-control\" placeholder=\" \"> </div> </td><td><div class=\"col-lg-9\"><input name=\"out_of_scope_purpose[]\" type=\"text\" class=\"form-control\" placeholder=\" \"></div> &nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a></td></tr>');
\t}
}
</script>
";
    }

    public function getTemplateName()
    {
        return "network-segmentation-second-part.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  404 => 168,  388 => 154,  382 => 150,  380 => 149,  370 => 143,  367 => 142,  346 => 125,  338 => 119,  322 => 117,  318 => 116,  314 => 115,  310 => 114,  307 => 113,  290 => 112,  271 => 95,  255 => 92,  251 => 91,  247 => 90,  243 => 89,  240 => 88,  223 => 87,  204 => 70,  188 => 67,  184 => 66,  180 => 65,  176 => 64,  173 => 63,  156 => 62,  128 => 36,  126 => 35,  121 => 33,  117 => 32,  113 => 31,  109 => 30,  104 => 28,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  75 => 16,  69 => 13,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
