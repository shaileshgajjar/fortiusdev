<?php

/* assessment-timeframe.html */
class __TwigTemplate_51987d314a1cbe2cb20de16dceec5dd9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t<input type=\"hidden\" name=\"parent_id\" id=\"parent_id\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "parent_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 18
            echo "<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"parent_id\" id=\"parent_id\" value=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "parent_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t 
      <!-- Nav tabs -->
\t\t  ";
            // line 40
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 41
            echo "      <!-- Tab panes -->
\t\t<div class=\"tab-content tab_border\">
            <div class=\"row new_field_block_part widget-box widget-color-blue\">
            \t<div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i>1 Contact Information and Report Date </h4>
                </div>
                <div class=\"widget-body\"> 
                \t<div class=\"widget-main widget_main_extra_part\">
                        <div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\"> 1.2 Date and timeframe of assessment</div>
                            <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part\">
                                <div class=\"field_part field_extra_part screen5_fix_height\">
                                    <div class=\"form_group_block\">
                                        <label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_align\">Date of report:</label>
                                        <div class=\"input-group\">
                                            <label for=\"date_of_report\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>
\t\t\t\t\t\t\t\t\t\t\t<input readonly type=\"text\" class=\"date-picker form-control\" name=\"date_of_report\" id=\"date_of_report\" required value=\"";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "date_of_report"), "value"), "html", null, true);
            echo "\" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                    
                            <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
                                <div class=\"field_part field_extra_part\">
                                    <div class=\"form-group form_group_block form_label_height\">
                                        <label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\"> Timeframe of assessment:</label>
                                        <div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t\t<textarea name=\"timeframe\" id=\"timeframe\" class=\"form-control\" rows=\"2\" placeholder=\"12nd August 30th September\" required>";
            // line 67
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "timeframe"), "value"), "html", null, true);
            echo "</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
                                <div class=\"field_part field_extra_part\">
                                    <div class=\"form-group form_group_block\">
                                        <label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">Identify date(s) spent onsite at the entity:</label>
                                        <div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
                                          <textarea name=\"date_spent_onsite\" id=\"date_spent_onsite\" class=\"form-control\" rows=\"2\" required>";
            // line 78
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "date_spent_onsite"), "value"), "html", null, true);
            echo "</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
                                <div class=\"field_part field_extra_part\">
                                    <div class=\"form-group form_group_block\">
                                        <label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">Descriptions of time spent onsite at the entity and time spent performing remote assessment activities, including time spent on validation of remediation activities.</label>
                                        <div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
                                          <textarea name=\"desc_of_time_spent\" id=\"desc_of_time_spent\" class=\"form-control\" rows=\"2\" placeholder=\"Time spent on site description\">";
            // line 89
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "desc_of_time_spent"), "value"), "html", null, true);
            echo "</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
\t\t\t\t\t\t\t<!-- <button class=\"btn btn-danger new_success pull-left\"  onclick=\"previous_step('";
            // line 94
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button> -->
\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button>
                    </div>                \t               
                </div>
                
            </div>
\t\t</div>
\t</form>
</div>
";
        }
    }

    // line 105
    public function block_footer($context, array $blocks = array())
    {
        // line 106
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 114
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 115
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 119
            echo "\$(document).ready(function() {
    \$('#frm').bootstrapValidator();
\t\$('body').on('focus',\".date-picker\", function(){
\t\t\$(this).datepicker({format: 'mm-dd-yyyy'});
\t}).on('changeDate', function(ev){
\t\t\$(\".datepicker\").hide();
\t});
});
";
        }
        // line 128
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "assessment-timeframe.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  261 => 128,  250 => 119,  244 => 115,  242 => 114,  230 => 106,  227 => 105,  212 => 94,  204 => 89,  190 => 78,  176 => 67,  162 => 56,  145 => 41,  143 => 40,  137 => 37,  133 => 36,  129 => 35,  125 => 34,  121 => 33,  117 => 32,  112 => 30,  108 => 29,  104 => 28,  100 => 27,  96 => 26,  92 => 25,  83 => 18,  77 => 15,  73 => 14,  69 => 13,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
