<?php

/* _upload-diagram-reviewed-env.html */
class __TwigTemplate_1e61401ee6b232c8480918445fcc9cfd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- Upload Document Div -->
<div class=\"modal fade\" id=\"upload\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"myModalLabel\">Upload Diagram</h4>
      </div>
      <div class=\"modal-body\">
        <form id=\"frmdiagram\" name=\"frmdiagram\" method=\"post\" action=\"/save-diagram.php\" enctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"savediagram\" />
\t\t\t<input type=\"hidden\" name=\"section_id\" id=\"section_id\" value=\"2\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"file\" name=\"diagram\" id=\"diagram\" style=\"height:30px; cursor:pointer;\" class=\"pull-left\" />
\t\t\t<button type=\"submit\" class=\"btn btn-success pull-left\">Upload</button>
\t\t</form>
\t\t<div class=\"progress\">
\t\t\t<div class=\"bar\"></div >
\t\t\t<div class=\"percent\">0%</div >
\t\t</div>
\t\t<div id=\"statusdiagram\" class=\"alert\"></div>
\t  </div>
      <div class=\"modal-footer\">
\t\t<button type=\"button\" class=\"btn btn-success\" data-dismiss=\"modal\" onclick=\"submitForm();\">Save</button>
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- End upload Doc -->";
    }

    public function getTemplateName()
    {
        return "_upload-diagram-reviewed-env.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 13,  19 => 1,);
    }
}
