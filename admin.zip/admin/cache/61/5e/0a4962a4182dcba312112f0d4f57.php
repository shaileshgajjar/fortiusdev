<?php

/* additional-services-provided-by-qsa.html */
class __TwigTemplate_615e0a4962a4182dcba312112f0d4f57 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 16
            echo "
<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\tdata-bv-message=\"This value is not valid\"
\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\tenctype=\"multipart/form-data\">
\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
\t\t<!-- Nav tabs -->
\t\t";
            // line 37
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 38
            echo "\t\t<!-- Tab panes -->
\t\t<div class=\"tab-content tab_border\">
\t\t\t<div role=\"tabpanel\" class=\"tab-pane active\" id=\"screen1\">
\t\t\t\t<div class=\"row new_field_block_part widget-box widget-color-blue\">
\t\t\t\t\t<div class=\"widget-header\">
\t\t\t\t\t\t<h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i> 1 Contact Information and Report Date </h4>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"widget-body\">
\t\t\t\t\t\t<div class=\"widget-main widget_main_extra_part\">
\t\t\t\t\t\t\t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">1.4\tAdditional services provided by QSA company</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">Disclose all services offered to the assessed entity by the QSAC:</label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"2\" placeholder=\"Disclose all services offered to the assessed entity by the QSAC, including but not limited to whether the assessed entity uses any security-related devices or security-related applications that have been developed or manufactured by the QSA, or to which the QSA owns the rights or that the QSA has configured or manages\" name=\"services_by_qsa\" id=\"services_by_qsa\">";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "services_by_qsa"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">Describe efforts made to ensure no conflict of interest resulted from the above mentioned services provided by the QSAC:</label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"2\" placeholder=\"Describe efforts made to ensure no conflict of interest resulted from the above mentioned services provided by the QSAC\" name=\"eforts_by_qsa\" id=\"eforts_by_qsa\" >";
            // line 66
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "eforts_by_qsa"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 71
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t\t\t\t\t\t<button class=\"btn btn-success new_success pull-right\" type=\"submit\" >Next <span><i class=\"fa fa-arrow-right\"></i></span></button>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</form>
</div>
";
        }
    }

    // line 82
    public function block_footer($context, array $blocks = array())
    {
        // line 83
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 91
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 92
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 96
            echo "\$(document).ready(function() {
    \$('#frm').bootstrapValidator();
\t\$( \"#pwd\" ).keyup(function() {
\t\tif ( \$('#pwd').val() == '' )
\t\t\t\$('#errpwd').show();
\t\telse
\t\t\t\$('#errpwd').hide();
\t});
\t\$(\".date-picker\").datepicker({
\t\tformat: 'mm-dd-yyyy'
\t}).on('changeDate', function(ev){
\t\t\$(\".datepicker\").hide();
\t});
});
";
        }
        // line 111
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "additional-services-provided-by-qsa.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  229 => 111,  212 => 96,  206 => 92,  204 => 91,  192 => 83,  189 => 82,  174 => 71,  166 => 66,  150 => 53,  133 => 38,  131 => 37,  126 => 35,  122 => 34,  118 => 33,  114 => 32,  110 => 31,  105 => 29,  101 => 28,  97 => 27,  93 => 26,  89 => 25,  85 => 24,  75 => 16,  69 => 13,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
