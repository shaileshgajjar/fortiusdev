<?php

/* reportings.html */
class __TwigTemplate_16d191710861f5722350faf467e96c64 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t\t\t";
        // line 10
        $this->env->loadTemplate("_new-panel.html")->display($context);
        // line 11
        echo "\t\t\t<div class=\"table-responsive\">
\t\t\t\t<table id=\"simple-table\" class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t   <thead>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t <th class=\"text-center\">
\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"ace\" />
\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t </th>
\t\t\t\t\t\t <th class=\"text-center\">";
        // line 21
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Sr.#", 1 => "rowid", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 22
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Requirement", 1 => "requirement", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 23
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "PCI DSS Requirement", 1 => "sub_requirement", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 24
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Testing Procedure", 1 => "title_procedure", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 25
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Reporting Head", 1 => "title", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th class=\"text-center\">Action</th>
\t\t\t\t\t  </tr>
\t\t\t\t   </thead>
\t\t\t\t   <tbody>
\t\t\t\t\t  ";
        // line 30
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 31
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td class=\"text-center\">
\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"removeid[]\" class=\"ace\" value=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t </td>
\t\t\t\t\t\t <td class=\"text-center\">";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "rowid"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "requirement"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "sub_requirement"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "title_procedure"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "title"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td class=\"text-center\"><button type=\"button\" title=\"Edit\" onclick=\"edit('";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "editscript"), "html", null, true);
            echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button></td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 46
        echo "\t\t\t\t\t  ";
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows")) == 0)) {
            // line 47
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td colspan=\"8\">No Records</td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        // line 51
        echo "\t\t\t\t   </tbody>
\t\t\t\t   <tfoot>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t<td class=\"text-center\"><button type=\"button\" title=\"Delete\" onclick=\"delconfirm(this.form);\" class=\"btn btn-danger\"><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></button></td>
\t\t\t\t\t\t<td colspan=\"8\"></td>
\t\t\t\t\t  </tr>
\t\t\t\t   </tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
";
    }

    // line 64
    public function block_footer($context, array $blocks = array())
    {
        // line 65
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
<script src=\"/admin/js/list.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "reportings.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 65,  160 => 64,  144 => 51,  138 => 47,  135 => 46,  124 => 43,  120 => 42,  116 => 41,  112 => 40,  108 => 39,  104 => 38,  97 => 34,  92 => 31,  88 => 30,  80 => 25,  76 => 24,  72 => 23,  68 => 22,  64 => 21,  52 => 11,  50 => 10,  46 => 9,  41 => 7,  37 => 6,  32 => 3,  29 => 2,);
    }
}
