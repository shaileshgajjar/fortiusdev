<?php

/* user.html */
class __TwigTemplate_45163fb5c949706a25ccf17bf1ff88f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 13
            echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userrole\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userrole"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"company_id\" id=\"company_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "company_id"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userrole\" id=\"userrole\" value=\"u\" />
\t\t\t<input type=\"hidden\" name=\"current_group_id\" id=\"current_group_id\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "user_group_id"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"user_group_name\" id=\"user_group_id\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "user_group_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"from\" id=\"from\" value=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "from"), "html", null, true);
            echo "\" />
\t\t\t<div class=\"widget-box widget-color-blue\">
\t\t\t\t<!-- #section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-header\">
\t\t\t\t\t<h5 class=\"widget-title smaller lighter\">
\t\t\t\t\t\t<i class=\"ace-icon fa fa-edit\"></i>
\t\t\t\t\t\t";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
            echo "
\t\t\t\t\t</h5>
\t\t\t\t</div>

\t\t\t\t<!-- /section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-body\">
\t\t\t\t\t<div class=\"widget-main\">
\t\t\t\t\t\t";
            // line 47
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") != "")) {
                // line 48
                echo "\t\t\t\t\t\t<div class=\"alert alert-danger\" role=\"alert\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err"), "html", null, true);
                echo "</div>
\t\t\t\t\t\t";
            }
            // line 50
            echo "\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">User Group
\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<select required id=\"user_group_id\" name=\"user_group_id\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t<option value=\"\">Select User Group</option>
\t\t\t\t\t\t\t\t\t";
            // line 56
            echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "user_groups");
            echo "
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>\t\t
\t\t\t\t\t
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">User Name/Email ID</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"email\" id=\"email\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\t\trequired 
\t\t\t\t\t\t\t\t\t\ttype=\"email\" value=\"";
            // line 66
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "email"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Password</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"pwd\" id=\"pwd\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\t\t";
            // line 73
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id") == 0)) {
                // line 74
                echo "\t\t\t\t\t\t\t\t\t\trequired
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 76
            echo "\t\t\t\t\t\t\t\t\t\ttype=\"password\" value=\"\" placeholder=\"Enter password\" pattern=\"(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!,@,#,\$,%,&,*,\\(,\\)]).{8,}\" 
\t\t\t\t\t\t\t\t\t\tdata-bv-regexp-message=\"Minimum 8 char includes one capital, one number and one special char ! @ # \$ % & * ( )\" />
\t\t\t\t\t\t\t\t\t<div class=\"pull-left\">[Keep blank to do not change]</div>
\t\t\t\t\t\t\t\t\t<div style=\"clear:both;\"></div>
\t\t\t\t\t\t\t\t\t<small id=\"errpwd\" style=\"display:block; color:#a94442; margin-bottom:10px; margin-top:5px;\">Minimum 8 char includes one capital, one number and one special char ! @ # \$ % &amp; * ( )</small>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Title</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<select required id=\"title\" name=\"title\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t<option value=\"mr\"";
            // line 87
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "title"), "value") == "mr")) {
                echo " selected=\"selected\"";
            }
            echo ">Mr.</option>
\t\t\t\t\t\t\t\t\t<option value=\"mrs\"";
            // line 88
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "title"), "value") == "mrs")) {
                echo " selected=\"selected\"";
            }
            echo ">Mrs.</option>
\t\t\t\t\t\t\t\t\t<option value=\"miss\"";
            // line 89
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "title"), "value") == "miss")) {
                echo " selected=\"selected\"";
            }
            echo ">Miss.</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">First Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"first_name\" id=\"first_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\trequired type=\"text\" value=\"";
            // line 97
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "first_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Last Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"last_name\" id=\"last_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\trequired type=\"text\" value=\"";
            // line 104
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "last_name"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Company Name</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"company_name\" id=\"company_name\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\t type=\"text\" value=\"";
            // line 111
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "company_name"), "value"), "html", null, true);
            echo "\" readonly />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Mobile</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"mobile\" id=\"mobile\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\trequired type=\"text\" value=\"";
            // line 118
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "mobile"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<label class=\"col-lg-2 control-label\">Office Location</label>
\t\t\t\t\t\t\t<div class=\"col-lg-10\">
\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"office_location\" id=\"office_location\" autocomplete=\"off\"
\t\t\t\t\t\t\t\t\trequired type=\"text\" value=\"";
            // line 125
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "office_location"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<div class=\"col-lg-10 col-lg-offset-2\">
\t\t\t\t\t\t\t\t<button type=\"submit\" title=\"Save\" class=\"btn btn-success\"><span class=\"glyphicon glyphicon-ok\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t\t<button type=\"button\" title=\"Cancel\" class=\"btn btn-danger\" onclick=\"this.form.action='";
            // line 131
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "'; this.form.submit();\"><span class=\"glyphicon glyphicon-arrow-left\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
<div class=\"modal fade\" id=\"addusergroup\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"myModalLabel\">Add User Group</h4>
      </div>
\t  <form name=\"frmusergroupadd\" id=\"frmusergroupadd\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\tdata-bv-message=\"This value is not valid\"
\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\tonsubmit=\"return false;\">
      <div class=\"modal-body\">
\t\t<div class=\"col-lg-12\">
\t\t\t<div class=\"form-group\">
\t\t\t\t<label for=\"user_group_name\">User Group</label>
\t\t\t\t<input class=\"col-lg-12 form-control\" name=\"user_group_name\" id=\"user_group_name\" autocomplete=\"off\" required type=\"text\" value=\"\" />
\t\t\t</div>
\t\t</div>
\t  </div>
\t  <div style=\"clear:both;\"></div>
      <div class=\"modal-footer\">
\t\t<div class=\"col-lg-12\">
        <div>
\t\t\t<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
\t\t\t<button type=\"submit\" onclick=\"savevalue();\" class=\"btn btn-success\">Save</button>
\t\t</div>
\t\t</div>
\t  </div>
\t  </form>
    </div>
  </div>
</div>
";
        }
    }

    // line 176
    public function block_footer($context, array $blocks = array())
    {
        // line 177
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
<script type=\"text/javascript\">
";
        // line 180
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 181
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 185
            echo "\$(document).ready(function() {
    \$('#frm').bootstrapValidator();
    \$('#frmusergroupadd').bootstrapValidator();
\t\$( \"#pwd\" ).keyup(function() {
\t\tif ( \$('#pwd').val() == '' )
\t\t\t\$('#errpwd').show();
\t\telse
\t\t\t\$('#errpwd').hide();
\t});
});
function setvalueug()
{
\tvar ugrp = \$('#user_group_name').val();
\tif(ugrp == '' || ugrp == 'undefined' )
\t{
\t\t\$(\"div.modal-body .form-group\").addClass('has-error');
\t\t\$(\"div.modal-body .form-group small.help-block\").css('display','block');
\t\treturn false;
\t}
\telse
\t{
\t\tformfields = 'save_action=add_group&user_group_name='+ugrp;
\t\ttheurl = '/user.php'; 
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\twindow.location = self.location;
\t\t});
\t}
}
flagsubmit = false;
function setvalue()
{
\t\$('#user_group_name').val('');
}
function savevalue()
{
\tif ( \$('#user_group_name').val() != '' )
\t{
\t\tformfields = 'task=save&company_id=";
            // line 228
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "&user_group_name='+\$('#user_group_name').val();
\t\ttheurl = 'savegroup.php';
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\t\$('#user_group_id').html(data);
\t\t\t\$('#user_group_name').val('');
\t\t\t\$('#addusergroup').modal('hide');
\t\t});
\t}
}
";
        }
        // line 244
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "user.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  403 => 244,  384 => 228,  339 => 185,  333 => 181,  331 => 180,  324 => 177,  321 => 176,  272 => 131,  263 => 125,  253 => 118,  243 => 111,  233 => 104,  223 => 97,  210 => 89,  204 => 88,  198 => 87,  185 => 76,  181 => 74,  179 => 73,  169 => 66,  156 => 56,  148 => 50,  142 => 48,  140 => 47,  130 => 40,  121 => 34,  117 => 33,  113 => 32,  108 => 30,  104 => 29,  99 => 27,  95 => 26,  91 => 25,  87 => 24,  83 => 23,  79 => 22,  75 => 21,  65 => 13,  59 => 10,  55 => 9,  51 => 8,  47 => 7,  43 => 6,  39 => 5,  34 => 4,  32 => 3,  29 => 2,);
    }
}
