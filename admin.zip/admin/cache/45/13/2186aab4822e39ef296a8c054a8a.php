<?php

/* statistics-charts.html */
class __TwigTemplate_45132186aab4822e39ef296a8c054a8a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "\t<div class=\"col-xs-12\">
\t\t<div class=\"tab-content\">
\t\t\t\t  <!-- Nav tabs -->
\t\t\t\t  <ul class=\"nav nav-tabs pane-nav-tabs\" role=\"tablist\">
\t\t\t\t  
\t\t\t\t\t";
        // line 8
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "customers"));
        foreach ($context['_seq'] as $context["key"] => $context["row"]) {
            // line 9
            echo "\t\t\t\t\t\t";
            $context["active"] = "";
            // line 10
            echo "\t\t\t\t\t\t";
            if (((isset($context["key"]) ? $context["key"] : null) == 0)) {
                // line 11
                echo "\t\t\t\t\t\t\t";
                $context["active"] = "active";
                // line 12
                echo "\t\t\t\t\t\t";
            }
            echo "\t
\t\t\t\t\t\t<li role=\"presentation\" class=\"fixed_width ";
            // line 13
            echo twig_escape_filter($this->env, (isset($context["active"]) ? $context["active"] : null), "html", null, true);
            echo "\"><a href=\"#customer_";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "\" aria-controls=\"home\" role=\"tab\" data-toggle=\"tab\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
            echo "</a></li>
\t\t\t\t\t
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 16
        echo "\t\t\t\t  </ul>
\t\t\t\t
\t\t\t\t\t  <!-- Tab panes starts here -->
\t\t\t\t\t  <div class=\"tab-content\">
\t\t\t\t\t\t";
        // line 20
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "customers"));
        foreach ($context['_seq'] as $context["key"] => $context["row"]) {
            // line 21
            echo "\t\t\t\t\t\t\t";
            $context["active"] = "in-active";
            // line 22
            echo "\t\t\t\t\t\t\t";
            if (((isset($context["key"]) ? $context["key"] : null) == 0)) {
                // line 23
                echo "\t\t\t\t\t\t\t\t";
                $context["active"] = "active";
                // line 24
                echo "\t\t\t\t\t\t\t";
            }
            // line 25
            echo "\t\t\t\t\t\t\t<div role=\"tabpanel\" class=\"tab-pane ";
            echo twig_escape_filter($this->env, (isset($context["active"]) ? $context["active"] : null), "html", null, true);
            echo "\" id=\"customer_";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"table-header navbar mold-corner\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-signal\"></i>
\t\t\t\t\t\t\t\t\t\t\t\tPriority - Company Name : <b>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
            echo "</b>, Assessment Type : <b> ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "merchant_type"), "html", null, true);
            echo " </b>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-7\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"panel panel-primary\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t\t\t\t\t\tAudit Completion
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div id=\"audit_chart_";
            // line 40
            echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
            echo "\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-5\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"panel panel-primary\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t\t\t\t\t\tCompliance / Severity
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div id=\"priority_chart_";
            // line 51
            echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
            echo "\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<!-- 
\t\t\t\t\t\t\t<div class=\"hide-link c2\">&nbsp;&nbsp;</div>
\t\t\t\t\t\t\t<div class=\"hide-link c1\">&nbsp;&nbsp;</div> -->
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 62
        echo "  
\t\t\t\t\t <!-- Tab panes ends here -->\t  
\t\t\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    // line 68
    public function block_footer($context, array $blocks = array())
    {
        // line 69
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
<script src=\"/assets/js/list.js\"></script>
<script src=\"/assets/js/highcharts/highcharts.js\"></script>
<script src=\"/assets/js/highcharts/highcharts-more.js\"></script>
<style type=\"text/css\">
#chart1 {
  width: 500px;
  height: 348x;
  margin: -10px auto 0 auto;
}
div.hide-link {
    background-color: #FF0000;
    left: 72%;
    margin-bottom: -7px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 1px;
    position: absolute;
    top: 92%;
    width: 160px;
    height: 15%;
}
div.mold-corner  {
  border-top-left-radius: 3px !important;
  border-top-right-radius: 3px !important;
  border-bottom-left-radius: 3px !important;
  border-bottom-right-radius: 3px !important;
  margin : 4px 0 8px 0;
}
div.tab-pane {
\tpadding:4px;
}
ul.pane-nav-tabs{
    list-style-type:none;
    white-space:nowrap;
}
li.fixed_width {
\twidth: 16% !important;
\tdisplay:inline !important;
}
ul.pane-nav-tabs > li.active {
\tbackground-color: hsl(208, 57%, 40%) !important;
}
ul.pane-nav-tabs > a :hover {
\tbackground-color: #FFF !important;
}
</style>
<script type=\"text/javascript\">
\$(document).ready(function(){
\t";
        // line 118
        $context["no"] = 0;
        // line 119
        echo "\t";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "controls"));
        foreach ($context['_seq'] as $context["key"] => $context["controls"]) {
            // line 120
            echo "\t\t";
            $context["s1"] = $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "s1"), "key");
            // line 121
            echo "\t\t
\t\t\t  \$(function () {
\t\t\t\t\$('#audit_chart_";
            // line 123
            echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
            echo "').highcharts({
\t\t\t\t\tchart: {
\t\t\t\t\t\ttype: 'bubble',
\t\t\t\t\t\tplotBorderWidth: 1,
\t\t\t\t\t\tzoomType: 'xy'
\t\t\t\t\t},

\t\t\t\t\ttitle: {
\t\t\t\t\t\ttext: ''
\t\t\t\t\t},

\t\t\t\t\txAxis: {
\t\t\t\t\t\t title: {text: 'Requirements'},    
\t\t\t\t\t\tgridLineWidth: 1
\t\t\t\t\t},

\t\t\t\t\tyAxis: {
\t\t\t\t\t\ttitle: {text: ''},   
\t\t\t\t\t\tstartOnTick: false,
\t\t\t\t\t\tendOnTick: false
\t\t\t\t\t},
\t\t\t\t\ttooltip: {
\t\t\t\t\t\tformatter: function() {
\t\t\t\t\t\t\treturn ' <b> ' + this.y + '</b> Procedures '+ this.series.name+' of Requirement #'+this.x;
\t\t\t\t\t\t}
\t\t\t\t\t},
\t\t\t\t\tseries: [{
\t\t\t\t\t\tname:'Y',
\t\t\t\t\t\tdata: [
\t\t\t\t\t\t\t";
            // line 152
            $context["i"] = 1;
            echo " 
\t\t\t\t\t\t\t";
            // line 153
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["controls"]) ? $context["controls"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["req"]) {
                // line 154
                echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
                // line 155
                if (((isset($context["i"]) ? $context["i"] : null) < 12)) {
                    // line 156
                    echo "\t\t\t\t\t\t\t\t\t[";
                    echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "Y"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "Y"), "html", null, true);
                    echo "],
\t\t\t\t\t\t\t\t";
                } else {
                    // line 158
                    echo "\t\t\t\t\t\t\t\t\t[";
                    echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "Y"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "Y"), "html", null, true);
                    echo "]
\t\t\t\t\t\t\t\t";
                }
                // line 160
                echo "\t\t\t\t\t\t\t\t";
                $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
                echo " 
\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['req'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 162
            echo "\t\t\t\t\t\t],
\t\t\t\t\t\tmarker: {
\t\t\t\t\t\t\tfillColor: {
\t\t\t\t\t\t\t\tradialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
\t\t\t\t\t\t\t\tstops: [
\t\t\t\t\t\t\t\t\t[0, 'rgba(59,201,34,0.5)'],
\t\t\t\t\t\t\t\t\t[1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0.5).get('rgba')]
\t\t\t\t\t\t\t\t]
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t}, {
\t\t\t\t\t\tname:'N',\t\t\t\t\t
\t\t\t\t\t\tdata: [
\t\t\t\t\t\t\t";
            // line 175
            $context["i"] = 1;
            echo " 
\t\t\t\t\t\t\t";
            // line 176
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["controls"]) ? $context["controls"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["req"]) {
                // line 177
                echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
                // line 178
                if (((isset($context["i"]) ? $context["i"] : null) < 12)) {
                    // line 179
                    echo "\t\t\t\t\t\t\t\t\t[";
                    echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "N"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "N"), "html", null, true);
                    echo "],
\t\t\t\t\t\t\t\t";
                } else {
                    // line 181
                    echo "\t\t\t\t\t\t\t\t\t[";
                    echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "N"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "N"), "html", null, true);
                    echo "]
\t\t\t\t\t\t\t\t";
                }
                // line 183
                echo "\t\t\t\t\t\t\t\t";
                $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
                echo " 
\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['req'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 185
            echo "\t\t\t\t\t\t],
\t\t\t\t\t\tmarker: {
\t\t\t\t\t\t\tfillColor: {
\t\t\t\t\t\t\t\tradialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
\t\t\t\t\t\t\t\tstops: [
\t\t\t\t\t\t\t\t\t[0, 'rgba(201,34,59,0.5)'],
\t\t\t\t\t\t\t\t\t[1, Highcharts.Color(Highcharts.getOptions().colors[1]).setOpacity(0.5).get('rgba')]
\t\t\t\t\t\t\t\t]
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t},{
\t\t\t\t\t\tname:'CCW',\t\t\t\t\t
\t\t\t\t\t\tdata: [
\t\t\t\t\t\t\t";
            // line 198
            $context["i"] = 1;
            echo " 
\t\t\t\t\t\t\t";
            // line 199
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["controls"]) ? $context["controls"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["req"]) {
                // line 200
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["req"]) ? $context["req"] : null), "C") > 0)) {
                    // line 201
                    echo "\t\t\t\t\t\t\t\t\t";
                    if (((isset($context["i"]) ? $context["i"] : null) < 12)) {
                        // line 202
                        echo "\t\t\t\t\t\t\t\t\t\t[";
                        echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "C"), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "C"), "html", null, true);
                        echo "],
\t\t\t\t\t\t\t\t\t";
                    } else {
                        // line 204
                        echo "\t\t\t\t\t\t\t\t\t\t[";
                        echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "C"), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "C"), "html", null, true);
                        echo "]
\t\t\t\t\t\t\t\t\t";
                    }
                    // line 206
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 207
                echo "\t\t\t\t\t\t\t\t";
                $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
                echo " 
\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['req'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 209
            echo "\t\t\t\t\t\t],
\t\t\t\t\t\tmarker: {
\t\t\t\t\t\t\tfillColor: {
\t\t\t\t\t\t\t\tradialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
\t\t\t\t\t\t\t\tstops: [
\t\t\t\t\t\t\t\t\t[0, 'rgba(34,59,201,0.5)'],
\t\t\t\t\t\t\t\t\t[1, Highcharts.Color(Highcharts.getOptions().colors[1]).setOpacity(0.5).get('rgba')]
\t\t\t\t\t\t\t\t]
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t},{
\t\t\t\t\t\tname:'NT',\t\t\t\t\t
\t\t\t\t\t\tdata: [
\t\t\t\t\t\t\t";
            // line 222
            $context["i"] = 1;
            echo " 
\t\t\t\t\t\t\t";
            // line 223
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["controls"]) ? $context["controls"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["req"]) {
                // line 224
                echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
                // line 225
                if (((isset($context["i"]) ? $context["i"] : null) < 12)) {
                    // line 226
                    echo "\t\t\t\t\t\t\t\t\t[";
                    echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NT"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NT"), "html", null, true);
                    echo "],
\t\t\t\t\t\t\t\t";
                } else {
                    // line 228
                    echo "\t\t\t\t\t\t\t\t\t[";
                    echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NT"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NT"), "html", null, true);
                    echo "]
\t\t\t\t\t\t\t\t";
                }
                // line 230
                echo "\t\t\t\t\t\t\t\t";
                $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
                echo " 
\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['req'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 232
            echo "\t\t\t\t\t\t],
\t\t\t\t\t\tmarker: {
\t\t\t\t\t\t\tfillColor: {
\t\t\t\t\t\t\t\tradialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
\t\t\t\t\t\t\t\tstops: [
\t\t\t\t\t\t\t\t\t[0, 'rgba(124,181,236,0.5)'],
\t\t\t\t\t\t\t\t\t[1, Highcharts.Color(Highcharts.getOptions().colors[1]).setOpacity(0.5).get('rgba')]
\t\t\t\t\t\t\t\t]
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t},{
\t\t\t\t\t\tname:'NA',\t\t\t\t\t
\t\t\t\t\t\tdata: [
\t\t\t\t\t\t\t";
            // line 245
            $context["i"] = 1;
            echo " 
\t\t\t\t\t\t\t";
            // line 246
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["controls"]) ? $context["controls"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["req"]) {
                // line 247
                echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
                // line 248
                if (($this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NA") > 0)) {
                    // line 249
                    echo "\t\t\t\t\t\t\t\t";
                    if (((isset($context["i"]) ? $context["i"] : null) < 12)) {
                        // line 250
                        echo "\t\t\t\t\t\t\t\t\t[";
                        echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NA"), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NA"), "html", null, true);
                        echo "],
\t\t\t\t\t\t\t\t";
                    } else {
                        // line 252
                        echo "\t\t\t\t\t\t\t\t\t[";
                        echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NA"), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["req"]) ? $context["req"] : null), "NA"), "html", null, true);
                        echo "]
\t\t\t\t\t\t\t\t";
                    }
                    // line 254
                    echo "\t\t\t\t\t\t\t\t";
                    $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
                    echo " 
\t\t\t\t\t\t\t\t";
                }
                // line 256
                echo "\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['req'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 257
            echo "\t\t\t\t\t\t],
\t\t\t\t\t\tmarker: {
\t\t\t\t\t\t\tfillColor: {
\t\t\t\t\t\t\t\tradialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
\t\t\t\t\t\t\t\tstops: [
\t\t\t\t\t\t\t\t\t[0, 'rgba(105,105,255,0.5)'],
\t\t\t\t\t\t\t\t\t[1, Highcharts.Color(Highcharts.getOptions().colors[1]).setOpacity(0.5).get('rgba')]
\t\t\t\t\t\t\t\t]
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t},]

\t\t\t\t});
\t\t\t});
\t";
            // line 271
            $context["no"] = ((isset($context["no"]) ? $context["no"] : null) + 1);
            // line 272
            echo "\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['controls'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        echo "\t
\t";
        // line 273
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "label2"));
        foreach ($context['_seq'] as $context["key"] => $context["label2"]) {
            // line 274
            echo "\t\t\$(function () {
\t\t\t\$('#priority_chart_";
            // line 275
            echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
            echo "').highcharts({
\t\t\t\tchart: {
\t\t\t\t\ttype: 'bar'
\t\t\t\t},
\t\t\t\ttitle: {
\t\t\t\t\ttext: ''
\t\t\t\t},
\t\t\t\txAxis: {
\t\t\t\t\tcategories: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']
\t\t\t\t},
\t\t\t\tyAxis: {
\t\t\t\t\tmin: 0,
\t\t\t\t\ttitle: {
\t\t\t\t\t\ttext: ''
\t\t\t\t\t}
\t\t\t\t},
\t\t\t\ttooltip: {
\t\t\t\tformatter: function() {
\t\t\t\t\treturn ' Completed <b> '+this.y+' % </b> of Requirement #'+ this.x;
\t\t\t\t}
\t\t\t},
\t\t\t\tlegend: {
\t\t\t\t\treversed: true
\t\t\t\t},
\t\t\t\tplotOptions: {
\t\t\t\t\tseries: {
\t\t\t\t\t\tstacking: 'normal'
\t\t\t\t\t}
\t\t\t\t},
\t\t\t\tseries: [{
\t\t\t\t\tname: 'Completed',
\t\t\t\t\t//data: [5, 3, 4, 7, 2, 1, 1, 1, 1, 1, 1, 1]
\t\t\t\t\tdata: [";
            // line 307
            echo (isset($context["label2"]) ? $context["label2"] : null);
            echo "],
\t\t\t\t\tpointWidth: 28
\t\t\t\t}]
\t\t\t});
\t\t});

\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['label2'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 314
        echo "
});

</script>
";
    }

    public function getTemplateName()
    {
        return "statistics-charts.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  622 => 314,  609 => 307,  574 => 275,  571 => 274,  567 => 273,  559 => 272,  557 => 271,  541 => 257,  535 => 256,  529 => 254,  519 => 252,  509 => 250,  506 => 249,  504 => 248,  501 => 247,  497 => 246,  493 => 245,  478 => 232,  469 => 230,  459 => 228,  449 => 226,  447 => 225,  444 => 224,  440 => 223,  436 => 222,  421 => 209,  412 => 207,  409 => 206,  399 => 204,  389 => 202,  386 => 201,  383 => 200,  379 => 199,  375 => 198,  360 => 185,  351 => 183,  341 => 181,  331 => 179,  329 => 178,  326 => 177,  322 => 176,  318 => 175,  303 => 162,  294 => 160,  284 => 158,  274 => 156,  272 => 155,  269 => 154,  265 => 153,  261 => 152,  229 => 123,  225 => 121,  222 => 120,  217 => 119,  215 => 118,  162 => 69,  159 => 68,  150 => 62,  132 => 51,  118 => 40,  104 => 31,  92 => 25,  89 => 24,  86 => 23,  83 => 22,  80 => 21,  76 => 20,  70 => 16,  57 => 13,  52 => 12,  49 => 11,  46 => 10,  43 => 9,  39 => 8,  32 => 3,  29 => 2,);
    }
}
