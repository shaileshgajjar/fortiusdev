<?php

/* _header.html */
class __TwigTemplate_e109320c2208e5e4911af59097cd918e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t\t<!-- #section:basics/navbar.layout -->
\t\t<div id=\"navbar\" class=\"navbar navbar-default navbar-collapse h-navbar navbar-fixed-top\">
\t\t\t<div class=\"navbar-container\" id=\"navbar-container\">
\t\t\t\t<div class=\"navbar-header pull-left\">
\t\t\t\t\t<!-- #section:basics/navbar.layout.brand -->
\t\t\t\t\t<a href=\"/admin/dashboard.php\" class=\"navbar-brand\">
\t\t\t\t\t\t<small>
\t\t\t\t\t\t\t<i class=\"fa fa-lock\"></i>
\t\t\t\t\t\t\tSecurity Admin
\t\t\t\t\t\t</small>
\t\t\t\t\t</a>

\t\t\t\t\t<!-- /section:basics/navbar.layout.brand -->

\t\t\t\t\t<!-- #section:basics/navbar.toggle -->
\t\t\t\t\t<button class=\"pull-right navbar-toggle navbar-toggle-img collapsed\" type=\"button\" data-toggle=\"collapse\" data-target=\".navbar-buttons,.navbar-menu\">
\t\t\t\t\t\t<span class=\"sr-only\">Toggle user menu</span>
\t\t\t\t\t\t\t";
        // line 18
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "users_avtar"), "value") != "")) {
            // line 19
            echo "\t\t\t\t\t\t\t\t<img id=\"mobprofilepic\" src=\"/uploads/avtars/";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "users_avtar"), "value"), "html", null, true);
            echo "\" alt=\"Avtar\" title=\"Avtar\" />
\t\t\t\t\t\t\t";
        } else {
            // line 21
            echo "\t\t\t\t\t\t\t\t<img id=\"mobprofilepic\" src=\"/assets/avatars/avatar4.png\" alt=\"Avtar\" title=\"Avtar\" />
\t\t\t\t\t\t\t";
        }
        // line 23
        echo "\t\t\t\t\t</button>

\t\t\t\t\t<button class=\"pull-right navbar-toggle collapsed\" type=\"button\" data-toggle=\"collapse\" data-target=\"#sidebar\">
\t\t\t\t\t\t<span class=\"sr-only\">Toggle sidebar</span>

\t\t\t\t\t\t<span class=\"icon-bar\"></span>

\t\t\t\t\t\t<span class=\"icon-bar\"></span>

\t\t\t\t\t\t<span class=\"icon-bar\"></span>
\t\t\t\t\t</button>

\t\t\t\t\t<!-- /section:basics/navbar.toggle -->
\t\t\t\t</div>

\t\t\t\t<!-- #section:basics/navbar.dropdown -->
\t\t\t\t<div class=\"navbar-buttons navbar-header pull-right  collapse navbar-collapse\" role=\"navigation\">
\t\t\t\t\t<ul class=\"nav ace-nav\">
\t\t\t\t\t\t<!-- #section:basics/navbar.user_menu -->
\t\t\t\t\t\t<li class=\"light-blue user-min\">
\t\t\t\t\t\t\t<a data-toggle=\"dropdown\" href=\"#\" class=\"dropdown-toggle\">
\t\t\t\t\t\t\t\t";
        // line 44
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "users_avtar"), "value") != "")) {
            // line 45
            echo "\t\t\t\t\t\t\t\t\t\t<img id=\"profilepic\" class=\"nav-user-photo\" src=\"/../../uploads/avtars/";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "profile"), "users_avtar"), "value"), "html", null, true);
            echo "\" alt=\"Avtar\" title=\"Avtar\" />
\t\t\t\t\t\t\t\t";
        } else {
            // line 47
            echo "\t\t\t\t\t\t\t\t\t\t<img id=\"profilepic\" class=\"nav-user-photo\" src=\"/assets/avatars/avatar4.png\" alt=\"Avtar\" title=\"Avtar\" />
\t\t\t\t\t\t\t\t";
        }
        // line 49
        echo "\t\t\t\t\t\t\t\t<span class=\"user-info\">
\t\t\t\t\t\t\t\t\t<small>Welcome,</small>
\t\t\t\t\t\t\t\t\t";
        // line 51
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "username"), "method"), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t</span>

\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-caret-down\"></i>
\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t<ul class=\"user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0);\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-globe\"></i>
\t\t\t\t\t\t\t\t\t\t";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "get_remote", array(), "method"), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t<li class=\"divider\"></li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"/admin/sendReport.php\" target=\"_blank\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-clock-o\"></i>
\t\t\t\t\t\t\t\t\t\tSend Notification
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"/admin/sendReminder.php\" target=\"_blank\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-clock-o\"></i>
\t\t\t\t\t\t\t\t\t\tSend Reminder
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"/admin/login_history.php\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-clock-o\"></i>
\t\t\t\t\t\t\t\t\t\tLogs
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\" data-toggle=\"modal\" data-target=\"#settings\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-cog\"></i>
\t\t\t\t\t\t\t\t\t\tSettings
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\" data-toggle=\"modal\" data-target=\"#profile\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-user\"></i>
\t\t\t\t\t\t\t\t\t\tProfile
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\" data-toggle=\"modal\" data-target=\"#upload_avtar\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-user\"></i>
\t\t\t\t\t\t\t\t\t\tChange Profile Picture
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t<li class=\"divider\"></li>

\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"/admin/logout.php\">
\t\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-power-off\"></i>
\t\t\t\t\t\t\t\t\t\tLogout
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</li>

\t\t\t\t\t\t<!-- /section:basics/navbar.user_menu -->
\t\t\t\t\t</ul>
\t\t\t\t</div>

\t\t\t</div><!-- /.navbar-container -->
\t\t</div>
\t\t<!-- /section:basics/navbar.layout -->
";
    }

    public function getTemplateName()
    {
        return "_header.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 61,  73 => 44,  50 => 23,  46 => 21,  40 => 19,  38 => 18,  19 => 1,  164 => 85,  161 => 84,  156 => 73,  106 => 4,  100 => 114,  94 => 112,  91 => 111,  85 => 49,  83 => 81,  74 => 74,  58 => 64,  54 => 62,  52 => 61,  44 => 55,  42 => 54,  37 => 51,  35 => 50,  27 => 4,  22 => 1,  152 => 58,  149 => 57,  145 => 55,  138 => 50,  129 => 47,  125 => 46,  121 => 45,  117 => 44,  113 => 7,  109 => 5,  105 => 41,  101 => 40,  97 => 113,  89 => 51,  84 => 37,  81 => 47,  78 => 35,  75 => 45,  72 => 73,  70 => 32,  64 => 67,  60 => 29,  32 => 3,  29 => 46,);
    }
}
