<?php

/* _side-bar.html */
class __TwigTemplate_9ac6bb7d01736844433db94563d3170f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t\t\t<!-- #section:basics/sidebar.horizontal -->
\t\t\t<div id=\"sidebar\" class=\"sidebar h-sidebar navbar-collapse collapse sidebar-fixed\">

\t\t\t\t<div class=\"sidebar-shortcuts\" id=\"sidebar-shortcuts\">
\t\t\t\t\t<div class=\"sidebar-shortcuts-large\" id=\"sidebar-shortcuts-large\">
\t\t\t\t\t\t<!-- #section:basics/sidebar.layout.shortcuts -->
\t\t\t\t\t\t<a href=\"/admin/sendReport.php\" target=\"_blank\" class=\"btn btn-success\" title=\"Send Notification\">
\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-bullhorn\"></i>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<a href=\"/admin/login_history.php\"  class=\"btn btn-success\" title=\"Logs\">
\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-signal\"></i>\t\t
\t\t\t\t\t\t</a>

\t\t\t\t\t\t<button class=\"btn btn-info\" data-toggle=\"modal\" data-target=\"#profile\" title=\"Edit Profile\">
\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-pencil\"> </i>
\t\t\t\t\t\t</button>

\t\t\t\t\t\t

\t\t\t\t\t\t<button class=\"btn btn-danger\" data-toggle=\"modal\" data-target=\"#settings\" title=\"Settings\">
\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-cogs\"></i>
\t\t\t\t\t\t</button>

\t\t\t\t\t\t<!-- /section:basics/sidebar.layout.shortcuts -->
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"sidebar-shortcuts-mini\" id=\"sidebar-shortcuts-mini\">
\t\t\t\t\t\t<span class=\"btn btn-success\"></span>

\t\t\t\t\t\t<span class=\"btn btn-info\"></span>

\t\t\t\t\t\t<span class=\"btn btn-warning\"></span>

\t\t\t\t\t\t<span class=\"btn btn-danger\"></span>
\t\t\t\t\t</div>
\t\t\t\t</div><!-- /.sidebar-shortcuts -->

\t\t\t\t<ul class=\"nav nav-list\">
\t\t\t\t\t<li class=\"hover";
        // line 39
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "dashboard")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t<a href=\"/admin/dashboard.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-tachometer\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Dashboard </span>
\t\t\t\t\t\t</a>

\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t</li>

\t\t\t\t\t<li class=\"hover";
        // line 48
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "masters")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t<a href=\"#\" class=\"dropdown-toggle\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-desktop\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\">
\t\t\t\t\t\t\t\tMaster
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>

\t\t\t\t\t\t<b class=\"arrow\"></b>

\t\t\t\t\t\t<ul class=\"submenu\">
\t\t\t\t\t\t\t<li class=\"hover";
        // line 60
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "admins")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"/admin/admins.php\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tSuper Admin
\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<li class=\"hover";
        // line 69
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "login_history")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"/admin/login_history.php\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tLogin History
\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t<li class=\"hover";
        // line 78
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "assessment_types")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"/admin/assessment_types.php\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tAssessment Type
\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t<li class=\"hover";
        // line 87
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "requirements")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"dropdown-toggle\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tRequirements
\t\t\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t\t<ul class=\"submenu\">
\t\t\t\t\t\t\t\t\t<li class=\"hover";
        // line 95
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "endpage") == "rroc")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t\t\t<a href=\"/admin/roc_requirements.php\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\t\t\tROC
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"hover";
        // line 102
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "endpage") == "rsaq")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t\t\t<a href=\"/admin/saq_requirements.php\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\t\t\tSAQ
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t<li class=\"hover";
        // line 112
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "sub_requirements")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"dropdown-toggle\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tSub Requirements
\t\t\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t\t<ul class=\"submenu\">
\t\t\t\t\t\t\t\t\t<li class=\"hover";
        // line 120
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "endpage") == "sroc")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t\t\t<a href=\"/admin/roc_sub_requirements.php\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\t\t\tROC
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"hover";
        // line 127
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "endpage") == "ssaq")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t\t\t<a href=\"/admin/saq_sub_requirements.php\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\t\t\tSAQ
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t<li class=\"hover";
        // line 137
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "procedures")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"dropdown-toggle\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tProcedure
\t\t\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t\t<ul class=\"submenu\">
\t\t\t\t\t\t\t\t\t<li class=\"hover";
        // line 145
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "endpage") == "proc")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t\t\t<a href=\"/admin/roc_procedures.php\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\t\t\tROC
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"hover";
        // line 152
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "endpage") == "psaq")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t\t\t<a href=\"/admin/saq_procedures.php\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\t\t\tSAQ
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<li class=\"hover";
        // line 162
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "reporting")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"/admin/roc_reportings.php\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tReporting ROC
\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t<li class=\"hover";
        // line 171
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "assessors")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"/admin/assessors.php\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tAssessors
\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<li class=\"hover";
        // line 180
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "merchant")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"/admin/merchants.php\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tMerchants
\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t<li class=\"hover";
        // line 189
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "customers")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"/admin/customers.php\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tCustomers
\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t<li class=\"hover";
        // line 198
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "usergroups")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"/admin/usergroups.php\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tUser Groups
\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"hover";
        // line 206
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "subpage") == "users")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t\t\t<a href=\"/admin/users.php\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-caret-right\"></i>
\t\t\t\t\t\t\t\t\tUsers
\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t<b class=\"arrow\"></b>
\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t</ul>
\t\t\t\t\t</li>

\t\t\t\t\t<li class=\"hover";
        // line 218
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "inputs")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t<a href=\"/admin/list-data.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-pencil-square-o\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Data Inputs </span>

\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>

\t\t\t\t\t\t<b class=\"arrow\"></b>

\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"hover";
        // line 229
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") == "statistics-charts")) {
            echo " active";
        }
        echo "\">
\t\t\t\t\t\t<a href=\"/admin/statistics-charts.php\">
\t\t\t\t\t\t\t<i class=\"menu-icon fa fa-signal\"></i>
\t\t\t\t\t\t\t<span class=\"menu-text\"> Statistics </span>

\t\t\t\t\t\t\t<b class=\"arrow fa fa-angle-down\"></b>
\t\t\t\t\t\t</a>

\t\t\t\t\t\t<b class=\"arrow\"></b>

\t\t\t\t\t</li>

\t\t\t\t</ul><!-- /.nav-list -->

\t\t\t</div>
\t\t\t<!-- /section:basics/sidebar.horizontal -->
";
    }

    public function getTemplateName()
    {
        return "_side-bar.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  354 => 229,  338 => 218,  321 => 206,  308 => 198,  294 => 189,  280 => 180,  266 => 171,  252 => 162,  237 => 152,  225 => 145,  212 => 137,  197 => 127,  185 => 120,  172 => 112,  157 => 102,  132 => 87,  118 => 78,  104 => 69,  90 => 60,  59 => 39,  102 => 61,  73 => 48,  50 => 23,  46 => 21,  40 => 19,  38 => 18,  19 => 1,  164 => 85,  161 => 84,  156 => 73,  106 => 4,  100 => 114,  94 => 112,  91 => 111,  85 => 49,  83 => 81,  74 => 74,  58 => 64,  54 => 62,  52 => 61,  44 => 55,  42 => 54,  37 => 51,  35 => 50,  27 => 4,  22 => 1,  152 => 58,  149 => 57,  145 => 95,  138 => 50,  129 => 47,  125 => 46,  121 => 45,  117 => 44,  113 => 7,  109 => 5,  105 => 41,  101 => 40,  97 => 113,  89 => 51,  84 => 37,  81 => 47,  78 => 35,  75 => 45,  72 => 73,  70 => 32,  64 => 67,  60 => 29,  32 => 3,  29 => 46,);
    }
}
