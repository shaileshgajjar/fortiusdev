<?php

/* _new-panel.html */
class __TwigTemplate_e225b950b51417f3cbfd09b1f1c6c3cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t\t<div class=\"widget-box widget-color-blue\">
\t\t\t<!-- #section:custom/widget-box.options -->
\t\t\t<div class=\"widget-header\">
\t\t\t\t<h5 class=\"widget-title smaller lighter\">
\t\t\t\t\t<i class=\"ace-icon fa fa-table\"></i>
\t\t\t\t\t";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
        echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rectitle");
        echo "
\t\t\t\t\t";
        // line 7
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "addbtnshow") == "1")) {
            // line 8
            echo "\t\t\t\t\t<div class=\"pull-right add-btn\"><button type=\"button\" title=\"New\" class=\"btn btn-success btn-xs\" onclick=\"edit('0', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "editscript"), "html", null, true);
            echo "');\"><span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\"></span></button></div>
\t\t\t\t\t";
        }
        // line 10
        echo "\t\t\t\t\t
\t\t\t\t</h5>
\t\t\t</div>

\t\t\t<!-- /section:custom/widget-box.options -->
\t\t\t<div class=\"widget-body\">
\t\t\t\t<div class=\"widget-main\">
\t\t\t\t\t";
        // line 17
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "enableversion") == "1")) {
            // line 18
            echo "\t\t\t\t\t<div class=\"col-lg-2 col-sm-2\">
\t\t\t\t\t\t<h3 class=\"block_title\"> Version:</h3>
\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t<select id=\"version\" name=\"version\" class=\"\">
\t\t\t\t\t\t\t\t<option value=\"v31_\"";
            // line 22
            if (("v31_" == $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "version"))) {
                echo " selected=\"selected\"";
            }
            echo "> 3.1</option>
\t\t\t\t\t\t\t\t<option value=\"v32_\"";
            // line 23
            if (("v32_" == $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "version"))) {
                echo " selected=\"selected\"";
            }
            echo "> 3.2</option>
\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 28
        echo "\t\t\t\t\t<div class=\"col-lg-3 col-sm-4\">
\t\t\t\t\t\t<h3 class=\"block_title\">Search By :</h3>
\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t<select id=\"searchby\" name=\"sb\" class=\"selectpicker\">
\t\t\t\t\t\t\t\t";
        // line 32
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "search"));
        foreach ($context['_seq'] as $context["key"] => $context["title"]) {
            // line 33
            echo "\t\t\t\t\t\t\t\t\t<option value=\"";
            echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
            echo "\"";
            if (((isset($context["key"]) ? $context["key"] : null) == $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"))) {
                echo " selected=\"selected\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, (isset($context["title"]) ? $context["title"] : null), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['title'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 35
        echo "\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-lg-3 col-sm-6\">
\t\t\t\t\t\t<h3 class=\"block_title\">Search For :</h3>
\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t  <input type=\"text\" class=\"form-control\" id=\"searchfor\" placeholder=\"Enter Your Keywords\" name=\"sk\" value=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
        echo "\" />
\t\t\t\t\t\t  <span class=\"input-group-btn\">
\t\t\t\t\t\t\t<button class=\"btn btn-primary btn-sm\" type=\"submit\">GO</button>
\t\t\t\t\t\t  </span>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t
\t\t\t\t\t<div class=\"col-lg-2 col-sm-6\">
\t\t\t\t\t\t<div class=\"\">
\t\t\t\t\t\t\t<h3 class=\"block_title\">Page Entry :</h3>
\t\t\t\t\t\t\t<div class=\"block_part3_right\">
\t\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t\t<select id=\"en\" class=\"selectpicker\" name=\"en\" onchange=\"this.form.submit();\">
\t\t\t\t\t\t\t\t\t\t<option value=\"10\"";
        // line 54
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en") == 10)) {
            echo " selected=\"selected\"";
        }
        echo ">10</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"25\"";
        // line 55
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en") == 25)) {
            echo " selected=\"selected\"";
        }
        echo ">25</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"50\"";
        // line 56
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en") == 50)) {
            echo " selected=\"selected\"";
        }
        echo ">50</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"100\"";
        // line 57
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en") == 100)) {
            echo " selected=\"selected\"";
        }
        echo ">100</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"0\"";
        // line 58
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en") == 0)) {
            echo " selected=\"selected\"";
        }
        echo ">All</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-lg-2 col-sm-6\">
\t\t\t\t\t\t<div class=\"\">
\t\t\t\t\t\t\t<h3 class=\"block_title\">Page :</h3>
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<select id=\"pg\" class=\"selectpicker\" name=\"pg\" onchange=\"this.form.submit();\">
\t\t\t\t\t\t\t\t\t";
        // line 69
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(1, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "total_pages")));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 70
            echo "\t\t\t\t\t\t\t\t\t\t<option value=";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            if (((isset($context["i"]) ? $context["i"] : null) == $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"))) {
                echo " selected=\"selected\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 72
        echo "\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div> 
\t\t\t\t\t<div style=\"clear:both;\"></div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<!-- Panel -->
";
    }

    public function getTemplateName()
    {
        return "_new-panel.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 70,  161 => 69,  145 => 58,  139 => 57,  133 => 56,  127 => 55,  121 => 54,  105 => 41,  97 => 35,  82 => 33,  78 => 32,  72 => 28,  62 => 23,  56 => 22,  50 => 18,  48 => 17,  39 => 10,  33 => 8,  31 => 7,  26 => 6,  19 => 1,  269 => 107,  266 => 106,  236 => 79,  230 => 75,  227 => 74,  217 => 70,  213 => 69,  209 => 68,  205 => 66,  195 => 64,  188 => 62,  181 => 61,  179 => 72,  174 => 58,  170 => 57,  166 => 56,  162 => 55,  158 => 54,  154 => 53,  150 => 52,  146 => 51,  142 => 50,  138 => 49,  131 => 45,  124 => 42,  120 => 41,  111 => 35,  107 => 34,  103 => 33,  99 => 32,  95 => 31,  91 => 30,  87 => 29,  83 => 28,  79 => 27,  75 => 26,  63 => 16,  59 => 15,  57 => 14,  54 => 13,  52 => 12,  46 => 9,  41 => 7,  37 => 6,  32 => 3,  29 => 2,);
    }
}
