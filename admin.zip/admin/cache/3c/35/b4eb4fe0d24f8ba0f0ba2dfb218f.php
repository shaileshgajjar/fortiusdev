<?php

/* assessment-environment-summary.html */
class __TwigTemplate_3c35b4eb4fe0d24f8ba0f0ba2dfb218f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 16
            echo "\t<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 35
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 36
            echo "      <!-- Tab panes -->
\t\t<div class=\"tab-content tab_border\">
\t\t\t<div role=\"tabpanel\" class=\"tab-pane active\" id=\"screen1\">
\t\t\t\t<div class=\"row new_field_block_part widget-box widget-color-blue\">
\t\t\t\t\t<div class=\"widget-header\">
\t\t\t\t\t\t<h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i>3 Description of SOW and Approach Taken</h4>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"widget-body\">
\t\t\t\t\t\t<div class=\"widget-main widget_main_extra_part\">
\t\t\t\t\t\t\t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">3.2 Cardholder Data Environment (CDE) overview </div>
\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t\tProvide anoverview of the cardholder data environment encompassing the people, processes, technologies, and locations (for example, client’s Internet access points, internal corporate network, processing connections).
\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group form_group_block\">
\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">People – such as technical support, management, administrators, operations teams, cashiers, telephone operators, etc:
\t\t\t\t\t\t\t\t<br><span class=\"label_note\"><b>Note:</b> this is not intended to be a list of individuals interviewed, but instead a list of the types of people, teams, etc. who were included in the scope<br></span>\t\t
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t  <textarea name=\"sow_people\"  id=\"sow_people\" class=\"form-control form_textarea_height\" rows=\"2\" >";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "sow_people"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t&nbsp;
\t\t\t\t\t\t</div>
\t\t\t\t\t   <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group form_group_block\">
\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">Processes - such as payment channels, business functions, etc:</label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t   <textarea name=\"sow_process\"  id=\"sow_process\" class=\"form-control form_textarea_height\" rows=\"2\" >";
            // line 69
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "sow_process"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t&nbsp;
\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group form_group_block\">
\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">Technologies:
\t\t\t\t\t\t\t\t<br><span class=\"label_note\"><b>Note:</b> this is not intended to be a list of devices but instead a list of the types of technologies, purposes, functions, etc. included in the scope<br></span>\t\t
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t <textarea name=\"sow_technologies\"  id=\"sow_technologies\" class=\"form-control form_textarea_height\" rows=\"2\" >";
            // line 84
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "sow_technologies"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t&nbsp;
\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group form_group_block\">
\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">Locations/sites/stores – such as retail outlets, data centers, corporate office locations, call centers, etc:</label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t <textarea name=\"sow_location_sites\"  id=\"sow_location_sites\" class=\"form-control form_textarea_height\" rows=\"2\"  >";
            // line 97
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "sow_location_sites"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group form_group_block\">
\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">Other details, if applicable :</label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t  <textarea name=\"sow_other_details\"  id=\"sow_other_details\" class=\"form-control form_textarea_height\" rows=\"2\" >";
            // line 107
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "sow_other_details"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<button class=\"btn btn-danger new_success pull-left\"  onclick=\"previous_step('";
            // line 112
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button> 
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</form>
</div>
";
        }
    }

    // line 123
    public function block_footer($context, array $blocks = array())
    {
        // line 124
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 132
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 133
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 137
            echo "\$(document).ready(function() {
    \$('#frm').bootstrapValidator();
});
";
        }
        // line 141
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "assessment-environment-summary.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  265 => 141,  259 => 137,  253 => 133,  251 => 132,  239 => 124,  236 => 123,  221 => 112,  213 => 107,  200 => 97,  184 => 84,  166 => 69,  150 => 56,  128 => 36,  126 => 35,  121 => 33,  117 => 32,  113 => 31,  109 => 30,  104 => 28,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  75 => 16,  69 => 13,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
