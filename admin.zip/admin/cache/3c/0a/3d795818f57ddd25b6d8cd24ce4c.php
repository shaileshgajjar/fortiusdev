<?php

/* front-fill-data.html */
class __TwigTemplate_3c0a3d795818f57ddd25b6d8cd24ce4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-front-layout.html");

        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-front-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_head($context, array $blocks = array())
    {
        // line 3
        echo "\t";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/chosen.css\" />
";
    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        // line 7
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save")) {
            // line 8
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t<input type=\"hidden\" name=\"requirements_id\" id=\"requirements_id\" value=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 18
            echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userrole\" id=\"userrole\" value=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"requirements_id\" id=\"requirements_id\" value=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id"), "html", null, true);
            echo "\" />
\t\t\t<div class=\"widget-box widget-color-blue\">
\t\t\t\t<!-- #section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-header\">
\t\t\t\t\t<h5 class=\"widget-title smaller lighter\">
\t\t\t\t\t\t<i class=\"ace-icon fa fa-edit\"></i>
\t\t\t\t\t\t";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
            echo " - Company Name : <b>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_name"), "html", null, true);
            echo "</b>, Assessment Type : <b>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "merchant_type"), "html", null, true);
            echo "</b>
\t\t\t\t\t</h5>
\t\t\t\t</div>
\t\t\t\t<!-- /section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-body\">
\t\t\t\t\t<div class=\"widget-main\">
\t\t\t\t\t\t<div id=\"sticky-anchor\"></div>
\t\t\t\t\t\t\t";
            // line 48
            if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") != "u") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") != "c"))) {
                // line 49
                echo "\t\t\t\t\t\t\t\t<div class=\"form-group\" id=\"sticky\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t<button type=\"button\" onclick=\"savedata('continue');\" class=\"btn btn-success\">Save &amp; Continue</button>
\t\t\t\t\t\t\t\t\t\t<button type=\"button\" onclick=\"savedata('save');\" class=\"btn btn-success\">Save &amp; Exit</button>
\t\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-danger\" onclick=\"this.form.action='";
                // line 53
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
                echo "'; this.form.submit();\">Cancel</button>\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t<div class=\"pull-right col-lg-3\">
\t\t\t\t\t\t\t\t\t\t\t<button type=\"button\" onclick=\"\$('#task').val(''); this.form.submit();\" class=\"pull-right btn btn-comments btn-xs btn-success  glyphicon glyphicon-search\" style=\" margin-left: 5px;  margin-top: 5px;padding-bottom: 4px; padding-left: 6px; padding-right: 8px; padding-top: 3px;\" title=\"Search\" ></button>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" style=\"width:86%; margin-top:5px;;\" autocomplete=\"off\" class=\"form-control\" placeholder=\"Search within requirement\" name=\"proc_req_search\" id=\"proc_req_search\" value=\"";
                // line 56
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "proc_req_search"), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t\t\t\t\t\t<select style=\"margin-top:5px;margin-left:5px;\" onchange=\"\$('#task').val(''); this.form.submit();\" name=\"inplace_filter\" id=\"inplace_filter\" class=\"form-control \">
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">Filter By</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"Y\"";
                // line 61
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "Y")) {
                    echo " selected=\"selected\"";
                }
                echo ">Y</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"N\"";
                // line 62
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "N")) {
                    echo " selected=\"selected\"";
                }
                echo ">N</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"C\"";
                // line 63
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "C")) {
                    echo " selected=\"selected\"";
                }
                echo ">C</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"NT\"";
                // line 64
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "NT")) {
                    echo " selected=\"selected\"";
                }
                echo ">NT</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"NA\"";
                // line 65
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "NA")) {
                    echo " selected=\"selected\"";
                }
                echo ">NA</option>
\t\t\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t";
                // line 68
                if (((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q")) || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "i"))) {
                    // line 69
                    echo "\t\t\t\t\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t\t\t\t\t<select style=\"margin-top:5px;\" onchange=\"\$('#task').val(''); this.form.submit();\" class=\"form-control pull-left\" name=\"filter_id\" id=\"filter_id\">
\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">Filter By</option>
\t\t\t\t\t\t\t\t\t\t\t";
                    // line 72
                    echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "filters");
                    echo "
\t\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t";
                }
                // line 76
                echo "\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
            } else {
                // line 80
                echo "\t\t\t\t\t\t\t\t<div class=\"form-group\" id=\"sticky\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-11\">
\t\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-info\" onclick=\"this.form.action='";
                // line 82
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
                echo "'; this.form.submit();\">Back</button>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            }
            // line 86
            echo "\t\t\t\t\t\t<div role=\"tabpanel\">

\t\t\t\t\t\t\t<!-- Nav tabs -->\t\t
\t\t\t\t\t\t\t<div id=\"security-inputs\">
\t\t\t\t\t\t\t<select name=\"requirements_id\" id=\"requirements_id\" class=\"form-control\" onchange=\"getcontent(this.value);\">
\t\t\t\t\t\t\t\t";
            // line 91
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements"));
            foreach ($context['_seq'] as $context["_key"] => $context["requirement"]) {
                // line 92
                echo "\t\t\t\t\t\t\t\t<option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\"";
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id") == $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"))) {
                    echo " selected=\"selected\"";
                }
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "rtitle"), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['requirement'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 94
            echo "\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- Nav tabs -->

\t\t\t\t\t\t\t<!-- Tab panes -->
\t\t\t\t\t\t\t<div class=\"tab-content\">
\t\t\t\t\t\t\t";
            // line 100
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["requirement"]) {
                // line 101
                echo "\t\t\t\t\t\t\t\t";
                $context["extra"] = "";
                // line 102
                echo "\t\t\t\t\t\t\t\t";
                $context["data"] = "n";
                // line 103
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id") == $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"))) {
                    // line 104
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["extra"] = " active";
                    // line 105
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["data"] = "y";
                    // line 106
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 107
                echo "\t\t\t\t\t\t\t\t<div role=\"tabpanel\" class=\"all-tabs tab-pane";
                echo twig_escape_filter($this->env, (isset($context["extra"]) ? $context["extra"] : null), "html", null, true);
                echo "\" id=\"tab";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" id=\"data";
                // line 108
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\" name=\"data";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, (isset($context["data"]) ? $context["data"] : null), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t<div id=\"req";
                // line 109
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\" class=\" item\">
\t\t\t\t\t\t\t\t\t";
                // line 110
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id") == $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"))) {
                    // line 111
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $this->env->loadTemplate("getcontent.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
                    // line 112
                    echo "\t\t\t\t\t\t\t\t\t";
                }
                // line 113
                echo "\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['requirement'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 116
            echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- Tab panes -->
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            // line 119
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript") == "list-data.php")) {
                // line 120
                echo "\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "show_type") != "view_only")) {
                    // line 121
                    echo "\t\t\t\t\t\t\t\t<div class=\"form-group\" style=\"margin:0px;\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t<button type=\"button\" onclick=\"savedata('continue');\" class=\"btn btn-success\">Save &amp; Continue</button>
\t\t\t\t\t\t\t\t\t\t<button type=\"button\" onclick=\"savedata('save');\" class=\"btn btn-success\">Save &amp; Exit</button>
\t\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-danger\" onclick=\"this.form.action='";
                    // line 125
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
                    echo "'; this.form.submit();\">Cancel</button>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
                } else {
                    // line 129
                    echo "\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-11\">
\t\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-info\" onclick=\"this.form.action='";
                    // line 131
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
                    echo "'; this.form.submit();\">Back</button>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
                }
                // line 135
                echo "\t\t\t\t\t\t";
            } else {
                // line 136
                echo "\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<div class=\"col-lg-11\">
\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-info\" onclick=\"this.form.action='";
                // line 138
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
                echo "'; this.form.submit();\">Back</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            }
            // line 142
            echo "\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
<input type=\"hidden\" name=\"cno\" id=\"cno\" value=\"\" />
<div class=\"modal fade\" id=\"ccw\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"myModalLabel\">Compensating Controls Worksheet</h4>
      </div>
      <div class=\"modal-body\" style=\"height:250px; overflow-y:scroll;\">
\t\t<label for=\"constraints\">Constraints</label>
        <textarea name=\"constraints\" class=\"form-control\" rows=\"3\" id=\"constraints\"></textarea>
\t\t<label for=\"objective\">Objective</label>
        <textarea name=\"objective\" class=\"form-control\" rows=\"3\" id=\"objective\"></textarea>
\t\t<label for=\"risk\">Identified Risk</label>
        <textarea name=\"risk\" class=\"form-control\" rows=\"3\" id=\"risk\"></textarea>
\t\t<label for=\"dcontrols\">Definition of Compensating Controls</label>
        <textarea name=\"dcontrols\" class=\"form-control\" rows=\"3\" id=\"dcontrols\"></textarea>
\t\t<label for=\"vcontrols\">Validation of Compensating Controls</label>
        <textarea name=\"vcontrols\" class=\"form-control\" rows=\"3\" id=\"vcontrols\"></textarea>
\t\t<label for=\"maintenance\">Maintenace</label>
        <textarea name=\"maintenance\" class=\"form-control\" rows=\"3\" id=\"maintenance\"></textarea>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" onclick=\"savevalueccw();\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
        <button type=\"button\" onclick=\"savevalueccw();\" data-dismiss=\"modal\" class=\"btn btn-primary\">Save changes</button>
      </div>
    </div>
  </div>
</div>

<div class=\"modal fade\" id=\"div-comment\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"myModalLabel\"></h4>
      </div>
\t  <input type=\"hidden\" name=\"c_proc_id\" id=\"c_proc_id\" value=\"\" />
\t  <input type=\"hidden\" name=\"room_id\" id=\"room_id\" value=\"\"> 
\t   <input type=\"hidden\" name=\"chat_type\" id=\"chat_type\" value=\"\"> 
      <div class=\"modal-body\" >
\t\t<div id=\"message_input\">
\t\t\t<textarea name=\"procedure_chat\" class=\"form-control\" rows=\"5\" id=\"procedure_chat\"></textarea>
\t\t</div>
\t\t<div style=\"height:8px;\"></div>
\t\t<div id=\"allcomments\"></div>
\t  </div>
      <div class=\"modal-footer\">
\t\t\t<span class=\"glyphicons glyphicons-user-ban\"></span>
\t\t\t<span class=\"glyphicons glyphicons-user-add\"></span>
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
        <button type=\"button\" onclick=\"save_procedure_chats('procedure_chat');\" data-dismiss=\"modal\" class=\"btn btn-primary\">Save changes</button>
      </div>
    </div>
  </div>
</div>
<!-- Upload Document Div -->
<div class=\"modal fade\" id=\"upload\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"myModalLabel\">Upload File</h4>
      </div>
      <div class=\"modal-body\">
        <form id=\"frmdocupload\" name=\"frmdocupload\" method=\"post\" action=\"uploadfile.php\" enctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"cnou\" id=\"cnou\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"company_id\" id=\"company_id\" value=\"";
            // line 215
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"document\" id=\"document\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"pid\" id=\"pid\" value=\"\" />
\t\t\t<input type=\"file\" name=\"mydoc\" id=\"mydoc\" style=\"height:30px; cursor:pointer;\" class=\"pull-left\" />
\t\t\t<button type=\"submit\" class=\"btn btn-success pull-left\">Upload</button>
\t\t</form>
\t\t<div class=\"progress\">
\t\t\t<div class=\"bar\"></div >
\t\t\t<div class=\"percent\">0%</div >
\t\t</div>
\t\t<div id=\"statusdoc\" class=\"alert\"></div>
\t\t<!-- div for user Doc list -->
\t\t<div id=\"doclist\">
\t\t</div>
\t\t<!-- div for user doc list -->
\t  </div>
      <div class=\"modal-footer\">
\t   <button type=\"button\" class=\"btn btn-success\" data-dismiss=\"modal\" onclick=\"submitForm();\">Save</button>
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- End upload Doc -->

<div class=\"modal fade\" id=\"div-guidance\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Guidance..</h4>
\t\t\t</div>
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div id=\"proc-guidance\"></div>
\t\t\t</div>
\t\t\t<div class=\"modal-footer\">
\t\t\t\t<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
<!-- popup to write reason of failed control -->
<div class=\"modal fade\" id=\"div-reason\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" >Reason of failure</h4>
      </div>
      <div class=\"modal-body\" >
\t\t<textarea name=\"reason_of_failure\" class=\"form-control\" rows=\"3\" id=\"reason_of_failure\"></textarea>
\t     <input type=\"hidden\" name=\"room_id\" id=\"room_id\" value=\"\"> 
\t     <input type=\"hidden\" name=\"chat_type\" id=\"chat_type\" value=\"\"> 
\t\t<div id=\"failure-thread\"></div>
\t  </div>
      <div class=\"modal-footer\">
\t\t\t<span class=\"glyphicons glyphicons-user-ban\"></span>
\t\t\t<span class=\"glyphicons glyphicons-user-add\"></span>
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
        <button type=\"button\" onclick=\"save_failed_control_due_date('";
            // line 275
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "');\"  class=\"btn btn-primary\">Save changes</button>
      </div>
    </div>
  </div>
</div>
<div class=\"modal fade\" id=\"loading\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Processing..</h4>
\t\t\t</div>
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div id=\"proc-guidance\">
\t\t\t\t\t<p>Loading.. Please wait!!</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
";
        }
    }

    // line 296
    public function block_footer($context, array $blocks = array())
    {
        // line 297
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
";
        // line 298
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save")) {
            // line 299
            echo "<script type=\"text/javascript\">
\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
</script>
";
        } else {
            // line 305
            echo "<script src=\"/assets/js/chosen.jquery.js\"></script>
<link href=\"/assets/css/bootstrap-switch.css\" type=\"text/css\" rel=\"stylesheet\">
<script src=\"/assets/js/bootstrap-switch.js\"></script>
<script type=\"text/javascript\">
function savedata(task)
{
\t\$('#task').val(task);
\t\$('#frm').submit();
}
function deletedoc(id, doc, company_id, pid)
{
\tif ( confirm(\"Are you sure? remove \"+doc+\" document?\") )
\t{
\t\tformfields = 'id='+id+'&document='+doc+'&company_id='+company_id+'&pid='+pid;
\t\ttheurl = '/deldocument.php';
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\t\$('#dropdown'+pid).html(data);
\t\t});
\t}
}
function setvalueu(cno)
{
\t\$('#cnou').val(cno);
\t\$('#pid').val(cno);
\t\$('#mydoc').val('');
\t\$('#statusdoc').empty();
\t\$('#statusdoc').hide();
\tvar percentVal = '0%';
\t\$('.bar').width(percentVal)
\t\$('.percent').html(percentVal);
\ttheurl = '/loaddocuments.php';
\tformfields = 'company_id=";
            // line 342
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t\$('#doclist').html(data);
\t});
}
function setvalueccw(id, cno, company_id,commented_to, doc_id, to_user_id, chat_tye)
{
\tif(id == 'N')
\t{
\t\t\$('#cno').val(cno);
\t\t//save_control_due_date(id);
\t\t//get_failure_reason('";
            // line 359
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "', cno);
\t\talert(doc_id);
\t\tsetvalue(cno, '";
            // line 361
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "',commented_to, doc_id, to_user_id, chat_tye);
\t\t\$('#div-reason').modal();
\t}
\tif(id == 'Y' || id == 'NA' || id == 'NT' )
\t{
\t\t\$('#cno').val(cno);
\t\tsave_control_due_date(id);
\t}\t
\tif ( id == 'C' || id == 'CC' )
\t{
\t\tsave_control_due_date(id);
\t\tif ( id == 'C')
\t\t\t\$('#ccw').modal();
\t\t\$('#cno').val(cno);
\t\tflds = ['constraints', 'objective', 'risk', 'dcontrols', 'vcontrols', 'maintenance'];
\t\tfor(f=0; f<flds.length; f++)
\t\t\t\$('#'+flds[f]).val(\$('#'+flds[f]+cno).val());
\t}
\telse
\t\t\$('#ccw'+cno).hide();
}
function savevalueccw()
{
\tcno = \$('#cno').val();
\t\$('#cno').val('');
\t\$('#ccw-btn-'+cno).removeClass('btn-success');
\t\$('#ccw-btn-'+cno).removeClass('btn-danger');
\tflds = ['constraints', 'objective', 'risk', 'dcontrols', 'vcontrols', 'maintenance'];
\tbtnclass = 'btn-success';
\tfor(f=0; f<flds.length; f++)
\t{
\t\tif ( \$('#'+flds[f]).val() == '' )
\t\t\tbtnclass = 'btn-danger';
\t\t\$('#'+flds[f]+cno).val(\$('#'+flds[f]).val());
\t}
\t\$('#ccw-btn-'+cno).addClass(btnclass);
\t\$('#ccw'+cno).show();
}
function sticky_relocate() {
    var window_top = \$(window).scrollTop();
    var div_top = \$('#sticky-anchor').offset().top;
    if (window_top > div_top-135) {
        \$('#sticky').addClass('stick');
    } else {
        \$('#sticky').removeClass('stick');
    }
}

\$(function () {
    \$(window).scroll(sticky_relocate);
    sticky_relocate();
\t\$(\".switch\").bootstrapSwitch();
\t\$('[data-rel=popover]').popover({html:true});
\t\$('.chosen-select').chosen({allow_single_deselect:true, width:\"250px\"});
});
function copydocumentforprocedure(id, doc, company_id)
{
\t\$('#document').val(doc);
\t\$('#id').val(id);
}

function submitForm()
{
\t//get all hidden field values
\tvar id = \$('#id').val();
\tvar pid = \$('#pid').val();
\tvar document = \$('#document').val();
\tif(id != \"\" && pid != \"\" && document != \"\")
\t{
\t\tformfields = 'id='+id+'&document='+document+'&company_id=";
            // line 430
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "&pid='+pid;
\t\ttheurl = '/copydocument.php';
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\tresary = data.split(\"\\n\");
\t\t\thtml = resary[1];
\t\t\t\$('#dropdown'+pid).html(html);
\t\t});
\t}
\t\$('#document').val('');
\t\$('#id').val('');
\t\$('#pid').val('');\t\t
}
function savevalue()
{
\tpid = \$('#cno').val();
\tvar company_id = \$('#id').val();
\tvar to_user_id = \$('#to_user_id').val();
\tvar commented_to = \$('#commented_to').val();
\tvar commented_by = \$('#commented_by').val();
\tvar comment = \$('#comment').val();
\tvar comment_type = 0;
\tif(commented_by == 's' && commented_to == 'u')
\t{
\t\tvar selected_id = \$('select#to_user_id').val();
\t\tif( selected_id != '0' )
\t\t{
\t\t\tto_user_id = selected_id;
\t\t\tcomment_type = 2;
\t\t}
\t}
\t\t
\tif( comment )
\t{\t
\t\tvar regEx = /[A-Za-z0-9-\\/\\.,:;@#% /\\&()]/gi;
\t\tvar validate_arr = comment.match(regEx);
\t\tif(validate_arr)
\t\t{
\t\t\tcomment = comment.replace(\"\\n\", \"<br />\");
\t\t\tcomment = comment.replace(\"\\r\", \"\"); 
\t\t}
\t\telse
\t\t{
\t\t\treturn false;
\t\t}
\t}
\telse
\t{
\t\treturn false;
\t}
\tformfields = 'pid='+pid+'&company_id='+company_id+'&comment='+comment+'&commented_to='+commented_to+'&commented_by='+commented_by+'&to_user_id='+to_user_id+'&comment_type='+comment_type;
\ttheurl = '/savecomments.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t
\t});
\tif ( \$('#comment').val() != '' )
\t{
\t\t\$('#btn-comment'+pid).removeClass('btn-default');
\t\t\$('#btn-comment'+pid).addClass('btn-success');
\t}
}

function getcontent(id)
{
\t\$('.all-tabs').hide();
\tif ( \$('#data'+id).val() == 'n' )
\t{
\t\t\$('#loading').modal('show');
\t\t\$('#data'+id).val('y');
\t\tformfields = 'requirements_id='+id+'&merchant_id=";
            // line 510
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "merchant_id"), "html", null, true);
            echo "&roc_saq=";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "roc_saq"), "html", null, true);
            echo "&company_id=";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "';
\t\ttheurl = '/getcontent.php';
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\t\$('#req'+id).html(data);
\t\t\t\$(\".switch\").bootstrapSwitch();
\t\t\t\$('[data-rel=popover]').popover({html:true});
\t\t\t\$('.chosen-select').chosen({allow_single_deselect:true, width:\"250px\"});
\t\t\t\$('#loading').modal('hide');
\t\t});
\t}
\t\$('#tab'+id).show();
}
function set_guidance(pid)
{
\t\$('.collapse').collapse({
\t\ttoggle: false
\t})
\t
\tvar formfields = 'pid='+pid;
\ttheurl = 'guidance.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t\$('#proc-guidance').html(data);
\t});
}

function lockunlock(tmp)
{
\tvar val = \$('#switch'+tmp).prop(\"checked\");
\tvar locked = '';
\tif(val == true)
\t\tlocked = '1';
\telse
\t\tlocked = '0';
\tif(locked == '0')\t
\t\t\$(\"#lock_icon_\"+tmp).removeClass(\"glyphicon glyphicon-lock text-danger\");
\telse
\t\t\$(\"#lock_icon_\"+tmp).addClass(\"glyphicon glyphicon-lock text-danger\");\t
\tformfields = 'did='+tmp+'&locked='+locked+'&task=save';
\ttheurl = '/savelocked.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t
\t});
}
function get_individ_comment(company_id, to_user_id, commented_by, username)
{
\tif(commented_by == 'c' )
\t\tvar commented_to = 'u';
\tif(commented_by == 's' )
\t\tvar commented_to = 'u';
\tif(commented_by == 'u' )
\t\tvar commented_to = 'c';\t
\tif(username != '0' )
\t{
\t\tvar lable = \"Comment to \"+username;
\t\t\$('#clabel').html(lable);
\t}\t
\t\$('input#commented_to').val(commented_to);
\t\$('input#commented_by').val(commented_by);
\t\$('input#company_id').val(company_id);
\t\$('input#to_user_id').val(to_user_id);
\tc_proc_id = \$('input#c_proc_id').val();
\tformfields = 'company_id='+company_id+'&commented_by='+commented_by+'&commented_to='+commented_to+'&comment_type=1&to_user_id='+to_user_id+'&c_proc_id='+c_proc_id;
\ttheurl = '/individ-comments.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t\$('div#individ-thread').html(data);
\t});
}
function get_failure_reason(company_id, cno)
{
\tvar formfields = 'company_id='+company_id+'&cno='+cno;
\ttheurl = '/get-failure-reason.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t\$('div#failure-thread').html(data);
\t});
}
function save_failed_control_due_date(company_id)
{
\tvar cno = \$('#cno').val();
\tvar reason_of_failure = \$('#reason_of_failure').val();
\t
\t\$('#cno').val('');
\tif( reason_of_failure )
\t{\t
\t\tvar regEx = /[A-Za-z0-9-\\/\\.,:;@#% /\\&()]/gi;
\t\tvar validate_arr = reason_of_failure.match(regEx);
\t\tif(validate_arr)
\t\t{
\t\t\treason_of_failure = reason_of_failure.replace(\"\\n\", \"<br />\");
\t\t\treason_of_failure = reason_of_failure.replace(\"\\r\", \"\"); 
\t\t}
\t\telse
\t\t{
\t\t\talert('Please write the reason of failure');
\t\t\treturn false;
\t\t}
\t}
\telse
\t{
\t\talert('Please write the reason of failure');
\t\treturn false;
\t}
\tformfields = 'company_id='+company_id+'&document_id='+cno+'&reason_of_failure='+reason_of_failure+'&ready_for=u';
\ttheurl = '/save-failed-control-due-date.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t \$('div#div-reason').modal('hide');
\t\t \$('#reason_of_failure').val();
\t});
}
function save_control_due_date(status)
{
\tvar cno = \$('#cno').val();
\tvar c_due_date = \"";
            // line 657
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "compliance_due_date"), "method"), "html", null, true);
            echo "\";
\tvar updated_by = \"";
            // line 658
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method"), "html", null, true);
            echo "\";
\tif(status == 'N')
\t\tvar ready_for = 'u';
\telse
\t\tvar ready_for = 'q';
\tformfields = 'did='+cno+'&ready_for='+ready_for+'&task=save&c_due_date='+c_due_date+'&updated_by='+updated_by;
\ttheurl = '/savereadyforreview.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t
\t});
}
// we call this function only once when QA or QSA user clicks on Chat icon to start texting to selected user QSA or QA
function createchatroom(company_id, sent_from_role, sent_from_id, sent_to_role, sent_to_id, chat_type){
\tvar current_user = ";
            // line 677
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method"), "html", null, true);
            echo ";
\tformfields = 'company_id='+company_id+'&sent_from_id='+sent_from_id+'&sent_from_role='+sent_from_role+'&sent_to_id='+sent_to_id+'&sent_to_role='+sent_to_role+'&chat_type='+chat_type;
\ttheurl = '/createchatroom.php';
\tvar room_id = \$.ajax({
\t\t\t\t\t\ttype: \"POST\",
\t\t\t\t\t\turl: theurl,
\t\t\t\t\t\tdata: formfields,
\t\t\t\t\t\tasync: !1,
\t\t\t\t\t\tdataType:'html',
\t\t\t\t\t\tbeforeSend: function( xhr ) {
\t\t\t\t\t\t},
\t\t\t\t\t\tsuccess:(function(response) { 
\t\t\t\t\t\t\treturn response;
\t\t\t\t\t\t}),
\t\t\t\t\t}).responseText;
\treturn room_id;\t\t\t\t
}
</script>
";
        }
    }

    public function getTemplateName()
    {
        return "front-fill-data.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  972 => 677,  950 => 658,  946 => 657,  792 => 510,  709 => 430,  637 => 361,  632 => 359,  612 => 342,  573 => 305,  565 => 299,  563 => 298,  558 => 297,  555 => 296,  530 => 275,  467 => 215,  392 => 142,  385 => 138,  381 => 136,  378 => 135,  371 => 131,  367 => 129,  360 => 125,  354 => 121,  351 => 120,  349 => 119,  344 => 116,  328 => 113,  325 => 112,  322 => 111,  320 => 110,  316 => 109,  308 => 108,  301 => 107,  298 => 106,  295 => 105,  292 => 104,  289 => 103,  286 => 102,  283 => 101,  266 => 100,  258 => 94,  243 => 92,  239 => 91,  232 => 86,  225 => 82,  221 => 80,  215 => 76,  208 => 72,  203 => 69,  201 => 68,  193 => 65,  187 => 64,  181 => 63,  175 => 62,  169 => 61,  161 => 56,  155 => 53,  149 => 49,  147 => 48,  133 => 41,  124 => 35,  120 => 34,  116 => 33,  111 => 31,  107 => 30,  103 => 29,  99 => 28,  95 => 27,  91 => 26,  81 => 18,  75 => 15,  71 => 14,  67 => 13,  63 => 12,  59 => 11,  55 => 10,  51 => 9,  46 => 8,  44 => 7,  41 => 6,  33 => 3,  30 => 2,);
    }
}
