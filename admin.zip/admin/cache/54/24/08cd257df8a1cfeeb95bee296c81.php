<?php

/* v32_assessment-third-party-payment-apps.html */
class __TwigTemplate_542408cd257df8a1cfeeb95bee296c81 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 15
            echo "<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 34
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 35
            echo "      <!-- Tab panes -->
\t\t<div class=\"tab-content tab_border\">
            <div class=\"screen7_inner_part widget-box widget-color-blue\">
                <div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i> 4 Reviewed Environment </h4>
                </div>
               <div class=\"widget-body\">
               \t\t<div class=\"widget-main widget_main_extra_part\">
                    \t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.8\tThird-party payment applications/solutions</div>
\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t\tUse the table on the following page to identify and list all third-party payment application products and version numbers in use, including whether each payment application has been validated according to PA-DSS or PCI P2PE. Even if a payment application has been PA-DSS or PCI P2PE validated, the assessor still needs to verify that the application has been implemented in a PCI DSS compliant manner and environment, and according to the payment application vendor’s PA-DSS Implementation Guidefor PA-DSS applications or P2PE Implementation Manual (PIM) and P2PE application vendor’s P2PE Application Implementation Guide for PCI P2PE applications/solutions
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t\t<span class=\"label_note\"><b>Note:</b> &nbsp; It is not a PCI DSS requirement to use PA-DSS validated applications. Please consult with each payment brand individually to understand their PA-DSS compliance requirements.</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t\t<span class=\"label_note\"><b>Note:</b> &nbsp; Homegrown payment applications/solutions must be reported at the sections for Critical Hardware and Critical Software. It is also strongly suggested to address such homegrown payment applications/solutions below at “Any additional comments or findings” in order to represent all payment applications in the assessed environment in this table.</span>
\t\t\t\t\t\t</div>
                    \t<div class=\"screen9_table_block_part screen10_extra screen11_part\">
                            <div class=\"table-responsive screen_field_part\">
                                <table class=\"table table-striped\" id=\"tbl1\">
\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">Name of Third-party Payment Application/Solution</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">Version of Product</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">PA-DSS validated?(yes/no)</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">P2PE validated? (yes/no)</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">PCI SSC Listing reference number</th>
\t\t\t\t\t\t\t\t\t\t\t<th class=\"col-md-2 col-sm-2 col-xs-2\">Expiry date of listing, if applicable</th>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t";
            // line 67
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "apps"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 68
                echo "\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td><input name=\"app_name[]\" placeholder=\"Name of Third-party Payment Application\" type=\"text\" class=\"form-control\" value=\"";
                // line 69
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "app_name"), "html", null, true);
                echo "\"></td>
\t\t\t\t\t\t\t\t\t\t\t<td><input name=\"version_of_product[]\" placeholder=\"Version of Product\" type=\"text\" class=\"form-control\" value=\"";
                // line 70
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "version_of_product"), "html", null, true);
                echo "\"></td>
\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock\">
\t\t\t\t\t\t\t\t\t\t\t\t<input id=\"pa_dss_validated-1-";
                // line 73
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"1\" ";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pa_dss_validated") == "yes")) {
                    echo " checked=\"checked\"";
                }
                echo " name=\"pa_dss_validated1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\"> 
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"pa_dss_validated[]\" id=\"pa_dss_validated";
                // line 74
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pa_dss_validated"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock\">
\t\t\t\t\t\t\t\t\t\t\t\t<input id=\"p2pe_validated-1-";
                // line 79
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"1\" ";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "p2pe_validated") == "yes")) {
                    echo " checked=\"checked\"";
                }
                echo " name=\"p2pe_validated1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\"> 
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"p2pe_validated[]\" id=\"p2pe_validated";
                // line 80
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "p2pe_validated"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td><input name=\"pci_ssc_ref_no[]\" placeholder=\"PCI SSC Listing reference number\" type=\"text\" class=\"form-control\" value=\"";
                // line 83
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pci_ssc_ref_no"), "html", null, true);
                echo "\" > </td>
\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exp_date_";
                // line 86
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>
\t\t\t\t\t\t\t\t\t\t\t\t<input readonly name=\"exp_date[]\" type=\"text\" id=\"exp_date_";
                // line 87
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" class=\"form-control date-picker\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "exp_date"), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 89
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 90
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 92
                echo "\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 95
            echo "\t\t\t\t\t\t\t\t\t</tbody>
                                </table>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow('tbl1');\" > Add Row </div> 
                        </div>
                        <div class=\"screen9_table_block_part screen10_extra screen11_part\">
                            <div class=\"assesment_reiview_env_soft_data_bg\">
                                <table class=\"table table-striped\">
                                  <tbody>
                                    <tr>
                                        <td class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Provide the name of the assessor who attests that all PA-DSS Validated payment applications were reviewed to verify they have been implemented in a PCI DSS compliant manner according to the payment application vendor's PA-DSS implementation Guide</strong></td>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"implementation_guide\" class=\"form-control\" rows=\"2\">";
            // line 106
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), 0), "implementation_guide"), "html", null, true);
            echo "</textarea></td>
                                    </tr>
                                    <tr>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Provide the name of the assessor who attests that all PACI SSC-validated P2PE applications and solutions were reviewed to verify they have been implemented in a PCI DSS compliant manner according to the P2PE application vendor's P2PE Application Implemention Guide and the P2PE Solution Vendor's P2PE Instruction Manual (PIM).</strong></td>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"manual\" class=\"form-control\" rows=\"2\">";
            // line 110
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), 0), "manual"), "html", null, true);
            echo "</textarea></td>
                                    </tr>
                                    <tr>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>For any of the above Third-Party Payment Applications and/or solutions that are not listed on the PCI SSC website, identify any being considered for scope reduction/exclusion/etc.</strong></td>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"scope_exclusion\" class=\"form-control\" rows=\"2\">";
            // line 114
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), 0), "scope_exclusion"), "html", null, true);
            echo "</textarea></td>
                                    </tr>
                                    <tr>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Any additional comments or findings assessor would like to share, as applicable:</strong></td>
                                        <td  class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"additional_comments\" class=\"form-control\" rows=\"2\">";
            // line 118
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), 0), "additional_comments"), "html", null, true);
            echo "</textarea></td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                        </div>
\t\t\t\t\t\t<button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button> 
                    </div>
               </div>
            </div>
\t\t</div>
\t</form>
</div>
";
        }
    }

    // line 134
    public function block_footer($context, array $blocks = array())
    {
        // line 135
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script src=\"/assets/js/chosen.jquery.js\"></script>
\t<link href=\"/assets/css/bootstrap-switch.css\" type=\"text/css\" rel=\"stylesheet\">
\t<script src=\"/assets/js/bootstrap-switch.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 147
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 148
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 152
            echo "rowno = ";
            echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "apps")), "html", null, true);
            echo ";
\$(document).ready(function() {
   
\t\$('#frm').bootstrapValidator();
\t\$(\".switch\").bootstrapSwitch();
    \$(\"#tbl1\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t\$('body').on('focus',\".date-picker\", function(){
\t\t\$(this).datepicker({format: 'mm-dd-yyyy'});
\t}).on('changeDate', function(ev){
\t\t\$(\".datepicker\").hide();
\t});
\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\tary = \$(this).attr('id').split('-');
\t\tval = state ? 'yes' : 'no';
\t\t\$('#'+ary[0]+ary[2]).val(val);
\t});
});

function addrow(tbl_id)
{
\thtml = '';
\thtml = html + '<tr>';
\thtml = html + '\t<td><input name=\"app_name[]\" type=\"text\" placeholder=\"Name of Third-party Payment Application\" class=\"form-control\"></td>';
\thtml = html + '\t<td><input name=\"version_of_product[]\" placeholder=\"Version of Product\" type=\"text\" class=\"form-control\"></td>';
\thtml = html + '\t<td>';
\thtml = html + '\t\t<div class=\"lockunlock\">';
\thtml = html + '\t\t\t<input id=\"pa_dss_validated-1-'+rowno+'\" value=\"1\" name=\"pa_dss_validated1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">';
\thtml = html + '\t\t\t<input type=\"hidden\" name=\"pa_dss_validated[]\" id=\"pa_dss_validated'+rowno+'\" value=\"no\" />';
\thtml = html + '\t\t</div>';
\thtml = html + '\t</td>';
\thtml = html + '\t<td>';
\thtml = html + '\t\t<div class=\"lockunlock\">';
\thtml = html + '\t\t\t<input id=\"p2pe_validated-1-'+rowno+'\" value=\"1\" name=\"p2pe_validated[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\"> ';
\thtml = html + '\t\t\t<input type=\"hidden\" name=\"p2pe_validated[]\" id=\"p2pe_validated'+rowno+'\" value=\"no\" />';
\thtml = html + '\t\t</div>';
\thtml = html + '\t</td>';
\thtml = html + '\t<td><input name=\"pci_ssc_ref_no[]\" placeholder=\"PCI SSC Listing reference number\" type=\"text\" class=\"form-control\"></td>';
\thtml = html + '\t<td>';
\thtml = html + '\t\t<div class=\"input-group\">';
\thtml = html + '\t\t\t<label for=\"exp_date_'+rowno+'\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>';
\thtml = html + '\t\t\t<input readonly name=\"exp_date[]\" type=\"text\" id=\"exp_date_'+rowno+'\" class=\"date-picker form-control\" value=\"";
            // line 194
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "current_date"), "html", null, true);
            echo "\">';
\thtml = html + '\t\t</div>';
\thtml = html + '\t\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>';
\thtml = html + '\t</td>';
\thtml = html + '</tr>';
\t\$(\"#\"+tbl_id).append(html);\t
\t\$(\".switch\").bootstrapSwitch();
\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\tary = \$(this).attr('id').split('-');
\t\tval = state ? 'yes' : 'no';
\t\t\$('#'+ary[0]+ary[2]).val(val);
\t});
\trowno++;
}
";
        }
        // line 209
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "v32_assessment-third-party-payment-apps.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  409 => 209,  391 => 194,  345 => 152,  339 => 148,  337 => 147,  321 => 135,  318 => 134,  304 => 124,  295 => 118,  288 => 114,  281 => 110,  274 => 106,  261 => 95,  245 => 92,  241 => 90,  239 => 89,  232 => 87,  228 => 86,  222 => 83,  214 => 80,  206 => 79,  196 => 74,  188 => 73,  182 => 70,  178 => 69,  175 => 68,  158 => 67,  124 => 35,  122 => 34,  117 => 32,  113 => 31,  109 => 30,  105 => 29,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  80 => 22,  71 => 15,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
