<?php

/* _front-kanban-grid.html */
class __TwigTemplate_443c0a12dd749ac95505398f2767201b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"kanban_board\">
<div class=\"col-lg-15\">
\t  <div class=\"panel\">
\t\t<div class=\"panel-heading\" >
\t\t";
        // line 5
        $context["count"] = "0";
        // line 6
        echo "\t\t";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "customers"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 7
            echo "\t\t\t";
            $context["company_id"] = $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id");
            // line 8
            echo "\t\t\t\t";
            $context["div_width"] = $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage");
            // line 9
            echo "\t\t\t\t\t";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage") > "85")) {
                // line 10
                echo "\t\t\t\t\t\t";
                $context["div_width"] = "86";
                // line 11
                echo "\t\t\t\t\t";
            }
            echo "\t
\t\t\t<div class=\"board_block_bg col-sm-3  \" >
\t\t\t<div class=\"col-lg-16 tasks\" onclick=\"javascript:edit('";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', 'fill-data.php');\" ><strong>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
            echo "</strong></div>
\t\t\t\t\t<div class=\"board_block_part\">
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"board_block_inner_part\">
\t\t\t\t\t\t\t<div class=\"profile_pic\"></div>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Assessment Type:</strong> ";
            // line 18
            echo twig_escape_filter($this->env, strtoupper($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "roc_saq")), "html", null, true);
            echo " </span>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Compliance Due Date:</strong> ";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "compliance_due_date"), "html", null, true);
            echo " </span>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"><strong>Completed </strong><small>[";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "filled"), "html", null, true);
            echo " <i> Out-of </i> ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total"), "html", null, true);
            echo "]  </small></span>
\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t<div class=\"time_manage_main completed\">
\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small><b>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
            echo "</b></small></span>
\t\t\t\t\t\t\t\t<div class=\"time_manage_comp\" style=\"width: ";
            // line 24
            echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
            echo "%;\" data-fill=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
            echo "%\">
\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
            // line 28
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ipt"));
            foreach ($context['_seq'] as $context["key_id"] => $context["row1"]) {
                // line 29
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
                // line 30
                if (((isset($context["key_id"]) ? $context["key_id"] : null) == (isset($context["company_id"]) ? $context["company_id"] : null))) {
                    // line 31
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["div_width"] = $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage");
                    // line 32
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (($this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage") > "85")) {
                        // line 33
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        $context["div_width"] = "85";
                        // line 34
                        echo "\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 35
                    echo "\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong> In Process Tasks </strong> <small>[ ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "filled"), "html", null, true);
                    echo " <i> Out-of </i> ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "total"), "html", null, true);
                    echo " ]</small> </span>
\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_main inprogress\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small><b>";
                    // line 38
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage"), "html", null, true);
                    echo "</b></small></span>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_ip\" style=\"width: ";
                    // line 39
                    echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
                    echo "%;\" data-fill=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage"), "html", null, true);
                    echo "%\">
\t\t\t\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 43
                echo "\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key_id'], $context['row1'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 44
            echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
            // line 45
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "uct"));
            foreach ($context['_seq'] as $context["key_id"] => $context["row1"]) {
                // line 46
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
                // line 47
                if (((isset($context["key_id"]) ? $context["key_id"] : null) == (isset($context["company_id"]) ? $context["company_id"] : null))) {
                    // line 48
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["div_width"] = $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage");
                    // line 49
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (($this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage") > "85")) {
                        // line 50
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        $context["div_width"] = "85";
                        // line 51
                        echo "\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 52
                    echo "\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"><strong> Upcoming Tasks</strong> <small>[ ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "filled"), "html", null, true);
                    echo " <i> Out-of </i> ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "total"), "html", null, true);
                    echo "  ]</small> </span>
\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_main upcoming\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small><b>";
                    // line 55
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage"), "html", null, true);
                    echo "</b></small></span>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_uc\" style=\"width: ";
                    // line 56
                    echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
                    echo "%;\" data-fill=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage"), "html", null, true);
                    echo "%\">
\t\t\t\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 60
                echo "\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key_id'], $context['row1'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 61
            echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
            // line 62
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ft"));
            foreach ($context['_seq'] as $context["key_id"] => $context["row1"]) {
                // line 63
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
                // line 64
                if (((isset($context["key_id"]) ? $context["key_id"] : null) == (isset($context["company_id"]) ? $context["company_id"] : null))) {
                    // line 65
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["div_width"] = $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage");
                    // line 66
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (($this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage") > "85")) {
                        // line 67
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        $context["div_width"] = "85";
                        // line 68
                        echo "\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 69
                    echo "\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Failed Tasks </strong><small>[ ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "filled"), "html", null, true);
                    echo " <i> Out-of </i> ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "total"), "html", null, true);
                    echo "  ]</small> </span>
\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_main failed\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small><b>";
                    // line 72
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage"), "html", null, true);
                    echo "</b></small></span>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_failed\" style=\"width: ";
                    // line 73
                    echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
                    echo "%;\" data-fill=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage"), "html", null, true);
                    echo "%\">
\t\t\t\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 77
                echo "\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key_id'], $context['row1'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 78
            echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
            // line 79
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "odt"));
            foreach ($context['_seq'] as $context["key_id"] => $context["row1"]) {
                // line 80
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
                // line 81
                if (((isset($context["key_id"]) ? $context["key_id"] : null) == (isset($context["company_id"]) ? $context["company_id"] : null))) {
                    // line 82
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["div_width"] = $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage");
                    // line 83
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (($this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage") > "85")) {
                        // line 84
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        $context["div_width"] = "85";
                        // line 85
                        echo "\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 86
                    echo "\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"><strong> Over Due Tasks </strong><small>[ ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "filled"), "html", null, true);
                    echo " <i> Out-of </i> ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "total"), "html", null, true);
                    echo "  ]</small> </span>
\t\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_main overdue\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small><b>";
                    // line 89
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage"), "html", null, true);
                    echo "</b></small></span>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"time_manage_od\" style=\"width: ";
                    // line 90
                    echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
                    echo "%;\" data-fill=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["row1"]) ? $context["row1"] : null), 0), "percentage"), "html", null, true);
                    echo "%\">
\t\t\t\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 94
                echo "\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key_id'], $context['row1'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 95
            echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t
\t\t\t\t\t\t\t<!--<span class=\"pull-right \" data-target=\"#section_4\" data-toggle=\"collapse\" title=\"Click to Expand/Collapse below section\" aria-expanded=\"true\"><small>View All</small></span>\t-->\t\t\t\t
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- <div class=\"board_block_part inner_section collapse out\" id=\"section_4\">
\t\t\t\t\t\t<div class=\"inner_section\"></div>
\t\t\t\t\t</div>\t-->
\t\t\t</div>
\t\t\t";
            // line 104
            $context["count"] = ((isset($context["count"]) ? $context["count"] : null) + 1);
            // line 105
            echo "\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 106
        echo "
\t\t
\t</div>
   </div>
</div>

";
    }

    public function getTemplateName()
    {
        return "_front-kanban-grid.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  313 => 106,  307 => 105,  305 => 104,  294 => 95,  288 => 94,  279 => 90,  275 => 89,  266 => 86,  263 => 85,  260 => 84,  257 => 83,  254 => 82,  252 => 81,  249 => 80,  245 => 79,  242 => 78,  236 => 77,  227 => 73,  223 => 72,  214 => 69,  211 => 68,  208 => 67,  205 => 66,  202 => 65,  200 => 64,  197 => 63,  193 => 62,  190 => 61,  184 => 60,  175 => 56,  171 => 55,  162 => 52,  159 => 51,  156 => 50,  153 => 49,  150 => 48,  148 => 47,  145 => 46,  141 => 45,  138 => 44,  132 => 43,  123 => 39,  119 => 38,  110 => 35,  107 => 34,  104 => 33,  101 => 32,  98 => 31,  96 => 30,  93 => 29,  89 => 28,  80 => 24,  76 => 23,  68 => 20,  64 => 19,  60 => 18,  50 => 13,  44 => 11,  41 => 10,  38 => 9,  35 => 8,  32 => 7,  27 => 6,  25 => 5,  19 => 1,);
    }
}
