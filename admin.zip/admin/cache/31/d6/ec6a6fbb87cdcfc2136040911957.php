<?php

/* list-data.html */
class __TwigTemplate_31d6ec6a6fbb87cdcfc2136040911957 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<form name=\"frmreport\" id=\"frmreport\" method=\"post\" action=\"\">
\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
        echo "\" />
\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
        echo "\" />
\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t<input type=\"hidden\" name=\"show_type\" id=\"show_type\" value=\"\" />
</form>
<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"show_type\" id=\"show_type\" value=\"\" />
\t\t\t";
        // line 18
        $this->env->loadTemplate("_new-panel.html")->display($context);
        // line 19
        echo "\t\t\t<div class=\"table-responsive\">
\t\t\t\t";
        // line 20
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "msg") != "")) {
            // line 21
            echo "\t\t\t\t<div id=\"orderform-success-alert\" class=\"alert alert-success\">  Download link sent to your email ID registered with us.  </div>
\t\t\t\t";
        }
        // line 23
        echo "\t\t\t\t<table id=\"simple-table\" class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t   <thead>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t <th class=\"text-center\">";
        // line 26
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Sr#", 1 => "rowid", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 27
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Assessment Type", 1 => "merchant_type", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 28
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Company Name", 1 => "company_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 29
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Contact Name", 1 => "username", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 30
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Telephone", 1 => "mobile", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 31
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Email", 1 => "email", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 32
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Compliance Due Date", 1 => "compliance_due_date", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th class=\"text-center\">Action</th>
\t\t\t\t\t\t <th class=\"text-center\">Reports</th>
\t\t\t\t\t  </tr>
\t\t\t\t   </thead>
\t\t\t\t   <tbody>
\t\t\t\t\t  ";
        // line 38
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 39
            echo "\t\t\t\t
\t\t\t\t\t  ";
            // line 40
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage") == 100)) {
                // line 41
                echo "\t\t\t\t\t\t\t";
                $context["glyphiconEdit"] = "glyphicon-file";
                // line 42
                echo "\t\t\t\t\t\t\t";
                $context["titleText"] = "View Data";
                // line 43
                echo "\t\t\t\t\t  ";
            } else {
                // line 44
                echo "\t\t\t\t\t\t\t";
                $context["glyphiconEdit"] = "glyphicon-pencil";
                // line 45
                echo "\t\t\t\t\t\t\t";
                $context["titleText"] = "Edit Data";
                // line 46
                echo "\t\t\t\t\t  ";
            }
            // line 47
            echo "\t\t\t\t\t  <tr";
            echo $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "class");
            echo ">
\t\t\t\t\t\t <td class=\"text-center\">";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "rowid"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "merchant_type"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "username"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 52
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "mobile"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "email"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "compliance_due_date"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td class=\"text-center\"><button type=\"button\" title=\"";
            // line 55
            echo twig_escape_filter($this->env, (isset($context["titleText"]) ? $context["titleText"] : null), "html", null, true);
            echo "\" onclick=\"edit('";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "editscript"), "html", null, true);
            echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon ";
            echo twig_escape_filter($this->env, (isset($context["glyphiconEdit"]) ? $context["glyphiconEdit"] : null), "html", null, true);
            echo "\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t";
            // line 56
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage") == 100)) {
                // line 57
                echo "\t\t\t\t\t\t\t\t <input type=\"hidden\" name=\"show_";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "\" id=\"show_";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "\" value=\"view_only\" />
\t\t\t\t\t\t\t";
            }
            // line 59
            echo "\t\t\t\t\t\t </td>
\t\t\t\t\t\t <td class=\"text-center\">
\t\t\t\t\t\t\t<button type=\"button\" onclick=\"report('";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', 'report-compliance.php');\" class=\"btn btn-success btn-xs btn-report\" title=\"Compliance/Sevirity\"><span class=\"glyphicon glyphicon-signal\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t<button type=\"button\" onclick=\"report('";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', 'report-priority.php');\" class=\"btn btn-warning btn-xs btn-report\" title=\"Priority\"><span class=\"glyphicon glyphicon-signal\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t<button type=\"button\" onclick=\"docreport('";
            // line 63
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', 'reporting-doc.php');\" class=\"btn btn-success btn-xs btn-report\" title=\"Download Report\"><span class=\"fa fa-book\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t\t<button data-toggle=\"modal\" data-dismis=\"modal\" data-target=\"#loading\" id=\"backup-btn\" type=\"button\" onclick=\"report('";
            // line 64
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', 'backup.php');\" class=\"btn btn-success btn-xs\" title=\"Backup\"><span class=\"fa fa-download\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t </td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 68
        echo "\t\t\t\t\t  ";
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows")) == 0)) {
            // line 69
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td colspan=\"11\">No Records</td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        // line 73
        echo "\t\t\t\t   </tbody>
\t\t\t\t   <tfoot>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t<td colspan=\"11\"></td>
\t\t\t\t\t  </tr>
\t\t\t\t   </tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
<div class=\"modal fade\" id=\"loading\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Processing..</h4>
\t\t\t</div>
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div id=\"proc-guidance\">
\t\t\t\t\t<p> Please wait!! </p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
";
    }

    // line 99
    public function block_footer($context, array $blocks = array())
    {
        // line 100
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
<script src=\"/admin/js/list.js\"></script>
<script>
\$(document).ready(function() {
\t\$('#loading').modal('hide');
\t\$('div.alert-success').fadeOut(6000);
 });
</script>
<script type=\"text/javascript\">
function docreport(id, fl)
{
\tdocument.frmreport.id.value = id;
\tdocument.frmreport.action = fl;
\tdocument.frmreport.target = '_blank';
\tdocument.frmreport.submit();
}
</script>
";
    }

    public function getTemplateName()
    {
        return "list-data.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  263 => 100,  260 => 99,  231 => 73,  225 => 69,  222 => 68,  212 => 64,  208 => 63,  204 => 62,  200 => 61,  196 => 59,  188 => 57,  186 => 56,  176 => 55,  172 => 54,  168 => 53,  164 => 52,  160 => 51,  156 => 50,  152 => 49,  148 => 48,  143 => 47,  140 => 46,  137 => 45,  134 => 44,  131 => 43,  128 => 42,  125 => 41,  123 => 40,  120 => 39,  116 => 38,  107 => 32,  103 => 31,  99 => 30,  95 => 29,  91 => 28,  87 => 27,  83 => 26,  78 => 23,  74 => 21,  72 => 20,  69 => 19,  67 => 18,  62 => 16,  57 => 14,  53 => 13,  44 => 7,  39 => 5,  35 => 4,  32 => 3,  29 => 2,);
    }
}
