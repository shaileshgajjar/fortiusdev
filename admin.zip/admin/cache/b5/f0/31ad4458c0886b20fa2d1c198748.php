<?php

/* summary-of-findings.html */
class __TwigTemplate_b5f031ad4458c0886b20fa2d1c198748 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 16
            echo "\t<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 35
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 36
            echo "      <!-- Tab panes -->
        <div class=\"tab-content tab_border\">
\t\t<div role=\"tabpanel\" class=\"tab-pane active\" id=\"screen1\">
            <div class=\"screen7_inner_part widget-box widget-color-blue\">
                <div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i> 1. \tContact Information and Report Date</h4>
                </div>
                
                <div class=\"widget-body\">
                \t<div class=\"widget-main widget_main_extra_part\">
                    <div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\"> 1.5\tSummary of Findings </div>
\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\tComplete the following for connected entities for processing. If the assessor needs to include additional reporting for the specific brand and/or acquirer, it can be included either here within 3.5 or as an appendix at the end of this report. Do not alter the Attestation of Compliance (AOC) for this purpose.
\t\t\t\t    </div>
                    \t<div class=\"screen9_table_block_part screen10_extra\">
                            <div class=\"table-responsive screen_field_part\">
                                <table class=\"table table-striped\" id=\"tbl1\">
                                  <thead>
                                    <tr>
                                      <th class=\"col-md-4 center\" rowspan=\"2\">PCI DSS Requirement</th>
\t\t\t\t\t\t\t\t\t  <th class=\"col-md-6 center\" colspan=\"3\" >Summary of Findings <br/>(check one) </th>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t <tr ><th class=\"center\">Compliant</th><th class=\"center\">Non Compliant</th><th class=\"center\">Not Applicable</th></tr>

                                  </thead>
                                  <tbody>
\t\t\t\t\t\t\t\t  ";
            // line 62
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "entity_type"));
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 63
                echo "\t\t\t\t\t\t\t\t\t <tr>
\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>1. Install and maintain a firewall configuration to protect card-holder data</label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_0\" value=\"compliant\" ";
                // line 70
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_0") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_0\" value=\"non_compliant\" ";
                // line 78
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_0") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_0\" value=\"not_applicable\" ";
                // line 86
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_0") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>2. Do not use vendor-supplied defaults for system passwords and other security parameters</label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_1\" value=\"compliant\" ";
                // line 99
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_1") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_1\" value=\"non_compliant\" ";
                // line 107
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_1") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_1\" value=\"not_applicable\" ";
                // line 115
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_1") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>\t
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>3. Protect stored card-holder data </label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_2\" value=\"compliant\" ";
                // line 128
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_2") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_2\" value=\"non_compliant\" ";
                // line 136
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_2") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_2\" value=\"not_applicable\" ";
                // line 144
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_2") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>4. Encrypt transmission of card-holder data across open, public networks</label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_3\" value=\"compliant\" ";
                // line 157
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_3") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_3\" value=\"non_compliant\" ";
                // line 165
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_3") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_3\" value=\"not_applicable\" ";
                // line 173
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_3") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>5. Protect all systems against malware and regularly update anti-virus software or programs</label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_4\" value=\"compliant\" ";
                // line 186
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_4") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_4\" value=\"non_compliant\" ";
                // line 194
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_4") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_4\" value=\"not_applicable\" ";
                // line 202
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_4") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>6. Develop and maintain secure systems and applications</label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_5\" value=\"compliant\" ";
                // line 215
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_5") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_5\" value=\"non_compliant\" ";
                // line 223
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_5") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_5\" value=\"not_applicable\" ";
                // line 231
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_5") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>7. Restrict access to cardholder data by business need to know</label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_6\" value=\"compliant\" ";
                // line 244
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_6") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_6\" value=\"non_compliant\" ";
                // line 252
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_6") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_6\" value=\"not_applicable\" ";
                // line 260
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_6") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>8. Identify and authenticate access to system components</label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_7\" value=\"compliant\" ";
                // line 273
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_7") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_7\" value=\"non_compliant\" ";
                // line 281
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_7") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_7\" value=\"not_applicable\" ";
                // line 289
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_7") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>9. Restrict physical access to card-holder data</label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_8\" value=\"compliant\" ";
                // line 302
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_8") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_8\" value=\"non_compliant\" ";
                // line 310
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_8") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_8\" value=\"not_applicable\" ";
                // line 318
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_8") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>10. Track and monitor all access to network resources and card-holder data</label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_9\" value=\"compliant\" ";
                // line 331
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_9") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_9\" value=\"non_compliant\" ";
                // line 339
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_9") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_9\" value=\"not_applicable\" ";
                // line 347
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_9") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>11. Regularly test security systems and processes</label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_10\" value=\"compliant\" ";
                // line 360
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_10") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_10\" value=\"non_compliant\" ";
                // line 368
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_10") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_10\" value=\"not_applicable\" ";
                // line 376
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_10") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<label>12. Maintain a policy that addresses information security for all personnel</label>
\t\t\t\t\t\t\t\t\t  </td>
\t\t\t\t\t\t\t\t\t\t<td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_1\" name=\"comp_ncomp_ntcomp_11\" value=\"compliant\" ";
                // line 389
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_11") == "compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t\t\t\t  </label>
                                            </div>
                                          </td>
                                          <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_2\" name=\"comp_ncomp_ntcomp_11\" value=\"non_compliant\" ";
                // line 397
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_11") == "non_compliant")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t  <td>
                                            <div class=\"radio center\">
                                              <label>
                                                <input class=\"ace\" type=\"radio\" id=\"part_3\" name=\"comp_ncomp_ntcomp_11\" value=\"not_applicable\" ";
                // line 405
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "comp_ncomp_ntcomp_11") == "not_applicable")) {
                    echo " checked=\"checked\"";
                }
                echo ">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
                                              </label>
                                            </div>
                                           </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 412
            echo "                                  </tbody>
                                </table>
                                
                              </div>
                              
                        </div>
                         <button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 418
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t \t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\" id=\"validateBtn\" >Next <span><i class=\"fa fa-arrow-right\" ></i></span> </button>
                    </div>
                </div>
            </div>
        </div>
      </div>
\t  </form>
    </div>
";
        }
    }

    // line 429
    public function block_footer($context, array $blocks = array())
    {
        // line 430
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
\t
<script type=\"text/javascript\">
";
        // line 437
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 438
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 442
            echo "\$(document).ready(function() {
  // row = ";
            // line 443
            echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "entity_type")), "html", null, true);
            echo ";
\t\$('#frm').bootstrapValidator();
    
\t
});
/*function addrow(tbl_id)
{
\thtml = '';
\thtml = html + '<tr>';
\thtml = html + '\t<td>';
\thtml = html + '\t\t<div class=\"radio\">';
\thtml = html + '\t\t\t<label>';
\thtml = html + '\t\t\t\t<input class=\"ace\" type=\"radio\" id=\"part_'+row+'1\" name=\"comp_ncomp_ntcomp['+row+'][]\" value=\"part\" checked=\"checked\">';
\thtml = html + '\t\t\t\t<span class=\"lbl\"></span>';
\thtml = html + '\t\t\t</label>';
\thtml = html + '\t\t</div>';
\thtml = html + '\t</td>';
\thtml = html + '\t<td>';
\thtml = html + '\t\t<div class=\"radio\">';
\thtml = html + '\t\t\t<label>';
\thtml = html + '\t\t\t\t<input class=\"ace\" type=\"radio\" id=\"part_'+row+'2\" name=\"comp_ncomp_ntcomp['+row+'][]\" value=\"separate\">';
\thtml = html + '\t\t\t\t<span class=\"lbl\"></span>';
\thtml = html + '\t\t\t</label>';
\thtml = html + '\t\t</div>';
\thtml = html + '\t</td>';
\thtml = html + '\t<td>';
\thtml = html + '\t\t<div class=\"radio\">';
\thtml = html + '\t\t\t<label>';
\thtml = html + '\t\t\t\t<input class=\"ace\" type=\"radio\" id=\"part_'+row+'3\" name=\"comp_ncomp_ntcomp['+row+'][]\" value=\"separate\">';
\thtml = html + '\t\t\t\t<span class=\"lbl\"></span>';
\thtml = html + '\t\t\t</label>';
\thtml = html + '\t\t</div>';
\thtml = html + '\t</td>';
\thtml = html + '</tr>';
\t\$(\"#\"+tbl_id).append(html);
\tif ( tbl_id == 'tbl1' )
\t\trow1++;
\t
}*/
";
        }
        // line 483
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "summary-of-findings.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  785 => 483,  742 => 443,  739 => 442,  733 => 438,  731 => 437,  720 => 430,  717 => 429,  702 => 418,  694 => 412,  679 => 405,  666 => 397,  653 => 389,  635 => 376,  622 => 368,  609 => 360,  591 => 347,  578 => 339,  565 => 331,  547 => 318,  534 => 310,  521 => 302,  503 => 289,  490 => 281,  477 => 273,  459 => 260,  446 => 252,  433 => 244,  415 => 231,  402 => 223,  389 => 215,  371 => 202,  358 => 194,  345 => 186,  327 => 173,  314 => 165,  301 => 157,  283 => 144,  270 => 136,  257 => 128,  239 => 115,  226 => 107,  213 => 99,  195 => 86,  182 => 78,  169 => 70,  160 => 63,  156 => 62,  128 => 36,  126 => 35,  121 => 33,  117 => 32,  113 => 31,  109 => 30,  104 => 28,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  75 => 16,  69 => 13,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
