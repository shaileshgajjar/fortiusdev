<?php

/* new-front-layout.html */
class __TwigTemplate_07799c70d72f12dd692f40fb251f4fd3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
\t<head>
";
        // line 4
        $this->displayBlock('head', $context, $blocks);
        // line 53
        echo "\t</head>
\t<body class=\"skin-1\">
\t\t
\t\t";
        // line 56
        $this->env->loadTemplate("_front-header.html")->display($context);
        // line 57
        echo "
\t\t<div class=\"main-container\" id=\"main-container\">

\t\t\t";
        // line 60
        $this->env->loadTemplate("_front-side-bar.html")->display($context);
        // line 61
        echo "\t\t\t<div class=\"main-content\">
\t\t\t\t<div class=\"main-content-inner\">
\t\t\t\t\t<div class=\"page-content\">
\t\t\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t\t\t<h1>
\t\t\t\t\t\t\t\tDashboard
\t\t\t\t\t\t\t\t";
        // line 67
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") != "dashboard")) {
            // line 68
            echo "\t\t\t\t\t\t\t\t<small>
\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-angle-double-right\"></i>
\t\t\t\t\t\t\t\t\t";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</small>
\t\t\t\t\t\t\t\t";
        }
        // line 73
        echo "\t\t\t\t\t\t\t</h1>
\t\t\t\t\t\t</div><!-- /.page-header -->

\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-xs-12\">
\t\t\t\t\t\t\t\t<!-- PAGE CONTENT BEGINS -->
\t\t\t\t\t\t\t\t";
        // line 79
        $this->displayBlock('body', $context, $blocks);
        // line 80
        echo "\t\t\t\t\t\t\t\t<!-- PAGE CONTENT ENDS -->
\t\t\t\t\t\t\t</div><!-- /.col -->
\t\t\t\t\t\t</div><!-- /.row -->
\t\t\t\t\t</div><!-- /.page-content -->
\t\t\t\t</div>
\t\t\t</div><!-- /.main-content -->

\t\t\t";
        // line 87
        $this->env->loadTemplate("_front-footer.html")->display($context);
        // line 88
        echo "\t\t</div><!-- /.main-container -->

\t\t";
        // line 90
        $this->displayBlock('footer', $context, $blocks);
        // line 364
        echo "\t\t";
        $this->env->loadTemplate("_front-profile.html")->display($context);
        // line 365
        echo "\t\t";
        $this->env->loadTemplate("_front-profile-avtar.html")->display($context);
        // line 366
        echo "\t\t";
        if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u"))) {
            // line 367
            echo "\t\t\t";
            $this->env->loadTemplate("_front-settings.html")->display($context);
            // line 368
            echo "\t\t\t";
            $this->env->loadTemplate("_front-join-group.html")->display($context);
            // line 369
            echo "\t\t";
        }
        // line 370
        echo "\t\t";
        if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s"))) {
            // line 371
            echo "\t\t\t";
            $this->env->loadTemplate("_front-failed-controls.html")->display($context);
            // line 372
            echo "\t\t";
        }
        // line 373
        echo "\t\t";
        if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "c") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u"))) {
            // line 374
            echo "\t\t\t";
            $this->env->loadTemplate("_front-comment-to-admin.html")->display($context);
            // line 375
            echo "\t\t\t
\t\t";
        }
        // line 377
        echo "\t\t";
        $this->env->loadTemplate("_front-latest-chats.html")->display($context);
        // line 378
        echo "\t</body>
</html>
";
    }

    // line 4
    public function block_head($context, array $blocks = array())
    {
        // line 5
        echo "\t\t<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />
\t\t<meta charset=\"utf-8\" />
\t\t<title>";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pagetitle"), "html", null, true);
        echo "</title>

\t\t<meta name=\"description\" content=\"top menu &amp; navigation\" />
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0\" />

\t\t<!-- bootstrap & fontawesome -->
\t\t<link rel=\"stylesheet\" href=\"/assets/css/bootstrap.css\" />
\t\t<link rel=\"stylesheet\" href=\"/assets/css/font-awesome.min.css\" />

\t\t<!-- page specific plugin styles -->

\t\t<!-- text fonts -->
\t\t<link rel=\"stylesheet\" href=\"/assets/css/ace-fonts.css\" />

\t\t<!-- ace styles -->
\t\t<link rel=\"stylesheet\" href=\"/assets/css/ace.css\" class=\"ace-main-stylesheet\" id=\"main-ace-style\" />
\t\t<link rel=\"stylesheet\" href=\"/assets/css/ace-skins.css\" class=\"ace-main-stylesheet\" id=\"main-ace-style\" />
\t\t<link rel=\"stylesheet\" href=\"/assets/css/security.css\" class=\"ace-main-stylesheet\" id=\"main-ace-style\" />

\t\t<!--[if lte IE 9]>
\t\t\t<link rel=\"stylesheet\" href=\"/assets/css/ace-part2.css\" class=\"ace-main-stylesheet\" />
\t\t<![endif]-->

\t\t<!--[if lte IE 9]>
\t\t  <link rel=\"stylesheet\" href=\"/assets/css/ace-ie.css\" />
\t\t<![endif]-->

\t\t<!-- inline styles related to this page -->

\t\t<!-- ace settings handler -->
\t\t<script src=\"/assets/js/ace-extra.js\"></script>

\t\t<!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

\t\t<!--[if lte IE 8]>
\t\t<script src=\"/assets/js/html5shiv.js\"></script>
\t\t<script src=\"/assets/js/respond.js\"></script>
\t\t<![endif]-->
\t\t<style type=\"text/css\">
\t\t\t.progress { position:relative; width:400px; border: 1px solid #ddd; border-radius: 3px; margin:55px 0px 0px 0px; height:27px; }
\t\t\t.bar { background-color: #5cb85c; width:0%; height:27px; border-radius: 3px; }
\t\t\t.percent { position:absolute; display:inline-block; top:3px; left:48%; }
\t\t\t#status { margin-bottom:0px; margin-top:10px; padding:10px; }
\t\t\tinput[type=\"file\"] { margin-top:5px; }
\t\t</style>
";
    }

    // line 79
    public function block_body($context, array $blocks = array())
    {
    }

    // line 90
    public function block_footer($context, array $blocks = array())
    {
        // line 91
        echo "\t\t<!-- basic scripts -->

\t\t<!--[if !IE]> -->
\t\t<script type=\"text/javascript\">
\t\t\twindow.jQuery || document.write(\"<script src='/assets/js/jquery.js'>\"+\"<\"+\"/script>\");
\t\t</script>

\t\t<!-- <![endif]-->

\t\t<!--[if IE]>
<script type=\"text/javascript\">
 window.jQuery || document.write(\"<script src='/assets/js/jquery1x.js'>\"+\"<\"+\"/script>\");
</script>
<![endif]-->
\t\t<script type=\"text/javascript\">
\t\t\tif('ontouchstart' in document.documentElement) document.write(\"<script src='/assets/js/jquery.mobile.custom.js'>\"+\"<\"+\"/script>\");
\t\t</script>
\t\t<script src=\"/assets/js/bootstrap.js\"></script>

\t\t<!-- page specific plugin scripts -->

\t\t<!-- ace scripts -->
\t\t<script src=\"/assets/js/ace/elements.scroller.js\"></script>
\t\t<script src=\"/assets/js/ace/ace.js\"></script>
\t\t<script src=\"/assets/js/ace/ace.sidebar.js\"></script>
\t\t<script src=\"/assets/js/jquery.form.js\"></script>
\t\t<script>
\t\tfunction getnotifications() {
\t\t\ttheurl = '/getnotifications.php';
\t\t\t  \$.ajax({
\t\t\t\turl: theurl,
\t\t\t\tdata:'',
\t\t\t\tsuccess: function(data) {
\t\t\t\t  var jsonStr = jQuery.parseJSON(data);
\t\t\t\t  \$(\".notifications\").attr(\"title\",jsonStr.counter+ \" new messages\");
\t\t\t\t  \$(\".notifications\").text(jsonStr.counter);
\t\t\t\t  /*\$.each(jsonStr.msgs, function(i) {
\t\t\t\t\t  \$.each(jsonStr.msgs[i], function(key,val) {
\t\t\t\t\t\tvar msgdata = val.split(\"^^^\");
\t\t\t\t\t\tvar msgid = msgdata[2];
\t\t\t\t\t\tif(!\$(\"li#msg\"+msgid).text()){
\t\t\t\t\t\t\tvar _li = '<li id=\"msg'+msgid+'\"><ahref=\"#\" data-toggle=\"modal\" data-target=\"#show_msgs\" ><small><b>'+msgdata[0]+'</b>:'+msgdata[1]+'</a></li>';
\t\t\t\t\t\t
\t\t\t\t\t\t\t\$(\"ul#msg_list\").append(_li);
\t\t\t\t\t\t}
\t\t\t\t\t  });
\t\t\t\t\t});
\t\t\t\t  */
\t\t\t\t}
\t\t\t  });
\t\t\t  setTimeout(getnotifications, 5000); // you could choose not to continue on failure...
\t\t}
\t\t\$(document).ready(function() {
\t\t\t// run the first time; all subsequent calls will take care of themselves
\t\t\tsetTimeout(getnotifications,1000);
\t\t});
\t\tfunction save_gen_comment(inputId,pid,company_id)
\t\t{
\t\t\t
\t\t\tvar from_id \t\t= ";
        // line 150
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method"), "html", null, true);
        echo ";
\t\t\tvar sent_from_role \t= '";
        // line 151
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method"), "html", null, true);
        echo "';
\t\t\t
\t\t\tvar toid = \$('select#toid').val();

\t\t\tif(toid){
\t\t\t\tif(toid == 0){
\t\t\t\t\tvar sent_to_id \t\t= \$(\"#group_id\").val();
\t\t\t\t\tvar sent_to_role \t= 'g';
\t\t\t\t\t
\t\t\t\t}
\t\t\t\tif( Number(toid) > 0){
\t\t\t\t\tvar sent_to_id \t\t= toid;
\t\t\t\t\tvar sent_to_role \t= 'u';
\t\t\t\t\t
\t\t\t\t}
\t\t\t\tformfields = 'company_id='+company_id+'&sent_from_id='+from_id+'&sent_from_role='+sent_from_role+'&sent_to_id='+sent_to_id+'&sent_to_role='+sent_to_role+'&chat_type=0';
\t\t\t\t\ttheurl = '/createchatroom.php';
\t\t\t\t\tvar room_id = \$.ajax({
\t\t\t\t\t\ttype: \"POST\",
\t\t\t\t\t\turl: theurl,
\t\t\t\t\t\tdata: formfields,
\t\t\t\t\t\tasync: !1,
\t\t\t\t\t\tdataType:'html',
\t\t\t\t\t\tbeforeSend: function( xhr ) {
\t\t\t\t\t\t},
\t\t\t\t\t\tsuccess:(function(response) { 
\t\t\t\t\t\t\treturn response;
\t\t\t\t\t\t}),
\t\t\t\t\t}).responseText;
\t\t\t\t\t
\t\t\t}else{ 
\t\t\t\tvar room_id \t\t= \$('input#room_id').val();
\t\t\t}
\t\t\t
\t\t\tvar comment = \$('#'+inputId).val();
\t\t\t//var comment = \$('#gen_comment').val();
\t\t\t\$('#gen_comment').val('');
\t\t\tif( comment )
\t\t\t{\t
\t\t\t\tvar regEx = /[A-Za-z0-9-\\/\\.,:;@#% /\\&()]/gi;
\t\t\t\tvar validate_arr = comment.match(regEx);
\t\t\t\tif(validate_arr)
\t\t\t\t{
\t\t\t\t\tcomment = comment.replace(\"\\n\", \"<br />\");
\t\t\t\t\tcomment = comment.replace(\"\\r\", \"\"); 
\t\t\t\t}
\t\t\t\telse
\t\t\t\t{
\t\t\t\t\treturn false;
\t\t\t\t}
\t\t\t}
\t\t\telse
\t\t\t{
\t\t\t\treturn false;
\t\t\t}
\t\t\tcomment = comment.replace(\"\\n\", \"<br />\");
\t\t\tcomment = comment.replace(\"\\r\", \"\");
\t\t\tfields = 'room_id='+room_id+'&comment='+comment+'&from_id='+from_id+'&pid='+pid;
\t\t\ttheurl = '/save-chats.php';
\t\t\t\$.ajax({
\t\t\t\ttype: \"POST\",
\t\t\t\turl: theurl,
\t\t\t\tdata: fields,
\t\t\t\tbeforeSend: function( xhr ) {
\t\t\t\t}
\t\t\t}).done(function(data) {
\t\t\t\t
\t\t\t});
\t\t}
\t\tfunction save_procedure_chats(inputId){
\t\t\tvar pid = \$('#c_proc_id').val();
\t\t\tvar company_id = \$('#id').val();
\t\t\tsave_gen_comment(inputId,pid, company_id);
\t\t}
\t\tfunction setvalue(pid, company_id,commented_to, doc_id, to_user_id, chat_tye)
\t\t\t{
\t\t\t\t
\t\t\t\t\$('input#room_id').val('');
\t\t\t\tvar room_id = 0;
\t\t\t\t\$('#cno').val(pid);
\t\t\t\t\$('#c_proc_id').val(pid);
\t\t\t\t\$('#comment').val(\$('#comment'+pid).val());
\t\t\t\tvar company_id = \$('#id').val();
\t\t\t\tvar userrole = '";
        // line 234
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method"), "html", null, true);
        echo "';
\t\t\t\tvar headingCommentTo = '';
\t\t\t\tif(commented_to == 'u')
\t\t\t\t{
\t\t\t\t\theadingCommentTo = 'Comment to User';
\t\t\t\t}
\t\t\t\telse if(commented_to == 's') 
\t\t\t\t{
\t\t\t\t\theadingCommentTo = 'Comment to QSA';
\t\t\t\t}
\t\t\t\telse
\t\t\t\t{
\t\t\t\t\theadingCommentTo = 'Comment to QA';
\t\t\t\t}
\t\t\t\t\$('div#div-comment #myModalLabel').html(headingCommentTo);
\t\t\t\tvar sent_from_id = ";
        // line 249
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method"), "html", null, true);
        echo ";
\t\t\t\t
\t\t\t\tformfields = 'pid='+pid+'&company_id='+company_id+'&commented_by='+userrole+'&commented_to='+commented_to+'&doc_id='+doc_id+'&to_user_id='+to_user_id;
\t\t\t\ttheurl = '/comments.php';
\t\t\t\t\$.ajax({
\t\t\t\t\ttype: \"POST\",
\t\t\t\t\turl: theurl,
\t\t\t\t\tdata: formfields,
\t\t\t\t\tbeforeSend: function( xhr ) {
\t\t\t\t\t}
\t\t\t\t}).done(function(data) {
\t\t\t\t\t//
\t\t\t\t\tvar jsonStr = jQuery.parseJSON(data);
\t\t\t\t\t//var  chat_tye = '0';  // 0= procedure chat, 1 = personal chat, 2 = group chat(between QA QSA and users)
\t\t\t\t\t
\t\t\t\t\t\$('div#allcomments').html(jsonStr.content);
\t\t\t\t\tif(chat_tye != 3){
\t\t\t\t\t\tif(jsonStr.userIds){
\t\t\t\t\t\t \$.each(jsonStr.userIds, function(key,val) {
\t\t\t\t\t\t\t room_id = createchatroom(company_id,userrole, sent_from_id, 'u', val, chat_tye);
\t\t\t\t\t\t });\t\t\t\t
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t\tif(jsonStr.groupId){
\t\t\t\t\t\t room_id = createchatroom(company_id,userrole, sent_from_id, 'g', jsonStr.groupId, chat_tye);
\t\t\t\t\t}
\t\t\t\t\t
\t\t\t\t\tif( commented_to == 'q'){ 
\t\t\t\t\t\t
\t\t\t\t\t\t room_id = createchatroom(company_id,userrole, sent_from_id, commented_to, to_user_id, 0);
\t\t\t\t\t}
\t\t\t\t\t// in case of QA login user here we have multiple assessors (QSA) of company so first we will needed to fetch all assessors and then we will create individual room for each assessor and on common room for all assessors
\t\t\t\t\t
\t\t\t\t\tif(room_id == 0 ){
\t\t\t\t\t\tif(commented_to == 'u'){
\t\t\t\t\t\t\talert(\"This task has not assigned to any group yet\");
\t\t\t\t\t\t\treturn false;
\t\t\t\t\t\t}
\t\t\t\t\t\tif(commented_to == 's'){
\t\t\t\t\t\t\tvar data = getassessors(company_id,sent_from_id,userrole,pid);
\t\t\t\t\t\t\tvar assessors = jQuery.parseJSON(data);
\t\t\t\t\t\t\tif(assessors.data){
\t\t\t\t\t\t\t\t\$('div#allcomments').append(assessors.data);
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\$.each(assessors.ids, function(key,val){
\t\t\t\t\t\t\t\troom_id = createchatroom(company_id,userrole, sent_from_id, 's', val, chat_tye);
\t\t\t\t\t\t\t\tgetchats(room_id, pid,'0', 's', sent_from_id, chat_tye);
\t\t\t\t\t\t\t});
\t\t\t\t\t\t}\t
\t\t\t\t\t}
\t\t\t\t\telse{
\t\t\t\t\t\t\$('input#room_id').val(room_id);
\t\t\t\t\t\t\$('input#chat_tye').val(room_id);
\t\t\t\t\t\tvar toid = \$('select#toid').val();
\t\t\t\t\t\tif(Number(chat_tye) != 3){
\t\t\t\t\t\t\tif(toid){
\t\t\t\t\t\t\t\t//initially we load group chat threads
\t\t\t\t\t\t\t\tgetchats(room_id, pid,'0', 'g', sent_from_id, chat_tye);
\t\t\t\t\t\t\t}else{
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\tgetchats(room_id, pid,'0', commented_to, sent_from_id, chat_tye);
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t\tif(Number(chat_tye) == 3){
\t\t\t\t\t\t\tgetchats(room_id, pid,'0', 'g', sent_from_id, chat_tye);
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t});
\t\t\t}
\t\t\tfunction getassessors(company_id,uid,userrole,pid){
\t\t\t\tformfields = 'cid='+company_id;
\t\t\t\ttheurl = '/getassessors.php';
\t\t\t\tvar assessors = \$.ajax({
\t\t\t\t\t\t\t\t\ttype: \"POST\",
\t\t\t\t\t\t\t\t\turl: theurl,
\t\t\t\t\t\t\t\t\tdata: formfields,
\t\t\t\t\t\t\t\t\tasync: !1,
\t\t\t\t\t\t\t\t\tdataType:'html',
\t\t\t\t\t\t\t\t\tbeforeSend: function( xhr ) {
\t\t\t\t\t\t\t\t\t},
\t\t\t\t\t\t\t\t\tsuccess:(function(response) { 
\t\t\t\t\t\t\t\t\t\treturn response;
\t\t\t\t\t\t\t\t\t}),
\t\t\t\t\t\t\t\t}).responseText;
\t\t\t\treturn assessors;\t\t\t\t
\t\t\t}
\t\t\tfunction getchats(room_id,procedure_id,chat_type, send_to_role, from_id, chat_tye){
\t\t\t\t\tvar flds = 'procedure_id='+procedure_id+'&chat_type='+chat_type+'&room_id='+room_id+'&to_role='+send_to_role+'&from_id='+from_id;
\t\t\t\t\t\$.ajax({
\t\t\t\t\t\ttype: \"POST\",
\t\t\t\t\t\turl: '/getchats.php',
\t\t\t\t\t\tdata: flds,
\t\t\t\t\t\tbeforeSend: function( xhr ) {
\t\t\t\t\t\t}
\t\t\t\t\t}).done(function(data1) {
\t\t\t\t\t\t
\t\t\t\t\t\t\$('div.chat-list').remove();
\t\t\t\t\t\t\$('div#allcomments').append(data1);
\t\t\t\t\t});
\t\t\t}
\t\t\tfunction getroomchats(company_id, current_user_id, current_user_role, to_group_id, to_user_id, procedure_id){
\t\t\t\tif(to_user_id == 0){
\t\t\t\t\tvar to_role \t= 'g';
\t\t\t\t\tvar to_id \t\t= to_group_id;
\t\t\t\t\tvar chat_type\t= '0';
\t\t\t\t}
\t\t\t\tif(to_user_id != 0){
\t\t\t\t\tvar to_role \t= 'u';
\t\t\t\t\tvar to_id \t\t= to_user_id;
\t\t\t\t\tvar chat_type\t= '0';
\t\t\t\t}
\t\t\t\tgetchats(company_id,procedure_id,current_user_id, current_user_role, to_id, to_role, chat_type);
\t\t\t}
\t\t</script>
\t\t";
    }

    public function getTemplateName()
    {
        return "new-front-layout.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  370 => 249,  352 => 234,  266 => 151,  262 => 150,  201 => 91,  198 => 90,  193 => 79,  143 => 7,  139 => 5,  136 => 4,  130 => 378,  127 => 377,  123 => 375,  120 => 374,  117 => 373,  114 => 372,  111 => 371,  108 => 370,  105 => 369,  102 => 368,  99 => 367,  96 => 366,  93 => 365,  90 => 364,  88 => 90,  84 => 88,  82 => 87,  73 => 80,  71 => 79,  63 => 73,  57 => 70,  53 => 68,  51 => 67,  43 => 61,  41 => 60,  36 => 57,  34 => 56,  29 => 53,  27 => 4,  22 => 1,);
    }
}
