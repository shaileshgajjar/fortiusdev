<?php

/* assessment-connected-entities.html */
class __TwigTemplate_8f6d6c22ac0751777ff144df88a55f08 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 16
            echo "\t<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 35
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 36
            echo "      <!-- Tab panes -->
        <div class=\"tab-content tab_border\">
\t\t<div role=\"tabpanel\" class=\"tab-pane active\" id=\"screen1\">
            <div class=\"screen7_inner_part widget-box widget-color-blue\">
                <div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i> 3 Description of SOW &amp; Approach Taken </h4>
                </div>
                
                <div class=\"widget-body\">
                \t<div class=\"widget-main widget_main_extra_part\">
                    <div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\"> 3.5 Connected entities for processing </div>
\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\tComplete the following for connected entities for processing. If the assessor needs to include additional reporting for the specific brand and/or acquirer, it can be included either here within 3.5 or as an appendix at the end of this report. Do not alter the Attestation of Compliance (AOC) for this purpose.
\t\t\t\t    </div>
                    \t<div class=\"screen9_table_block_part screen10_extra\">
                            <div class=\"table-responsive screen_field_part\">
                                <table class=\"table table-striped\" id=\"tbl1\">
                                  <thead>
                                    <tr>
                                      <th class=\"col-md-4\" rowspan=\"2\">Identify All Processing Entities<br /> (Acquirer/ Bank / Brands directly connected to for processing)</th>
\t\t\t\t\t\t\t\t\t  <th class=\"col-md-2 center\"  rowspan=\"2\">Directly Connected? <br/ >(yes/no)</th>
\t\t\t\t\t\t\t\t\t  <th class=\"col-md-6 center\" colspan=\"2\" >
\t\t\t\t\t\t\t\t\t\tReason(s) for Connection:
\t\t\t\t\t\t\t\t\t  </th>
\t\t\t\t\t\t\t\t\t  <th class=\"col-md-4\" rowspan=\"2\">Description of any discussions/issues between the <br /> QSA and Processing Entity on behalf of the <br /> Assessed Entity for this PCI DSS Assessment (if any)</th>
\t\t\t\t\t\t\t\t\t </tr>
\t\t\t\t\t\t\t\t\t <tr class=\"center\"><th class=\"center\">Processing</th><th class=\"center\">Transmission</th></tr>

                                  </thead>
                                  <tbody>
\t\t\t\t\t\t\t\t\t";
            // line 66
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "apps"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 67
                echo "                                    <tr>
\t\t\t\t\t\t\t\t\t
                                      <th class=\"col-md-6 col-sm-6 col-xs-6 widget_textarea_extra\"><textarea name=\"sec_3_5_entities[]\" class=\"form-control\" rows=\"2\"  required>";
                // line 69
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "sec_3_5_entities"), "html", null, true);
                echo "</textarea></th>
                                      
\t\t\t\t\t\t\t\t\t <th class=\"center\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock\">
\t\t\t\t\t\t\t\t\t\t\t\t<input id=\"sec_3_5_connected-1-";
                // line 73
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"1\" ";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "sec_3_5_connected") == "yes")) {
                    echo " checked=\"checked\"";
                }
                echo " name=\"sec_3_5_connected1[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\"> 
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"sec_3_5_connected[]\" id=\"sec_3_5_connected";
                // line 74
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "sec_3_5_connected"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</th>
\t\t\t\t\t\t\t\t\t<th class=\"center\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock\">
\t\t\t\t\t\t\t\t\t\t\t\t<input id=\"sec_3_5_processing-1-";
                // line 79
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"1\" ";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "sec_3_5_processing") == "yes")) {
                    echo " checked=\"checked\"";
                }
                echo " name=\"sec_3_5_processing1[]\" data-size=\"large\" data-handle-width=\"65\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"Uncheck\" data-on-text=\"Check\"> 
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"sec_3_5_processing[]\" id=\"sec_3_5_processing";
                // line 80
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "sec_3_5_processing"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</th>
\t\t\t\t\t\t\t\t\t<th class=\"center\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock\">
\t\t\t\t\t\t\t\t\t\t\t\t<input id=\"sec_3_5_trans-1-";
                // line 85
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"1\" ";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "sec_3_5_trans") == "yes")) {
                    echo " checked=\"checked\"";
                }
                echo " name=\"sec_3_5_trans1[]\" data-size=\"large\" data-handle-width=\"65\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"Uncheck\" data-on-text=\"Check\"> 
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"sec_3_5_trans[]\" id=\"sec_3_5_trans";
                // line 86
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "sec_3_5_trans"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</th>
\t\t\t\t\t\t\t\t\t 
\t\t\t\t\t\t\t\t\t<th class=\"col-md-6 col-sm-6 col-xs-6 widget_textarea_extra\"><textarea name=\"sec_3_5_description[]\" class=\"form-control\" rows=\"2\"  required>";
                // line 90
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "sec_3_5_description"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t";
                // line 92
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 93
                    echo "\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t";
                }
                // line 95
                echo "\t\t\t\t\t\t\t\t\t</th>
                                    </tr>
\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 97
            echo "\t
                                  </tbody>
                                </table>
                                <table class=\"table table-striped\">
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\"> <div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow();\" > Add New </div> </td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\tOther details, if applicable (add content or tables here for brand/acquirer  use, if needed):
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-6 col-sm-6 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t\t\t <textarea name=\"connected_ent_other_data\" id=\"connected_ent_other_data\" class=\"form-control\" rows=\"2\" placeholder=\"Please Enter here\">";
            // line 110
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "connected_ent_other_data"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
                                </table>
                              </div>
                              
                        </div>
                         <button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 118
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t \t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\" id=\"validateBtn\" >Next <span><i class=\"fa fa-arrow-right\" ></i></span> </button>
                    </div>
                </div>
            </div>
        </div>
      </div>
\t  </form>
    </div>
";
        }
    }

    // line 129
    public function block_footer($context, array $blocks = array())
    {
        // line 130
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script src=\"/assets/js/chosen.jquery.js\"></script>
\t<link href=\"/assets/css/bootstrap-switch.css\" type=\"text/css\" rel=\"stylesheet\">
\t<script src=\"/assets/js/bootstrap-switch.js\"></script>
\t
<script type=\"text/javascript\">
";
        // line 143
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 144
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 148
            echo "
rowno = ";
            // line 149
            echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "apps")), "html", null, true);
            echo ";
\$(document).ready(function() {
   
\t\$('#frm').bootstrapValidator();
\t\$(\".switch\").bootstrapSwitch();
\t\$(\"#tbl1\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\tary = \$(this).attr('id').split('-');
\t\tval = state ? 'yes' : 'no';
\t\t\$('#'+ary[0]+ary[2]).val(val);
\t});
\t
});
";
        }
        // line 165
        echo "function addrow()
{
\t
\thtml = '';
\thtml = html + '<tr>';
\thtml = html + '\t<th class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"sec_3_5_entities[]\" class=\"form-control\" rows=\"3\"   required></textarea></th>';
\thtml = html + '\t<th class=\"center\">';
\thtml = html + '\t\t<div class=\"lockunlock\">';
\thtml = html + '\t\t\t<input id=\"sec_3_5_connected-1-'+rowno+'\" value=\"1\" name=\"sec_3_5_connected[]\" data-size=\"large\" data-handle-width=\"16\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">';
\thtml = html + '\t\t\t<input type=\"hidden\" name=\"sec_3_5_connected[]\" id=\"sec_3_5_connected'+rowno+'\" value=\"no\" />';
\thtml = html + '\t\t</div>';
\thtml = html + '\t</th>';
\thtml = html + '\t<th class=\"center\">';
\thtml = html + '\t\t<div class=\"lockunlock\">';
\thtml = html + '\t\t\t<input id=\"sec_3_5_processing-1-'+rowno+'\" value=\"1\" name=\"sec_3_5_processing[]\" data-size=\"large\" data-handle-width=\"65\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"Uncheck\" data-on-text=\"Check\">';
\thtml = html + '\t\t\t<input type=\"hidden\" name=\"sec_3_5_processing[]\" id=\"sec_3_5_processing'+rowno+'\" value=\"no\" />';
\thtml = html + '\t\t</div>';
\thtml = html + '\t</th>';
\thtml = html + '\t<th class=\"center\">';
\thtml = html + '\t\t<div class=\"lockunlock\">';
\thtml = html + '\t\t\t<input id=\"sec_3_5_trans-1-'+rowno+'\" value=\"1\" name=\"sec_3_5_trans[]\" data-size=\"large\" data-handle-width=\"65\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"Uncheck\" data-on-text=\"Check\">';
\thtml = html + '\t\t\t<input type=\"hidden\" name=\"sec_3_5_trans[]\" id=\"sec_3_5_trans'+rowno+'\" value=\"no\" />';
\thtml = html + '\t\t</div>';
\thtml = html + '\t</th>';
\thtml = html + '\t<th class=\"col-md-6 col-sm-6 col-xs-6 widget_textarea_extra\">';
\thtml = html + '\t\t<textarea name=\"sec_3_5_description[]\" class=\"form-control\" rows=\"3\"   required></textarea>'
\thtml = html + '\t\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>';
\thtml = html + '\t</th>';
\thtml = html + '</tr>';
\t\$(\"#tbl1\").append(html);
\t\$(\".switch\").bootstrapSwitch();
\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\tary = \$(this).attr('id').split('-');
\t\tval = state ? 'yes' : 'no';
\t\t\$('#'+ary[0]+ary[2]).val(val);
\t});
\trowno++;
}
</script>
";
    }

    public function getTemplateName()
    {
        return "assessment-connected-entities.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  359 => 165,  340 => 149,  337 => 148,  331 => 144,  329 => 143,  312 => 130,  309 => 129,  294 => 118,  283 => 110,  268 => 97,  252 => 95,  248 => 93,  246 => 92,  241 => 90,  232 => 86,  224 => 85,  214 => 80,  206 => 79,  196 => 74,  188 => 73,  181 => 69,  177 => 67,  160 => 66,  128 => 36,  126 => 35,  121 => 33,  117 => 32,  113 => 31,  109 => 30,  104 => 28,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  75 => 16,  69 => 13,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
