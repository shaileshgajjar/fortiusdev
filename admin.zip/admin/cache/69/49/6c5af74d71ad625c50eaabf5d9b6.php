<?php

/* _settings.html */
class __TwigTemplate_69496c5af74d71ad625c50eaabf5d9b6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t<div class=\"modal fade\" id=\"settings\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Assessor Company Details</h4>
\t\t\t</div>
\t\t\t<form class=\"form-horizontal bv-form\" name=\"frmsettings\" id=\"frmsettings\" method=\"post\" action=\"\"
\t\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\">
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save_settings\" />
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Company Name</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"assr_company_name\" id=\"assr_company_name\" autocomplete=\"off\"
\t\t\t\t\t\t\trequired type=\"text\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "settings"), "assr_company_name"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Company Address</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"assr_company_address\" id=\"assr_company_address\" autocomplete=\"off\"
\t\t\t\t\t\t\trequired type=\"text\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "settings"), "assr_company_address"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\"> Company URL</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"assr_company_url\" id=\"assr_company_url\" autocomplete=\"off\"
\t\t\t\t\t\t\ttype=\"url\" value=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "settings"), "assr_company_url"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\"> Upcoming Task Reminder Days </label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"upcoming_reminder\" id=\"upcoming_reminder\" autocomplete=\"off\"
\t\t\t\t\t\t\ttype=\"url\" value=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "settings"), "upcoming_reminder"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\"> Over Due Later Reminder Days </label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"over_due_reminder\" id=\"over_due_reminder\" autocomplete=\"off\"
\t\t\t\t\t\t\ttype=\"url\" value=\"";
        // line 47
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "settings"), "over_due_reminder"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\"> Failed Controls Reminder Days </label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"failed_task_due_date\" id=\"failed_task_due_date\" autocomplete=\"off\"
\t\t\t\t\t\t\ttype=\"url\" value=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "settings"), "failed_task_due_date"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Email From</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"email_from\" id=\"email_from\" autocomplete=\"off\"
\t\t\t\t\t\t\ttype=\"url\" value=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "settings"), "email_from"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Spark Post Key</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"sparkpost_key\" id=\"sparkpost_key\" autocomplete=\"off\"
\t\t\t\t\t\t\ttype=\"url\" value=\"";
        // line 68
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "settings"), "sparkpost_key"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-lg-4 control-label\">Spark Post URL</label>
\t\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t\t<input class=\"form-control\" name=\"sparkpost_end_url\" id=\"sparkpost_end_url\" autocomplete=\"off\"
\t\t\t\t\t\t\ttype=\"url\" value=\"";
        // line 75
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "settings"), "sparkpost_end_url"), "value"), "html", null, true);
        echo "\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"modal-footer\">
\t\t\t\t<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
\t\t\t\t<button type=\"submit\" onclick=\"savesettings();\" data-dismiss=\"modal\" class=\"btn btn-primary\">Save changes</button>
\t\t\t</div>
\t\t\t</form>
\t\t</div>
\t</div>
\t</div>
<script type=\"text/javascript\">
function savesettings()
{
\tformfields = \$('#frmsettings').serialize();
\ttheurl = '/savesettings.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t});
}
</script>
";
    }

    public function getTemplateName()
    {
        return "_settings.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 75,  109 => 68,  99 => 61,  89 => 54,  79 => 47,  69 => 40,  59 => 33,  49 => 26,  39 => 19,  19 => 1,);
    }
}
