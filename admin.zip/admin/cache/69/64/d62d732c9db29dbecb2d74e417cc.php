<?php

/* getassigntasks.html */
class __TwigTemplate_6964d62d732c9db29dbecb2d74e417cc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t\t\t\t\t\t\t";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 2
            echo "\t\t\t\t\t\t\t\t";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "usercan") == "1")) {
                // line 3
                echo "\t\t\t\t\t\t\t\t";
                $context["bgclass"] = "alert-info";
                // line 4
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "Y")) {
                    // line 5
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["bgclass"] = "alert-success";
                    // line 6
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 7
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "N")) {
                    // line 8
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["bgclass"] = "alert-danger";
                    // line 9
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 10
                echo "\t\t\t\t\t\t\t\t<div class=\"number alert ";
                echo twig_escape_filter($this->env, (isset($context["bgclass"]) ? $context["bgclass"] : null), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"assignchk";
                // line 11
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id"), "html", null, true);
                echo "\" name=\"doc_id";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id"), "html", null, true);
                echo "[]\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "\"";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "dugid") != "")) {
                    echo " checked=\"checked\"";
                }
                echo " /> &nbsp;";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "ptitle"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div style=\"clear:both;\"></div>
\t\t\t\t\t\t\t\t";
            }
            // line 15
            echo "\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
    }

    public function getTemplateName()
    {
        return "getassigntasks.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 15,  53 => 11,  48 => 10,  45 => 9,  42 => 8,  39 => 7,  36 => 6,  33 => 5,  30 => 4,  27 => 3,  24 => 2,  19 => 1,);
    }
}
