<?php

/* _footer.html */
class __TwigTemplate_2b946fe254edc21289c45d5ecb169788 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t\t\t<div class=\"footer\">
\t\t\t\t<div class=\"footer-inner\">
\t\t\t\t\t<!-- #section:basics/footer -->
\t\t\t\t\t<div class=\"footer-content\">
\t\t\t\t\t\t<span class=\"bigger-120\">
\t\t\t\t\t\t\t<span class=\"blue bolder\">Security</span>
\t\t\t\t\t\t\tApplication &copy; 2014-2015
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<!--
\t\t\t\t\t\t&nbsp; &nbsp;
\t\t\t\t\t\t<span class=\"action-buttons\">
\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-twitter-square light-blue bigger-150\"></i>
\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-facebook-square text-primary bigger-150\"></i>
\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-rss-square orange bigger-150\"></i>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t-->
\t\t\t\t\t</div>

\t\t\t\t\t<!-- /section:basics/footer -->
\t\t\t\t</div>
\t\t\t</div>
";
    }

    public function getTemplateName()
    {
        return "_footer.html";
    }

    public function getDebugInfo()
    {
        return array (  366 => 124,  360 => 123,  358 => 122,  347 => 113,  341 => 112,  332 => 108,  327 => 106,  318 => 103,  315 => 102,  312 => 101,  309 => 100,  306 => 99,  304 => 98,  301 => 97,  297 => 96,  288 => 94,  279 => 90,  275 => 89,  263 => 85,  260 => 84,  257 => 83,  254 => 82,  249 => 80,  245 => 79,  242 => 78,  236 => 77,  227 => 73,  223 => 72,  214 => 69,  211 => 68,  208 => 67,  205 => 66,  202 => 65,  200 => 64,  193 => 62,  190 => 61,  184 => 60,  175 => 56,  171 => 55,  162 => 52,  159 => 51,  153 => 49,  150 => 48,  148 => 47,  141 => 45,  123 => 39,  119 => 38,  110 => 35,  107 => 34,  98 => 31,  95 => 30,  82 => 25,  66 => 20,  62 => 19,  43 => 11,  34 => 8,  30 => 7,  25 => 5,  354 => 229,  338 => 218,  321 => 206,  308 => 198,  294 => 95,  280 => 180,  266 => 86,  252 => 81,  237 => 152,  225 => 145,  212 => 137,  197 => 63,  185 => 120,  172 => 112,  157 => 102,  132 => 43,  118 => 78,  104 => 33,  90 => 60,  59 => 39,  102 => 61,  73 => 48,  50 => 23,  46 => 12,  40 => 10,  38 => 18,  19 => 1,  164 => 85,  161 => 84,  156 => 50,  106 => 4,  100 => 114,  94 => 112,  91 => 29,  85 => 49,  83 => 81,  74 => 74,  58 => 64,  54 => 62,  52 => 14,  44 => 55,  42 => 54,  37 => 9,  35 => 50,  27 => 6,  22 => 1,  152 => 58,  149 => 57,  145 => 46,  138 => 44,  129 => 47,  125 => 46,  121 => 45,  117 => 44,  113 => 7,  109 => 5,  105 => 41,  101 => 32,  97 => 113,  89 => 51,  84 => 37,  81 => 47,  78 => 24,  75 => 45,  72 => 73,  70 => 21,  64 => 67,  60 => 29,  32 => 3,  29 => 46,);
    }
}
