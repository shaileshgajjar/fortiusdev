<?php

/* _front-kanban-grid-users.html */
class __TwigTemplate_243bad2b55520233b11bd335de9085d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
<input type=\"hidden\" name=\"id\" id=\"id\" value=\"\" />
<input type=\"hidden\" name=\"requirements_id\" id=\"requirements_id\" value=\"\" />
<div class=\"kanban_board\">
<div class=\"col-lg-15\">
\t<div class=\"panel\">
\t\t<div class=\"panel-heading\" >
\t\t<div class=\"board_block_bg col-sm-3\" >
\t\t\t
\t\t\t<div class=\"col-sm-12 tasks\" ><strong>Completed Tasks &nbsp; <span class=\"badge badge-success\" title=\"Found ";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "cmpt"), 0), "filled"), "html", null, true);
        echo " tasks\"> ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "cmpt"), 0), "filled"), "html", null, true);
        echo " </span></strong></div> 
\t\t\t";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "cmpt"));
        foreach ($context['_seq'] as $context["key"] => $context["row"]) {
            // line 12
            echo "\t\t\t\t";
            $context["div_width"] = $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage");
            // line 13
            echo "\t\t\t\t\t";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage") > "85")) {
                // line 14
                echo "\t\t\t\t\t\t";
                $context["div_width"] = "85";
                // line 15
                echo "\t\t\t\t\t";
            }
            // line 16
            echo "\t\t\t\t
\t\t\t\t<div class=\"board_block_part\">
\t\t\t\t\t
\t\t\t\t\t<div class=\"board_block_inner_part\">
\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Compliance Due Date:</strong> ";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "compliance_due_date"), "html", null, true);
            echo " </span>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"><strong>Completed </strong><small>[";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "filled"), "html", null, true);
            echo " <i> Out-of </i> ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total"), "html", null, true);
            echo "]  </small></span>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> &nbsp; </span>
\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t<div class=\"time_manage_main completed\">
\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small><b>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
            echo "</b></small></span>
\t\t\t\t\t\t\t\t<div class=\"time_manage_comp\" style=\"width: ";
            // line 26
            echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
            echo "%;\" data-fill=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
            echo "%\">
\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t</div>\t\t\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 33
        echo "\t\t</div>
\t\t
\t\t<div class=\"board_block_bg col-sm-3\" >
\t\t\t<div class=\"col-sm-12 tasks\" ><strong>Upcoming Tasks &nbsp;</strong> <span class=\"badge badge-success\" id=\"uc-total\" title=\"\">  </span></div>
\t\t\t";
        // line 37
        if ($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "upcoming"), "thisweek")) {
            // line 38
            echo "\t\t\t\t\t
\t\t\t\t\t";
            // line 39
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "upcoming"), "thisweek"));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 40
                echo "\t\t\t\t\t<div class=\"board_block_part\">
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"board_block_inner_part\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<ul class=\"list_item_part task-status\">
\t\t\t\t\t\t\t\t<li class=\"space-left\"><h4>This Week </h4> </li>
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>No.of Tasks </strong><a href=\"javascript: filluserdata('";
                // line 46
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo "', 'user-data.php');\"><span class=\"badge badge-upcoming row-total\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total"), "html", null, true);
                echo "</span></a> </li> </li>
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Assigned To :</strong> <span class=\"caption\">";
                // line 47
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_group_name"), "html", null, true);
                echo " </span></li>
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Completion Date :</strong> <span class=\"caption\">";
                // line 48
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "cdate"), "html", null, true);
                echo " </span> </li>
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>PCI-DSS Requirements</strong> : &nbsp;&nbsp;#<a href=\"javascript: filluserdata('";
                // line 49
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo "', 'user-data.php');\"> ";
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo " </a><span class=\"badge badge-upcoming\" >";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "days_to_go"), "html", null, true);
                echo " Days to go</span></li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> No.of Tasks</span>
\t\t\t\t\t\t\t<!--<span class=\"pull-right \" data-target=\"#section_4\" data-toggle=\"collapse\" title=\"Click to Expand/Collapse below section\" aria-expanded=\"true\"><small>View All</small></span>\t-->\t\t\t\t
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 56
            echo "\t\t\t\t
\t\t\t";
        }
        // line 58
        echo "\t\t\t";
        if ($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "upcoming"), "nextweek")) {
            // line 59
            echo "\t\t\t\t\t";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "upcoming"), "nextweek"));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 60
                echo "\t\t\t\t\t<div class=\"board_block_part\">
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"board_block_inner_part\">
\t\t\t\t\t\t\t<ul class=\"list_item_part task-status\">
\t\t\t\t\t\t\t\t<li class=\"space-left\"><h4>Next Week </h4> </li>
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>No.of Tasks </strong><a href=\"javascript: filluserdata('";
                // line 65
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo "', 'user-data.php');\"><span class=\"badge badge-upcoming row-total\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total"), "html", null, true);
                echo "</span></a> </li> </li>
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Assigned To :</strong> ";
                // line 67
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_group_name"), "html", null, true);
                echo "</li>
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Completion Date  </strong> ";
                // line 68
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "cdate"), "html", null, true);
                echo " </li>
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>PCI-DSS Requirements</strong> : &nbsp;&nbsp;#<a href=\"javascript: filluserdata('";
                // line 69
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo "', 'user-data.php');\"> ";
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo " </a></li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t<!--<span class=\"pull-right \" data-target=\"#section_4\" data-toggle=\"collapse\" title=\"Click to Expand/Collapse below section\" aria-expanded=\"true\"><small>View All</small></span>\t-->\t\t\t\t
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 75
            echo "\t\t\t\t
\t\t\t";
        }
        // line 77
        echo "\t\t\t";
        if ($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "upcoming"), "nextmonth")) {
            echo "\t\t\t\t
\t\t\t\t\t";
            // line 78
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "upcoming"), "nextmonth"));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 79
                echo "\t\t\t\t\t<div class=\"board_block_part\">
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"board_block_inner_part\">
\t\t\t\t\t\t\t<ul class=\"list_item_part task-status\">
\t\t\t\t\t\t\t\t<li class=\"space-left\"></li>
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>No.of Tasks </strong><a href=\"javascript: filluserdata('";
                // line 84
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo "', 'user-data.php');\"><span class=\"badge badge-upcoming row-total\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total"), "html", null, true);
                echo "</span></a> </li> </li>
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Assigned To :</strong> ";
                // line 85
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_group_name"), "html", null, true);
                echo "</li>
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Completion Date : </strong> ";
                // line 86
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "cdate"), "html", null, true);
                echo " </li>
\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>PCI-DSS Requirements :</strong> : &nbsp;&nbsp;#<a href=\"javascript: filluserdata('";
                // line 87
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo "', 'user-data.php');\"> ";
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo " </a></li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t<!--<span class=\"pull-right \" data-target=\"#section_4\" data-toggle=\"collapse\" title=\"Click to Expand/Collapse below section\" aria-expanded=\"true\"><small>View All</small></span>\t-->\t\t\t\t
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 93
            echo "\t\t\t\t
\t\t\t";
        }
        // line 95
        echo "\t\t</div>
\t\t
\t\t<div class=\"board_block_bg col-sm-3\" >
\t\t\t<div class=\"col-sm-12 tasks\" ><strong>Failed Tasks</strong>&nbsp; <span class=\"badge badge-failed\" title=\"Found ";
        // line 98
        echo twig_escape_filter($this->env, count($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "failed")), "html", null, true);
        echo " tasks\"> ";
        echo twig_escape_filter($this->env, count($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "failed")), "html", null, true);
        echo " </span></div>
\t\t\t";
        // line 99
        if ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "failed")) {
            // line 100
            echo "\t\t\t\t";
            $context["total"] = 0;
            // line 101
            echo "\t\t\t\t";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "failed"));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 102
                echo "\t\t\t\t";
                $context["assigned_to"] = $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "uid"), "method");
                // line 103
                echo "\t\t\t\t\t
\t\t\t\t\t\t<div class=\"board_block_part\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"board_block_inner_part\">
\t\t\t\t\t\t\t\t<ul class=\"list_item_part task-status\">
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
                // line 109
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_id") == (isset($context["assigned_to"]) ? $context["assigned_to"] : null))) {
                    // line 110
                    echo "\t\t\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Assigned To :</strong> <span class=\"caption\"><a href=\"javascript: filluserdata('";
                    echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                    echo "', 'user-data.php');\"> ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "username"), "method"), "html", null, true);
                    echo " </a></span></li>
\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 112
                    echo "\t\t\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Owner Group :</strong> <span class=\"caption\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_group_name"), "html", null, true);
                    echo "</span></li>
\t\t\t\t\t\t\t\t\t";
                }
                // line 114
                echo "\t\t\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_id") == (isset($context["assigned_to"]) ? $context["assigned_to"] : null))) {
                    // line 115
                    echo "\t\t\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Procedure #:</strong> <a href=\"javascript: filluserdata('";
                    echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                    echo "', 'user-data.php');\"><span class=\"badge badge-failed\"> ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "number"), "html", null, true);
                    echo " </span></a></li>
\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 117
                    echo "\t\t\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Procedure #:</strong> <span class=\"badge badge-failed\"> ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "number"), "html", null, true);
                    echo " </span></li>
\t\t\t\t\t\t\t\t\t";
                }
                // line 119
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Updated On :</strong> <span class=\"caption\">";
                // line 120
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "updated_on"), "html", null, true);
                echo "</span> </li>
\t\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Completion Date :</strong> <span class=\"caption\">";
                // line 121
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "cdate"), "html", null, true);
                echo " </span></li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 122
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_id") == (isset($context["assigned_to"]) ? $context["assigned_to"] : null))) {
                    // line 123
                    echo "\t\t\t\t\t\t\t\t\t\t<a href=\"javascript: filluserdata('";
                    echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                    echo "', 'user-data.php');\"> <li class=\"space-left\"><strong>PCI-DSS Requirements</strong> : &nbsp;&nbsp;<span class=\"caption\"> # ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "rid"), "html", null, true);
                    echo "</span></li></a>
\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 125
                    echo "\t\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>PCI-DSS Requirements</strong> : &nbsp;&nbsp;<span class=\"caption\"># ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "rid"), "html", null, true);
                    echo "</span></li>
\t\t\t\t\t\t\t\t\t";
                }
                // line 127
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t<!--<span class=\"pull-right \" data-target=\"#section_4\" data-toggle=\"collapse\" title=\"Click to Expand/Collapse below section\" aria-expanded=\"true\"><small>View All</small></span>\t-->\t\t\t\t
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 133
            echo "\t\t";
        }
        // line 134
        echo "\t\t</div>
\t\t<div class=\"board_block_bg col-sm-3\" >
\t\t\t
\t\t\t";
        // line 137
        if ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "overdue")) {
            // line 138
            echo "\t\t\t\t<div class=\"col-sm-12 tasks\" > <strong>Overdue Tasks </strong>&nbsp;<span class=\"badge badge-overdue\" title=\"Found ";
            echo twig_escape_filter($this->env, count($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "overdue")), "html", null, true);
            echo " tasks\"> ";
            echo twig_escape_filter($this->env, count($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "overdue")), "html", null, true);
            echo " </span></div>
\t\t\t\t";
            // line 139
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "overdue"));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 140
                echo "\t\t\t\t<div class=\"board_block_part\">
\t\t\t\t\t
\t\t\t\t\t<div class=\"board_block_inner_part\">
\t\t\t\t\t\t
\t\t\t\t\t\t<ul class=\"list_item_part task-status\">
\t\t\t\t\t\t\t<li><strong>PCI-DSS Requirements</strong> : &nbsp;&nbsp;<span class=\"caption\">#<a href=\"javascript: filluserdata('";
                // line 145
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo "', 'user-data.php');\"> ";
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo " </a></span></li>
\t\t\t\t\t\t\t<li><strong>No. of  Tasks</strong> <a href=\"javascript: filluserdata('";
                // line 146
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo "', 'user-data.php');\"><span class=\"badge badge-overdue\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total"), "html", null, true);
                echo "</span></a></li>
\t\t\t\t\t\t\t";
                // line 147
                if ($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "updated_on")) {
                    // line 148
                    echo "\t\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Updated On :  </strong> <span class=\"caption\"> ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "updated_on"), "html", null, true);
                    echo " </span></li>
\t\t\t\t\t\t\t";
                }
                // line 150
                echo "\t\t\t\t\t\t\t<li class=\"space-left\"><strong>Completion Date :  </strong> <span class=\"caption\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "cdate"), "html", null, true);
                echo " </span> </li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t
\t\t\t\t\t\t<!--<span class=\"pull-right \" data-target=\"#section_4\" data-toggle=\"collapse\" title=\"Click to Expand/Collapse below section\" aria-expanded=\"true\"><small>View All</small></span>\t-->\t\t\t\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 157
            echo "\t\t";
        }
        // line 158
        echo "\t\t</div>
\t</div>
</div>
</div>
</form>";
    }

    public function getTemplateName()
    {
        return "_front-kanban-grid-users.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  412 => 158,  409 => 157,  389 => 148,  387 => 147,  381 => 146,  368 => 140,  364 => 139,  357 => 138,  355 => 137,  350 => 134,  347 => 133,  336 => 127,  322 => 123,  316 => 121,  312 => 120,  309 => 119,  303 => 117,  292 => 114,  286 => 112,  278 => 110,  276 => 109,  268 => 103,  265 => 102,  260 => 101,  249 => 98,  244 => 95,  240 => 93,  226 => 87,  222 => 86,  218 => 85,  196 => 77,  192 => 75,  178 => 69,  174 => 68,  170 => 67,  156 => 60,  123 => 48,  119 => 47,  105 => 40,  98 => 38,  96 => 37,  90 => 33,  75 => 26,  71 => 25,  62 => 21,  49 => 15,  43 => 13,  40 => 12,  36 => 11,  30 => 10,  255 => 99,  241 => 140,  228 => 132,  214 => 124,  212 => 84,  181 => 105,  162 => 94,  131 => 76,  102 => 59,  87 => 49,  66 => 30,  45 => 19,  38 => 15,  33 => 13,  217 => 127,  208 => 121,  202 => 119,  193 => 112,  191 => 111,  176 => 103,  164 => 91,  161 => 90,  151 => 59,  148 => 58,  146 => 82,  117 => 59,  113 => 46,  101 => 39,  77 => 30,  73 => 28,  67 => 26,  65 => 25,  55 => 25,  50 => 15,  47 => 14,  34 => 11,  31 => 10,  19 => 1,  198 => 92,  195 => 113,  190 => 80,  140 => 7,  136 => 5,  133 => 77,  127 => 49,  124 => 130,  121 => 129,  118 => 68,  115 => 127,  112 => 126,  109 => 55,  103 => 53,  100 => 122,  97 => 121,  94 => 120,  91 => 119,  89 => 91,  85 => 89,  83 => 88,  74 => 81,  72 => 80,  64 => 74,  58 => 20,  54 => 69,  52 => 16,  44 => 62,  42 => 12,  37 => 58,  35 => 14,  27 => 4,  22 => 1,  771 => 414,  760 => 407,  709 => 358,  700 => 352,  664 => 318,  662 => 317,  659 => 316,  642 => 301,  636 => 300,  630 => 298,  620 => 296,  610 => 294,  607 => 293,  605 => 292,  602 => 291,  598 => 290,  594 => 289,  579 => 276,  570 => 274,  560 => 272,  550 => 270,  548 => 269,  545 => 268,  541 => 267,  537 => 266,  522 => 253,  513 => 251,  510 => 250,  500 => 248,  490 => 246,  487 => 245,  484 => 244,  480 => 243,  476 => 242,  461 => 229,  452 => 227,  442 => 225,  432 => 223,  430 => 222,  427 => 221,  423 => 220,  419 => 219,  404 => 206,  395 => 150,  385 => 202,  375 => 145,  373 => 199,  370 => 198,  366 => 197,  362 => 196,  330 => 125,  328 => 165,  320 => 122,  317 => 159,  306 => 151,  295 => 115,  293 => 141,  283 => 133,  281 => 132,  274 => 129,  271 => 128,  263 => 123,  261 => 122,  257 => 100,  254 => 119,  251 => 118,  248 => 117,  245 => 116,  242 => 115,  239 => 114,  236 => 113,  233 => 112,  230 => 111,  220 => 103,  209 => 122,  205 => 79,  201 => 78,  194 => 93,  188 => 90,  185 => 89,  183 => 88,  179 => 104,  175 => 86,  171 => 85,  167 => 92,  163 => 65,  159 => 89,  153 => 79,  144 => 56,  141 => 77,  138 => 76,  135 => 75,  132 => 74,  130 => 69,  126 => 72,  120 => 70,  116 => 69,  110 => 65,  106 => 124,  104 => 60,  82 => 42,  79 => 41,  76 => 40,  51 => 17,  48 => 20,  46 => 14,  32 => 3,  29 => 9,);
    }
}
