<?php

/* users.html */
class __TwigTemplate_b3a0883852bab0494afc2daa4366c580 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'head' => array($this, 'block_head'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"user_group_id\" id=\"user_group_id\" value=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "user_group_id"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"user_group_name\" id=\"user_group_name\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"company_id\" id=\"company_id\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"from\" id=\"from\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "from"), "html", null, true);
        echo "\" />
\t\t\t";
        // line 14
        $this->env->loadTemplate("_new-panel.html")->display($context);
        // line 15
        echo "\t\t\t<div class=\"table-responsive\">
\t\t\t\t<table class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t   <thead>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t 
\t\t\t\t\t\t <th class=\"text-center\">";
        // line 20
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Sr.#", 1 => "id", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 21
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Company Name", 1 => "company_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 22
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "User Group Name", 1 => "user_group_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 23
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Email ID", 1 => "email", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 24
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "First Name", 1 => "first_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 25
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Last Name", 1 => "last_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th class=\"text-center\">Action</th>
\t\t\t\t\t\t
\t\t\t\t\t  </tr>
\t\t\t\t   </thead>
\t\t\t\t   <tbody>
\t\t\t\t\t\t";
        // line 31
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot") == "desc")) {
            // line 32
            echo "\t\t\t\t\t\t\t";
            $context["index"] = twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
            // line 33
            echo "\t\t\t\t\t\t";
        } else {
            // line 34
            echo "\t\t\t\t\t\t\t";
            $context["index"] = 1;
            // line 35
            echo "\t\t\t\t\t\t";
        }
        // line 36
        echo "\t\t\t\t\t  ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 37
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td class=\"text-center\">";
            // line 38
            echo twig_escape_filter($this->env, (isset($context["index"]) ? $context["index"] : null), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 40
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_group_name") == "")) {
                echo " No Group ";
            } else {
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_group_name"), "html", null, true);
                echo " ";
            }
            echo "</td>
\t\t\t\t\t\t <td>";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "email"), "html", null, true);
            echo " </td>
\t\t\t\t\t\t <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "first_name"), "html", null, true);
            echo " </td>
\t\t\t\t\t\t <td>";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "last_name"), "html", null, true);
            echo " </td>
\t\t\t\t\t\t <td class=\"text-center ";
            // line 44
            echo twig_escape_filter($this->env, (isset($context["active_row"]) ? $context["active_row"] : null), "html", null, true);
            echo "\"><button type=\"button\" title=\"Edit\" onclick=\"edit_user('";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_group_id"), "html", null, true);
            echo "','";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_group_name"), "html", null, true);
            echo "','";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "editscript"), "html", null, true);
            echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button>
\t\t\t\t\t\t </td>
\t\t\t\t\t </tr>
\t\t\t\t\t  ";
            // line 47
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot") == "desc")) {
                // line 48
                echo "\t\t\t\t\t\t\t";
                $context["index"] = ((isset($context["index"]) ? $context["index"] : null) - 1);
                // line 49
                echo "\t\t\t\t\t\t";
            } else {
                // line 50
                echo "\t\t\t\t\t\t\t";
                $context["index"] = ((isset($context["index"]) ? $context["index"] : null) + 1);
                // line 51
                echo "\t\t\t\t\t\t";
            }
            // line 52
            echo "\t\t\t\t\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 53
        echo "\t\t\t\t\t  ";
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows")) == 0)) {
            // line 54
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td colspan=\"8\">No Records</td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        // line 58
        echo "\t\t\t\t   </tbody>
\t\t\t\t   <tfoot>
\t\t\t\t\t 
\t\t\t\t   </tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
";
    }

    // line 68
    public function block_head($context, array $blocks = array())
    {
        // line 69
        echo "\t";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
<script src=\"/admin/js/list.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "users.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  209 => 69,  206 => 68,  193 => 58,  187 => 54,  184 => 53,  178 => 52,  175 => 51,  172 => 50,  169 => 49,  166 => 48,  164 => 47,  150 => 44,  146 => 43,  142 => 42,  138 => 41,  128 => 40,  124 => 39,  120 => 38,  117 => 37,  112 => 36,  109 => 35,  106 => 34,  103 => 33,  100 => 32,  98 => 31,  89 => 25,  85 => 24,  81 => 23,  77 => 22,  73 => 21,  69 => 20,  62 => 15,  60 => 14,  56 => 13,  50 => 10,  46 => 9,  41 => 7,  37 => 6,  32 => 3,  29 => 2,);
    }
}
