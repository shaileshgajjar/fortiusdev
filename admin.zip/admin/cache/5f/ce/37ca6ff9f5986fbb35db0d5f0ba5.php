<?php

/* assessment-exec-summary.html */
class __TwigTemplate_5fce37ca6ff9f5986fbb35db0d5f0ba5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 16
            echo "<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\tdata-bv-message=\"This value is not valid\"
\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\tenctype=\"multipart/form-data\">
\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
\t\t<input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
\t\t<!-- Nav tabs -->
\t\t";
            // line 36
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 37
            echo "\t\t<!-- Tab panes -->
\t\t<div class=\"tab-content tab_border\">
\t\t\t<div role=\"tabpanel\" class=\"tab-pane active\" id=\"screen1\">
\t\t\t\t<div class=\"row new_field_block_part widget-box widget-color-blue\">
\t\t\t\t\t<div class=\"widget-header\">
\t\t\t\t\t\t<h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i> 2 Executive Summary  </h4>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"widget-body\">
\t\t\t\t\t\t<div class=\"widget-main widget_main_extra_part\">
\t\t\t\t\t\t\t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">2.1 Description of the entity’s payment card business</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">Describe the nature of the entity’s business (what kind of work they do, etc.)
\t\t\t\t\t\t\t\t\t\t<br><span class=\"label_note\"><b>Note:</b> This is not intended to be a cut-and-paste from the entity’s website, but should be a tailored description that shows the assessor understands the business of the entity being assessed.<br></span></label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t\t<input name=\"nature_of_business\" id=\"nature_of_business\" type=\"text\" class=\"form-control\" value=\"";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "nature_of_business"), "value"), "html", null, true);
            echo "\" placeholder=\"\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t\t&nbsp;
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">\tDescribe how the entity stores, processes, and/or transmits card-holder data:
\t\t\t\t\t\t\t\t\t\t<br><span class=\"label_note\"><b>Note:</b> This is not intended to be a cut-and-paste from above, but should build on the understanding of the business and the impact this can have upon the security of card-holder data.<br></span>\t\t
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"2\" placeholder=\"\" name=\"executive_summary1\" id=\"executive_summary1\">";
            // line 68
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "executive_summary1"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t\t&nbsp;
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">\tDescribe why the entity stores, processes, and/or transmits card-holder data.
\t\t\t\t\t\t\t\t\t\t<br><span class=\"label_note\"><b>Note:</b> This is not intended to be a cut-and-paste from above, but should build on the understanding of the business and the impact this can have upon the security of card-holder data.<br></span>\t\t
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"2\" placeholder=\"\" name=\"executive_summary2\" id=\"executive_summary2\">";
            // line 83
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "executive_summary2"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t\t&nbsp;
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">\tIdentify thetypes of payment channels the entity serves, such as card-present and card-not-present (for example, mail order/telephone order (MOTO), e-commerce).</label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"2\" placeholder=\"\" name=\"executive_summary3\" id=\"executive_summary3\" >";
            // line 97
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "executive_summary3"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">
\t\t\t\t\t\t\t&nbsp;
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
\t\t\t\t\t\t\t\t<div class=\"field_part field_extra_part\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"col-md-3 col-sm-4 col-xs-12 control-label label_height label_align\">Other details, if applicable:</label>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-9 col-sm-8 col-xs-12 widget_textarea_extra\">
\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"2\" placeholder=\"\" name=\"executive_summary4\" id=\"executive_summary4\" >";
            // line 110
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "executive_summary4"), "value"), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"screen5_discription_part\">
\t\t\t\t\t\t\t\t<!--<h1 class=\"screen_title\">2.2 High-level network diagram(s)</h1>-->
\t\t\t\t\t\t\t\t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">2.2 High-level network diagram(s)</div>
\t\t\t\t\t\t\t\t<p>Provide a high-level network diagram (either obtained from the entity or created by assessor) of the entity's networking topography, showing the overall architecture of the environment being assessed. This high-level diagram should summarize all locations and key systems, and the boundaries between them and should include the following.</p>
\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t<li>Connections into and out of the network including demarcation points between the cardholder data environment (CDE) and other networks/zones</li>
\t\t\t\t\t\t\t\t\t<li>Critical components within the cardholder data environment, including POS devices, systems, databases, and web servers, as applicable</li>
\t\t\t\t\t\t\t\t\t<li>Other necessary payment components, as applicable</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t<div data-target=\"#upload\" data-toggle=\"modal\" class=\"btn btn-primary primary_btn_extra\"><span><i class=\"fa fa-plus\"></i></span> Add high-level network diagram  </div>
\t\t\t\t\t\t\t\t<div class=\"btn btn-info primary_btn_extra collapsed\" title=\"Show/Hide Uploaded Files\" data-toggle=\"collapse\" data-target=\"#section_1\" aria-expanded=\"false\"> Show/Hide Uploaded Files</div>
\t\t\t\t\t\t\t\t<div id=\"section_1\" class=\"collapse in\">
\t\t\t\t\t\t\t\t\t<ol id=\"diagramslist\" class=\"\"> 
\t\t\t\t\t\t\t\t\t\t";
            // line 129
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "wizard_diagrams"));
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 130
                echo "\t\t\t\t\t\t\t\t\t\t<li id=\"list_";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "diagram_path"), "html", null, true);
                echo " Date : ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "upload_date"), "html", null, true);
                echo " &nbsp;&nbsp;&nbsp;<span onclick=\"javasctipt: removethis('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "','";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "company_id"), "html", null, true);
                echo "')\" ><i class=\"fa fa-trash trash-icon\" title=\"Remove\" ></i></span><a href=\"../uploads/diagrams/";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "diagram_path"), "html", null, true);
                echo "\" data-toggle=\"modal\" class=\"btn btn-primary primary_btn_extra\" target=\"_blank\">View</a> </li>
\t\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 132
            echo "\t\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 135
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t\t\t\t\t\t<button class=\"btn btn-success new_success pull-right\" type=\"submit\" >Next <span><i class=\"fa fa-arrow-right\"></i></span></button>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</form>
</div>

";
            // line 145
            $this->env->loadTemplate("_upload-diagram.html")->display($context);
            echo " 
";
        }
    }

    // line 148
    public function block_footer($context, array $blocks = array())
    {
        // line 149
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 157
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 158
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 162
            echo "\$(document).ready(function() {
    \$('#frm').bootstrapValidator();
\t\$( \"#pwd\" ).keyup(function() {
\t\tif ( \$('#pwd').val() == '' )
\t\t\t\$('#errpwd').show();
\t\telse
\t\t\t\$('#errpwd').hide();
\t});
\t\$(\".date-picker\").datepicker({
\t\tformat: 'mm-dd-yyyy'
\t}).on('changeDate', function(ev){
\t\t\$(\".datepicker\").hide();
\t});
});
";
        }
        // line 177
        echo "function removethis(did, cid)
{
\tif( confirm('Are you sure to delete this file') == true )
\t{
\t\tif ( did != '' )
\t\t{
\t\t\ttheurl = '/remove-diagram.php?did='+did+'&cid='+cid;
\t\t\t\$.ajax({
\t\t\t\ttype: \"POST\",
\t\t\t\turl: theurl,
\t\t\t\tbeforeSend: function( xhr ) {
\t\t\t\t}
\t\t\t}).done(function(data) {
\t\t\t\t\$('li#list_'+did).remove();
\t\t\t\t
\t\t\t});
\t\t}
\t}
}
</script>
";
    }

    public function getTemplateName()
    {
        return "assessment-exec-summary.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  329 => 177,  312 => 162,  306 => 158,  304 => 157,  292 => 149,  289 => 148,  282 => 145,  269 => 135,  264 => 132,  245 => 130,  241 => 129,  219 => 110,  203 => 97,  186 => 83,  168 => 68,  150 => 53,  132 => 37,  130 => 36,  125 => 34,  121 => 33,  117 => 32,  113 => 31,  109 => 30,  104 => 28,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  75 => 16,  69 => 13,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
