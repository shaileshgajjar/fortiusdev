<?php

/* front-user-data.html */
class __TwigTemplate_bc4e3017a9a61967511f846de23abb7e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-front-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'head' => array($this, 'block_head'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-front-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        $this->displayBlock('head', $context, $blocks);
        // line 7
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save")) {
            // line 8
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 18
            echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "\" />
\t\t\t <input type=\"hidden\" name=\"userrole\" id=\"userrole\" value=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method"), "html", null, true);
            echo "\" />
\t\t\t <input type=\"hidden\" name=\"commented_by\" id=\"commented_by\" value=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
\t\t\t<div class=\"widget-box widget-color-blue\">
\t\t\t\t<!-- #section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-header\">
\t\t\t\t\t<h5 class=\"widget-title smaller lighter\">
\t\t\t\t\t\t<i class=\"ace-icon fa fa-edit\"></i>
\t\t\t\t\t\t";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
            echo " - Company Name : <b>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_name"), "html", null, true);
            echo "</b>, Assessment Type : <b>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "merchant_type"), "html", null, true);
            echo "</b>
\t\t\t\t\t</h5>
\t\t\t\t</div>
\t\t\t\t<!-- /section:custom/widget-box.options -->
\t\t\t\t<div class=\"widget-body\">
\t\t\t\t\t<div class=\"widget-main\">
\t\t\t\t\t\t<div id=\"sticky-anchor\"></div>
\t\t\t\t\t\t<div class=\"form-group\" id=\"sticky\">
\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t<button type=\"submit\" onclick=\"savedata('continue');\" class=\"btn btn-success\">Save &amp; Continue</button>
\t\t\t\t\t\t\t\t<button type=\"submit\" onclick=\"savedata('save');\" class=\"btn btn-success\">Save &amp; Exit</button>
\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-danger\" onclick=\"this.form.action='";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "'; this.form.submit();\">Cancel</button>
\t\t\t\t\t\t\t\t<div class=\"pull-right col-lg-3\">
\t\t\t\t\t\t\t\t\t<button type=\"button\" onclick=\"\$('#task').val(''); this.form.submit();\" class=\"pull-right btn btn-comments btn-xs btn-success  glyphicon glyphicon-search\" style=\" margin-left: 5px;  margin-top: 5px;padding-bottom: 4px; padding-left: 6px; padding-right: 8px; padding-top: 3px;\" title=\"Search\" ></button>
\t\t\t\t\t\t\t\t\t<input type=\"text\" style=\"width:86%; margin-top:5px;;\" autocomplete=\"off\" class=\"form-control\" placeholder=\"Search within requirement\" name=\"proc_req_search\" id=\"proc_req_search\" value=\"";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "proc_req_search"), "html", null, true);
            echo "\">

\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t\t\t<select style=\"margin-top:5px;margin-left:5px;\" onchange=\"\$('#task').val(''); this.form.submit();\" name=\"inplace_filter\" id=\"inplace_filter\" class=\"form-control selectpicker\">
\t\t\t\t\t\t\t\t\t\t<option value=\"\">Filter By</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"Y\"";
            // line 62
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "Y")) {
                echo " selected=\"selected\"";
            }
            echo ">Y</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"N\"";
            // line 63
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "N")) {
                echo " selected=\"selected\"";
            }
            echo ">N</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"C\"";
            // line 64
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "C")) {
                echo " selected=\"selected\"";
            }
            echo ">C</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"NT\"";
            // line 65
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "NT")) {
                echo " selected=\"selected\"";
            }
            echo ">NT</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"NA\"";
            // line 66
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "inplace_filter") == "NA")) {
                echo " selected=\"selected\"";
            }
            echo ">NA</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div role=\"tabpanel\">
\t\t\t\t\t\t  <!-- Nav tabs -->
\t\t\t\t\t\t\t<div id=\"security-inputs\">
\t\t\t\t\t\t\t<select name=\"requirements_id\" class=\"form-control\" id=\"requirements_id\" onchange=\"getcontent(this.value);\">
\t\t\t\t\t\t\t\t";
            // line 75
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements"));
            foreach ($context['_seq'] as $context["_key"] => $context["requirement"]) {
                // line 76
                echo "\t\t\t\t\t\t\t\t<option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\"";
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id") == $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"))) {
                    echo " selected=\"selected\"";
                }
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "rtitle"), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['requirement'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 78
            echo "\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t  <!-- Nav tabs -->
\t\t\t\t\t\t\t<div style=\"clear:both;\"></div>
\t\t\t\t\t\t  <!-- Tab panes -->
\t\t\t\t\t\t\t<div class=\"tab-content\">
\t\t\t\t\t\t\t";
            // line 84
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["requirement"]) {
                // line 85
                echo "\t\t\t\t\t\t\t\t";
                $context["extra"] = "";
                // line 86
                echo "\t\t\t\t\t\t\t\t";
                $context["data"] = "n";
                // line 87
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id") == $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"))) {
                    // line 88
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["extra"] = " active";
                    // line 89
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["data"] = "y";
                    // line 90
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 91
                echo "\t\t\t\t\t\t\t\t<div role=\"tabpanel\" class=\"all-tabs tab-pane";
                echo twig_escape_filter($this->env, (isset($context["extra"]) ? $context["extra"] : null), "html", null, true);
                echo "\" id=\"tab";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" id=\"data";
                // line 92
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\" name=\"data";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, (isset($context["data"]) ? $context["data"] : null), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t<div id=\"req";
                // line 93
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
                echo "\" class=\" item\">
\t\t\t\t\t\t\t\t\t";
                // line 94
                if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "requirements_id") == $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"))) {
                    // line 95
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $this->env->loadTemplate("getcontentuser.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
                    // line 96
                    echo "\t\t\t\t\t\t\t\t\t";
                }
                // line 97
                echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['requirement'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 100
            echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t  <!-- Tab panes -->
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<div class=\"col-lg-11\">
\t\t\t\t\t\t\t\t<button type=\"submit\" onclick=\"savedata('continue');\" class=\"btn btn-success\">Save &amp; Continue</button>
\t\t\t\t\t\t\t\t<button type=\"submit\" onclick=\"savedata('save');\" class=\"btn btn-success\">Save &amp; Exit</button>
\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-danger\" onclick=\"this.form.action='";
            // line 107
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "'; this.form.submit();\">Cancel</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</form>
\t</div>
</div>

<input type=\"hidden\" name=\"cno\" id=\"cno\" value=\"\" />
<div class=\"modal fade\" id=\"div-comment\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"myModalLabel\"></h4>
      </div>
       <div class=\"modal-body\" >
\t\t<div id=\"message_input\">
\t\t\t<textarea name=\"procedure_chat\" class=\"form-control\" rows=\"5\" id=\"procedure_chat\"></textarea>
\t\t</div>
\t\t<div style=\"height:8px;\"></div>
\t\t<div id=\"allcomments\"></div>
\t  </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
        <button type=\"button\" onclick=\"javascript: save_procedure_chats('procedure_chat');\" data-dismiss=\"modal\" class=\"btn btn-primary\">Save changes</button>
      </div>
    </div>
  </div>
</div>
<div class=\"modal fade\" id=\"upload\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"myModalLabel\">Upload File</h4>
      </div>
      <div class=\"modal-body\">
        <form id=\"frmdocupload\" name=\"frmdocupload\" method=\"post\" action=\"/uploadfile.php\" enctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"cnou\" id=\"cnou\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"company_id\" id=\"company_id\" value=\"";
            // line 149
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"document\" id=\"document\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"pid\" id=\"pid\" value=\"\" />
\t\t\t<input type=\"file\" name=\"mydoc\" id=\"mydoc\" style=\"height:30px; cursor:pointer;\" class=\"pull-left\" />
\t\t\t<button type=\"submit\" class=\"btn btn-success pull-left\">Upload</button>
\t\t</form>
\t\t<div class=\"progress\">
\t\t\t<div class=\"bar\"></div >
\t\t\t<div class=\"percent\">0%</div >
\t\t</div>
\t\t<div id=\"statusdoc\" class=\"alert\"></div>
\t\t<!-- div for user Doc list -->
\t\t<div id=\"doclist\">
\t\t</div>
\t\t<!-- div for user doc list -->
\t  </div>
      <div class=\"modal-footer\">
\t   <button type=\"button\" class=\"btn btn-success\" data-dismiss=\"modal\" onclick=\"submitForm();\">Save</button>
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
<div class=\"modal fade\" id=\"user-comments\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"myModalLabel\"> </h4>
      </div>
\t   <input type=\"hidden\" name=\"c_proc_id\" id=\"c_proc_id\" value=\"\" />
\t  <input type=\"hidden\" name=\"room_id\" id=\"room_id\" value=\"\"> 
      <div class=\"modal-body\" >
\t\t<div id=\"message_input\">
\t\t\t<textarea name=\"procedure_chat\" class=\"form-control\" rows=\"5\" id=\"procedure_chat\"></textarea>
\t\t</div>
\t\t<div style=\"height:8px;\"></div>
\t\t<div id=\"allcomments\"></div>
\t  </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
<div class=\"modal fade\" id=\"div-guidance\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Guidance..</h4>
\t\t\t</div>
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div id=\"proc-guidance\"></div>
\t\t\t</div>
\t\t\t<div class=\"modal-footer\">
\t\t\t\t<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
<div class=\"modal fade\" id=\"loading\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Processing..</h4>
\t\t\t</div>
\t\t\t<div class=\"modal-body\">
\t\t\t\t<div id=\"proc-guidance\">
\t\t\t\t\t<p>Loading.. Please wait!!</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
";
        }
    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        // line 4
        echo "\t";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/chosen.css\" />
";
    }

    // line 227
    public function block_footer($context, array $blocks = array())
    {
        // line 228
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
";
        // line 229
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save")) {
            // line 230
            echo "<script type=\"text/javascript\">
\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
</script>
";
        } else {
            // line 236
            echo "<script src=\"/assets/js/chosen.jquery.js\"></script>
<link href=\"/assets/css/bootstrap-switch.css\" type=\"text/css\" rel=\"stylesheet\">
<script src=\"/assets/js/bootstrap-switch.js\"></script>
<script type=\"text/javascript\">
function set_guidance(pid)
{
\tvar formfields = 'pid='+pid;
\ttheurl = 'guidance.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t\$('#proc-guidance').html(data);
\t});
}

function setvalueu(cno)
{
\t\$('#cnou').val(cno);
\t\$('#pid').val(cno);
\t\$('#mydoc').val('');
\t\$('#statusdoc').empty();
\t\$('#statusdoc').hide();
\tvar percentVal = '0%';
\t\$('.bar').width(percentVal)
\t\$('.percent').html(percentVal);
\ttheurl = '/loaddocuments.php';
\tformfields = 'company_id=";
            // line 266
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t\$('#doclist').html(data);
\t});
}

function savevalue()
{
\tpid = \$('#cno').val();
\tcompany_id = '";
            // line 281
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "';
\tcommented_to = \$('#commented_to').val();
\tcommented_by = \$('#commented_by').val();
\tcomment = \$('#comment').val();
\tif( comment )
\t{\t
\t\tvar regEx = /[A-Za-z0-9-\\/\\.,:;@#% /\\&()]/gi;
\t\tvar validate_arr = comment.match(regEx);
\t\tif(validate_arr)
\t\t{
\t\t\tcomment = comment.replace(\"\\n\", \"<br />\");
\t\t\tcomment = comment.replace(\"\\r\", \"\"); 
\t\t}
\t\telse
\t\t{
\t\t\treturn false;
\t\t}
\t}
\telse
\t{
\t\treturn false;
\t}
\tcomment = comment.replace(\"\\n\", \"<br />\");
\tcomment = comment.replace(\"\\r\", \"\");
\tformfields = 'pid='+pid+'&company_id='+company_id+'&comment='+comment+'&commented_to='+commented_to+'&commented_by='+commented_by+'&comment_type=2';
\ttheurl = '/savecomments.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t});
\tif ( \$('#comment').val() != '' )
\t{
\t\t\$('#btn-comment'+pid).removeClass('btn-default');
\t\t\$('#btn-comment'+pid).addClass('btn-success');
\t}
}

function showcomment(comment)
{
\t\$('#user-comment').html(comment);
}

function savedata(task)
{
\t\$('#task').val(task);
}
function getcontent(id)
{
\t\$('.all-tabs').hide();
\tif ( \$('#data'+id).val() == 'n' )
\t{
\t\t\$('#loading').modal('show');
\t\t\$('#data'+id).val('y');
\t\tformfields = 'requirements_id='+id+'&merchant_id=";
            // line 338
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "merchant_id"), "html", null, true);
            echo "&roc_saq=";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "roc_saq"), "html", null, true);
            echo "&company_id=";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "';
\t\ttheurl = '/getcontentuser.php';
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\t\$('#req'+id).html(data);
\t\t\t\$('[data-rel=popover]').popover({html:true});
\t\t\t\$('#loading').modal('hide');
\t\t});
\t}
\t\$('#tab'+id).show();
}

function deletedoc(id, doc, company_id, pid)
{
\tif ( confirm(\"Are you sure? remove \"+doc+\" document?\") )
\t{
\t\tformfields = 'id='+id+'&document='+doc+'&company_id='+company_id+'&pid='+pid;
\t\ttheurl = 'deldocument.php';
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\t\$('#dropdown'+pid).html(data);
\t\t});
\t}
}

function copydocumentforprocedure(id, doc, company_id )
{
\t// set value to hiddenfield 
\t\$('#document').val(doc);
\t\$('#id').val(id);
}
function submitForm()
{
\t//get all hidden field values
\tvar id = \$('#id').val();
\tvar pid = \$('#pid').val();
\tvar document = \$('#document').val();
\tif(id != \"\" && pid != \"\" && document != \"\")
\t{
\t\tformfields = 'id='+id+'&document='+document+'&company_id=";
            // line 387
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
            echo "&pid='+pid;
\t\ttheurl = '/copydocument.php';
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\tresary = data.split(\"\\n\");
\t\t\thtml = resary[1];
\t\t\t\$('#dropdown'+pid).html(html);
\t\t});
\t}
\t\$('#document').val('');
\t\$('#id').val('');
\t\$('#pid').val('');\t\t
}

function sticky_relocate() {
    var window_top = \$(window).scrollTop();
    var div_top = \$('#sticky-anchor').offset().top;
    if (window_top > div_top-135) {
        \$('#sticky').addClass('stick');
    } else {
        \$('#sticky').removeClass('stick');
    }
}

\$(function () {
    \$(window).scroll(sticky_relocate);
    sticky_relocate();
\t\$('[data-rel=popover]').popover({html:true});
});
function setready(tmp)
{
\tvar val = \$('#switch'+tmp).prop(\"checked\");
\tvar ready_for = '';
\tvar c_due_date = \"";
            // line 425
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "compliance_due_date"), "method"), "html", null, true);
            echo "\";
\tvar updated_by = \"";
            // line 426
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method"), "html", null, true);
            echo "\";
\tif(val == true)
\t\tready_for = 'review';
\telse
\t\tready_for = '0';
\tif(ready_for == '0')\t
\t\t\$(\"#lock_icon_\"+tmp).removeClass(\"glyphicon glyphicon-lock text-danger\");
\telse
\t\t\$(\"#lock_icon_\"+tmp).addClass(\"glyphicon glyphicon-lock text-danger\");\t
\tformfields = 'did='+tmp+'&ready_for='+ready_for+'&task=save&c_due_date='+c_due_date+'&updated_by='+updated_by;
\ttheurl = '/savereadyforreview.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t
\t});
}
</script>
";
        }
    }

    public function getTemplateName()
    {
        return "front-user-data.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  680 => 426,  676 => 425,  635 => 387,  579 => 338,  519 => 281,  501 => 266,  469 => 236,  461 => 230,  459 => 229,  454 => 228,  451 => 227,  443 => 4,  440 => 3,  358 => 149,  313 => 107,  304 => 100,  288 => 97,  285 => 96,  282 => 95,  280 => 94,  276 => 93,  268 => 92,  261 => 91,  258 => 90,  255 => 89,  252 => 88,  249 => 87,  246 => 86,  243 => 85,  226 => 84,  218 => 78,  203 => 76,  199 => 75,  185 => 66,  179 => 65,  173 => 64,  167 => 63,  161 => 62,  152 => 56,  146 => 53,  128 => 42,  119 => 36,  115 => 35,  111 => 34,  107 => 33,  102 => 31,  98 => 30,  94 => 29,  90 => 28,  86 => 27,  82 => 26,  72 => 18,  66 => 15,  62 => 14,  58 => 13,  54 => 12,  50 => 11,  46 => 10,  42 => 9,  37 => 8,  35 => 7,  33 => 3,  30 => 2,);
    }
}
