<?php

/* admins.html */
class __TwigTemplate_3f064f5c842b705b4f20eead4ae07ebe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-layout.html");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t\t\t";
        // line 10
        $this->env->loadTemplate("_new-panel.html")->display($context);
        // line 11
        echo "\t\t\t<div class=\"table-responsive\">
\t\t\t\t<table id=\"simple-table\" class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t   <thead>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t <th class=\"text-center\">
\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"ace\" />
\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t </th>
\t\t\t\t\t\t <th class=\"text-center\">";
        // line 21
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Sr.#", 1 => "rowid", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 22
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "First Name", 1 => "first_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 23
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Last Name", 1 => "last_name", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 24
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Email", 1 => "email", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th>";
        // line 25
        echo $this->getAttribute((isset($context["lib"]) ? $context["lib"] : null), "view_caption", array(0 => "Telephone", 1 => "mobile", 2 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), 3 => $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot")), "method");
        echo "</th>
\t\t\t\t\t\t <th class=\"text-center\">Action</th>
\t\t\t\t\t  </tr>
\t\t\t\t   </thead>
\t\t\t\t   <tbody>
\t\t\t\t\t  ";
        // line 30
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 31
            echo "\t\t\t\t\t\t  <tr>
\t\t\t\t\t\t\t <td class=\"text-center\">
\t\t\t\t\t\t\t\t";
            // line 33
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id") != "1")) {
                // line 34
                echo "\t\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"removeid[]\" class=\"ace\" value=\"";
                // line 35
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
                echo "\" />
\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t";
            }
            // line 39
            echo "\t\t\t\t\t\t\t </td>
\t\t\t\t\t\t\t <td class=\"text-center\">";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "rowid"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t <td>";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "first_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "last_name"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t <td>";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "email"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "mobile"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t <td class=\"text-center\"><button type=\"button\" title=\"Edit\" onclick=\"edit('";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "id"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "editscript"), "html", null, true);
            echo "');\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button></td>
\t\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 48
        echo "\t\t\t\t\t  ";
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows")) == 0)) {
            // line 49
            echo "\t\t\t\t\t  <tr>
\t\t\t\t\t\t <td colspan=\"10\">No Records</td>
\t\t\t\t\t  </tr>
\t\t\t\t\t  ";
        }
        // line 53
        echo "\t\t\t\t   </tbody>
\t\t\t\t   <tfoot>
\t\t\t\t\t  <tr>
\t\t\t\t\t\t<td class=\"text-center\"><button type=\"button\" title=\"Delete\" onclick=\"delconfirm(this.form);\" class=\"btn btn-danger\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></button></td>
\t\t\t\t\t\t<td colspan=\"11\"></td>
\t\t\t\t\t  </tr>
\t\t\t\t   </tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</form>
\t</div>
</div>
";
    }

    // line 66
    public function block_footer($context, array $blocks = array())
    {
        // line 67
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
<script src=\"/admin/js/list.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "admins.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  170 => 67,  167 => 66,  151 => 53,  145 => 49,  142 => 48,  131 => 45,  127 => 44,  123 => 43,  119 => 42,  115 => 41,  111 => 40,  108 => 39,  101 => 35,  98 => 34,  96 => 33,  92 => 31,  88 => 30,  80 => 25,  76 => 24,  72 => 23,  68 => 22,  64 => 21,  52 => 11,  50 => 10,  46 => 9,  41 => 7,  37 => 6,  32 => 3,  29 => 2,);
    }
}
