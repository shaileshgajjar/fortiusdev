<?php

/* _front-failed-controls.html */
class __TwigTemplate_63394edb8cd45b85346181af2eaba850 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t<div class=\"modal fade\" id=\"failed_control\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
\t\t\t\t<h4 class=\"modal-title\" id=\"myModalLabel\">Failed Controls</h4>
\t\t\t</div>
\t\t\t<form class=\"form-horizontal bv-form\" name=\"frmfailedcontrols\" id=\"frmfailedcontrols\" method=\"post\" action=\"\"
\t\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\t\tenctype=\"multipart/form-data\">
\t\t\t\t<input type=\"hidden\" id=\"company_id\" name=\"company_id\" value=\"\">
\t\t\t\t<input type=\"hidden\" id=\"task\" name=\"task\" value=\"save_control\">
\t\t\t<div class=\"modal-body\"  style=\"height:450px;
overflow-x:auto;overflow-y:scroll;bottom:0;left:0;right:0;top:0;
z-index:9999;\">
\t\t\t\t<div class=\"form-group pull-left\">
\t\t\t\t\t<label class=\"col-lg-5 control-label\">Completion Date</label>
\t\t\t\t\t<div class=\"col-lg-7\">
\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t<label for=\"completion_date\" class=\"cal-icon btn\" ><span class=\"glyphicon glyphicon-calendar\"></span></label>
\t\t\t\t\t\t<input id=\"completion_date\" type=\"text\" name=\"completion_date\" class=\"date-picker form-control\" value=\"\"  />
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<div class=\"col-lg-12\" id=\"failed_controls_data\">
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"modal-footer\">
\t\t\t\t<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
\t\t\t\t<button type=\"submit\" onclick=\"save_failed_controls();\" data-dismiss=\"modal\" class=\"btn btn-primary\">Save changes</button>
\t\t\t</div>
\t\t\t</form>
\t\t</div>
\t</div>
\t</div>
<style>
.datepicker{z-index:1151 !important;}
</style>\t
<link rel=\"stylesheet\" href=\"/assets/css/datepicker3.css\">
<script type=\"text/javascript\" src=\"/assets/js/bootstrap-datepicker.js\"></script>
<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
<script type=\"text/javascript\">
function save_failed_controls()
{
\tformfields = \$('#frmfailedcontrols').serialize();
\ttheurl = 'save-failed-controls-note.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t});
}
function get_failed_controls(company_id, pid, docid)
{
\t
\tvar formfields = 'company_id='+company_id+'&pid='+pid+'&docid='+docid;
\t\$(\"div#failed_control input#company_id\").val(company_id);
\ttheurl = 'get-failed-controls.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t\$('div#failed_controls_data').html(data);
\t\tvar cdate = \$('#cdate').val();
\t\tif(\$('#cdate').val() != '')
\t\t\t\$('#completion_date').val(cdate);
\t});
\t
}
</script>
";
    }

    public function getTemplateName()
    {
        return "_front-failed-controls.html";
    }

    public function getDebugInfo()
    {
        return array (  313 => 106,  307 => 105,  305 => 104,  294 => 95,  288 => 94,  279 => 90,  275 => 89,  266 => 86,  263 => 85,  260 => 84,  257 => 83,  254 => 82,  252 => 81,  249 => 80,  245 => 79,  242 => 78,  236 => 77,  227 => 73,  223 => 72,  214 => 69,  211 => 68,  208 => 67,  205 => 66,  202 => 65,  200 => 64,  197 => 63,  193 => 62,  190 => 61,  184 => 60,  175 => 56,  171 => 55,  162 => 52,  159 => 51,  156 => 50,  153 => 49,  150 => 48,  148 => 47,  145 => 46,  141 => 45,  138 => 44,  132 => 43,  123 => 39,  119 => 38,  110 => 35,  107 => 34,  104 => 33,  101 => 32,  98 => 31,  96 => 30,  93 => 29,  89 => 28,  80 => 24,  76 => 23,  68 => 20,  64 => 19,  60 => 18,  50 => 13,  44 => 11,  41 => 10,  38 => 9,  35 => 8,  32 => 7,  27 => 6,  25 => 5,  19 => 1,);
    }
}
