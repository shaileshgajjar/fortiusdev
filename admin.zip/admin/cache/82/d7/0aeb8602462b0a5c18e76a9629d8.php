<?php

/* v32_assessment-reviewed-env-sampling-data.html */
class __TwigTemplate_82d70aeb8602462b0a5c18e76a9629d8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 15
            echo "<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 34
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 35
            echo "      <!-- Tab panes -->
\t\t\t<div class=\"tab-content tab_border\">
            \t<div class=\"widget-box widget-color-blue widget_main_extra_part\">
                \t<div class=\"widget-header\">
                        <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i>4 Reviewed Environment</h4>
                    </div>
                    <div class=\"widget-body\">
                    \t<div class=\"widget-main widget_main_extra_part\">
                        \t<div class=\"screen7_inner_part\">
                                <div class=\"screen9_table_block_part screen10_extra screen11_part\">
                                    <!--<h1 class=\"screen_title\">4.6 Sampling</h1>-->
                                    <div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.5 Sampling</div>
                                    <h5>Identify whether sampling was used during the assessment.</h5>
                                    <div class=\"assesment_reiview_env_soft_data_bg\">
                                        <table class=\"table table-striped\">
                                          <thead>
                                            <tr>
                                                <th colspan=\"2\">If sampling is not used:</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            <tr>
                                                <td class=\"col-md-6 col-sm-6 col-xs-6\">Provide the name of the assessor who attests that every system component and all business facilities have been assessed.</td>
                                                <td class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"sampling_1\" class=\"form-control\" rows=\"2\">";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "env_sampling"), "sampling_1"), "html", null, true);
            echo "</textarea></td>
                                            </tr>
                                            <tr>
                                                <td colspan=\"2\"><strong>If sampling is used:</strong></td>
                                            </tr>
                                            <tr>
                                                <td class=\"col-md-6 col-sm-6 col-xs-6\">Provide the name of the assessor who attests that all sample sets used for this assessment are represented in the below \"sample sets for reporting\" table. Examples may include, but are not limited to firewall, application servers. retail locations, data centers, User IDs, people, etc.</td>
                                                <td class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"sampling_2\" class=\"form-control\" rows=\"2\">";
            // line 65
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "env_sampling"), "sampling_2"), "html", null, true);
            echo "</textarea></td>
                                            </tr>
                                            <tr>
                                                <td class=\"col-md-6 col-sm-6 col-xs-6\">Describe the sampling rationale and/or standardized PCI DSS security and operational processes/controls used for selecting sample sizes (for people, processes, technologies, devices, locations/sites, etc.).</td>
                                                <td class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"sampling_3\" class=\"form-control\" rows=\"2\">";
            // line 69
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "env_sampling"), "sampling_3"), "html", null, true);
            echo "</textarea></td>
                                            </tr>
                                            <tr>
                                                <td class=\"col-md-6 col-sm-6 col-xs-6\">Describe the standardized PCI DSS security and operational processes/controls used to determine sample size.</td>
                                                <td class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"sampling_4\" class=\"form-control\" rows=\"2\">";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "env_sampling"), "sampling_4"), "html", null, true);
            echo "</textarea></td>
                                            </tr>
                                            <tr>
                                                <td class=\"col-md-6 col-sm-6 col-xs-6\">Describe how the above processes and controls were validated by the assessor.</td>
                                                <td class=\"col-md-6 col-sm-6 col-xs-6\"><textarea name=\"sampling_5\" class=\"form-control\" rows=\"2\">";
            // line 77
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "env_sampling"), "sampling_5"), "html", null, true);
            echo "</textarea></td>
                                            </tr>
                                          </tbody>
                                        </table>
                                    </div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 83
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button> 
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
            </div>
\t</form>
</div>


";
        }
    }

    // line 96
    public function block_footer($context, array $blocks = array())
    {
        // line 97
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 103
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 104
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 108
            echo "\$(document).ready(function() {
   
\t\$('#frm').bootstrapValidator();
\t//\$(\".switch\").bootstrapSwitch();
    \$(\"#tbl1\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t \$(\"#tbl2\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t \$(\"#tbl3\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
});
";
        }
        // line 123
        echo "
function addrow(tbl_id)
{
\tformfields = 'tbl_id='+tbl_id;
\ttheurl = '/ajax-env-software-data.php';
\t\$.ajax({
\t\ttype: \"POST\",
\t\turl: theurl,
\t\tdata: formfields,
\t\tbeforeSend: function( xhr ) {
\t\t}
\t}).done(function(data) {
\t\t\$(\"#\"+tbl_id).append(data);\t\t\t\t\t
\t});\t\t
}
</script>
";
    }

    public function getTemplateName()
    {
        return "v32_assessment-reviewed-env-sampling-data.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  244 => 123,  227 => 108,  221 => 104,  219 => 103,  209 => 97,  206 => 96,  189 => 83,  180 => 77,  173 => 73,  166 => 69,  159 => 65,  149 => 58,  124 => 35,  122 => 34,  117 => 32,  113 => 31,  109 => 30,  105 => 29,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  80 => 22,  71 => 15,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
