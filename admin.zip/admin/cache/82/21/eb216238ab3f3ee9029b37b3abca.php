<?php

/* getcontent.html */
class __TwigTemplate_8221eb216238ab3f3ee9029b37b3abca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t\t\t\t\t\t\t<div id=\"mastercollapse\" class=\"number alert alert-warning\" title=\"Click to Expand / Collapse All Sections\">&nbsp;<span class=\"pull-right alert-warning\"><b>Expand/Collapse All</b></span></div>
\t\t\t\t\t\t\t<div id=\"req";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["requirement"]) ? $context["requirement"] : null), "id"), "html", null, true);
        echo "\" class=\"item\">
\t\t\t\t\t\t\t";
        // line 3
        $context["nmbr"] = 0;
        // line 4
        echo "\t\t\t\t\t\t\t";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "rows"));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 5
            echo "\t\t\t\t\t\t\t";
            $context["readyfor"] = "";
            // line 6
            echo "\t\t\t\t\t\t\t
\t\t\t\t\t\t\t";
            // line 7
            $context["lock_unlock"] = $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locked");
            // line 8
            echo "\t\t\t\t\t\t\t ";
            $context["bgclass"] = "alert-info";
            // line 9
            echo "\t\t\t\t\t\t\t\t";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "Y")) {
                // line 10
                echo "\t\t\t\t\t\t\t\t\t";
                $context["bgclass"] = "alert-success";
                // line 11
                echo "\t\t\t\t\t\t\t\t";
            }
            // line 12
            echo "\t\t\t\t\t\t\t\t";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "N")) {
                // line 13
                echo "\t\t\t\t\t\t\t\t\t";
                $context["bgclass"] = "alert-danger";
                // line 14
                echo "\t\t\t\t\t\t\t\t";
            }
            // line 15
            echo "\t\t\t\t\t\t\t\t";
            if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s") && ($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "ready_for") == "review"))) {
                // line 16
                echo "\t\t\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "completion_date") != 0)) {
                    // line 17
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["readyfor"] = "Ready for review";
                    // line 18
                    echo "\t\t\t\t\t\t\t\t\t";
                }
                // line 19
                echo "\t\t\t\t\t\t\t\t";
            }
            // line 20
            echo "\t\t\t\t\t\t\t\t";
            if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q")) {
                // line 21
                echo "\t\t\t\t\t\t\t\t\t";
                if ((($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") != "N") && ($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") != ""))) {
                    // line 22
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["readyfor"] = "Ready for review";
                    // line 23
                    echo "\t\t\t\t\t\t\t\t\t";
                }
                echo "\t
\t\t\t\t\t\t\t\t\t";
                // line 24
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "N")) {
                    // line 25
                    echo "\t\t\t\t\t\t\t\t\t\t";
                    $context["readyfor"] = "Failed";
                    // line 26
                    echo "\t\t\t\t\t\t\t\t\t";
                }
                // line 27
                echo "\t\t\t\t\t\t\t\t";
            }
            // line 28
            echo "\t\t\t\t\t\t\t\t<div class=\"number alert ";
            echo twig_escape_filter($this->env, (isset($context["bgclass"]) ? $context["bgclass"] : null), "html", null, true);
            echo "\" title=\"Click to Expand/Collapse below section\" data-toggle=\"collapse\" data-target=\"#section_";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\"> ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "number"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<span id=\"lock_icon_";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
            echo "\" class=\" ";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locked") == "1")) {
                echo " glyphicon glyphicon-lock text-danger ";
            }
            echo " \"></span> &nbsp;&nbsp;&nbsp; <small><b>  ";
            echo twig_escape_filter($this->env, (isset($context["readyfor"]) ? $context["readyfor"] : null), "html", null, true);
            echo "  </b></small> 
\t\t\t\t\t\t\t\t\t<span class=\"pull-right glyphicon glyphicon-minus alert-success\"></span> 
\t\t\t\t\t\t\t\t\t<div class=\"pull-right\">/</div> <span class=\"pull-right glyphicon glyphicon-plus alert-success\" ></span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div id=\"section_";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" class=\"collapse\" style=\"padding:5px 10px; border:1px solid #cccccc; margin:2px;\">
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
            // line 35
            if (((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q")) || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "i"))) {
                // line 36
                echo "\t\t\t\t\t\t\t\t<div class=\"title\">
\t\t\t\t\t\t\t\t<select multiple=\"\" class=\"chosen-select form-control\" id=\"filter";
                // line 37
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "\" name=\"filter";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "[]\" data-placeholder=\"Choose Filters..\">
\t\t\t\t\t\t\t\t\t";
                // line 38
                echo getfilters($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"));
                echo "
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
            }
            // line 42
            echo "\t\t\t\t\t\t\t\t<div class=\"title\">
\t\t\t\t\t\t\t\t\t";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "ptitle"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t";
            // line 44
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "guidance") != "")) {
                // line 45
                echo "\t\t\t\t\t\t\t\t\t<br />
\t\t\t\t\t\t\t\t\t<span class=\"alert alert-warning\">(";
                // line 46
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "guidance"), "html", null, true);
                echo ")</span>
\t\t\t\t\t\t\t\t\t";
            }
            // line 48
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"documents pull-left\">
\t\t\t\t\t\t\t\t\t";
            // line 50
            $context["disabled"] = "";
            // line 51
            echo "\t\t\t\t\t\t\t\t\t";
            $context["readonly"] = "";
            // line 52
            echo "\t\t\t\t\t\t\t\t\t";
            $context["to_qsa_qa"] = "q";
            // line 53
            echo "\t\t\t\t\t\t\t\t\t";
            $context["title_qsa_qa"] = "Comment to QA";
            // line 54
            echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
            // line 55
            if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q")) {
                // line 56
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context["title_qsa_qa"] = "Comment to QSA";
                // line 57
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context["to_qsa_qa"] = "s";
                // line 58
                echo "\t\t\t\t\t\t\t\t\t";
            }
            // line 59
            echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
            // line 60
            if (((($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locked") == "1") && ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") != "q")) && ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") != "a"))) {
                // line 61
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t";
                // line 62
                $context["disabled"] = " disabled";
                // line 63
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context["readonly"] = " readonly";
                // line 64
                echo "\t\t\t\t\t\t\t\t\t";
            }
            // line 65
            echo "\t\t\t\t\t\t\t\t\t";
            $context["extra"] = "";
            // line 66
            echo "\t\t\t\t\t\t\t\t\t";
            if (((twig_length_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "documents")) == 0) && ((isset($context["disabled"]) ? $context["disabled"] : null) == ""))) {
                // line 67
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context["extra"] = " disabled";
                // line 68
                echo "\t\t\t\t\t\t\t\t\t";
            }
            // line 69
            echo "\t\t\t\t\t\t\t\t\t<div class=\"dropdown\" id=\"dropdown";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t<button";
            // line 70
            echo twig_escape_filter($this->env, (isset($context["extra"]) ? $context["extra"] : null), "html", null, true);
            echo twig_escape_filter($this->env, (isset($context["disabled"]) ? $context["disabled"] : null), "html", null, true);
            echo " class=\"btn btn-default btn-xs\" id=\"dLabel\" type=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
\t\t\t\t\t\t\t\t\t\tDocuments
\t\t\t\t\t\t\t\t\t\t<span class=\"caret\"></span>
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t<ul class=\"dropdown-menu\" role=\"menu\" aria-labelledby=\"dLabel\">
\t\t\t\t\t\t\t\t\t\t\t";
            // line 75
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "documents"));
            foreach ($context['_seq'] as $context["key"] => $context["f"]) {
                // line 76
                echo "\t\t\t\t\t\t\t\t\t\t\t\t ";
                $context["fileName"] = $this->getAttribute((isset($context["f"]) ? $context["f"] : null), 0);
                // line 77
                echo "\t\t\t\t\t\t\t\t\t\t\t\t ";
                $context["filepath"] = $this->getAttribute((isset($context["f"]) ? $context["f"] : null), "enc_doc");
                // line 78
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<li><a class=\"pull-left\" href=\"/viewdocument.php?q=";
                echo twig_escape_filter($this->env, (isset($context["filepath"]) ? $context["filepath"] : null), "html", null, true);
                echo "\" target=\"_blank\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["f"]) ? $context["f"] : null), 0), "html", null, true);
                echo "&nbsp;&nbsp;&nbsp;&nbsp;<span class=\"glyphicon glyphicon-save\"></span></a> <small > Date: ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["f"]) ? $context["f"] : null), 1), "html", null, true);
                echo " </small> <a href=\"javascript:deletedoc('";
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, (isset($context["fileName"]) ? $context["fileName"] : null), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                echo "');\" class=\"pull-right\">  <span class=\"glyphicon glyphicon-remove text-danger\"></span></a></li>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 79
                $context["fileName"] = "";
                // line 80
                echo "\t\t\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['f'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 81
            echo "\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<!-- upload document code -->
\t\t\t\t\t\t\t\t<div class=\"comments pull-left\">
\t\t\t\t\t\t\t\t\t<button type=\"button\"";
            // line 86
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locked") == "1")) {
                echo " disabled ";
            }
            echo " onclick=\"setvalueu('";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "');\" title=\"Upload\" data-toggle=\"modal\" data-target=\"#upload\" class=\"btn btn-primary\"><span class=\"glyphicon glyphicon-open\"></span></button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<!-- end Code -->
\t\t\t\t\t\t\t\t\t<div class=\"inplace label-inputs pull-left\">
\t\t\t\t\t\t\t\t\t<select onchange=\"setvalueccw(this.value,'";
            // line 90
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "','u','";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
            echo "', '0',3);\"";
            echo twig_escape_filter($this->env, (isset($context["disabled"]) ? $context["disabled"] : null), "html", null, true);
            echo twig_escape_filter($this->env, (isset($context["readonly"]) ? $context["readonly"] : null), "html", null, true);
            echo " id=\"opt";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" name=\"opt";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" class=\"form-control selectpicker\">
\t\t\t\t\t\t\t\t\t\t<option value=\"\">In place?</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"Y\"";
            // line 92
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "Y")) {
                echo " selected=\"selected\"";
            }
            echo ">Y</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"N\"";
            // line 93
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "N")) {
                echo " selected=\"selected\"";
            }
            echo ">N</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"C\"";
            // line 94
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "C")) {
                echo " selected=\"selected\"";
            }
            echo ">C</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"NT\"";
            // line 95
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "NT")) {
                echo " selected=\"selected\"";
            }
            echo ">NT</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"NA\"";
            // line 96
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "NA")) {
                echo " selected=\"selected\"";
            }
            echo ">NA</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"constraints";
            // line 98
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" id=\"constraints";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "constraints"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"objective";
            // line 99
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" id=\"objective";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "objective"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"risk";
            // line 100
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" id=\"risk";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "risk"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"dcontrols";
            // line 101
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" id=\"dcontrols";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "dcontrols"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"vcontrols";
            // line 102
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" id=\"vcontrols";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "vcontrols"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"maintenance";
            // line 103
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" id=\"maintenance";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "maintenance"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
            // line 105
            if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q")) {
                // line 106
                echo "\t\t\t\t\t\t\t\t\t\t<div class=\"comments pull-left\">
\t\t\t\t\t\t\t\t\t\t\t<button";
                // line 107
                echo twig_escape_filter($this->env, (isset($context["disabled"]) ? $context["disabled"] : null), "html", null, true);
                echo " type=\"button\" id=\"btn-comment";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                echo "\" onclick=\"setvalue('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
                echo "','s', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "', '0',0);\" title=\"Comment to QSA\" data-toggle=\"modal\" data-target=\"#div-comment\" class=\"btn btn-comments btn-xs ";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total_comments") == 0)) {
                    echo "btn-default";
                } else {
                    echo "btn-success";
                }
                echo "\"><span class=\"glyphicon glyphicon-user\"></span></button>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
            }
            // line 110
            echo "\t\t\t\t\t\t\t\t\t";
            if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s")) {
                // line 111
                echo "\t\t\t\t\t\t\t\t\t\t<div class=\"comments pull-left\">
\t\t\t\t\t\t\t\t\t\t\t<button";
                // line 112
                echo twig_escape_filter($this->env, (isset($context["disabled"]) ? $context["disabled"] : null), "html", null, true);
                echo " type=\"button\" id=\"btn-comment";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                echo "\" onclick=\"setvalue('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
                echo "','q', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "qa_id"), "html", null, true);
                echo "',0);\" title=\"Comment to QA\" data-toggle=\"modal\" data-target=\"#div-comment\"  class=\"btn btn-comments btn-xs ";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total_comments") == 0)) {
                    echo "btn-default";
                } else {
                    echo "btn-success";
                }
                echo "\"><span class=\"glyphicon glyphicon-user\"></span></button>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"comments pull-left\">
\t\t\t\t\t\t\t\t\t\t\t<button";
                // line 115
                echo twig_escape_filter($this->env, (isset($context["disabled"]) ? $context["disabled"] : null), "html", null, true);
                echo " type=\"button\" id=\"btn-comment";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                echo "\" onclick=\"setvalue('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
                echo "','u','";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "', '0',0);\" title=\" Comment to User\" data-toggle=\"modal\" data-target=\"#div-comment\"  class=\"btn btn-comments btn-xs ";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total_comments") == 0)) {
                    echo "btn-default";
                } else {
                    echo "btn-success";
                }
                echo "\"><span class=\"glyphicon glyphicon-user\"></span></button>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
            }
            // line 118
            echo "\t\t\t\t\t\t\t\t<div id=\"ccw";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" class=\"comments pull-left\" style=\"display:";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "inplace") == "C")) {
                echo "block;";
            } else {
                echo "none;";
            }
            echo "\">
\t\t\t\t\t\t\t\t\t<button";
            // line 119
            echo twig_escape_filter($this->env, (isset($context["disabled"]) ? $context["disabled"] : null), "html", null, true);
            echo " id=\"ccw-btn-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "\" type=\"button\" onclick=\"setvalueccw('CC', '";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "pid"), "html", null, true);
            echo "');\" title=\"Compensating Controls Worksheet\" data-toggle=\"modal\" data-target=\"#ccw\" class=\"btn btn-comments btn-xs ";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "ccw_completed") == "n")) {
                echo "btn-danger";
            } else {
                echo "btn-success";
            }
            echo "\">CCW</button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
            // line 121
            if ((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "a"))) {
                // line 122
                echo "\t\t\t\t\t\t\t\t<div class=\"lockunlock pull-left\" id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t<input";
                // line 123
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "locked") == "1")) {
                    echo " checked ";
                }
                echo " value=\"1\" onchange=\"lockunlock('";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "');\" id=\"switch";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "\" data-size=\"large\" data-handle-width=\"50\" data-on-color=\"danger\" data-off-color=\"success\" class=\"switch\" type=\"checkbox\" data-off-text=\"Unlock\" data-on-text=\"Lock\" > 
\t\t\t\t\t\t\t\t\t<div id=\"val";
                // line 124
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
            }
            // line 127
            echo "\t\t\t\t\t\t\t\t";
            if (((($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "q") || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s")) || ($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "a"))) {
                // line 128
                echo "\t\t\t\t\t\t\t\t<div class=\"comments pull-left\">
\t\t\t\t\t\t\t\t<select multiple=\"multiple\" class=\"chosen-select form-control\" id=\"";
                // line 129
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "_int_id\" name=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "_int_id[]\" data-placeholder=\"Choose interviewed employee \">
\t\t\t\t\t\t\t\t\t\t";
                // line 130
                echo getinterviewer($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"));
                echo "
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"comments pull-left\">
\t\t\t\t\t\t\t\t<select multiple=\"multiple\" class=\"chosen-select form-control\" id=\"";
                // line 134
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "_set_id\" name=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "_set_id[]\" data-placeholder=\"Choose sample set \">
\t\t\t\t\t\t\t\t\t\t";
                // line 135
                echo getsamplesets($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"));
                echo "
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"comments pull-left\">
\t\t\t\t\t\t\t\t<select multiple=\"multiple\" class=\"chosen-select form-control\" id=\"";
                // line 139
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "_doc_id\" name=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                echo "_doc_id[]\" data-placeholder=\"Choose Document \">
\t\t\t\t\t\t\t\t\t\t";
                // line 140
                echo getdocfiles($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"));
                echo "
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
            }
            // line 144
            echo "\t\t\t\t\t\t\t\t";
            if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "roc_saq") == "roc")) {
                // line 145
                echo "\t\t\t\t\t\t\t\t<div class=\"pull-right col-lg-7\" >
\t\t\t\t\t\t\t\t\t\t";
                // line 146
                if ((twig_length_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "reports")) > 0)) {
                    // line 147
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "reports"));
                    foreach ($context['_seq'] as $context["key1"] => $context["val1"]) {
                        // line 148
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        if (($this->getAttribute((isset($context["val1"]) ? $context["val1"] : null), "bulet") == 1)) {
                            // line 149
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                            $context["ul_style"] = "list-style:none; overflow-y: hidden !important; height:auto !important;";
                            // line 150
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                            $context["allow_input"] = 1;
                            // line 151
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        } else {
                            // line 152
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                            $context["ul_style"] = "overflow-y: hidden !important; height:auto !important;";
                            // line 153
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                            $context["allow_input"] = 0;
                            // line 154
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        // line 155
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<ul  role=\"menu\" aria-labelledby=\"dLabel\" style=\"";
                        echo twig_escape_filter($this->env, (isset($context["ul_style"]) ? $context["ul_style"] : null), "html", null, true);
                        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<li style=\"border:none !important; \"> ";
                        // line 156
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["val1"]) ? $context["val1"] : null), "title"), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 157
                        if (((isset($context["allow_input"]) ? $context["allow_input"] : null) == 1)) {
                            // line 158
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea id=\"doc_report_input";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                            echo "[]\" rows=\"2\" cols=\"5\" ";
                            echo twig_escape_filter($this->env, (isset($context["readonly"]) ? $context["readonly"] : null), "html", null, true);
                            echo " class=\"form-control\" name=\"doc_report_input";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                            echo "[]\" >";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["val1"]) ? $context["val1"] : null), "drc"), "html", null, true);
                            echo "</textarea>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"rep_id";
                            // line 159
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), "html", null, true);
                            echo "[]\" value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["val1"]) ? $context["val1"] : null), "id"), "html", null, true);
                            echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        // line 161
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t</li>\t
\t\t\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['key1'], $context['val1'], $context['_parent'], $context['loop']);
                    $context = array_merge($_parent, array_intersect_key($context, $_parent));
                    // line 164
                    echo "\t\t\t\t\t\t\t\t\t\t";
                }
                // line 165
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context["is_html"] = true;
                // line 166
                echo "\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, printInterviewer($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), (isset($context["is_html"]) ? $context["is_html"] : null)), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t";
                // line 167
                echo twig_escape_filter($this->env, printSamplesets($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), (isset($context["is_html"]) ? $context["is_html"] : null)), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t";
                // line 168
                echo twig_escape_filter($this->env, printDocfiles($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "doc_id"), (isset($context["is_html"]) ? $context["is_html"] : null)), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
            }
            // line 171
            echo "\t\t\t\t\t\t\t\t<div style=\"clear:both;\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
            // line 173
            $context["nmbr"] = ((isset($context["nmbr"]) ? $context["nmbr"] : null) + 1);
            echo "\t
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 175
        echo "\t\t\t\t\t\t\t</div>";
    }

    public function getTemplateName()
    {
        return "getcontent.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  655 => 175,  647 => 173,  643 => 171,  637 => 168,  633 => 167,  628 => 166,  625 => 165,  622 => 164,  614 => 161,  607 => 159,  596 => 158,  594 => 157,  590 => 156,  585 => 155,  582 => 154,  579 => 153,  576 => 152,  573 => 151,  570 => 150,  567 => 149,  564 => 148,  559 => 147,  557 => 146,  554 => 145,  551 => 144,  544 => 140,  538 => 139,  531 => 135,  525 => 134,  518 => 130,  512 => 129,  509 => 128,  506 => 127,  500 => 124,  490 => 123,  485 => 122,  483 => 121,  468 => 119,  457 => 118,  437 => 115,  415 => 112,  412 => 111,  409 => 110,  389 => 107,  386 => 106,  384 => 105,  375 => 103,  367 => 102,  359 => 101,  351 => 100,  343 => 99,  335 => 98,  328 => 96,  322 => 95,  316 => 94,  310 => 93,  304 => 92,  288 => 90,  277 => 86,  270 => 81,  264 => 80,  262 => 79,  245 => 78,  242 => 77,  239 => 76,  235 => 75,  226 => 70,  221 => 69,  218 => 68,  215 => 67,  212 => 66,  209 => 65,  206 => 64,  203 => 63,  201 => 62,  198 => 61,  196 => 60,  193 => 59,  190 => 58,  187 => 57,  184 => 56,  182 => 55,  179 => 54,  176 => 53,  173 => 52,  170 => 51,  168 => 50,  164 => 48,  159 => 46,  156 => 45,  154 => 44,  150 => 43,  147 => 42,  140 => 38,  134 => 37,  131 => 36,  129 => 35,  124 => 33,  111 => 29,  102 => 28,  99 => 27,  96 => 26,  93 => 25,  91 => 24,  86 => 23,  83 => 22,  80 => 21,  77 => 20,  74 => 19,  71 => 18,  68 => 17,  65 => 16,  62 => 15,  59 => 14,  56 => 13,  53 => 12,  50 => 11,  47 => 10,  44 => 9,  41 => 8,  39 => 7,  36 => 6,  33 => 5,  28 => 4,  26 => 3,  22 => 2,  19 => 1,);
    }
}
