<?php

/* network-segmentation.html */
class __TwigTemplate_64f2a57a8ca4a0ceaded6245a710b221 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 16
            echo "<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 35
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 36
            echo "      <!-- Tab panes -->
\t\t<div class=\"tab-content tab_border\">
\t\t<div role=\"tabpanel\" class=\"tab-pane active\" id=\"screen1\">
            <div class=\"screen7_inner_part new_field_block_part widget-box widget-color-blue\">
            \t<div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i> 3 Description of SOW &amp; Approach Taken </h4>
                </div>
                
                <div class=\"widget-body\">
                \t<div class=\"widget-main widget_main_extra_part\">
                    \t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">3.3 Network segmentation</div>
                    \t<div class=\"table-responsive screen_field_part\">
                \t\t\t<table class=\"table table-striped\">
                              <tbody>
                                <tr>
                                  <td><strong>Identify whether the assessed entity has used network segmentation to reduce the scope of the assessment.(Yes/No)</strong></td>
                                  <td>
                                  <div class=\"lockunlock pull-left\" >
                                  <input value=\"0\" id=\"segment_used-1-1\" name=\"segment_used1\"";
            // line 54
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "segment_used"), "value") == "yes")) {
                echo " checked=\"checked\"";
            }
            echo " data-size=\"large\" data-handle-width=\"50\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\">
                                  <input type=\"hidden\" name=\"segment_used\" id=\"segment_used1\" value=\"";
            // line 55
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "segment_used"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t</td>
                                </tr>
                                <tr>
                                  <td><strong>If segmentation is used:</strong></th>
                                  <td><strong>If segmentation is not used:</strong></th>
                                </tr>
                                <tr>
                                  <td>
                                      <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
                                        <div class=\"field_part field_part_height network_seg_field widget_field_part\">
                                            <div class=\"form-group form_block_margin\">
                                                <label class=\"col-md-6 col-sm-6 col-xs-12 control-label network_label_height label_align\">Briefly describe how the segmentation is implemented:</label>
                                                <div class=\"col-md-6 col-sm-6 col-xs-12 widget_textarea_extra\">
                                                  <textarea name=\"implemented\" id=\"implemented\" class=\"form-control used_yes\" rows=\"2\" placeholder=\"Please Enter Here\">";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "implemented"), "value"), "html", null, true);
            echo "</textarea>
                                                </div>
                                              </div>
                                        </div>
                                    </div>
                                </td>
                                  <td>
                                  <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
                                        <div class=\"field_part field_part_height network_seg_field widget_field_part\">
                                            <div class=\"form-group form_block_margin\">
                                                <label class=\"col-md-6 col-sm-6 col-xs-12 control-label network_label_height label_align\">Provide the name of the assessor who attests that the whole network has been included in the scope of the assessment.</label>
                                                <div class=\"col-md-6 col-sm-6 col-xs-12 widget_textarea_extra\">
                                                  <textarea name=\"not_used\" id=\"not_used\" class=\"form-control used_no\" rows=\"2\" placeholder=\"\">";
            // line 82
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "not_used"), "value"), "html", null, true);
            echo "</textarea>
                                                </div>
                                              </div>
                                        </div>
                                    </div>
                                </td>
                                <tr>
                                    <td>
                                  <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
                                        <div class=\"field_part field_part_height network_seg_field widget_field_part\">
                                            <div class=\"form-group form_block_margin\">
                                                <label class=\"col-md-6 col-sm-6 col-xs-12 control-label network_label_height label_align\">Identify the technologies used and any supporting processes:</label>
                                                <div class=\"col-md-6 col-sm-6 col-xs-12 widget_textarea_extra\">
                                                  <textarea name=\"technologies\" id=\"technologies\"  class=\"form-control used_yes\" rows=\"2\" placeholder=\"Please Enter here\">";
            // line 95
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "technologies"), "value"), "html", null, true);
            echo "</textarea>
                                                </div>
                                              </div>
                                        </div>
                                    </div>
                                </td>
                                <td rowspan=\"5\">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td>
                                        <strong>Explain how the assessor validated the effectiveness of the segmentation, as follows:</strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                  <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
                                        <div class=\"field_part field_part_height network_seg_field widget_field_part\">
                                            <div class=\"form-group form_block_margin\">
                                                <label class=\"col-md-6 col-sm-6 col-xs-12 control-label network_label_height label_align\">Describe the methods used to validate the effectiveness of the segmentation:</label>
                                                <div class=\"col-md-6 col-sm-6 col-xs-12 widget_textarea_extra\">
                                                  <textarea name=\"methods_used\" id=\"methods_used\" class=\"form-control used_yes\" rows=\"2\" placeholder=\"Please Enter here\">";
            // line 115
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "methods_used"), "value"), "html", null, true);
            echo "</textarea>
                                                </div>
                                              </div>
                                        </div>
                                    </div>
                                </td>
                                </tr>
                                <tr>
                                    <td>
                                  <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
                                        <div class=\"field_part field_part_height network_seg_field widget_field_part\">
                                            <div class=\"form-group form_block_margin\">
                                                <label class=\"col-md-6 col-sm-6 col-xs-12 control-label network_label_height label_align\">Describe how it was verified that the segmentation is functioning as intended.</label>
                                                <div class=\"col-md-6 col-sm-6 col-xs-12 widget_textarea_extra\">
                                                  <textarea name=\"verified_functioning\" id=\"verified_functioning\" class=\"form-control used_yes\" rows=\"2\" placeholder=\"Please Enter here\">";
            // line 129
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "verified_functioning"), "value"), "html", null, true);
            echo "</textarea>
                                                </div>
                                              </div>
                                        </div>
                                    </div>
                                </td>
                                </tr>
                                <tr>
                                    <td>
                                  <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
                                        <div class=\"field_part field_part_height network_seg_field widget_field_part\">
                                            <div class=\"form-group form_block_margin\">
                                                <label class=\"col-md-6 col-sm-6 col-xs-12 control-label network_label_height label_align\">-\tIdentify the security controls that are in place to ensure the integrity of the segmentation mechanisms (e.g., access controls, change management, logging, monitoring, etc.).</label>
                                                <div class=\"col-md-6 col-sm-6 col-xs-12 widget_textarea_extra\">
                                                  <textarea name=\"mechanism\" id=\"mechanism\" class=\"form-control used_yes\" rows=\"2\" placeholder=\"Please Enter here\">";
            // line 143
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "mechanism"), "value"), "html", null, true);
            echo "</textarea>
                                                </div>
                                              </div>
                                        </div>
                                    </div>
                                </td>
                                </tr>
\t\t\t\t\t\t\t\t<tr>
                                    <td>
                                  <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
                                        <div class=\"field_part field_part_height network_seg_field widget_field_part\">
                                            <div class=\"form-group form_block_margin\">
                                                <label class=\"col-md-6 col-sm-6 col-xs-12 control-label network_label_height label_align\">-\tDescribe how it was verified that the identified security controls are in place.</label>
                                                <div class=\"col-md-6 col-sm-6 col-xs-12 widget_textarea_extra\">
                                                  <textarea name=\"security_control\" id=\"security_control\" class=\"form-control used_yes\" rows=\"2\" placeholder=\"Please Enter here\">";
            // line 157
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "security_control"), "value"), "html", null, true);
            echo "</textarea>
                                                </div>
                                              </div>
                                        </div>
                                    </div>
                                </td>
                                </tr>
                                <tr>
                                    <td colspan=\"2\">
                                  <div class=\"col-md-12 col-sm-12 col-xs-12 screen_field_part widget_field_part_margin\">
                                        <div class=\"field_part screen7_extra network_seg_field widget_field_part\">
                                            <div class=\"form-group form_block_margin field_part_height\">
                                                <label class=\"col-md-6 col-sm-6 col-xs-12 control-label network_label_height label_align\">Provid the name of the assessor who attests that the segmentation was verified to be adequate to redute the scope of the assessment AND that the technologies/processes used to implement segmentation were included in the PCI DSS assessment.</label>
                                                <div class=\"col-md-6 col-sm-6 col-xs-12 widget_textarea_extra\">
                                                  <textarea name=\"tech_included_pci_dss\" id=\"tech_included_pci_dss\" class=\"form-control\" rows=\"2\" placeholder=\"Please Enter here\">";
            // line 171
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "tech_included_pci_dss"), "value"), "html", null, true);
            echo "</textarea>
                                                </div>
                                              </div>
                                        </div>
                                    </div>
                                </td>
                                </tr>
                                </tr>
                              </tbody>
                            </table>
              \t\t\t</div>
\t\t\t\t\t\t<button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 182
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button> 
                    </div>
                </div>
            </div>
        </div>
\t\t</div>
\t</form>
</div>
";
        }
    }

    // line 193
    public function block_footer($context, array $blocks = array())
    {
        // line 194
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/admin/css/datepicker3.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/admin/js/bootstrap-datepicker.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script src=\"/assets/js/chosen.jquery.js\"></script>
\t<link href=\"/assets/css/bootstrap-switch.css\" type=\"text/css\" rel=\"stylesheet\">
\t<script src=\"/assets/js/bootstrap-switch.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 205
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 206
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 210
            echo "\t\$(document).ready(function() {
\t\t\$('#frm').bootstrapValidator();
\t\t\$(\".switch\").bootstrapSwitch();
\t\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\t\tary = \$(this).attr('id').split('-');
\t\t\tval = state ? 'yes' : 'no';
\t\t\t\$('#'+ary[0]+ary[2]).val(val);
\t\t\tif ( val == 'yes' )
\t\t\t{
\t\t\t\t\$(\".used_no\").attr(\"readonly\", \"readonly\");
\t\t\t\t\$(\".used_yes\").removeAttr(\"readonly\");
\t\t\t}
\t\t\telse
\t\t\t{
\t\t\t\t\$(\".used_yes\").attr(\"readonly\", \"readonly\");
\t\t\t\t\$(\".used_no\").removeAttr(\"readonly\");
\t\t\t}
\t\t});
\t});
\t";
            // line 229
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "segment_used"), "value") == "yes")) {
                // line 230
                echo "\t\t\$(\".used_no\").attr(\"readonly\", \"readonly\");
\t";
            } else {
                // line 232
                echo "\t\t\$(\".used_yes\").attr(\"readonly\", \"readonly\");
\t";
            }
        }
        // line 235
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "network-segmentation.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  381 => 235,  376 => 232,  372 => 230,  370 => 229,  349 => 210,  343 => 206,  341 => 205,  326 => 194,  323 => 193,  308 => 182,  294 => 171,  277 => 157,  260 => 143,  243 => 129,  226 => 115,  203 => 95,  187 => 82,  172 => 70,  154 => 55,  148 => 54,  128 => 36,  126 => 35,  121 => 33,  117 => 32,  113 => 31,  109 => 30,  104 => 28,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  75 => 16,  69 => 13,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
