<?php

/* front-bulk-upload.html */
class __TwigTemplate_398f3ab21ebe80495d91514b2c887f54 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("new-front-layout.html");

        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "new-front-layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_head($context, array $blocks = array())
    {
        // line 3
        echo "\t";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/jupload/css/jquery.fileupload.css\">
\t<link rel=\"stylesheet\" href=\"/assets/jupload/css/jquery.fileupload-ui.css\">
\t<!-- CSS adjustments for browsers with JavaScript disabled -->
\t<noscript><link rel=\"stylesheet\" href=\"/assets/jupload/css/jquery.fileupload-noscript.css\"></noscript>
\t<noscript><link rel=\"stylesheet\" href=\"/assets/jupload/css/jquery.fileupload-ui-noscript.css\"></noscript>
\t<style type=\"text/css\">
\t.progress {
\t\theight:14px;
\t\tmargin:0px;
\t\twidth:auto;
\t}
\t</style>
";
    }

    // line 17
    public function block_body($context, array $blocks = array())
    {
        // line 18
        echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
<div class=\"row\">
\t<div class=\"col-xs-12\">
\t\t";
        // line 21
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s")) {
            // line 22
            echo "\t\t<div class=\"col-sm-3\">
\t\t\t<select name=\"cmp_id\" id=\"cmp_id\" class=\"form-control\" style=\"margin-top: 4px;\" onchange=\"getdocumentlist('company', '');\">
\t\t\t\t<option value=\"\">Select Company</option>
\t\t\t\t";
            // line 25
            echo $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "companies");
            echo "
\t\t\t</select>
\t\t</div>
\t\t";
        } else {
            // line 29
            echo "\t\t\t<input type=\"hidden\" name=\"cmp_id\" id=\"cmp_id\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "company_id"), "method"), "html", null, true);
            echo "\" />
\t\t";
        }
        // line 31
        echo "\t\t<div class=\"col-sm-3\">
\t\t\t<a href=\"javascript:void(0);\" id=\"uploadfiles\" onclick=\"setcompany();\" class=\"btn btn-default\" data-toggle=\"modal\"><i class=\"fa fa-files-o\"></i> Upload Files</a>
\t\t</div>
\t\t<div class=\"col-sm-3 col-sm-offset-";
        // line 34
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "s")) {
            echo "3";
        } else {
            echo "6";
        }
        echo "\">
\t\t\t<div class=\"pull-right\" style=\"margin-top: 8px;\">
\t\t\t\t<label for=\"pg\">Page</label>
\t\t\t\t<select id=\"pg\" class=\"selectpicker\" name=\"pg\" onchange=\"getdocumentlist('page', '');\">
\t\t\t\t\t<option value=\"\">Page</option>
\t\t\t\t</select>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"col-sm-12\" style=\"margin-top: 10px;\">
\t\t\t<div class=\"table-responsive\">
\t\t\t\t<table id=\"simple-table\" class=\"table table-bordered table-hover table-striped table-condensed\">
\t\t\t\t\t<thead>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<th class=\"text-center\">
\t\t\t\t\t\t\t\t<label class=\"pos-rel\">
\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"ace\" />
\t\t\t\t\t\t\t\t\t<span class=\"lbl\"></span>
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t</th>
\t\t\t\t\t\t\t<th class=\"text-center\">Sr.</th>
\t\t\t\t\t\t\t<th>File</th>
\t\t\t\t\t\t\t<th>Udated Date</th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</thead>
\t\t\t\t\t<tbody id=\"documents\">
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td colspan=\"8\">No Records</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</tbody>
\t\t\t\t\t<tfoot>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td class=\"text-center\"><button type=\"button\" title=\"Delete\" onclick=\"deldocs();\" class=\"btn btn-danger\"><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></button></td>
\t\t\t\t\t\t\t<td colspan=\"8\"></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
</form>

<div class=\"modal fade bs-example-modal-lg\" id=\"upload_files\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
\t<div class=\"modal-dialog modal-lg\">
\t\t<div class=\"modal-content\">
\t\t\t<div class=\"modal-header\">
\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
\t\t\t\t<h4 class=\"modal-title\" id=\"upload-title\">Upload Files</h4>
\t\t\t</div>
\t\t\t<div class=\"modal-body\">
\t\t\t\t<form id=\"fileupload\" action=\"\" method=\"POST\" enctype=\"multipart/form-data\">
\t\t\t\t\t<input type=\"hidden\" name=\"company_id\" id=\"company_id\" value=\"1\" />
\t\t\t\t\t<div class=\"row fileupload-buttonbar\">
\t\t\t\t\t\t<div class=\"col-lg-7\">
\t\t\t\t\t\t\t<!-- The fileinput-button span is used to style the file input field as button -->
\t\t\t\t\t\t\t<span class=\"btn btn-success fileinput-button\">
\t\t\t\t\t\t\t\t<i class=\"glyphicon glyphicon-plus\"></i>
\t\t\t\t\t\t\t\t<span>Add files...</span>
\t\t\t\t\t\t\t\t<input type=\"file\" name=\"files[]\" multiple>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-primary start\">
\t\t\t\t\t\t\t\t<i class=\"glyphicon glyphicon-upload\"></i>
\t\t\t\t\t\t\t\t<span>Start upload</span>
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t<button type=\"reset\" class=\"btn btn-warning cancel\">
\t\t\t\t\t\t\t\t<i class=\"glyphicon glyphicon-ban-circle\"></i>
\t\t\t\t\t\t\t\t<span>Cancel upload</span>
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t<!-- The global file processing state -->
\t\t\t\t\t\t\t<span class=\"fileupload-process\"></span>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<table role=\"presentation\" class=\"table table-striped\"><tbody class=\"files\"></tbody></table>
\t\t\t\t</form>
\t\t\t</div>
\t\t\t<div class=\"modal-footer\">
\t\t\t\t<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
";
        // line 147
        echo "
<script id=\"template-upload\" type=\"text/x-tmpl\">
{% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class=\"template-upload fade\">
        <td>
            <span class=\"preview\"></span>
        </td>
        <td>
            <p class=\"name\">{%=file.name%}</p>
            <strong class=\"error text-danger\"></strong>
        </td>
        <td>
            <p class=\"size\">Processing...</p>
            <div class=\"progress progress-striped active\" role=\"progressbar\" aria-valuemin=\"0\" aria-valuemax=\"100\" aria-valuenow=\"0\"><div class=\"progress-bar progress-bar-success\" style=\"width:0%;\"></div></div>
        </td>
        <td>
            {% if (!i && !o.options.autoUpload) { %}
                <button class=\"btn btn-primary start\" disabled>
                    <i class=\"glyphicon glyphicon-upload\"></i>
                    <span>Start</span>
                </button>
            {% } %}
            {% if (!i) { %}
                <button class=\"btn btn-warning cancel\">
                    <i class=\"glyphicon glyphicon-ban-circle\"></i>
                    <span>Cancel</span>
                </button>
            {% } %}
        </td>
    </tr>
{% } %}
</script>
";
        echo "
";
    }

    // line 149
    public function block_footer($context, array $blocks = array())
    {
        // line 150
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<script src=\"/assets/js/list.js\"></script>
\t<!-- The jQuery UI widget factory, can be omitted if jQuery UI is already included -->
\t<script src=\"/assets/jupload/js/vendor/jquery.ui.widget.js\"></script>
\t<!-- The Templates plugin is included to render the upload/download listings -->
\t<script src=\"/assets/jupload/js/tmpl.min.js\"></script>
\t<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
\t<script src=\"/assets/jupload/js/jquery.iframe-transport.js\"></script>
\t<!-- The basic File Upload plugin -->
\t<script src=\"/assets/jupload/js/jquery.fileupload.js\"></script>
\t<!-- The File Upload processing plugin -->
\t<script src=\"/assets/jupload/js/jquery.fileupload-process.js\"></script>
\t<!-- The File Upload validation plugin -->
\t<script src=\"/assets/jupload/js/jquery.fileupload-validate.js\"></script>
\t<!-- The File Upload user interface plugin -->
\t<script src=\"/assets/jupload/js/jquery.fileupload-ui.js\"></script>
\t<!-- The XDomainRequest Transport is included for cross-domain file deletion for IE 8 and IE 9 -->
\t<!--[if (gte IE 8)&(lt IE 10)]>
\t<script src=\"/assets/jupload/js/cors/jquery.xdr-transport.js\"></script>
\t<![endif]-->
\t<script type=\"text/javascript\">
\t\$(function () {
\t\t'use strict';

\t\t// Initialize the jQuery File Upload widget:
\t\t\$('#fileupload').fileupload({
\t\t\t// Uncomment the following to send cross-domain cookies:
\t\t\t//xhrFields: {withCredentials: true},
\t\t\turl: '/lib/jupload/'
\t\t\t,done: function(e, data) {
\t\t\t\t\$('.files').html('');
\t\t\t\tgetdocumentlist('company', '');
\t\t\t}
\t\t});
\t});
\tfunction getdocumentlist(source, delids)
\t{
\t\tformfields = 'source='+source+'&cmp_id='+\$('#cmp_id').val()+'&pg='+\$('#pg').val()+'&delids='+delids;
\t\ttheurl = '/getdocumentlist.php';
\t\t\$.ajax({
\t\t\ttype: \"POST\",
\t\t\turl: theurl,
\t\t\tdata: formfields,
\t\t\tbeforeSend: function( xhr ) {
\t\t\t}
\t\t}).done(function(data) {
\t\t\tary = data.split('||||');
\t\t\t\$('#documents').html(ary[0]);
\t\t\t\$('#pg').html(ary[1]);
\t\t});
\t}
\tfunction setcompany()
\t{
\t\tif ( \$('#cmp_id').val() == '' )
\t\t{
\t\t\talert('Please select company');
\t\t\treturn false;
\t\t}
\t\t\$('#upload-title').html('Upload File :: '+\$(\"#cmp_id option[value='\"+\$('#cmp_id').val()+\"']\").text());
\t\t\$('#company_id').val(\$('#cmp_id').val());
\t\t\$('#upload_files').modal('show');
\t}
\tfunction deldocs()
\t{
\t\tfrm = document.getElementById('frm');
\t\tcnt = 0;
\t\tdelstr = '';
\t\tfor(i=0; i<frm.elements.length; i++)
\t\t{
\t\t\tvar e = frm.elements[i];
\t\t\tif ( e.name == 'removeid[]' && e.checked )
\t\t\t{
\t\t\t\tif ( delstr != '' ) delstr = delstr + ',';
\t\t\t\tdelstr = delstr + e.value;
\t\t\t\tcnt++;
\t\t\t}
\t\t}
\t\tif ( cnt == 0 )
\t\t{
\t\t\talert('Please check atlest one document to delete');
\t\t}
\t\tif ( cnt > 0 && confirm('Are you sure? delete selected document(s)') )
\t\t{
\t\t\tgetdocumentlist('company', delstr);
\t\t}
\t}
\t";
        // line 236
        if (($this->getAttribute((isset($context["session"]) ? $context["session"] : null), "get", array(0 => "userrole"), "method") == "u")) {
            // line 237
            echo "\t\$(document).ready(function() {
\t\tgetdocumentlist('company', '');
\t});
\t";
        }
        // line 241
        echo "\t</script>
";
    }

    public function getTemplateName()
    {
        return "front-bulk-upload.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  312 => 241,  306 => 237,  304 => 236,  214 => 150,  211 => 149,  173 => 147,  85 => 34,  80 => 31,  74 => 29,  67 => 25,  62 => 22,  60 => 21,  55 => 18,  52 => 17,  33 => 3,  30 => 2,);
    }
}
