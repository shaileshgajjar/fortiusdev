<?php

/* _upload-diagram-reviewed-env.html */
class __TwigTemplate_96a74f0f7deb51f4008fb6a4487179f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- Upload Document Div -->
<div class=\"modal fade\" id=\"upload\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"myModalLabel\">Upload Diagram</h4>
      </div>
      <div class=\"modal-body\">
        <form id=\"frmdiagram\" name=\"frmdiagram\" method=\"post\" action=\"/save-diagram.php\" enctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"savediagram\" />
\t\t\t<input type=\"hidden\" name=\"section_id\" id=\"section_id\" value=\"2\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
        echo "\" />
\t\t\t<input type=\"file\" name=\"diagram\" id=\"diagram\" style=\"height:30px; cursor:pointer;\" class=\"pull-left\" />
\t\t\t<button type=\"submit\" class=\"btn btn-success pull-left\">Upload</button>
\t\t</form>
\t\t<div class=\"progress\">
\t\t\t<div class=\"bar\"></div >
\t\t\t<div class=\"percent\">0%</div >
\t\t</div>
\t\t<div id=\"statusdiagram\" class=\"alert\"></div>
\t  </div>
      <div class=\"modal-footer\">
\t\t<button type=\"button\" class=\"btn btn-success\" data-dismiss=\"modal\" onclick=\"submitForm();\">Save</button>
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- End upload Doc -->";
    }

    public function getTemplateName()
    {
        return "_upload-diagram-reviewed-env.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 13,  19 => 1,  375 => 155,  364 => 146,  358 => 142,  356 => 141,  346 => 135,  343 => 134,  336 => 131,  324 => 122,  316 => 116,  300 => 113,  296 => 111,  292 => 109,  290 => 108,  286 => 107,  282 => 106,  278 => 105,  258 => 103,  244 => 91,  227 => 88,  221 => 87,  215 => 86,  212 => 85,  195 => 84,  175 => 66,  158 => 64,  154 => 63,  124 => 35,  122 => 34,  117 => 32,  113 => 31,  109 => 30,  105 => 29,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  80 => 22,  71 => 15,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
