<?php

/* new-layout.html */
class __TwigTemplate_96be5fc88574906cb534b967a8f23807 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
\t<head>
";
        // line 4
        $this->displayBlock('head', $context, $blocks);
        // line 46
        echo "\t</head>

\t<body class=\"skin-1\">
\t\t
\t\t";
        // line 50
        $this->env->loadTemplate("_header.html")->display($context);
        // line 51
        echo "
\t\t<div class=\"main-container\" id=\"main-container\">

\t\t\t";
        // line 54
        $this->env->loadTemplate("_side-bar.html")->display($context);
        // line 55
        echo "\t\t\t<div class=\"main-content\">
\t\t\t\t<div class=\"main-content-inner\">
\t\t\t\t\t<div class=\"page-content\">
\t\t\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t\t\t<h1>
\t\t\t\t\t\t\t\tDashboard
\t\t\t\t\t\t\t\t";
        // line 61
        if (($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "page") != "dashboard")) {
            // line 62
            echo "\t\t\t\t\t\t\t\t<small>
\t\t\t\t\t\t\t\t\t<i class=\"ace-icon fa fa-angle-double-right\"></i>
\t\t\t\t\t\t\t\t\t";
            // line 64
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "title"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</small>
\t\t\t\t\t\t\t\t";
        }
        // line 67
        echo "\t\t\t\t\t\t\t</h1>
\t\t\t\t\t\t</div><!-- /.page-header -->

\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-xs-12\">
\t\t\t\t\t\t\t\t<!-- PAGE CONTENT BEGINS -->
\t\t\t\t\t\t\t\t";
        // line 73
        $this->displayBlock('body', $context, $blocks);
        // line 74
        echo "\t\t\t\t\t\t\t\t<!-- PAGE CONTENT ENDS -->
\t\t\t\t\t\t\t</div><!-- /.col -->
\t\t\t\t\t\t</div><!-- /.row -->
\t\t\t\t\t</div><!-- /.page-content -->
\t\t\t\t</div>
\t\t\t</div><!-- /.main-content -->

\t\t\t";
        // line 81
        $this->env->loadTemplate("_footer.html")->display($context);
        // line 82
        echo "\t\t</div><!-- /.main-container -->

\t\t";
        // line 84
        $this->displayBlock('footer', $context, $blocks);
        // line 131
        echo "\t";
        $this->env->loadTemplate("_settings.html")->display($context);
        // line 132
        echo "\t";
        $this->env->loadTemplate("_profile.html")->display($context);
        // line 133
        echo "\t";
        $this->env->loadTemplate("_profile-avtar.html")->display($context);
        // line 134
        echo "\t</body>
</html>
";
    }

    // line 4
    public function block_head($context, array $blocks = array())
    {
        // line 5
        echo "\t\t<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />
\t\t<meta charset=\"utf-8\" />
\t\t<title>";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pagetitle"), "html", null, true);
        echo "</title>

\t\t<meta name=\"description\" content=\"top menu &amp; navigation\" />
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0\" />

\t\t<!-- bootstrap & fontawesome -->
\t\t<link rel=\"stylesheet\" href=\"/assets/css/bootstrap.css\" />
\t\t<link rel=\"stylesheet\" href=\"/assets/css/font-awesome.min.css\" />

\t\t<!-- page specific plugin styles -->

\t\t<!-- text fonts -->
\t\t<link rel=\"stylesheet\" href=\"/assets/css/ace-fonts.css\" />

\t\t<!-- ace styles -->
\t\t<link rel=\"stylesheet\" href=\"/assets/css/ace.css\" class=\"ace-main-stylesheet\" id=\"main-ace-style\" />
\t\t<link rel=\"stylesheet\" href=\"/assets/css/ace-skins.css\" class=\"ace-main-stylesheet\" id=\"main-ace-style\" />
\t\t<link rel=\"stylesheet\" href=\"/assets/css/security.css\" class=\"ace-main-stylesheet\" id=\"main-ace-style\" />

\t\t<!--[if lte IE 9]>
\t\t\t<link rel=\"stylesheet\" href=\"/assets/css/ace-part2.css\" class=\"ace-main-stylesheet\" />
\t\t<![endif]-->

\t\t<!--[if lte IE 9]>
\t\t  <link rel=\"stylesheet\" href=\"/assets/css/ace-ie.css\" />
\t\t<![endif]-->

\t\t<!-- inline styles related to this page -->

\t\t<!-- ace settings handler -->
\t\t<script src=\"/assets/js/ace-extra.js\"></script>

\t\t<!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

\t\t<!--[if lte IE 8]>
\t\t<script src=\"/assets/js/html5shiv.js\"></script>
\t\t<script src=\"/assets/js/respond.js\"></script>
\t\t<![endif]-->
";
    }

    // line 73
    public function block_body($context, array $blocks = array())
    {
    }

    // line 84
    public function block_footer($context, array $blocks = array())
    {
        // line 85
        echo "\t\t<!-- basic scripts -->

\t\t<!--[if !IE]> -->
\t\t<script type=\"text/javascript\">
\t\t\twindow.jQuery || document.write(\"<script src='/assets/js/jquery.js'>\"+\"<\"+\"/script>\");
\t\t</script>

\t\t<!-- <![endif]-->

\t\t<!--[if IE]>
<script type=\"text/javascript\">
 window.jQuery || document.write(\"<script src='/assets/js/jquery1x.js'>\"+\"<\"+\"/script>\");
</script>
<![endif]-->
\t\t<script type=\"text/javascript\">
\t\t\tif('ontouchstart' in document.documentElement) document.write(\"<script src='/assets/js/jquery.mobile.custom.js'>\"+\"<\"+\"/script>\");
\t\t</script>
\t\t<script src=\"/assets/js/bootstrap.js\"></script>

\t\t<!-- page specific plugin scripts -->

\t\t<!-- ace scripts -->
\t\t<script src=\"/assets/js/ace/elements.scroller.js\"></script>
\t\t<script src=\"/assets/js/ace/ace.js\"></script>
\t\t<script src=\"/assets/js/ace/ace.sidebar.js\"></script>
\t\t<script type=\"text/javascript\">
\t\t\$(document).ready(function() {
\t\t\t//get_notifications();
\t\t});
\t\tfunction get_notifications() {
\t\t\tformfields = 'pid='+pid+'&company_id='+company_id+'&commented_by='+userrole+'&commented_to='+commented_to;
\t\t\ttheurl = '/getnotifications.php';\t
\t\t\t\$.ajax({
\t\t\t\turl: theurl,
\t\t\t\tdata:formfields,
\t\t\t\tsuccess: function(response) {
\t\t\t\t alert(response);
\t\t\t\t},
\t\t\t\tcomplete: function() {
\t\t\t\t  // Schedule the next request when the current one's complete
\t\t\t\t  setTimeout(get_notifications, 50000);
\t\t\t\t}
\t\t\t  });
\t\t}
\t\t</script>
\t\t";
    }

    public function getTemplateName()
    {
        return "new-layout.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 85,  161 => 84,  156 => 73,  113 => 7,  109 => 5,  106 => 4,  100 => 134,  97 => 133,  94 => 132,  91 => 131,  89 => 84,  85 => 82,  83 => 81,  74 => 74,  72 => 73,  64 => 67,  58 => 64,  54 => 62,  52 => 61,  44 => 55,  42 => 54,  37 => 51,  35 => 50,  29 => 46,  27 => 4,  22 => 1,);
    }
}
