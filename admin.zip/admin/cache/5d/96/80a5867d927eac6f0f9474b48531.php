<?php

/* v32_assessment-reviewed-disclosure-summary.html */
class __TwigTemplate_5d9680a5867d927eac6f0f9474b48531 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "mainlayout"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 4
            echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "nextscript"), "html", null, true);
            echo "\">
    <input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
    <input type=\"hidden\" name=\"prescript\" id=\"prescript\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "\" />
</form>
";
        } else {
            // line 15
            echo "<div class=\"screen_tab_part\">
\t<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\" class=\"form-horizontal\"
\t\t\tdata-bv-message=\"This value is not valid\"
\t\t\tdata-bv-feedbackicons-valid=\"glyphicon glyphicon-ok\"
\t\t\tdata-bv-feedbackicons-invalid=\"glyphicon glyphicon-remove\"
\t\t\tdata-bv-feedbackicons-validating=\"glyphicon glyphicon-refresh\"
\t\t\tenctype=\"multipart/form-data\">
\t\t\t<input type=\"hidden\" name=\"ob\" id=\"ob\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ob"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"ot\" id=\"ot\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "ot"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sb\" id=\"sb\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sb"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"sk\" id=\"sk\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "sk"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"pg\" id=\"pg\" value=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "pg"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"en\" id=\"en\" value=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "en"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"task\" id=\"task\" value=\"save\" />
\t\t\t<input type=\"hidden\" name=\"id\" id=\"id\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"audit_wizard_id\" id=\"audit_wizard_id\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "audit_wizard_id"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"userid\" id=\"userid\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "userid"), "value"), "html", null, true);
            echo "\" />
\t\t\t<input type=\"hidden\" name=\"listscript\" id=\"listscript\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "listscript"), "html", null, true);
            echo "\" />
      <!-- Nav tabs -->
\t\t  ";
            // line 34
            $this->env->loadTemplate("_wizards-nav-tabs.html")->display(array_merge($context, (isset($context["web"]) ? $context["web"] : null)));
            // line 35
            echo "      <!-- Tab panes -->
\t\t<div class=\"tab-content tab_border\">
            <div class=\"screen7_inner_part widget-box widget-color-blue\">
                <div class=\"widget-header\">
                    <h4 class=\"widget-title smaller lighter\"> <i class=\"ace-icon fa fa-edit\"></i> 4 Reviewed Environment </h4>
                </div>
                <div class=\"widget-body\">
                \t<div class=\"widget-main widget_main_extra_part\">
                    \t<div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.12\tDisclosure summary for “In Place with Compensating Control” responses</div>
                    \t
                        <div class=\"screen9_table_block_part screen10_extra screen11_part\">
                            <div class=\"table-responsive screen_field_part\">
                                <table class=\"table table-striped\" id=\"tbl1\">
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Identify whether there were any responses indicated as\"In Place with Compensating Control\" (yes/no)</strong></td>
\t\t\t\t\t\t\t\t\t\t\t<td  class=\"col-md-6 col-sm-6 col-xs-6\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock pull-left\" >
\t\t\t\t\t\t\t\t\t\t\t\t\t<input value=\"1\" id=\"inplace_yes_no-1-1\" ";
            // line 53
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "inplace_yes_no"), "value") == "yes")) {
                echo " checked=\"checked\"";
            }
            echo " name=\"inplace_yes_no1\" data-size=\"large\" data-handle-width=\"50\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\"> 
\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"inplace_yes_no\" id=\"inplace_yes_no1\" value=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "inplace_yes_no"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\"  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>If \"yes,\" complete the table below:</strong></td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6\"><strong>List of all Requirements/tested procedures with this result</strong></td>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Summary of the issue (legal obligation, etc.)</strong></td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t";
            // line 65
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "inplace"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 66
                echo "\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6\">
\t\t\t\t\t\t\t\t\t\t\t\t<textarea name=\"inplace_tested_procedure[]\" class=\"form-control\" rows=\"2\" placeholder=\"List of all Requirements/tested procedures with this result\">";
                // line 68
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "tested_procedure"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6\">
\t\t\t\t\t\t\t\t\t\t\t\t<textarea name=\"inplace_summary[]\" class=\"form-control\" rows=\"2\" placeholder=\"Summary of the issue\">";
                // line 71
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "summary"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 72
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 73
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t&nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 75
                echo "\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 77
            echo "\t
\t\t\t\t\t\t\t\t\t</tbody>
                                </table>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow('tbl1', 'inplace');\" > Add New </div>
                        </div>
                        
                        <div class=\"screen9_table_block_part screen10_extra screen11_part\">
                            <!--<h1 class=\"screen_title\">4.14 Disclosure summary for \"Not Tested\" responses</h1>-->
                            <div class=\"col-lg-12 col-sm-12 col-xs-12 alert alert-success\">4.13\tDisclosure summary for “Not Tested” responses</div>
                            <div class=\"table-responsive screen_field_part\">
                                <table class=\"table table-striped\" id=\"tbl2\">
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Identify whether there were any responses indicated as \"Not Tested\", (yes/no)</strong></td>
\t\t\t\t\t\t\t\t\t\t\t<td class=\"col-md-6 col-sm-6 col-xs-6\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"lockunlock pull-left\" >
\t\t\t\t\t\t\t\t\t\t\t\t\t<input value=\"1\" id=\"nottested_yes_no-1-1\" ";
            // line 94
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "nottested_yes_no"), "value") == "yes")) {
                echo " checked=\"checked\"";
            }
            echo " name=\"nottested_yes_no\" data-size=\"large\" data-handle-width=\"50\" data-on-color=\"success\" data-off-color=\"danger\" class=\"switch\" type=\"checkbox\" data-off-text=\"No\" data-on-text=\"Yes\"> 
\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"nottested_yes_no\" id=\"nottested_yes_no1\" value=\"";
            // line 95
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "nottested_yes_no"), "value"), "html", null, true);
            echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\" class=\"col-md-6 col-sm-6 col-xs-6\"><strong>If \"yes,\" complete the table below:</strong></td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>List of all Requirements/tested procedures with this result</strong></td>
\t\t\t\t\t\t\t\t\t\t\t<td  class=\"col-md-6 col-sm-6 col-xs-6\"><strong>Summary of the issue(for example, not deemed in scope for the assessment, reliance on a third-party service provider who is compliant to PCI DSS v3.1 and hasn’t yet assessed against 3.2, etc.)</strong></td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t";
            // line 106
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fields"), "nottested"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 107
                echo "\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td  class=\"col-md-6 col-sm-6 col-xs-6\">
\t\t\t\t\t\t\t\t\t\t\t\t<textarea name=\"nottested_tested_procedure[]\" class=\"form-control\" rows=\"2\" placeholder=\"List of all Requirements/tested procedures with this result\">";
                // line 109
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "tested_procedure"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td  class=\"col-md-6 col-sm-6 col-xs-6\">
\t\t\t\t\t\t\t\t\t\t\t\t<textarea name=\"nottested_summary[]\" class=\"form-control\" rows=\"2\" placeholder=\"Summary of the issue\">";
                // line 112
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "summary"), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 113
                if ((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "first"))) {
                    // line 114
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 116
                echo "\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 118
            echo "\t\t
\t\t\t\t\t\t\t\t\t</tbody>
                                </table>
                              </div>
                              <div class=\"btn btn-primary primary_add_btn pull-right\" onclick=\"addrow('tbl2', 'nottested');\" > Add New </div>
                        </div>
\t\t\t\t\t\t<button class=\"btn btn-danger new_success pull-left\" onclick=\"previous_step('";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "prescript"), "html", null, true);
            echo "');\"><span><i class=\"fa fa-arrow-left\"></i></span> Previous </button>
\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success new_success pull-right\">Next <span><i class=\"fa fa-arrow-right\"></i></span></button> 
                    </div>
                </div>
            </div>
        </div>
\t</form>
</div>
";
        }
    }

    // line 134
    public function block_footer($context, array $blocks = array())
    {
        // line 135
        echo "\t";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
\t<link rel=\"stylesheet\" href=\"/assets/css/wizards-responsive.css\">
\t<link rel=\"stylesheet\" href=\"/assets/css/assessments-wizards.css\">
\t<script type=\"text/javascript\" src=\"/assets/js/bootstrapValidator.js\"></script>
\t<script src=\"/assets/js/chosen.jquery.js\"></script>
\t<link href=\"/assets/css/bootstrap-switch.css\" type=\"text/css\" rel=\"stylesheet\">
\t<script src=\"/assets/js/bootstrap-switch.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/js/wizards-common-functions.js\"></script>
<script type=\"text/javascript\">
";
        // line 144
        if ((($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "task") == "save") && ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "err") == ""))) {
            // line 145
            echo "\$(document).ready(function() {
\tdocument.getElementById('frm').submit();
});
";
        } else {
            // line 149
            echo "\$(document).ready(function() {
   
\t\$('#frm').bootstrapValidator();
\t\$(\".switch\").bootstrapSwitch();
    \$(\"#tbl1\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t\$(\"#tbl2\").on('click','.remCF',function(){
        \$(this).parent().parent().remove();
    });
\t\$('.switch').on('switchChange.bootstrapSwitch', function(event, state) {
\t\tary = \$(this).attr('id').split('-');
\t\tval = state ? 'yes' : 'no';
\t\t\$('#'+ary[0]+ary[2]).val(val);
\t});
});
function addrow(tbl_id, section)
{
\thtml = '';
\thtml = html + '<tr>';
\thtml = html + '\t<td class=\"col-md-6 col-sm-6 col-xs-6\">';
\thtml = html + '\t\t<textarea name=\"'+section+'_tested_procedure[]\" class=\"form-control\" rows=\"2\" placeholder=\"List of all Requirements/tested procedures with this result\"></textarea>';
\thtml = html + '\t</td>';
\thtml = html + '\t<td class=\"col-md-6 col-sm-6 col-xs-6\">';
\thtml = html + '\t\t<textarea name=\"'+section+'_summary[]\" class=\"form-control\" rows=\"2\" placeholder=\"Summary of the issue\"></textarea>';
\thtml = html + '\t\t&nbsp; <a href=\"javascript:void(0);\" class=\"remCF pull-right\" title=\"Remove\" ><i class=\"fa fa-trash\"></i></a>';
\thtml = html + '\t</td>';
\thtml = html + '</tr>';
\t\$(\"#\"+tbl_id).append(html);
}
";
        }
        // line 180
        echo "</script>
";
    }

    public function getTemplateName()
    {
        return "v32_assessment-reviewed-disclosure-summary.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  388 => 180,  355 => 149,  349 => 145,  347 => 144,  334 => 135,  331 => 134,  317 => 124,  309 => 118,  293 => 116,  289 => 114,  287 => 113,  283 => 112,  277 => 109,  273 => 107,  256 => 106,  242 => 95,  236 => 94,  217 => 77,  201 => 75,  197 => 73,  195 => 72,  191 => 71,  185 => 68,  181 => 66,  164 => 65,  150 => 54,  144 => 53,  124 => 35,  122 => 34,  117 => 32,  113 => 31,  109 => 30,  105 => 29,  100 => 27,  96 => 26,  92 => 25,  88 => 24,  84 => 23,  80 => 22,  71 => 15,  65 => 12,  61 => 11,  57 => 10,  53 => 9,  49 => 8,  45 => 7,  41 => 6,  37 => 5,  32 => 4,  30 => 3,  27 => 2,);
    }
}
