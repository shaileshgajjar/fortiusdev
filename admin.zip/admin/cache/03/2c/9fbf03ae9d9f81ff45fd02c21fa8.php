<?php

/* _front-kanban-grid-company.html */
class __TwigTemplate_032c9fbf03ae9d9f81ff45fd02c21fa8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<form name=\"frm\" id=\"frm\" method=\"post\" action=\"\">
<input type=\"hidden\" name=\"id\" id=\"id\" value=\"\" />
<input type=\"hidden\" name=\"requirements_id\" id=\"requirements_id\" value=\"\" />
<div class=\"kanban_board\">
<div class=\"col-lg-15\">
\t<div class=\"panel\">
\t\t<div class=\"panel-heading\" >
\t\t<div class=\"board_block_bg col-sm-3\" >
\t\t\t
\t\t\t<div class=\"col-sm-12 tasks\" ><strong>Completed Tasks &nbsp; <span class=\"badge badge-success\" title=\"Found ";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "cmpt"), 0), "filled"), "html", null, true);
        echo " tasks\"> ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "cmpt"), 0), "filled"), "html", null, true);
        echo " </span></strong></div> 
\t\t\t";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "cmpt"));
        foreach ($context['_seq'] as $context["key"] => $context["row"]) {
            // line 12
            echo "\t\t\t\t";
            $context["div_width"] = $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage");
            // line 13
            echo "\t\t\t\t\t";
            if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage") > "85")) {
                // line 14
                echo "\t\t\t\t\t\t";
                $context["div_width"] = "85";
                // line 15
                echo "\t\t\t\t\t";
            }
            // line 16
            echo "\t\t\t\t
\t\t\t\t<div class=\"board_block_part\">
\t\t\t\t\t
\t\t\t\t\t<div class=\"board_block_inner_part\">
\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Compliance Due Date:</strong> ";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "compliance_due_date"), "html", null, true);
            echo " </span>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"><strong>Completed </strong><small>[";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "filled"), "html", null, true);
            echo " <i> Out-of </i> ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total"), "html", null, true);
            echo "]  </small></span>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> &nbsp; </span>
\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t<div class=\"time_manage_main completed\">
\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small><b>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
            echo "</b></small></span>
\t\t\t\t\t\t\t\t<div class=\"time_manage_comp\" style=\"width: ";
            // line 26
            echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
            echo "%;\" data-fill=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
            echo "%\">
\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t</div>\t\t\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 33
        echo "\t\t</div>
\t\t<div class=\"board_block_bg col-sm-3\" >
\t\t\t";
        // line 35
        if ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fc")) {
            // line 36
            echo "\t\t\t<div class=\"col-sm-12 tasks\" ><strong>Failed Tasks &nbsp; <span class=\"badge badge-failed\" title=\"Found ";
            echo twig_escape_filter($this->env, count($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fc")), "html", null, true);
            echo " tasks\"> ";
            echo twig_escape_filter($this->env, count($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fc")), "html", null, true);
            echo " </span></strong></div>
\t\t\t\t";
            // line 37
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "fc"));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 38
                echo "\t\t\t\t\t
\t\t\t\t\t\t<div class=\"board_block_part\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"board_block_inner_part\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>PCI-DSS Requirements   : </strong> <a href=\"assigntasks.php\"> # ";
                // line 43
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "rid"), "html", null, true);
                echo "</a> </span>
\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Owner Group : </strong> ";
                // line 44
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "user_group_name"), "html", null, true);
                echo " </span>
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
                // line 47
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "updated_on") != "")) {
                    // line 48
                    echo "\t\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Updated On  : </strong> ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "updated_on"), "html", null, true);
                    echo " </span>
\t\t\t\t\t\t\t\t";
                }
                // line 50
                echo "\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Completion Date   : </strong> ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "cdate"), "html", null, true);
                echo " </span>
\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> </span>
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Procedure #: </strong> <a href=\"#\" data-toggle=\"modal\" onclick=\"get_failed_controls('";
                // line 54
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["web"]) ? $context["web"] : null), "company_id"), "html", null, true);
                echo "', '";
                echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
                echo "',";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "docid"), "html", null, true);
                echo ");\" data-target=\"#failed_control\" title=\"Put note or add completion date to failed control\"> <span class=\"badge badge-failed\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "number"), "html", null, true);
                echo " </span></a></span>
\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 59
            echo "\t\t";
        }
        // line 60
        echo "\t\t</div>
\t\t<div class=\"board_block_bg col-sm-3\" >
\t\t\t
\t\t\t";
        // line 63
        if ($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "od")) {
            // line 64
            echo "\t\t\t\t<div class=\"col-sm-12 tasks\" > <strong> Overdue Tasks &nbsp;<span class=\"badge badge-overdue\" title=\"Found ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "od"), 0), "filled"), "html", null, true);
            echo " tasks\"> ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "od"), 0), "filled"), "html", null, true);
            echo " </span></strong> </div>
\t\t\t\t";
            // line 65
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["web"]) ? $context["web"] : null), "overdue"));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 66
                echo "\t\t\t\t\t\t";
                $context["div_width"] = $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage");
                // line 67
                echo "\t\t\t\t\t\t\t";
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage") > "85")) {
                    // line 68
                    echo "\t\t\t\t\t\t\t\t";
                    $context["div_width"] = "85";
                    // line 69
                    echo "\t\t\t\t\t\t\t";
                }
                // line 70
                echo "\t\t\t\t<div class=\"board_block_part\">
\t\t\t\t\t<div class=\"board_block_inner_part\">
\t\t\t\t\t\t
\t\t\t\t\t\t<span class=\"menu-text task-status\"> <strong>Compliance Due Date:</strong> ";
                // line 73
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "compliance_due_date"), "html", null, true);
                echo " </span>
\t\t\t\t\t\t\t<span class=\"menu-text task-status\"><strong>No. of Tasks </strong><small>[";
                // line 74
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "filled"), "html", null, true);
                echo " <i> Out-of </i> ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "total"), "html", null, true);
                echo "]  </small></span><span class=\"menu-text task-status\"> &nbsp; </span>
\t\t\t\t\t\t\t<span class=\"menu-text task-percent\"> [ % ]</span>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"time_manage_main overdue\">
\t\t\t\t\t\t\t\t<span class=\"pull-right\"><small><b>";
                // line 78
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
                echo "</b></small></span>
\t\t\t\t\t\t\t\t<div class=\"time_manage_od\" style=\"width: ";
                // line 79
                echo twig_escape_filter($this->env, (isset($context["div_width"]) ? $context["div_width"] : null), "html", null, true);
                echo "%;\" data-fill=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["row"]) ? $context["row"] : null), "percentage"), "html", null, true);
                echo "%\">
\t\t\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t\t</div>\t\t\t\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 85
            echo "\t\t";
        }
        // line 86
        echo "\t\t</div>
\t</div>
</div>
</div>
</form>";
    }

    public function getTemplateName()
    {
        return "_front-kanban-grid-company.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  229 => 86,  226 => 85,  212 => 79,  208 => 78,  199 => 74,  195 => 73,  190 => 70,  187 => 69,  184 => 68,  181 => 67,  178 => 66,  174 => 65,  167 => 64,  165 => 63,  160 => 60,  157 => 59,  140 => 54,  132 => 50,  126 => 48,  124 => 47,  118 => 44,  114 => 43,  107 => 38,  103 => 37,  96 => 36,  94 => 35,  90 => 33,  75 => 26,  71 => 25,  62 => 21,  58 => 20,  52 => 16,  49 => 15,  46 => 14,  43 => 13,  40 => 12,  36 => 11,  30 => 10,  19 => 1,);
    }
}
