<?php
require(dirname(__FILE__).'/../config/config.new.php');
$web['id'] = $request->get('id', '');
$web['vr'] = $request->get('vr', '');
$web['tp'] = $request->get('tp', '');
$opt = '<option value="">Select Sub Requirement</option>';
if ( $web['id'] > 0 )
{
	$conditions[] = array('type' => 'WHERE', 'field' => 'requirements_id', 'value' => $web['id']);
	$opt .= getdropdown($web['vr'].'sub_requirements', 'id', 'title', 0, $conditions);
}
echo $opt;
?>
