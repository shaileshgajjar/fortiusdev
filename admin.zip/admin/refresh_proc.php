<?php
require(dirname(__FILE__).'/../config/config.new.php');
$web['id'] = $request->get('id', '');
$web['vr'] = $request->get('vr', '');
$web['tp'] = $request->get('tp', '');
$opt = '<option value="">Select Procedure</option>';
if ( $web['id'] > 0 )
{
	$conditions[] = array('type' => 'WHERE', 'field' => 'sub_requirements_id', 'value' => $web['id']);
	$opt .= getdropdown($web['vr'].'procedure', 'id', 'title', 0, $conditions);
}
echo $opt;
?>
