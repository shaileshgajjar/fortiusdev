<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");
$web['pagetitle']				= $web['company'].' - Data';
$web['table']					= 'requirements';
$web['page']					= 'inputs';
$web['editscript']				= 'fill-doc.php';
$web['listscript']				= 'fill-doc.php';

if ( $web['listscript'] == 'fill-doc.php' )
	$web['listscript'] = 'fill-doc.php';

$web['title']			= str_replace('_', ' ', $web['version']).'Data';
$web['id']				= $request->get('id', 0);
$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['pid']				= $request->get('pid', 0);
$web['requirements_id']	= $request->get('requirements_id');
$web['company_id']		= $web['id'];
$web['userrole']		= $session->get('userrole');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'title');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

writeDocumentReport();
?>