<?php
$web['table']	= $web['version'].$web['table'];
$web['title']	= str_replace('_', ' ', $web['version']).$web['title'];
$web['page']	= 'masters';
$web['subpage']	= 'sub_requirements';
$web['task']	= $request->get('task', '');
$web['err']		= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'ref');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$web['fields'] = array();
$web['fields']['requirements_id']	= array('value' => '');
$web['fields']['title']				= array('value' => '');
$web['fields']['info']				= array('value' => '');
$web['fields']['srnote']			= array('value' => '');
$web['fields']['description']		= array('value' => '');

$web['tbl'] = new table($web['table']);
if ( $web['id'] > 0 )
	$web['tbl']->load($web['id']);
	
if ( $web['task'] == 'save' )
{
	foreach($web['fields'] as $key => $value)
		$web['tbl']->setValue($key, $request->get($key, ''));
	$web['tbl']->save();
	$act = ($web['id'] == 0)?'ADD':'EDIT';
	add_log_history($act, 'REQ', $session->get('uid'), 'a');
}

foreach($web['fields'] as $key => $value)
	$web['fields'][$key]['value'] = $web['tbl']->getValue($key);
unset($web['tbl']);

$web['requirements'] = getdropdown($web['version'].$web['type'].'requirements', 'id', 'title', $web['fields']['requirements_id']['value']);

echo $twig->render('sub_requirement.html', array('web' => $web));
?>
