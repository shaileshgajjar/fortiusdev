<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");
	
$web['enableversion'] = '1';
$web['version'] 	= $request->get('version', 'v32_');
$web['endpage']	= 'rsaq';
$web['pagetitle']	= $web['company'].' - Requirements [SAQ]';
$web['table']		= 'saq_requirements';
$web['title']		= 'Requirements [SAQ]';
$web['editscript']	= 'saq_requirement.php';
$web['listscript']	= 'saq_requirements.php';
$web['type']		= 'saq_';
require('requirements.php');
?>
