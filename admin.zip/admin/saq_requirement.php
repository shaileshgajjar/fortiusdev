<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['endpage']		= 'rsaq';
$web['id']			= $request->get('id', '0');
$web['pagetitle']	= $web['company'].' - Requirements [SAQ]';
$web['table']		= 'saq_requirements';
$web['title']		= 'Requirements [SAQ] '.($web['id'] == '0' ? 'New' : 'Edit');
$web['editscript']	= 'saq_requirement.php';
$web['listscript']	= 'saq_requirements.php';
require('requirement.php');
?>
