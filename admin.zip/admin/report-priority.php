<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

if ( !isset($_SESSION['backscript']) || $_SESSION['backscript'] == '' )
{
	$listscripts = explode("/", $_SERVER["HTTP_REFERER"]);
	$_SESSION['backscript'] = $listscripts[count($listscripts)-1];
}
$web['pagetitle']				= $web['company'].' - Priority';
$web['table']					= 'customer';
$web['page']					= 'inputs';
$web['editscript']				= 'report-priority.php';
$web['listscript']				= $_SESSION['backscript'];

$web['title']	= 'Priority';
$web['id']	= $request->get('id', '');
$web['task']	= $request->get('task', '');
$web['err']	= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'title');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$web['company_id'] = $web['id'];

$tbl = new table('merchant_type');
$tbl->cols('t1.merchant_type');
$tbl->cols('t1.roc_saq');
$tbl->cols('c.company_name');
$tbl->join('customer','c.merchant_type_id','t1.id', 'c');
$tbl->condition('WHERE','c.id', $web['id']);

$rows = $tbl->getList();	

foreach($rows as $rw)
{
	
	$web['company_name'] = $rw['company_name'];
	$web['merchant_type'] = $rw['merchant_type'];
	$web['roc_saq'] = $rw['roc_saq'];
}	
unset($tbl);
$roc_saq = ($web['roc_saq'] == 'saq') ? 'saq' : '';
$tbl = new table('document');
$tbl->cols('t1.inplace');
$tbl->cols('p.requirements_id');
$tbl->cols('p.sub_requirements_id');
$tbl->cols('p.id AS pid');
$tbl->cols('p.priority');
$tbl->join($web['version'].$roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$tbl->orderby('p.requirements_id');
$tbl->orderby('p.sub_requirements_id');
$tbl->orderby('p.id');

$rows2 = $tbl->getList();	

$web['rows'] = array();

$totalary = array('p1' => array(0, 0), 'p2' => array(0, 0), 'p3' => array(0, 0), 'p4' => array(0, 0), 'p5' => array(0, 0), 'p6' => array(0, 0));
foreach( $rows2 as $rw )
{
	if ( !isset($web['rows'][$rw['requirements_id']]) )
		$web['rows'][$rw['requirements_id']] = array('p1' => array(0, 0), 'p2' => array(0, 0), 'p3' => array(0, 0), 'p4' => array(0, 0), 'p5' => array(0, 0), 'p6' => array(0, 0));
	if ( $rw['inplace'] == 'Y' || $rw['inplace'] == 'C' )
	{
		$web['rows'][$rw['requirements_id']]['p'.$rw['priority']][0]++;
		$totalary['p'.$rw['priority']][0]++;
	}
	if ( $rw['inplace'] == 'Y' || $rw['inplace'] == 'C' || $rw['inplace'] == 'N' || $rw['inplace'] == 'NT' )
	{
		$web['rows'][$rw['requirements_id']]['p'.$rw['priority']][1]++;
		$totalary['p'.$rw['priority']][1]++;
	}
}
$web['total'] = $totalary;
$s1 = array();
$label = array();
$ticks = array();
$web['pie'] = '';
$web['pie_new'] = '';
for($p=1; $p<7; $p++)
{
	$web['percn']['p'.$p] = 'NA';
	//if ( $web['total']['p'.$p][1] > 0 )
	//{
		$web['percn']['p'.$p] = 0;
		if ( $web['total']['p'.$p][1] > 0 )
			$web['percn']['p'.$p] = round($web['total']['p'.$p][0]/$web['total']['p'.$p][1]*100);
		$s1[] = $web['percn']['p'.$p];
		$label[] = "'".$web['percn']['p'.$p]."%'";
		$ticks[] = "'".$p."'";
		if ( $web['pie_new'] != '' )
			$web['pie_new'] .= ', ';	
		$web['pie_new'] .= "{name: ' #P".$p." ', y:".$web['percn']['p'.$p]."}";
}

$web['s1'] = implode(', ', $s1);
$web['label'] = implode(', ', $label);
$web['ticks'] = implode(', ', $ticks);

echo $twig->render('report-priority.html', array('web' => $web));
?>
