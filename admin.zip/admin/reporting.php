<?php
$web['page']	= 'masters';
$web['subpage']	= 'reporting';
$web['task']	= $request->get('task', '');
$web['err']		= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'ref');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$web['fields'] = array();
$web['fields']['requirements_id']		= array('value' => '');
$web['fields']['sub_requirements_id']	= array('value' => '');
$web['fields']['procedure_id']			= array('value' => '');
$web['fields']['title']					= array('value' => '');
$web['fields']['bulet']					= array('value' => '');

$web['tbl'] = new table($web['table']);
if ( $web['id'] > 0 )
	$web['tbl']->load($web['id']);

if ( $web['task'] == 'save' )
{
	foreach($web['fields'] as $key => $value)
		$web['tbl']->setValue($key, $request->get($key, ''));
	$web['tbl']->save();
	$act = ($web['id'] == 0)?'ADD':'EDIT';
	add_log_history($act, 'R_ROC', $session->get('uid'), 'a');
}

foreach($web['fields'] as $key => $value)
	$web['fields'][$key]['value'] = $web['tbl']->getValue($key);
unset($web['tbl']);

$web['requirements']		= '<option value="">Select Requirement</option>';
$web['sub_requirements']	= '<option value="">Select Sub Requirement</option>';
$web['procedures']			= '<option value="">Select Procedure</option>';
$web['requirements']	   .= getdropdown($web['version'].$web['type'].'requirements', 'id', 'title', $web['fields']['requirements_id']['value']);
if ( $web['id'] > 0 )
{
	$conditions[0] = array('type' => 'WHERE', 'field' => 'requirements_id', 'value' => $web['fields']['requirements_id']['value']);
	$web['sub_requirements']	.= getdropdown($web['version'].$web['type'].'sub_requirements', 'id', 'title', $web['fields']['sub_requirements_id']['value'], $conditions);
	$conditions[0] = array('type' => 'WHERE', 'field' => 'sub_requirements_id', 'value' => $web['fields']['sub_requirements_id']['value']);
	$web['procedures']			.= getdropdown($web['version'].$web['type'].'procedure', 'id', 'title', $web['fields']['procedure_id']['value'], $conditions);
}

echo $twig->render('reporting.html', array('web' => $web));
?>
