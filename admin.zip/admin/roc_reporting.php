<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['endpage']		= 'roc';
$web['version'] 	= $request->get('version', 'v32_');
$web['id']		= $request->get('id', '0');
$web['pagetitle']	= $web['company'].' - Reporting Head [ROC]';
$web['table']		= $web['version'].'reporting';
$web['title']		= str_replace('_', ' ', $web['version']).'Reporting Head [ROC] '.($web['id'] == '0' ? 'New' : 'Edit');
$web['editscript']	= 'roc_reporting.php';
$web['listscript']	= 'roc_reportings.php';
$web['type']		= '';
$web['roc_saq']		= 'roc';
require('reporting.php');
?>
