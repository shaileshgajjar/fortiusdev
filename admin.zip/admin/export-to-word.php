<?php

require_once('report-new.php');

$html = generate_report($_REQUEST['id']);
echo $html;