<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");
if ( !isset($_SESSION['backscript']) || $_SESSION['backscript'] == '' )
{
	$listscripts = explode("/", $_SERVER["HTTP_REFERER"]);
	$_SESSION['backscript'] = $listscripts[count($listscripts)-1];
}
$web['pagetitle']				= $web['company'].' - Compliance/Severity';
$web['table']				= 'customer';
$web['page']					= 'inputs';
$web['editscript']			= 'report-compliance.php';
$web['listscript']			= $session->get('backscript');

$web['title']	= 'Compliance/Severity';
$web['id']		= $request->get('id', '');
$web['task']		= $request->get('task', '');
$web['err']		= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'title');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$web['company_id'] = $web['id'];

$tbl = new table('merchant_type');
$tbl->cols('t1.merchant_type');
$tbl->cols('t1.roc_saq');
$tbl->cols('c.company_name');
$tbl->join('customer','c.merchant_type_id','t1.id', 'c');
$tbl->condition('WHERE','c.id', $web['id']);
$rows = $tbl->getList();
foreach( $rows as $rw)
{
	
	$web['company_name'] = $rw['company_name'];
	$web['merchant_type'] = $rw['merchant_type'];
	$web['roc_saq'] = $rw['roc_saq'];
}	
$roc_saq = ($web['roc_saq'] == 'saq') ? 'saq' : '';
unset($tbl);
$tbl = new table('document');
$tbl->cols('t1.inplace');
$tbl->cols('p.requirements_id');
$tbl->cols('p.sub_requirements_id');
$tbl->cols('p.id AS pid');
$tbl->cols('p.priority');
$tbl->join($web['version'].$roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$tbl->orderby('p.requirements_id');
$tbl->orderby('p.sub_requirements_id');
$tbl->orderby('p.id');
$web['rows'] = array();

$totayary = array('Y'=>0, 'N'=>0, 'C'=>0, 'NA'=>0, 'NT'=>0, 'severity'=>0, 'maxseverity'=>0);
$rows1 = $tbl->getList();
foreach( $rows1 as $rw )
{
	if ( !isset($web['rows'][$rw['requirements_id']]) )
		$web['rows'][$rw['requirements_id']] = array('Y'=>0, 'N'=>0, 'C'=>0, 'NA'=>0, 'NT'=>0, 'severity'=>0, 'maxseverity'=>0, 'total'=>0, 'percentage'=>0);
	$inplace = $rw['inplace'];
	if ( $inplace == '' )
		$inplace = 'NT';
	$web['rows'][$rw['requirements_id']][$inplace]++;
	$web['rows'][$rw['requirements_id']]['total']++;
	$totayary[$inplace]++;
	$web['rows'][$rw['requirements_id']]['maxseverity'] += abs(7-$rw['priority']);
	$totayary['maxseverity'] += abs(7-$rw['priority']);
	if ( $rw['inplace'] == 'Y' || $rw['inplace'] == 'C' || $rw['inplace'] == 'NA' )
	{
		$web['rows'][$rw['requirements_id']]['severity'] += abs(7-$rw['priority']);
		$totayary['severity'] += abs(7-$rw['priority']);
	}
}
$s1 = array();
$label = array();
$ticks = array();
foreach($web['rows'] as $k => $v)
{
	if ( $v['total'] == 0 )
		$web['rows'][$k]['percentage'] = 'NA';
	else
		$web['rows'][$k]['percentage'] = round(($v['Y']+$v['C'])/$v['total']*100);
	//if ( $web['rows'][$k]['percentage'] > 0 )
	//{
		$s1[] = $web['rows'][$k]['percentage'];
		//$label[] = "'".$web['rows'][$k]['percentage'].'%'."'";
		// haere we needed data in integer to use highcharts ui 
		$label[] = $web['rows'][$k]['percentage'];
		$ticks[] = "'".$k."'";
	//}
}
$web['s1'] = implode(', ', $s1);
$web['label'] = implode(', ', $label);
$web['ticks'] = implode(', ', $ticks);
$web['total'] = $totayary;

$CustomersDataArr = array();
$CustomersDataArr['id'] = $web['id'];
$CustomersDataArr['merchant_type'] = $web['merchant_type'];
$CustomersDataArr['company_name'] = $web['company_name'];
$CustomersDataArr['company_id'] = $web['company_id'];

//sendFrequentlyReport($CustomersDataArr);

echo $twig->render('report-compliance.html', array('web' => $web));
?>
