<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['enableversion'] = '1';	
$web['version'] 	= $request->get('version', 'v32_');
$web['endpage']	= 'psaq';
$web['pagetitle']	= $web['company'].' - Testing Procedure [SAQ]';
$web['table']		= 'saq_procedure';
$web['title']		= 'Testing Procedure [SAQ]';
$web['editscript']	= 'saq_procedure.php';
$web['listscript']	= 'saq_procedures.php';
$web['type']		= 'saq_';
require('procedures.php');
?>
