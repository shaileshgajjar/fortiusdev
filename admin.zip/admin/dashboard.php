<?php
//$role = array('a');
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) /*$role = array('c', 'u', 'q', 's', 'a');*/
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['pagetitle']	= 'Security System - Dashboard';
$web['page']		= 'dashboard';
$web['title']		= 'Dashboard';

$customer = new table('customer');
$customer->cols('t1.*');
$customer->cols("m.merchant_type,CONCAT(u.first_name, ' ', u.last_name) AS username");
$customer->cols('u.mobile');
$customer->cols('u.email');
$customer->cols("CONCAT(u_s.first_name, ' ', u_s.last_name) AS qsa");
$customer->cols("CONCAT(u_q.first_name, ' ', u_q.last_name) AS qa");
$customer->cols("(SELECT COUNT(id) FROM ".$customer->getPrefix()."document d WHERE d.company_id = t1.id) AS total");
$customer->cols("(SELECT COUNT(id) FROM ".$customer->getPrefix()."document d WHERE d.company_id = t1.id AND inplace <> '') AS filled");
$customer->join('merchant_type', 'm.id', 't1.merchant_type_id', 'm');
$customer->join('users', 'u.company_id', 't1.id', 'u');
$customer->join('users', 'u_q.id', 't1.qa_id', 'u_q');
$customer->join('users', 'u_s.id', 't1.qsa_id', 'u_s');
$customer->groupby('t1.id');

$web['customers'] = array();
$rows = $customer->getList();
unset($customer);
$no = 0;
foreach( $rows as $rw )
{
	$web['customers'][$no] = $rw;
	$web['customers'][$no]['class'] = '';
	if ( date('Ymd') > $lib->format_date($rw['compliance_due_date'], 'Ymd') )
		$web['customers'][$no]['class'] = ' class="danger"';
	$web['customers'][$no]['compliance_due_date'] = $lib->format_date($rw['compliance_due_date'], 'd M Y');
	$web['customers'][$no]['percentage'] = 0;
	if ( $rw['total'] > 0 )
		$web['customers'][$no]['percentage'] = round($rw['filled'] / $rw['total'] * 100);
	if ( $web['customers'][$no]['percentage'] == 100 )
		$web['customers'][$no]['class'] = ' class="success"';
		
	$web['customers'][$no]['filled'] = $rw['filled'];		
	$no++;
}
$web['ipt']	= getQaQsaTasks('inprocess', 'a', 0, 0);
$web['uct']	= getQaQsaTasks('upcoming', 'a', 0, 0);
$web['ft'] 	= getQaQsaTasks('failed', 'a', 0, 0);
$web['odt'] 	= getQaQsaTasks('overdue', 'a', 0, 0);
$web['odo'] 	= getQaQsaTasks('overdue_open', 'a', 0, 0);
echo $twig->render('dashboard.html', array('web' => $web));
?>
