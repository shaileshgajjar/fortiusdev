<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");
if ( !isset($_SESSION['backscript']) || $_SESSION['backscript'] == '' )
{
	$listscripts = explode("/", $_SERVER["HTTP_REFERER"]);
	$_SESSION['backscript'] = $listscripts[count($listscripts)-1];
}
$web['pagetitle']			= $web['company'].' - Statistics';
$web['table']				= 'customer';
$web['page']				= 'statistics-charts';
$web['editscript']			= 'statistics-charts.php';
$web['listscript']			= $session->get('backscript');

$web['title']	= 'Statistics';
$web['id']		= $request->get('id', '');
$web['task']		= $request->get('task', '');
$web['err']		= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'title');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$customer = new table('customer');
$customer->cols('t1.*');
$customer->cols("m.merchant_type,CONCAT(u.first_name, ' ', u.last_name) AS username");
$customer->cols('m.roc_saq');
$customer->cols('u.mobile');
$customer->cols('u.email');
$customer->cols("CONCAT(u_s.first_name, ' ', u_s.last_name) AS qsa");
$customer->cols("CONCAT(u_q.first_name, ' ', u_q.last_name) AS qa");
$customer->cols("(SELECT COUNT(id) FROM ".$customer->getPrefix()."document d WHERE d.company_id = t1.id) AS total");
$customer->cols("(SELECT COUNT(id) FROM ".$customer->getPrefix()."document d WHERE d.company_id = t1.id AND inplace <> '') AS filled");
$customer->join('merchant_type', 'm.id', 't1.merchant_type_id', 'm');
$customer->join('users', 'u.company_id', 't1.id', 'u');
$customer->join('users', 'u_q.id', 't1.qa_id', 'u_q');
$customer->join('users', 'u_s.id', 't1.qsa_id', 'u_s');
$customer->groupby('t1.id');

$web['customers'] = array();
$web['controls'] = array();
$web['failed'] = array();
$web['fc'] = array();

$rows1 = $customer->getList();
unset($customer);
$m = 0;
foreach( $rows1 as $rw1 )
{
	$web['customers'][$m] = $rw1;
	$m++;
}

$n = 0;
// to get data of all company 
foreach( $rows1 as $rw1 )
{
	$roc_saq 		= ($rw1['roc_saq'] == 'roc') ? '' : 'saq_';
	$tbl = new table('document');
	$tbl->cols('t1.inplace');
	$tbl->cols('t1.id AS docid');
	$tbl->cols('t1.requirements_id');
	$tbl->cols('t1.procedure_id');
	$tbl->cols('t1.completion_date');
	$tbl->cols('t1.user_id');
	$tbl->cols('r.id');
	$tbl->cols('p.title');
	$tbl->cols('p.number');
	$tbl->cols('p.priority');
	$tbl->join($web['version'].$roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p', 'JOIN');
	$tbl->join($web['version'].$roc_saq.'requirements', 'r.id', 't1.requirements_id', 'r', 'JOIN');
	$tbl->condition('WHERE', 't1.company_id', $rw1['id']);
	$rows = $tbl->getList();
	unset($tbl);
	$totayary[$n] = array('Y'=>0, 'N'=>0, 'C'=>0, 'NA'=>0, 'NT'=>0, 'severity'=>0, 'maxseverity'=>0);
	$web['controls'][$n] = array();
	$web['failed'][$n] = array();
	foreach ( $rows as $rw )
	{
		if ( !isset($web['controls'][$n][$rw['requirements_id']]) )
			$web['controls'][$n][$rw['requirements_id']] = array('Y'=>0, 'N'=>0, 'C'=>0, 'NA'=>0, 'NT'=>0, 'severity'=>0, 'maxseverity'=>0, 'total'=>0, 'percentage'=>0);
		$inplace = $rw['inplace'];
		if ( $inplace == '' )
			$inplace = 'NT';	
		$web['controls'][$n][$rw['requirements_id']][$inplace]++;
		$web['controls'][$n][$rw['requirements_id']]['total']++;
		$totayary[$n][$inplace]++;
	}
	$web['total'][$n] = $totayary[$n];
	// Compliance / Severity
	$s1[$n] = array();
	$label[$n] = array();
	$ticks[$n] = array();
	foreach($web['controls'][$n] as $k => $v)
	{
		if ( $v['total'] == 0 )
			$web['controls'][$n][$k]['percentage'] = 'NA';
		else
			$web['controls'][$n][$k]['percentage'] = round(($v['Y']+$v['C'])/$v['total']*100);
		$s1[$n][] = $web['controls'][$n][$k]['percentage'];
		//$label[] = "'".$web['controls'][$k]['percentage'].'%'."'";
		// haere we needed data in integer to use highcharts ui 
		$label[$n][] = $web['controls'][$n][$k]['percentage'];
		$ticks[$n][] = "'".$k."'";
	}
	$web['s2'][$n] = implode(', ', $s1[$n]);
	$web['label2'][$n] = implode(', ', $label[$n]);
	$web['ticks2'][$n] = implode(', ', $ticks[$n]);
	
	$tbl = new table('document');
	$tbl->cols('t1.inplace');
	$tbl->cols('p.requirements_id');
	$tbl->cols('p.sub_requirements_id');
	$tbl->cols('p.id AS pid');
	$tbl->cols('p.priority');
	$tbl->join($roc_saq.'procedure', 'p.id', 't1.procedure_id', 'p');
	$tbl->condition('WHERE', 't1.company_id', $rw1['id']);
	$tbl->orderby('p.requirements_id');
	$tbl->orderby('p.sub_requirements_id');
	$tbl->orderby('p.id');
	$reports[$n] = $tbl->getList();
	unset($tbl);	
  $n++;
}
echo $twig->render('statistics-charts.html', array('web' => $web));
?>
