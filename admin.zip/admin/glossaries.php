<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['pagetitle']				= $web['company'].' - Glossary';
$web['table']					= 'glossary';
$web['page']					= 'masters';
$web['subpage']					= 'glossaries';
$web['editscript']				= 'glossary.php';
$web['listscript']				= 'glossaries.php';

$web['search']['title']			= 'Glossary Title';

$web['title']	= 'Glossary';
$web['id']	= $request->get('id', '');
$web['task']	= $request->get('task', '');
$web['err']	= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'title');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

if ( $web['task'] == 'delete' )
{
	$removeid	= $request->get('removeid', '');
	$tbl = new table($web['table']);
	$tbl->cols('id');
	$tbl->condition('WHERE', 'id', $removeid, 'IN');
	$rows = $tbl->getList();
	foreach ( $rows as $rw )
	{
		$params = array($rw['id']);
		$sql = "DELETE FROM ".$tbl->getPrefix().$web['table']." WHERE id = ?";
		$tbl->execute($sql, $params);
	}
	unset($tbl);
	add_log_history('DEL', 'GLOSS', $_SESSION['uid'], $_SESSION['userrole']);
}

$web['rows'] = array();
$tbl = new table($web['table']);
$tbl->condition('WHERE', 't1.userrole', 'a');
if ( $web['sk'] != "" )
	$tbl->condition('AND', $web['sb'], '%'.$web['sk'].'%', 'LIKE');
$tbl->orderby($web['ob'], $web['ot']);
$web['rows'] = $tbl->getList($web['pg'], $web['en']);
$web['total_pages'] = $tbl->getPages();
$web['rectitle'] = '<span>&nbsp;&nbsp;[No records]</span>';
if ( $tbl->getTotal() > 0 )
	$web['rectitle'] = '<span>&nbsp;&nbsp;[' . $tbl->getStart() . ' to ' . $tbl->getEnd() . ' out of ' . $tbl->getTotal() . ']</span>';
unset($tbl);

echo $twig->render('glossaries.html', array('web' => $web));
?>
