<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['endpage']		= 'psaq';
$web['id']			= $request->get('id', '0');
$web['pagetitle']	= $web['company'].' - Testing Procedure [SAQ]';
$web['table']		= 'saq_procedure';
$web['title']		= 'Testing Procedure [SAQ] '.($web['id'] == '0' ? 'New' : 'Edit');
$web['editscript']	= 'saq_procedure.php';
$web['listscript']	= 'saq_procedures.php';
$web['type']		= 'saq_';
$web['roc_saq']	= 'saq';
require('procedure.php');
?>
