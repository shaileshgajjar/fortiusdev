<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['pagetitle']				= $web['company'].' - User Group';
$web['table']					= 'user_group';
$web['page']					= 'masters';
$web['subpage']					= 'usergroups';
$web['editscript']				= 'usergroup.php';
$web['listscript']				= 'usergroups.php';

$web['search']['rowid']  			= 'User Group No.';
$web['search']['company_name']		= 'Company Name';
$web['search']['user_group_name']	= 'User Group Name';

$web['title']	= 'User Group';
$web['id']	= $request->get('id', '');
$web['task']	= $request->get('task', '');
$web['err']	= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'user_group_name');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'rowid');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
if ( $web['task'] == 'delete' )
{
	$removeid	= $request->get('removeid', '');
	$tbl->delete('id', $removeid, 'in');
	add_log_history('DEL', 'UG', $session->get('uid'), $session->get('userrole'));
}
$tbl->cols('t1.*');
$tbl->cols(" (SELECT COUNT(id) FROM users u WHERE u.user_group_id = t1.id AND u.userrole='u' ) as group_users ");	
$tbl->cols(" IF(c.company_name IS NULL or c.company_name = '' , 'Admin', c.company_name ) AS company_name ");
$tbl->join('customer', 'c.id', 't1.company_id', 'c');
if ( $web['sk'] != "" )
	$tbl->having($web['sb'], "%".trim($web['sk'])."%", 'LIKE');
$tbl->orderby($web['ob'], $web['ot']);
$web['rows'] = $tbl->getList($web['pg'], $web['en']);
$web['total_pages'] = $tbl->getPages();
$web['rectitle'] = '<span>&nbsp;&nbsp;[No records]</span>';
if ( $tbl->getTotal() > 0 )
	$web['rectitle'] = '<span>&nbsp;&nbsp;[' . $tbl->getStart() . ' to ' . $tbl->getEnd() . ' out of ' . $tbl->getTotal() . ']</span>';
unset($tbl);

echo $twig->render('usergroups.html', array('web' => $web));
?>
