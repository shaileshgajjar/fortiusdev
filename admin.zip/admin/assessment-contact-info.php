<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");


$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= 'customer';
$web['page']		= 'masters';
$web['subpage']	= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-config.php';
$web['nextscript']	= 'assessment-timeframe.php';
$web['current_section']	= 'section2';

$web['listscript']	= ('assessment-timeframe.php');

$web['id']		= $request->get('id', $session->get('cid'));
$web['task']		= $request->get('task', '');
$web['err']		= $request->get('err', '');
$web['title']		= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');


if($web['id'] != 0)
	$web['editscript']	= 'assessment-respondent.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$web['fields'] = array();
$web['fields']['company_name']			= array('value' => '0');
$web['fields']['company_address']		= array('value' => '');
$web['fields']['city']				= array('value' => '');
$web['fields']['state']				= array('value' => '');
$web['fields']['country']				= array('value' => '');
$web['fields']['zipcode']				= array('value' => '');
$web['fields']['company_url']			= array('value' => '');
$web['fields']['assr_company_name']		= array('value' => '');
$web['fields']['assr_company_address']	= array('value' => '');
$web['fields']['assr_city']			= array('value' => '');
$web['fields']['assr_state']			= array('value' => '');
$web['fields']['assr_country']			= array('value' => '');
$web['fields']['assr_zip']			= array('value' => '');
$web['fields']['assr_company_url']		= array('value' => '');

$customer = new table('customer');
$customer->load($web['id']);
	
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	
	$qa_tbl = new table('users');
	$qa_tbl->setValue('username', $request->get('qa_name', ''));
	$qa_tbl->setValue('first_name', $request->get('qa_name', ''));
	$qa_tbl->setValue('company_name', $request->get('assr_company_name', ''));
	$qa_tbl->setValue('mobile', $request->get('qa_mobile', ''));
	$qa_tbl->setValue('email', $request->get('qa_email', ''));
	$qa_tbl->setValue('pwd', md5('Tester12#'));
	$qa_tbl->setValue('userrole', 'q');
	$qa_tbl->save();
	$qa_id = $qa_tbl->getValue('id');
	unset($qa_tbl);
	
	$qsa_tbl = new table('users');
	$qsa_tbl->setValue('first_name', $request->get('qsa_name', ''));
	$qsa_tbl->setValue('username', $request->get('qsa_name', ''));
	$qsa_tbl->setValue('pci_credential', $request->get('pci_credential', ''));
	$qsa_tbl->setValue('company_name', $request->get('assr_company_name', ''));
	$qsa_tbl->setValue('mobile', $request->get('qsa_mobile', ''));
	$qsa_tbl->setValue('email', $request->get('qsa_email', ''));
	$qsa_tbl->setValue('pwd', md5('Tester12#'));
	$qsa_tbl->setValue('userrole', 's');
	$qsa_tbl->save();
	$qsa_id = $qsa_tbl->getValue('id');
	unset($qsa_tbl);
	
	foreach($web['fields'] as $key => $value)
		$customer->setValue($key, $request->get($key, ''));
		
	$customer->setValue('qa_id', $qa_id);	
	$customer->setValue('qsa_id', $qsa_id);	
	$customer->save();
	//company admin data
	$company_admin = new table('users');
	$company_admin->setValue('first_name', $request->get('first_name', ''));
	$company_admin->setValue('username', $request->get('first_name', ''));
	$company_admin->setValue('company_name', $request->get('company_name', ''));
	$company_admin->setValue('mobile', $request->get('mobile', ''));
	$company_admin->setValue('email', $request->get('email', ''));
	$company_admin->setValue('pwd', md5('Tester12#'));
	$company_admin->setValue('userrole', 'c');
	$company_admin->setValue('company_id', $web['id']);
	$company_admin->save();
	unset($company_admin);	
}
$company_admin = new table('users');
$company_admin->find(array('company_id', 'userrole'), array($web['id'], 'c'));
$web['users'] = array();
$web['users']['first_name']['value'] 	= $company_admin->getValue('first_name');
$web['users']['mobile']['value'] 		= $company_admin->getValue('mobile');
$web['users']['email']['value'] 		= $company_admin->getValue('email');

foreach($web['fields'] as $key => $value)
	$web['fields'][$key]['value'] = $customer->getValue($key);

$web['assr'] = array();
$web['assr']['assr_company_name']['value'] 	= $customer->getValue('assr_company_name');
$web['assr']['assr_company_address']['value'] = $customer->getValue('assr_company_address');
$web['assr']['assr_city']['value'] 		= $customer->getValue('assr_city');
$web['assr']['assr_state']['value'] 		= $customer->getValue('assr_state');
$web['assr']['assr_country']['value'] 		= $customer->getValue('assr_country');
$web['assr']['assr_zip']['value'] 			= $customer->getValue('assr_zip');
$web['assr']['assr_company_url']['value'] 	= $customer->getValue('assr_company_url');

$qsa_id = $customer->getValue('qsa_id');
$qsa_tbl = new table('users');	
$qsa_tbl->load($qsa_id);
$web['assr']['qsa_name']['value'] 		= $qsa_tbl->getValue('first_name');
$web['assr']['qsa_mobile']['value'] 	= $qsa_tbl->getValue('mobile');
$web['assr']['qsa_email']['value'] 	= $qsa_tbl->getValue('email');
$web['assr']['pci_credential']['value'] = $qsa_tbl->getValue('pci_credential');

$qa_id = $customer->getValue('qa_id');
$qa_tbl = new table('users');	
$qa_tbl->load($qa_id);
$web['assr']['qa_name']['value'] 	= $qa_tbl->getValue('first_name');
$web['assr']['qa_mobile']['value'] = $qa_tbl->getValue('mobile');
$web['assr']['qa_email']['value'] 	= $qa_tbl->getValue('email');

echo $twig->render('assessment-contact-info.html', array('web' => $web));
?>
