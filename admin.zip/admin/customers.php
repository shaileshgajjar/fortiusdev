<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['pagetitle']				= $web['company'].' - Customer';
$web['table']					= 'customer';
$web['page']						= 'masters';
$web['subpage']					= 'customers';
$web['editscript']				= 'customer.php';
$web['subsidiary']				= 'subsidiary.php';
$web['listscript']				= 'customers.php';
$web['wizardscript']				= '/execsumm/assessment-timeframe.php';
$_SESSION['backscript']			= '';

$web['search']['merchant_type']	= 'Assessment Type';
$web['search']['qsa']				= 'Assessor QSA';
$web['search']['qa']				= 'Assessor QA';
$web['search']['company_name']		= 'Company Name';
$web['search']['pcname']			= 'Parent Company';
$web['search']['username']			= 'Contact Name';
$web['search']['mobile']			= 'Telephone';
$web['search']['email']			= 'Email';

$web['title']	= 'Customer';
$web['id']		= $request->get('id', '');
$web['task']	= $request->get('task', '');
$web['err']		= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'title');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'rowid');
$web['ot']	= $request->get('ot', 'asc');

//$web['msg']	= $request->get('msg', '');

$tbl = new table($web['table']);
if ( $web['task'] == 'delete' )
{
	$removeid	= $request->get('removeid', '');
	$tbl->delete('id', $removeid, 'in');
	$users = new table('users');
	$users->delete('company_id', $removeid, 'in');
	unset($users);
	add_log_history('DEL', 'CUST', $session->get('uid'), $session->get('userrole'));
}

$tbl->cols('t1.*');
$tbl->cols("m.merchant_type,CONCAT(u.first_name, ' ', u.last_name) AS username");
$tbl->cols('u.mobile');
$tbl->cols('u.email');
$tbl->cols(" IF( pc.company_name !='', pc.company_name, 'Self') AS pcname ");
$tbl->cols("CONCAT(u_s.first_name, ' ', u_s.last_name) AS qsa");
$tbl->cols("CONCAT(u_q.first_name, ' ', u_q.last_name) AS qa");
$tbl->cols("(SELECT COUNT(id) FROM ".$tbl->getPrefix()."document d WHERE d.company_id = t1.id) AS total");
$tbl->cols("(SELECT COUNT(id) FROM ".$tbl->getPrefix()."document d WHERE d.company_id = t1.id AND inplace <> '') AS filled");
$tbl->join('merchant_type', 'm.id', 't1.merchant_type_id', 'm');
$tbl->join('customer', 'pc.id', 't1.parent_id', 'pc');
$tbl->join('users', 'u.company_id', 't1.id', 'u');
$tbl->join('users', 'u_q.id', 't1.qa_id', 'u_q');
$tbl->join('users', 'u_s.id', 't1.qsa_id', 'u_s');
$tbl->groupby('t1.id');
if ( $web['sk'] != "" )
	$tbl->having($web['sb'], '%'.$web['sk'].'%', 'LIKE');
$tbl->orderby($web['ob'], $web['ot']);

$rows = $tbl->getList($web['pg'], $web['en']);
$web['total_pages'] = $tbl->getPages();
$web['rectitle'] = '<span>&nbsp;&nbsp;[No records]</span>';
if ( $tbl->getTotal() > 0 )
	$web['rectitle'] = '<span>&nbsp;&nbsp;[' . $tbl->getStart() . ' to ' . $tbl->getEnd() . ' out of ' . $tbl->getTotal() . ']</span>';

$no = 0;
foreach ( $rows as $rw )
{
	$web['rows'][$no] = $rw;
	$web['rows'][$no]['class'] = '';
	if ( date('Ymd') > $lib->format_date($rw['compliance_due_date'], 'Ymd') )
		$web['rows'][$no]['class'] = ' class="danger"';
	$web['rows'][$no]['compliance_due_date'] = $lib->format_date($rw['compliance_due_date'], 'd M Y');
	$web['rows'][$no]['percentage'] = 0;
	if ( $rw['total'] > 0 )
		$web['rows'][$no]['percentage'] = round($rw['filled'] / $rw['total'] * 100);
	if ( $web['rows'][$no]['percentage'] == 100 )
		$web['rows'][$no]['class'] = ' class="success"';
	$ver_no = ($rw['assessment_version']) ? $rw['assessment_version'] : 'v32_'; 
	$tblname = $ver_no.'audit_wizard' ;
	$aw_tbl = new table($tblname);
	$aw_tbl->find(array('company_id'), array($rw['id']));
	if( $aw_tbl->getValue('id'))
		 $web['rows'][$no]['audit_wizard_id'] = $aw_tbl->getValue('id',0);
	else
		$web['rows'][$no]['audit_wizard_id'] = 0;
	
	$web['rows'][$no]['ver_no'] = $ver_no;
	$no++;
}

echo $twig->render('customers.html', array('web' => $web));
