<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['pagetitle']				= $web['company'].' - Users';
$web['table']					= 'users';
$web['page']					= 'masters';
$web['subpage']				= 'users';
$web['editscript']				= 'user.php';
$web['listscript']				= 'users.php';
$web['addbtnshow']				= 0;


$web['search']['c.company_name']		= 'Company Name';
$web['search']['ug.user_group_name']	= 'User Group Name';
$web['search']['t1.email']			= 'User Email';
$web['search']['t1.first_name']	     = 'First Name';
$web['search']['t1.last_name']	     = 'Last Name';



$web['title']	= 'Users';
$web['id']	= $request->get('id', '');
$web['company_id']	= $request->get('company_id', '');
$web['task']	= $request->get('task', '');
$web['err']	= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'username');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'c.company_name');
$web['ot']	= $request->get('ot', 'asc');
$web['user_group_id']	= $request->get('user_group_id', '');
$web['company_id']		= $request->get('company_id', '');
$web['from']			= $request->get('from', '');
$web['user_group_name']	= $request->get('user_group_name', '');
	
$web['rows'] = array();
$tbl = new table('users');
$tbl->cols('t1.*');
$tbl->cols('ug.user_group_name');
$tbl->cols('c.company_name');
$tbl->join('user_group', 'ug.id', 't1.user_group_id', 'ug');
$tbl->join('customer', 'c.id', 't1.company_id', 'c');
$tbl->condition('WHERE', 't1.userrole', 'u');
if( isset($web['from']) && ($web['from'] == 'users_group') )
	$tbl->condition('AND', 't1.user_group_id', $web['user_group_id']);
if ( $web['sk'] != "" )
		$tbl->condition('AND', $web['sb'], '%'.trim($web['sk']).'%', 'LIKE');	
$tbl->orderby($web['ob'], $web['ot']);
$web['rows'] = $tbl->getList($web['pg'], $web['en']);
$web['total_pages'] = $tbl->getPages();
$web['rectitle'] = '<span>&nbsp;&nbsp;[No records]</span>';
if ( $tbl->getTotal() > 0 )
	$web['rectitle'] = '<span>&nbsp;&nbsp;[' . $tbl->getStart() . ' to ' . $tbl->getEnd() . ' out of ' . $tbl->getTotal() . ']</span>';
unset($tbl);
echo $twig->render('users.html', array('web' => $web));
?>
