<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");
$web['pagetitle']				= $web['company'].' - Glossary';
$web['table']					= 'glossary';
$web['page']					= 'masters';
$web['subpage']				= 'glossaries';
$web['editscript']				= 'glossary.php';
$web['listscript']				= 'glossaries.php';

$web['id']					= $request->get('id', '0');
$web['task']					= $request->get('task', '');
$web['err']					= $request->get('err', '');
$web['title']					= 'Glossary '.($web['id'] == '0' ? 'New' : 'Edit');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'title');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$web['fields'] = array();
$web['fields']['title']			= array('value' => '');
$web['fields']['description']	= array('value' => '');

foreach($web['fields'] as $key => $value)
	$web['fields'][$key]['value'] = $request->get($key, '');
$tbl = new table('glossary');
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->load($web['id']);
	$tbl->savedata($web['fields']);
	$act = ($web['id'] == 0)?'ADD':'EDIT';
	add_log_history($act, 'GLOSS', $session->get('uid'), 'a');
}

if ( $web['id'] > 0 && $web['err'] == '' )
{
	$tbl->load($web['id']);
	foreach($web['fields'] as $key => $value)
		$web['fields'][$key]['value'] = $tbl->getValue($key);
}
echo $twig->render('glossary.html', array('web' => $web));
?>
