<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");
$id	= $request->get('id', '');

$conditions[] = array('type' => 'WHERE', 'field' => 'id', 'value' => $id, 'condition_type' => '!=');
$conditions[] = array('type' => 'AND', 'field' => '(userrole', 'value' => 'q');
$conditions[] = array('type' => 'OR', 'field' => 'userrole', 'value' => 's)');
echo '<option value="0">Select QA</option>';
echo getdropdown('users', 'id', "CONCAT(first_name, ' ', last_name) as qsa", 0, $conditions);
?>