<?php
$web['table']			= $web['version'].$web['table'];
$web['title']			= str_replace('_', ' ', $web['version']).$web['title'];
$web['page']			= 'masters';
$web['subpage']			= 'requirements';
$web['search']['ref']	= 'Ref';
$web['search']['title']	= 'Title';

$web['id']		= $request->get('id', '');
$web['task']	= $request->get('task', '');
$web['err']		= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'ref');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'rowid');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
if ( $web['task'] == 'delete' )
{
	$removeid	= $request->get('removeid', '');
	$tbl->delete('id', $removeid, 'in');
	add_log_history('DEL', 'REQ', $session->get('uid'), $session->get('userrole'));
}

if ( $web['sk'] != "" )
	$tbl->condition('WHERE', $web['sb'], '%'.$web['sk'].'%', 'LIKE');
$tbl->orderby($web['ob'], $web['ot']);

$web['rows'] = $tbl->getList($web['pg'], $web['en']);
$web['total_pages'] = $tbl->getPages();
$web['rectitle'] = '<span>&nbsp;&nbsp;[No records]</span>';
if ( $tbl->getTotal() > 0 )
	$web['rectitle'] = '<span>&nbsp;&nbsp;[' . $tbl->getStart() . ' to ' . $tbl->getEnd() . ' out of ' . $tbl->getTotal() . ']</span>';
unset($tbl);

echo $twig->render('requirements.html', array('web' => $web));
?>
