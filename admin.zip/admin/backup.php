<?php
/******************************************************/
/* File 	: backup.php ********************************/
/* Usage	: Take back up of company data from databse */
/* and files from uploads *****************************/
/******************************************************/
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");
error_reporting(E_ALL);
$id = $request->get('id', '');

$company_id = $id;
$tbl_comment = '';
if($company_id != 0)
{	
	//here taking backup of company data from below tables 
	$tables = array();
	$tables[0] = 'customer';
	$tables[1] = 'users';
	$tables[2] = 'user_group';
	$tables[3] = 'document';
	$tables[4] = 'document_user_group';
	$tables[5] = 'document_reporting';
	$tables[6] = 'procedure_comment';
	$tables[7] = 'procedure_document';
	//here we first takes backup of documents and zip the folder	
	$path = '../uploads/documents/'.$company_id.'/';
	$lineBreak = 30;
	$backup_path = '../uploads/backup/'.$company_id;
	if (!is_dir($backup_path))
		mkdir($backup_path, 0777);
	$tbl = new table('procedure_document');
	$tbl->cols('document');
	$tbl->condition('WHERE', 't1.company_id', $company_id);
	foreach( $tbl->getList() as $rw1)
	{
		$document = $rw1['document'];
		$docpath = $path.$document;
		if(file_exists($docpath))
			copy($docpath, $backup_path.'/'.$document);
	}
	$all_qry = '';
	$return = '';
	$insert_str 	= '';
	foreach( $tables as $table )
	{
		
		$tbl = new table($table);
		
		$tmp = $tbl->getStructure();
		$fields = $tmp['structure'];
		$num_fields = count($fields);
		$tbl->cols('t1.*');
		if ( $table == 'customer' )
			$tbl->condition('WHERE', 't1.id', $company_id);
		else
			$tbl->condition('WHERE', 't1.company_id', $company_id);
		$rows = $tbl->getList();	
		$cnt = $tbl->getTotal();
		$i=0;
		$_colstr 	= '';
		
		$insert_str = 'INSERT INTO '. $table . ' ( ';
		$p=0;
		foreach($fields as $key => $cols) 
		{
			$_colstr .= "`".$key."`" ;
			if ($p<($num_fields-1)) $_colstr .= ', '; 
			$p++;		
		}	
		$insert_str.= $_colstr.' ) VALUES ';
		$col_val = '';
		foreach( $rows as $row )
		{
			$j=0;
			$col_val .= $insert_str .'(';
			foreach($fields as $key => $cols) 
			{ 
				$fld = $row[$key];
				$fld = addslashes($fld);
				if (isset($fld))
					$col_val.= "'".$fld."'" ;
				else 
					 $col_val.= "' '";
				if ($j<($num_fields-1))
					$col_val.= ','; 
			$j++;	
			}
			$col_val .= "); \n";
		 $i++;	
		}		
		$return .= $tbl_comment . $col_val . "\n\n";
	}
	$all_qry = $return;
	$content = $all_qry;
	$sql_file_path = '../uploads/backup/'.$company_id.'/backup.sql';
	$fp = fopen($sql_file_path,"wb");
	if( $fp == true )
		fwrite($fp,$content); fclose($fp);

	//creating zip 
	$overwrite = false;
	$rootpath = $_SERVER["DOCUMENT_ROOT"];
	$source 	= $rootpath.'/uploads/backup/'.$company_id.'/'; 
	$dirlist 	= new RecursiveDirectoryIterator($source);
	$filelist = new RecursiveIteratorIterator($dirlist);
	$file = tempnam("tmp", "zip");
	$dest = $backup_path.'.zip';
	$zip = new ZipArchive();
	if ($zip->open($file, $overwrite ? ZIPARCHIVE::OVERWRITE : ZIPARCHIVE::CREATE) !== true)
		return false;
	if (($filelist))
	{
		foreach ($filelist as $key => $val)
		{
			if ( preg_match("/\/\./", $key) )
				continue;
			$path = str_replace($source, "", $key);
			if( file_exists($key) && is_readable($key) )
			{
				$zip->addFromString($path, $key);
				$zip->addFile( realpath($key), $path );
			}
		}
	}
	$zip->close();
	$dest = $rootpath.'/uploads/backup/'.$company_id.'.zip';
	$file_to_download = $file;
	rename($file, $dest);
	$secure_key = 'dwnload'.$company_id.rand();
	$tbl= new table('customer');
	$tbl->load($company_id);
	$tbl->setValue('secure_key', $secure_key);
	$tbl->save();
	$tbl= new table('users');
	$tbl->cols('t1.first_name');
	$tbl->cols('t1.last_name');
	$tbl->cols('t1.email');
	$tbl->condition('WHERE', 't1.company_id', $company_id);
	$tbl->condition('AND', 't1.userrole', 'c');
	$userdata = $tbl->getList();
	
	foreach($userdata as $user)
	{
		$first_name 	= $user['first_name'];
		$last_name 	= $user['last_name'];
		$email_id = $user['email'];
	}
	$tbl= new table('users');
	$tbl->cols("CONCAT(t1.first_name, ' ', t1.last_name) AS username");
	$tbl->cols('t1.email');
	//$tbl->condition('WHERE', 't1.company_id', 0);
	$tbl->condition('WHERE', 't1.userrole', 'a');
	$admindata = $tbl->getList();
	
	foreach($admindata as $admin)
		$admin_email_id = $admin['email'];
		$cid = base64_encode('company_id='.$company_id.'&secure_key='.$secure_key);
	$link = '<a href="http://'.$_SERVER['HTTP_HOST'].'/downloadbackup.php?q='.$cid.'">Download</a>';
	$subject = 'Backup Company Data';
	$html = array();
	$html['first_name'] = $first_name;
	$html['last_name'] 	= $last_name;
	$html['link'] = $link;
	$f_path =  APP_PATH .'emailtemplates/html_download_backup.html';
	
	$lib->send_mail($f_path, $email_id, $admin_email_id, $subject,'', $html, false);
		
	header('location:list-data.php?msg=linksent');
}
?>