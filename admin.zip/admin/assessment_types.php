<?php
require(dirname(__FILE__).'/../config/config.new.php');
if ( !isset($role) ) $role = array('c', 'u', 'q', 's', 'a');
if ( !in_array($session->get('userrole'), $role) )
	$response->redirect("index.php?err=3");

$web['pagetitle']				= $web['company'].' - Assessment Type';
$web['table']					= 'merchant_type';
$web['page']					= 'masters';
$web['subpage']					= 'assessment_types';
$web['editscript']				= 'assessment_type.php';
$web['listscript']				= 'assessment_types.php';

$web['search']['merchant_type']	= 'Assessment Type';
$web['search']['roc_saq']		= 'ROC / SAQ';

$web['title']	= 'Assessment Type';
$web['id']		= $request->get('id', '');
$web['task']	= $request->get('task', '');
$web['err']		= $request->get('err', '');

$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'merchant_type');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'rowid');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
if ( $web['task'] == 'delete' )
{
	$removeid	= $request->get('removeid', '');
	$tbl->delete('id', $removeid, 'in');
	add_log_history('DEL', 'MT', $session->get('uid'), $session->get('userrole'));
}

if ( $web['sk'] != "" )
	$tbl->condition('WHERE', $web['sb'], "%".$web['sk']."%", 'LIKE');
$tbl->orderby($web['ob'], $web['ot']);

$web['rows'] = $tbl->getList($web['pg'], $web['en']);
$web['total_pages'] = $tbl->getPages();
$web['rectitle'] = '<span>&nbsp;&nbsp;[No records]</span>';
if ( $tbl->getTotal() > 0 )
	$web['rectitle'] = '<span>&nbsp;&nbsp;[' . $tbl->getStart() . ' to ' . $tbl->getEnd() . ' out of ' . $tbl->getTotal() . ']</span>';
unset($tbl);

echo $twig->render('assessment_types.html', array('web' => $web));
?>
