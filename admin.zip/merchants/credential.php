<?php
$role = array('a', 'm');

if ( $session->get('userrole') == '' )
	$response->redirect("/index.php?err=3");
$web['id'] = $request->get('id',0);
if ( $session->get('userrole') == 'a' )
{
	$web['mainlayout'] = 'new-layout.html';
	$dashboard = '/admin/dashboard.php';
}
else
{
	$web['mainlayout'] = 'new-front-layout.html';
	$dashboard = '/dashboard.php';
}
if ( !in_array($session->get('userrole'), $role) || $web['id'] == '' || $web['id'] == 0 )
	$response->redirect($dashboard);

