<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$customer = new table('customer');
$customer->load($web['id']);
$session->set('company_name', $customer->getValue('company_name'));
unset($customer);

$web['wizards_pages'] = array();
$web['subsection']	= 'Part 1b';
$pagestable = new table('saq_wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']		= $web['company'].' - Customer';
$web['table']			= $web['version'].'saq_audit_wizard';
$web['page']			= 'masters';
$web['subpage']			= 'customers';
$web['editscript']		= 'qualified-assessor-company-info.php';
$web['prescript']	= 'subsidiary.php';
$web['parent_id']		= $request->get('parent_id', '0');
$web['nextscript']		= 'merchant-business-type.php';
$web['current_sections']	= 'section1';
$web['listscript']		= 'customer.php';
$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
$web['cust_type'] 		= $session->get('audit_wizard_id');
if($web['id'] != 0)
	$web['editscript']	= 'qualified-assessor-company-info.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);

if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->setValue('company_id', $web['id']);
	$tbl->setValue('company_name', $request->get('company_name', ''));
	$tbl->setValue('qsa_contact_name', $request->get('qsa_contact_name', ''));
	$tbl->setValue('title', $request->get('title', ''));
	$tbl->setValue('mobile', $request->get('mobile', ''));
	$tbl->setValue('email', $request->get('email', ''));
	$tbl->setValue('business_address', $request->get('business_address', ''));
	$tbl->setValue('city', $request->get('city', ''));
	$tbl->setValue('state', $request->get('state', ''));
	$tbl->setValue('country', $request->get('country', ''));
	$tbl->setValue('zip_code', $request->get('zip_code', ''));
	$tbl->setValue('url', $request->get('url', ''));
	$tbl->save();
	$session->set('audit_wizard_id',$tbl->getValue('id'));
}

$web['fields'] = array();
$web['fields']['company_id']['value'] 			= $tbl->getValue('company_id');
$web['fields']['company_name']['value']	 		= $tbl->getValue('company_name');
$web['fields']['qsa_contact_name']['value']	 	= $tbl->getValue('qsa_contact_name');
$web['fields']['title']['value'] 				= $tbl->getValue('title');
$web['fields']['mobile']['value'] 				= $tbl->getValue('mobile');
$web['fields']['email']['value'] 				= $tbl->getValue('email');
$web['fields']['business_address']['value'] 	= $tbl->getValue('business_address');
$web['fields']['city']['value'] 				= $tbl->getValue('city');
$web['fields']['state']['value'] 				= $tbl->getValue('state');
$web['fields']['country']['value'] 				= $tbl->getValue('country');
$web['fields']['zip_code']['value'] 			= $tbl->getValue('zip_code');
$web['fields']['url']['value'] 					= $tbl->getValue('url');

$cust_tbl = new table('customer');
$cust_tbl->load($web['id']);
$web['prescript'] = ($cust_tbl->getValue('parent_id') == 0) ? 'customer.php' : 'subsidiary.php' ;

echo $twig->render('qualified-assessor-company-info.html', array('web' => $web));
