<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$customer = new table('customer');
$customer->load($web['id']);
$session->set('company_name', $customer->getValue('company_name'));
unset($customer);

$web['wizards_pages'] = array();
$web['subsection']	= '1.2';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']		= $web['company'].' - Customer';
$web['table']			= $web['version'].'audit_wizard';
$web['page']			= 'masters';
$web['subpage']			= 'customers';
$web['editscript']		= 'assessment-exec-summary.php';

$web['parent_id']		= $request->get('parent_id', '0');
$web['nextscript']		= 'assessment-pci-dss-version.php';
$web['current_section']	= 'section1';
$web['listscript']		= 'customer.php';
$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';

if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->setValue('company_id', $web['id']);
	$tbl->setValue('date_of_report', savedateformat($request->get('date_of_report', ''), 'm-d-Y'));
	$tbl->setValue('timeframe', $request->get('timeframe', ''));
	$tbl->setValue('date_spent_onsite', $request->get('date_spent_onsite', ''));
	$tbl->setValue('desc_of_time_spent', $request->get('desc_of_time_spent', ''));
	$tbl->save();
	$session->set('audit_wizard_id',$tbl->getValue('id'));
}

if ( $tbl->getValue('date_of_report') == '' )
	$tbl->setValue('date_of_report', date('m-d-Y'));
$web['fields'] = array();
$web['fields']['date_of_report']['value'] 		= $lib->format_date($tbl->getValue('date_of_report'), 'm-d-Y');
$web['fields']['timeframe']['value']	 		= $tbl->getValue('timeframe');
$web['fields']['date_spent_onsite']['value'] 	= $tbl->getValue('date_spent_onsite');
$web['fields']['desc_of_time_spent']['value'] 	= $tbl->getValue('desc_of_time_spent');

$cust_tbl = new table('customer');
$cust_tbl->load($web['id']);
$web['prescript'] = ($cust_tbl->getValue('parent_id') == 0) ? 'customer.php' : 'subsidiary.php' ;

echo $twig->render('assessment-timeframe.html', array('web' => $web));
