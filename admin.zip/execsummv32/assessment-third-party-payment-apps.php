<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '4.8';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-service-providers-data.php';
$web['nextscript']	= 'assessment-reviewed-docs.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section4';
$web['id']			= $request->get('id', $session->get('cid'));
$web['section_id']		= $request->get('section_id',1);
$web['audit_wizard_id']	= $session->get('audit_wizard_id');
$web['task']			= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl1 = new table('third_party_payment_details');
$tbl2 = new table('third_party_payment_apps');
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl1->delete('company_id', $web['id']);
	$tbl1->setValue('id', 0);
	$tbl1->setValue('company_id', $web['id']);
	$tbl1->setValue('implementation_guide', $request->get('implementation_guide',''));
	$tbl1->setValue('manual', $request->get('manual',''));
	$tbl1->setValue('scope_exclusion', $request->get('scope_exclusion',''));
	$tbl1->setValue('additional_comments', $request->get('additional_comments',''));
	$tbl1->save();

	$tbl2->delete('company_id', $web['id']);
	$app_name 			= $request->get('app_name', array());
	$version_of_product = $request->get('version_of_product', array());
	$pa_dss_validated 	= $request->get('pa_dss_validated', array());
	$p2pe_validated 	= $request->get('p2pe_validated', array());
	$pci_ssc_ref_no 	= $request->get('pci_ssc_ref_no', array());
	$exp_date	 		= $request->get('exp_date', array());
	
	for($i=0; $i<count($app_name); $i++ )
	{
		$tbl2->setValue('id', 0);
		$tbl2->setValue('company_id', $web['id']);
		$tbl2->setValue('app_name', $app_name[$i]);
		$tbl2->setValue('version_of_product', $version_of_product[$i]);
		$tbl2->setValue('pa_dss_validated', $pa_dss_validated[$i]);
		$tbl2->setValue('p2pe_validated', $p2pe_validated[$i]);
		$tbl2->setValue('pci_ssc_ref_no', $pci_ssc_ref_no[$i]);
		$ary = explode('-', $exp_date[$i]);
		$tbl2->setValue('exp_date', $ary[2].'-'.$ary[0].'-'.$ary[1]);
		$tbl2->save();
	}
}

$web['current_date'] = date('m-d-Y');
$web['fields'] = array();
$tbl1->cols('t1.*');
$tbl1->condition('WHERE', 't1.company_id', $web['id']);
$web['fields'] = $tbl1->getList();

$tbl2->cols('t1.*');
$tbl2->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl2->getList();
$web['fields']['apps'] = array();
$no = 0;
foreach($rows as $rw)
{
	$web['fields']['apps'][$no] = $rw;
	$web['fields']['apps'][$no]['exp_date'] = $lib->format_date($rw['exp_date'], 'm-d-Y');
	$no++;
}
if ( count($web['fields']['apps']) == 0 )
	$web['fields']['apps'][] = array('app_name' => '', 'version_of_product' => '', 'pa_dss_validated' => '', 'p2pe_validated' => 'no', 'pci_ssc_ref_no' => 'no', 'exp_date' => $web['current_date']);

echo $twig->render($web['version'].'assessment-third-party-payment-apps.html', array('web' => $web));
