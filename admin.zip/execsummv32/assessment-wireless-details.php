<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '3.8';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']	= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-wireless-summary.php';
$web['nextscript']	= 'assessment-reviewed-environment.php';
$web['current_section']	= 'section3';
$web['id']				= $request->get('id', $session->get('cid'));

$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
$web['audit_wizard_id'] = $session->get('audit_wizard_id');
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl = new table('wireless_tech_in_scope'); 
	$tbl->delete('company_id', $web['id']);
	$wireless_tech		= $request->get('wireless_tech', array());
	$used_to_store_chd	= $request->get('used_to_store_chd', array());
	$connected_to_cde	= $request->get('connected_to_cde', array());
	$inpact_the_cde		= $request->get('inpact_the_cde', array());
	/*echo "<pre>";print_r($wireless_tech);
	echo "<pre>";print_r($used_to_store_chd);
	echo "<pre>";print_r($connected_to_cde);
	echo "<pre>";print_r($inpact_the_cde);
	exit;*/
	$i = 0;
	foreach($wireless_tech as $val )
	{
		$tbl->setValue('id', 0);
		$tbl->setValue('company_id', $web['id']);
		$tbl->setValue('wireless_tech', $wireless_tech[$i]);
		$tbl->setValue('used_to_store_chd', $used_to_store_chd[$i]);
		$tbl->setValue('connected_to_cde', $connected_to_cde[$i]);
		$tbl->setValue('inpact_the_cde', $inpact_the_cde[$i]);
		$tbl->save();
		$i++;	
	}
	
	$tbl = new table('wireless_tech_not_in_scope'); 
	$tbl->delete('company_id', $web['id']);
	$tech_not_in_scope = $request->get('tech_not_in_scope', array());
	$how_validated = $request->get('how_validated', array());
	$i = 0;
	foreach($tech_not_in_scope as $val)
	{
		$tbl->setValue('id', 0);
		$tbl->setValue('company_id', $web['id']);
		$tbl->setValue('tech_not_in_scope', $tech_not_in_scope[$i]);
		$tbl->setValue('how_validated', $how_validated[$i]);
		$tbl->save();
		$i++;
	}
}

$web['fields'] = array();
$tbl = new table('wireless_tech_in_scope');
$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl->getList();
foreach($rows as $rw )
	$web['fields']['in_scope'][] = $rw;
if ( !isset($web['fields']['in_scope']) )
	$web['fields']['in_scope'][] = array('wireless_tech' => '', 'used_to_store_chd' => 'no', 'connected_to_cde' => 'no', 'inpact_the_cde' => 'no');
	
$tbl = new table('wireless_tech_not_in_scope');
$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl->getList();
foreach($rows as $rw )
	$web['fields']['not_in_scope'][] = $rw;	
if ( !isset($web['fields']['not_in_scope']) )
	$web['fields']['not_in_scope'][] = array('tech_not_in_scope' => '', 'how_validated' => '');
	
echo $twig->render('assessment-wireless-details.html', array('web' => $web));
