<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '4.3';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-reviewed-environment.php';
//$web['nextscript']	= 'assessment-reviewed-env-software-data.php';
$web['nextscript']	= 'assessment-reviewed-env-sampling-data.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section4';
$web['id']			= $request->get('id', $session->get('cid'));
$web['section_id']		= $request->get('section_id',1);

$web['task']			= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
$web['audit_wizard_id'] = $session->get('audit_wizard_id');
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl1 = new table('reviewed_env_chd_storage');
$tbl2 = new table('reviewed_env_hardware_detail'); 
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl1->delete('company_id', $web['id']);
	$data 		= $request->get('data_store', array());
	$data_file 		= $request->get('data_file', array());
	$elements 	= $request->get('data_elements_stored', array());
	$security 	= $request->get('data_security', array());
	$access 	= $request->get('access_to_data', array());
	
	$i = 0;
	foreach($data as $val )
	{
		$tbl1->setValue('id', 0);
		$tbl1->setValue('company_id', $web['id']);
		$tbl1->setValue('data_store', $data[$i]);
		$tbl1->setValue('data_file', $data_file[$i]);
		$tbl1->setValue('data_elements_stored', $elements[$i]);
		$tbl1->setValue('data_security', $security[$i]);
		$tbl1->setValue('access_to_data', $access[$i]);
		$tbl1->save();
		$i++;	
	}
	
	$tbl2->delete('company_id', $web['id']);
	$type_of_device 	= $request->get('type_of_device', array());
	$vendor 			= $request->get('vendor', array());
	$vendor_role 		= $request->get('vendor_role', array());
	$software_product 	= $request->get('software_product', array());
	$software_version 	= $request->get('software_version', array());
	$func_role 			= $request->get('func_role', array());
	
	$i = 0;
	foreach($type_of_device as $val )
	{
		$tbl2->setValue('id', 0);
		$tbl2->setValue('company_id', $web['id']);
		$tbl2->setValue('type_of_device', $type_of_device[$i]);
		$tbl2->setValue('vendor', $vendor[$i]);
		$tbl2->setValue('vendor_role', $vendor_role[$i]);
		$tbl2->setValue('software_product', $software_product[$i]);
		$tbl2->setValue('software_version', $software_version[$i]);
		$tbl2->setValue('func_role', $func_role[$i]);
		$tbl2->save();
		$i++;	
	}
}

$tbl1->cols('t1.*');
$tbl1->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl1->getList();
$web['env_chd_flow'] = array();
foreach($rows as $rw)
	$web['env_chd_flow'][] = $rw;
$tbl2->cols('t1.*');
$tbl2->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl2->getList();
$web['hardware_detail'] = array();
foreach($rows as $rw)
	$web['hardware_detail'][] = $rw;
	
unset($tbl1);
unset($tbl2);
if ( count($web['env_chd_flow']) == 0 )
	$web['env_chd_flow'][] = array('data_store' => '', 'data_file' => '', 'data_elements_stored' => '', 'data_security' => '', 'access_to_data' => '');
if ( count($web['hardware_detail']) == 0 )
	$web['hardware_detail'][] = array('data_store' => '', 'data_elements_stored' => '', 'data_security' => '', 'access_to_data' => '');
echo $twig->render($web['version'].'assessment-reviewed-env-second-part.html', array('web' => $web));
