<?php

require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '3.5';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'network-segmentation-second-part.php';
$web['nextscript']	= 'assessment-other-business-entities.php';
$web['current_section']	= 'section3';
$web['id']			= $request->get('id', $session->get('cid'));

$web['audit_wizard_id'] = $session->get('audit_wizard_id');

$web['task']		= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']		= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']		.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$audit_wizard = new table($web['table']);

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);

if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->setValue('connected_ent_other_data', $request->get('connected_ent_other_data',''));
	$tbl->save();
	$sec_3_5_entities 		= $request->get('sec_3_5_entities', array());
	$sec_3_5_connected 		= $request->get('sec_3_5_connected', array());
	$sec_3_5_processing 	= $request->get('sec_3_5_processing', array());
	$sec_3_5_trans 			= $request->get('sec_3_5_trans', array());
	$sec_3_5_description 	= $request->get('sec_3_5_description', array());
	
	$tbls = new table('v32_audit_wizard_roc_sec_3_5');
	$tbls->delete('company_id', $web['id']);
	
	for($i=0; $i<count($sec_3_5_entities); $i++ )
	{
		$tbls->setValue('id', 0);
		$tbls->setValue('company_id', $web['id']);
		$tbls->setValue('sec_3_5_entities', $sec_3_5_entities[$i]);
		$tbls->setValue('sec_3_5_connected', $sec_3_5_connected[$i]);
		$tbls->setValue('sec_3_5_processing', $sec_3_5_processing[$i]);
		$tbls->setValue('sec_3_5_trans', $sec_3_5_trans[$i]);
		$tbls->setValue('sec_3_5_description', $sec_3_5_description[$i]);
		$tbls->save();
	}
	unset($tbls);
}

$web['fields'] = array();
$web['fields']['connected_ent_other_data']['value'] = $tbl->getValue('connected_ent_other_data');
$tbls = new table('v32_audit_wizard_roc_sec_3_5');
$tbls->cols('t1.*');
$tbls->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbls->getList();
$web['fields']['apps'] = array();
$no = 0;
foreach($rows as $rw ){
	$web['fields']['apps'][$no] = $rw;
	$no++;
}
if ( count($web['fields']['apps']) == 0 )
	$web['fields']['apps'][] = array('sec_3_5_entities' => '', 'sec_3_5_connected' => 'no', 'sec_3_5_processing' => 'no', 'sec_3_5_trans' => 'no', 'sec_3_5_description' => '');

echo $twig->render('assessment-connected-entities.html', array('web' => $web));
