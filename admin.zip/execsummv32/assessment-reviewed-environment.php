<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '4.1';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-wireless-details.php';
$web['nextscript']	= 'assessment-reviewed-env-second-part.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section4';
$web['id']				= $request->get('id', $session->get('cid'));
$web['section_id']		= $request->get('section_id',1);
$web['audit_wizard_id']	= $session->get('audit_wizard_id');
$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');
$web['cap']	= array('Authorization', 'Capture', 'Settlement', 'Chargeback');

$tbls = new table($web['table']);
$tbls->find('company_id', $web['id']);

$tbl = new table('reviewed_env_chd_flow');
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbls->setValue('card_holder_chd', $request->get('card_holder_chd',''));
	$tbls->save();
	$tbl->delete('company_id', $web['id']);
	$vars = array('pre', 'post');
	foreach($vars as $var)
	{
		$field1 = $request->get($var.'_event_name', array());
		$field2	= $request->get($var.'_types_chd', array());
		$field3	= $request->get($var.'_how_chd_transmitted', array());
		$i = 0;
		foreach($field1 as $val )
		{
			$event_name = $field1[$i];
			$types_chd = $field2[$i];
			$how_chd_transmitted = $field3[$i];
			$tbl->setValue('id', 0);
			$tbl->setValue('company_id', $web['id']);
			$tbl->setValue('event_type', $var);
			$tbl->setValue('event_name', $event_name);
			$tbl->setValue('types_chd', $types_chd);
			$tbl->setValue('how_chd_transmitted', $how_chd_transmitted);
			$tbl->save();
			$i++;	
		}			
	}
}

$web['fields'] = array();
$web['fields']['card_holder_chd']['value'] = $tbls->getValue('card_holder_chd');

$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl->getList();

foreach($rows as $rw)
	$web['fields'][$rw['event_type']][] = $rw;
	
if ( !isset($web['fields']['pre']) )
{
	for($i=0; $i<4; $i++)
		$web['fields']['pre'][] = array('event_name' => '', 'types_chd' => '', 'how_chd_transmitted' => '');
}
if ( !isset($web['fields']['post']) )
{
	for($i=0; $i<2; $i++)
		$web['fields']['post'][] = array('event_name' => '', 'types_chd' => '', 'how_chd_transmitted' => '');
}
unset($tbl);
	
$tbl = new table('network_diagram');
$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$tbl->condition('AND', 't1.section_id', '2');
$rows = $tbl->getList();
$web['wizard_diagrams'] = array();
foreach($rows as $rw)
	$web['wizard_diagrams'][] =  $rw;
unset($tbl);

echo $twig->render('assessment-reviewed-environment.html', array('web' => $web));
