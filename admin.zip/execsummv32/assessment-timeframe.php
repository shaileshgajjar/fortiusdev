<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['id']				= $request->get('id',0); // here we are setting id as company_id
$customer = new table('customer');
$customer->load($web['id']); 
$session->set('company_name', $customer->getValue('company_name'));
$session->set('assessment_version', $customer->getValue('assessment_version'));
$web['ver_no']		= $customer->getValue('assessment_version');
unset($customer);

$web['wizards_pages'] = array();
$web['subsection']	= '1.2';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']		= $web['company'].' - Customer';
$web['table']			= $web['ver_no'].'audit_wizard';
$web['page']			= 'masters';
$web['subpage']			= 'customers';
$web['editscript']		= 'assessment-exec-summary.php';

$web['parent_id']		= $request->get('parent_id', '0');
$web['nextscript']		= 'assessment-pci-dss-version.php';
$web['current_section']	= 'section1';
$web['listscript']		= 'customer.php';
$web['task']			= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';

if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');


$session->set('cid', $web['id']);
$tbl = new table($web['table']);
$found = $tbl->find(array('company_id'),array($web['id']));
if ( $found )
	$web['audit_wizard_id']	= $tbl->getValue('id');	
else
	$web['audit_wizard_id']	= 0;		

if ( $web['task'] == 'save' )
{
	$aw_wizard_id = $request->get('audit_wizard_id');
	$web['err'] = '';
	$tbl2 = new table($web['table']);
        if($aw_wizard_id > 0){
                 $tbl2->load($aw_wizard_id);
                 $tbl2->setValue('date_spent_onsite', $request->get('date_spent_onsite', ''));
	        $tbl2->setValue('date_of_report', savedateformat($request->get('date_of_report', ''), 'm-d-Y'));
	         $tbl2->setValue('timeframe', $request->get('timeframe', ''));
	         $tbl2->setValue('desc_of_time_spent', $request->get('desc_of_time_spent', ''));
	         $tbl2->save();
       
        }

         if($aw_wizard_id == 0){
                 $tbl2->setValue('id',0);
	         $tbl2->setValue('company_id',$web['id']);
	         $tbl2->setValue('date_spent_onsite', $request->get('date_spent_onsite', ''));
	         $tbl2->setValue('date_of_report', savedateformat($request->get('date_of_report', ''), 'm-d-Y'));
	         $tbl2->setValue('timeframe', $request->get('timeframe', ''));
	         $tbl2->setValue('desc_of_time_spent', $request->get('desc_of_time_spent', ''));
	         $tbl2->save();
       
        }
    
	$session->set('audit_wizard_id',$tbl2->getValue('id'));
}

if ( $tbl->getValue('date_of_report') == '' )
	$tbl->setValue('date_of_report', date('m-d-Y'));
$web['fields'] = array();
$web['fields']['date_of_report']['value'] 		= $lib->format_date($tbl->getValue('date_of_report'), 'm-d-Y');
$web['fields']['timeframe']['value']	 		= $tbl->getValue('timeframe');
$web['fields']['date_spent_onsite']['value'] 	= $tbl->getValue('date_spent_onsite');
$web['fields']['desc_of_time_spent']['value'] 	= $tbl->getValue('desc_of_time_spent');

$cust_tbl = new table('customer');
$cust_tbl->load($web['id']);
$web['prescript'] = ($cust_tbl->getValue('parent_id') == 0) ? 'customer.php' : 'subsidiary.php' ;

echo $twig->render('assessment-timeframe.html', array('web' => $web));
