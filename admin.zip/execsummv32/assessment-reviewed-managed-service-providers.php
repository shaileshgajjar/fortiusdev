<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '4.11';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-reviewed-docs.php';
$web['nextscript']	= 'assessment-reviewed-disclosure-summary.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section4';
$web['id']			= $request->get('id', $session->get('cid'));
$web['section_id']		= $request->get('section_id',1);

$web['task']			= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
$web['audit_wizard_id']	= $session->get('audit_wizard_id');
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table('reviewed_managed_services');
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->delete('company_id', $web['id']);
	$tbl->setValue('id', 0);
	$tbl->setValue('company_id', $web['id']);
	$tbl->setValue('assess_yes_no', $request->get('assess_yes_no', ''));
	$tbl->setValue('detail_1', $request->get('detail_1', ''));
	$tbl->setValue('detail_2', $request->get('detail_2', ''));	
	$tbl->setValue('detail_3', $request->get('detail_3', ''));	
	$tbl->setValue('detail_4', $request->get('detail_4', ''));	
	$tbl->setValue('detail_5', $request->get('detail_5', ''));	
	$tbl->save();
}

$web['fields'] = array();
$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl->getList();
$web['fields'] = $rows;
if ( count($web['fields']) == 0 )
	$web['fields'][] = array('assess_yes_no' => 'no', 'detail_1' => '', 'detail_2' => '', 'detail_3' => '', 'detail_4' => '', 'detail_5' => '');

echo $twig->render($web['version'].'assessment-reviewed-managed-service-providers.html', array('web' => $web));
