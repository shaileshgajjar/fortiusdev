<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '1.5';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'summary_of_findings';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'additional-services-provided-by-qsa.php';
$web['nextscript']	= 'assessment-exec-summary.php';
$web['current_section']	= 'section1';
$web['id']				= $request->get('id', $session->get('cid'));
$web['audit_wizard_id'] = $session->get('audit_wizard_id');
$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);

if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	//first save data 
		$tbls = new table('v32_summary_of_findings'); 
		$tbls->delete('company_id', $web['id']);
	
			$tbls->setValue('company_id', $web['id']);
			$tbls->setValue('comp_ncomp_ntcomp_0', $request->get('comp_ncomp_ntcomp_0'));
			$tbls->setValue('comp_ncomp_ntcomp_1', $request->get('comp_ncomp_ntcomp_1'));
			$tbls->setValue('comp_ncomp_ntcomp_2', $request->get('comp_ncomp_ntcomp_2'));
			$tbls->setValue('comp_ncomp_ntcomp_3', $request->get('comp_ncomp_ntcomp_3'));
			$tbls->setValue('comp_ncomp_ntcomp_4', $request->get('comp_ncomp_ntcomp_4'));
			$tbls->setValue('comp_ncomp_ntcomp_5', $request->get('comp_ncomp_ntcomp_5'));
			$tbls->setValue('comp_ncomp_ntcomp_6', $request->get('comp_ncomp_ntcomp_6'));
			$tbls->setValue('comp_ncomp_ntcomp_7', $request->get('comp_ncomp_ntcomp_7'));
			$tbls->setValue('comp_ncomp_ntcomp_8', $request->get('comp_ncomp_ntcomp_8'));
			$tbls->setValue('comp_ncomp_ntcomp_9', $request->get('comp_ncomp_ntcomp_9'));
			$tbls->setValue('comp_ncomp_ntcomp_10', $request->get('comp_ncomp_ntcomp_10'));
			$tbls->setValue('comp_ncomp_ntcomp_11', $request->get('comp_ncomp_ntcomp_11'));
			$tbls->save();
		
			
	}
	
$web['fields'] = array();
$web['fields']['comp_ncomp_ntcomp_0']['value'] 		= $tbl->getValue('comp_ncomp_ntcomp_0');
$web['fields']['comp_ncomp_ntcomp_1']['value'] 	= $tbl->getValue('comp_ncomp_ntcomp_1');
$web['fields']['comp_ncomp_ntcomp_2']['value'] 	= $tbl->getValue('comp_ncomp_ntcomp_2');
$web['fields']['comp_ncomp_ntcomp_3']['value'] 	= $tbl->getValue('comp_ncomp_ntcomp_3');
$web['fields']['comp_ncomp_ntcomp_4']['value'] = $tbl->getValue('comp_ncomp_ntcomp_4');
$web['fields']['comp_ncomp_ntcomp_5']['value'] = $tbl->getValue('comp_ncomp_ntcomp_5');
$web['fields']['comp_ncomp_ntcomp_6']['value'] = $tbl->getValue('comp_ncomp_ntcomp_6');
$web['fields']['comp_ncomp_ntcomp_7']['value'] = $tbl->getValue('comp_ncomp_ntcomp_7');
$web['fields']['comp_ncomp_ntcomp_8']['value'] = $tbl->getValue('comp_ncomp_ntcomp_8');
$web['fields']['comp_ncomp_ntcomp_9']['value'] = $tbl->getValue('comp_ncomp_ntcomp_9');
$web['fields']['comp_ncomp_ntcomp_10']['value'] = $tbl->getValue('comp_ncomp_ntcomp_10');
$web['fields']['comp_ncomp_ntcomp_11']['value'] = $tbl->getValue('comp_ncomp_ntcomp_11');


$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl->getList();

$web['fields']['entity_type'] = array();
foreach($rows as $rw)
	$web['fields']['entity_type'][] = $rw;
	
unset($tbl);
if ( count($web['fields']['entity_type']) == 0 )
	$web['entity_type'] = array('comp_ncomp_ntcomp_0' => 'not_applicable', 'comp_ncomp_ntcomp_1' => 'not_applicable', 'comp_ncomp_ntcomp_2' => 'not_applicable', 'comp_ncomp_ntcomp_3' => 'not_applicable', 'comp_ncomp_ntcomp_4' => 'not_applicable', 'comp_ncomp_ntcomp_5' => 'not_applicable', 'comp_ncomp_ntcomp_6' => 'not_applicable', 'comp_ncomp_ntcomp_7' => 'not_applicable', 'comp_ncomp_ntcomp_8' => 'not_applicable', 'comp_ncomp_ntcomp_9' => 'not_applicable', 'comp_ncomp_ntcomp_10' => 'not_applicable', 'comp_ncomp_ntcomp_11' => 'not_applicable');

echo $twig->render('summary-of-findings.html', array('web' => $web));
