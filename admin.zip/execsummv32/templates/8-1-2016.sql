ALTER TABLE `reviewed_qrtly_results_init` ADD `assessor_comments` TEXT NOT NULL AFTER `how_verified`;

ALTER TABLE `network_segmetation` ADD `network_segmetation` TEXT NOT NULL AFTER `technologies`;
ALTER TABLE `network_segmetation` CHANGE `network_segmetation` `security_control` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL;