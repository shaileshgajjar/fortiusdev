<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '4.5';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
//$web['prescript']	= 'assessment-reviewed-env-software-data.php';
$web['prescript']	= 'assessment-reviewed-env-second-part.php';
$web['nextscript']	= 'assessment-reviewed-sample-data.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section4';
$web['id']			= $request->get('id', $session->get('cid'));
$web['section_id']		= $request->get('section_id',1);

$web['task']			= $request->get('task', '');
$web['err']			= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
$web['audit_wizard_id'] 	= $session->get('audit_wizard_id');
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table('reviewed_env_sampling'); 
if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->delete('company_id', $web['id']);
	
	$sampling_1 	= $request->get('sampling_1','');
	$sampling_2 	= $request->get('sampling_2','');
	$sampling_3 	= $request->get('sampling_3','');
	$sampling_4 	= $request->get('sampling_4','');
	$sampling_5 	= $request->get('sampling_5','');
	
	$tbl->setValue('id', 0);
	$tbl->setValue('company_id', $web['id']);
	$tbl->setValue('sampling_1', $sampling_1);
	$tbl->setValue('sampling_2', $sampling_2);
	$tbl->setValue('sampling_3', $sampling_3);
	$tbl->setValue('sampling_4', $sampling_4);
	$tbl->setValue('sampling_5', $sampling_5);
	$tbl->save();	
}

$tbl->cols('t1.*');
$tbl->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl->getList();
$web['env_sampling'] = array('sampling_1' => '', 'sampling_2' => '', 'sampling_3' => '', 'sampling_4' => '', 'sampling_5' => '');
foreach($rows as $rw)
	$web['env_sampling'] = $rw;	

echo $twig->render($web['version'].'assessment-reviewed-env-sampling-data.html', array('web' => $web));
