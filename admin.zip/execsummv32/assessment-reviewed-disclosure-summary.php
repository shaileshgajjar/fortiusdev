<?php
require(dirname(__FILE__).'/../config/config.new.php');
require(__DIR__.'/credential.php');

$web['wizards_pages'] = array();
$web['subsection']	= '4.12';
$pagestable = new table('wizards_pages');
$allpages = $pagestable->getList();
foreach($allpages as $page)
	$web['wizards_pages'][] = $page;
$web['pagetitle']	= $web['company'].' - Customer';
$web['table']		= $web['version'].'audit_wizard';
$web['page']		= 'masters';
$web['subpage']		= 'customers';
$web['editscript']	= 'assessment-contact-info.php';
$web['prescript']	= 'assessment-reviewed-managed-service-providers.php';
$web['nextscript']	= 'assessment-quarterly-result-initial.php';
$web['wizardspage']	= 'exec-summary';
$web['diagramid']	= 1;
$web['current_section']	= 'section4';
$web['id']				= $request->get('id', $session->get('cid'));
$web['section_id']		= $request->get('section_id',1);
$web['audit_wizard_id']	= $session->get('audit_wizard_id');
$web['task']			= $request->get('task', '');
$web['err']				= $request->get('err', '');
$web['title']			= 'Customer '.($web['id'] == '0' ? 'New' : 'Edit');
$web['title']			.= ' [ '. $session->get('company_name') .' ]';
if($web['id'] != 0)
	$web['editscript']	= 'assessment-exec-summary.php';
	
$web['pg']	= $request->get('pg', 1);
$web['en']	= $request->get('en', 10);
$web['sb']	= $request->get('sb', 'customer_owner');
$web['sk']	= $request->get('sk', '');
$web['ob']	= $request->get('ob', 'id');
$web['ot']	= $request->get('ot', 'asc');

$tbl = new table($web['table']);
$tbl->find('company_id', $web['id']);
$tbl2 = new table('reviewed_disclosure_summary');

if ( $web['task'] == 'save' )
{
	$web['err'] = '';
	$tbl->setValue('inplace_yes_no', $request->get('inplace_yes_no', ''));
	$tbl->setValue('nottested_yes_no', $request->get('nottested_yes_no', ''));	
	$tbl->save();
	
	$tbl2->delete('company_id', $web['id']);
	$vars = array('inplace', 'nottested');
	foreach($vars as $var)
	{
		$field1	= $request->get($var.'_tested_procedure', array());
		$field2 = $request->get($var.'_summary', array());
		for($i=0; $i<count($field1); $i++ )
		{
			$tested_procedure	= $field1[$i];
			$summary		 	= $field2[$i];
			$tbl2->setValue('id', 0);
			$tbl2->setValue('company_id', $web['id']);
			$tbl2->setValue('section', $var);
			$tbl2->setValue('tested_procedure', $tested_procedure);
			$tbl2->setValue('summary', $summary);
			$tbl2->save();
		}
	}
}

$web['fields'] = array();
$web['fields']['inplace_yes_no']['value'] 	= $tbl->getValue('inplace_yes_no');
$web['fields']['nottested_yes_no']['value'] = $tbl->getValue('nottested_yes_no');
if ( $web['fields']['inplace_yes_no']['value'] == '' ) $web['fields']['inplace_yes_no']['value'] = 'no';
if ( $web['fields']['nottested_yes_no']['value'] == '' ) $web['fields']['nottested_yes_no']['value'] = 'no';

$tbl2->cols('t1.*');
$tbl2->condition('WHERE', 't1.company_id', $web['id']);
$rows = $tbl2->getList();
foreach($rows as $rw )
	$web['fields'][$rw['section']][] = array('tested_procedure' => $rw['tested_procedure'], 'summary' => $rw['summary']);
if ( !isset($web['fields']['inplace']) )
	$web['fields']['inplace'][] = array('tested_procedure' => '', 'summary' => '');
if ( !isset($web['fields']['nottested']) )
	$web['fields']['nottested'][] = array('tested_procedure' => '', 'summary' => '');

echo $twig->render($web['version'].'assessment-reviewed-disclosure-summary.html', array('web' => $web));
